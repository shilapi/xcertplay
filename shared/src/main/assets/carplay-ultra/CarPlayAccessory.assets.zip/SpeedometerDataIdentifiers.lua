-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local SpeedometerDataIdentifiers = APL.LuaUtils.namedObject(
    "SpeedometerDataIdentifiers",
    { "vehicleSpeedDataIdentifier", "string" },
    { "vehicleSpeedUnitDataIdentifier", "string" },
    { "vehicleSpeedMaxDataIdentifier", "string" },
    { "showSecondarySpeedDataIdentifier", "string" },
    { "uiSceneStateDataIdentifier", "string" }
)







function SpeedometerDataIdentifiers.fromJson(json)


    return SpeedometerDataIdentifiers.new(
        json.dataIdentifier,
        json.unitDataIdentifier,
        json.vehicleSpeedMaxDataIdentifier,
        json.showSecondarySpeedDataIdentifier,
        json.uiSceneStateDataIdentifier
    )
end

return APL.LuaUtils.readOnly(SpeedometerDataIdentifiers)
