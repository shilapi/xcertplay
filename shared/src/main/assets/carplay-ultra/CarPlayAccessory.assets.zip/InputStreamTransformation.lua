-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local InputStreamTransformation = APL.LuaUtils.namedObject(
    "InputStreamTransformation",
    { "frame", "Rect" },
    { "mask", "ShapeLayer?" },
    { "transform", "Transform" }
)

return APL.LuaUtils.readOnly(InputStreamTransformation)