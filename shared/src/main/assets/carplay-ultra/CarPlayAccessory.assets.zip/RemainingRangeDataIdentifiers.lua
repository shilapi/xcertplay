-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local RemainingRangeDataIdentifiers = APL.LuaUtils.namedObject(
    "RemainingRangeDataIdentifiers",
    { "remainingRangeDataIdentifier", "string" },
    { "unitDataIdentifier", "string" }
)







function RemainingRangeDataIdentifiers.fromJson(json)


    return RemainingRangeDataIdentifiers.new(
        json.remainingRangeDataIdentifier,
        json.unitDataIdentifier
    )
end

return APL.LuaUtils.readOnly(RemainingRangeDataIdentifiers)
