-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local DynamicGradientColor = require "DynamicGradientColor"
local GradientColor = require "GradientColor"


local ColorType = APL.LuaUtils.namedObject(
    "ColorType",
    { "dynamic", "DynamicGradientColor?" },
    { "single", "GradientColor?" }
)







function ColorType.fromJson(json)


    local dynamic
    local single
    if json.dynamic then
        dynamic = DynamicGradientColor.fromJson(json.dynamic.value)
    elseif json.single then
        single = GradientColor.fromJson(json.single.value)
    else

    end

    return ColorType.new(dynamic, single)
end

return APL.LuaUtils.readOnly(ColorType)