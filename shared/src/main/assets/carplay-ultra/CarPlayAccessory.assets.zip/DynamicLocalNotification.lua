-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Button = require "Button"
local Shadow = require "Shadow"
local LocalNotificationState = require "LocalNotificationState"
local Texture = require "APL.Texture"
local VectorFontManager = require "APL.VectorFontManager"
local AttributedString = require "APL.AttributedString"
local StandardColorPalette = require "StandardColorPalette"
local DynamicLocalNotification = APL.LuaUtils.makeObject({ _type = "DynamicLocalNotification" })

local Layout = APL.LuaUtils.namedObject(
    "DynamicLocalNotification.Layout",
    { "width" , "number" }, -- The width offer to the layout pass.
    { "height" , "number" }, -- The height offer to the layout pass.
    { "bounds" , "Rect" }, -- The overal bounds required for the content.
    { "titleFrame" , "Rect?" },
    { "bodyFrame" , "Rect?" },
    { "closeButtonFrame" , "Rect?" },
    { "symbolFrame" , "Rect?" }
)











function DynamicLocalNotification.new(state, config, appearanceState, closeButton, shadow, symbolNameAndColor)






    local self = APL.LuaUtils.newObject(DynamicLocalNotification, {
        _rootLayer = APL.LuaUtils.NIL,
        _config = config,
        _state = state,
        _button = closeButton or APL.LuaUtils.NIL,
        _shadow = shadow or APL.LuaUtils.NIL,
        _titleLayer = APL.LuaUtils.NIL,
        _bodyLayer = APL.LuaUtils.NIL,
        _layout = APL.LuaUtils.NIL,
        _symbolLayer = APL.LuaUtils.NIL,
        _symbolImageLayer = APL.LuaUtils.NIL,
        _currentAppearanceState = appearanceState.appearance
    })

    self._rootLayer = APL.Layer.new()
        :setCornerRadius(config.cornerRadius)
        :setCornerCurve(APL.Layer.CORNER_CURVE.CONTINUOUS)

    local textContent = state.textContent
    if textContent then
        local symbolNameAndColor = textContent.symbolNameAndColor



        local symbol = self:getImage(symbolNameAndColor, appearanceState.appearance)
        if symbol then
            self._symbolLayer = APL.Layer.new():addToSuperLayer(self._rootLayer)

            self._symbolImageLayer = APL.ImageLayer.new():setTexture(symbol)
            self._symbolImageLayer:addToSuperLayer(self._symbolLayer)
        else
            local sfSymbol = self:getSFSymbol(symbolNameAndColor, config)
            if sfSymbol then
                self._symbolLayer = sfSymbol
                    :addToSuperLayer(self._rootLayer)
            end
        end
    end

    if shadow then
        shadow:getRootLayer():addToSuperLayer(self._rootLayer)
    end

    if #state.textContent.title > 0 then
        self._titleLayer = APL.TextLayer.new(config.titleFont)
            :setText(state.textContent.title)
            :addToSuperLayer(self._rootLayer)
    end

    if #state.textContent.body > 0 then
        self._bodyLayer = APL.TextLayer.new(config.bodyFont)
            :setText(state.textContent.body)
            :addToSuperLayer(self._rootLayer)
    end

    if closeButton then
        closeButton:getRootLayer():addToSuperLayer(self._rootLayer)
        closeButton:setEnabled(true)
    end

    self:setAppearanceState(appearanceState)

    return self
end








function DynamicLocalNotification:getImage(symbolNameAndColor, appearanceMode)




    APL.Log.info(DynamicLocalNotification, function() return "getImage with symbolNameAndColor: " .. APL.LuaUtils.prettyPrint(symbolNameAndColor) .. "appearance mode: " .. appearanceMode end)

    local function symbolNameAndColorName()
        local symbolName = symbolNameAndColor.name
        local imageArchiveURLPrefix = "imageArchive://?identifier="

        local hasPrefix = APL.LuaUtils.hasPrefix(symbolName, imageArchiveURLPrefix)
        if hasPrefix then
            return symbolName:sub(#imageArchiveURLPrefix + 1)
        else
            return nil
        end
    end

    local symbolName = symbolNameAndColorName()

    if symbolName then

        APL.Log.info(DynamicLocalNotification, function() return "Getting local image with name: " .. APL.LuaUtils.prettyPrint(symbolName) .. " appearance mode: " .. appearanceMode end)


        return Texture.newWithImageName(symbolName, appearanceMode)
    end

    return nil
end








function DynamicLocalNotification:getSFSymbol(symbolNameAndColor, config)






    if symbolNameAndColor.name == "" then
        return nil
    end

    local symbolName = string.lower(symbolNameAndColor.name)

    APL.Log.info(DynamicLocalNotification, function() return "Looking up SF symbol with name: " .. APL.LuaUtils.prettyPrint(symbolName) end)

    local codepoint = VectorFontManager.getSymbolForName(VectorFontManager.getDefaultManager(), symbolName)
    local font = config.symbolFont
    if codepoint and font then
        local unicodeString = utf8.char(tonumber(codepoint, 16))
        local textLayer = APL.TextLayer.new(font)
            :setAlignment(APL.AttributedString.ALIGNMENT.CENTER)
            :setText(unicodeString)

        return textLayer
    end

    APL.Log.error(DynamicLocalNotification, function() return "No SF Symbol found" end)

    return nil
end






function DynamicLocalNotification:getState()


    return self._state
end







function DynamicLocalNotification:setEnabled(enabled)



    if self._button then
        self._button:setEnabled(enabled)
    end

    return self
end







function DynamicLocalNotification:setFrame(frame)



    self._rootLayer:setFrame(frame)


    if self._layout and self._layout.width == frame._width and self._layout.height == height then
        return
    end

    self._layout = self:_calculateLayout(frame._width, frame._height)

    if self._titleLayer then
        self._titleLayer:setFrame(self._layout.titleFrame)
    end

    if self._bodyLayer then
        self._bodyLayer:setFrame(self._layout.bodyFrame)
    end

    if self._button then
        self._button:setFrame(self._layout.closeButtonFrame)
    end

    if self._shadow then
        self._shadow:setContentFrame(self._layout.bounds)
    end

    if self._symbolLayer then
        if self._symbolImageLayer then


            local symbolWidth, symbolHeight = self._symbolImageLayer:getTexture():getSize()
            local symbolImageFrame = APL.Rect.new(0, 0, symbolWidth, symbolHeight)
            symbolImageFrame = symbolImageFrame:centeredInRect(APL.Rect.new(0, 0, self._layout.symbolFrame._width, self._layout.symbolFrame._height))
            self._symbolImageLayer:setFrame(symbolImageFrame)
        end
        self._symbolLayer:setFrame(self._layout.symbolFrame)
    end

    return self
end







function DynamicLocalNotification:setAppearanceState(state)



    self._rootLayer:setBackgroundColor(state:getSolidColor(self._config.backgroundColorID))

    if self._titleLayer then
        self._titleLayer:setForegroundColor(state:getSolidColor(self._config.titleColorID))
    end

    if self._bodyLayer then
        self._bodyLayer:setForegroundColor(state:getSolidColor(self._config.bodyColorID))
    end

    if self._button then
        self._button:setAppearanceState(state)
    end

    if self:hasSFSymbol() then
        local symbolColor = StandardColorPalette:getColor(self._state.textContent.symbolNameAndColor.color, state.appearance)
        self._symbolLayer:setForegroundColor(symbolColor)
    elseif self:hasCustomImage() and state.appearance ~= self._currentAppearanceState then


        local symbol = self:getImage(self._state.textContent.symbolNameAndColor, state.appearance)
        if symbol then


            self._symbolImageLayer:setTexture(symbol)
        end
    end



    self._currentAppearanceState = state.appearance

    return self
end






function DynamicLocalNotification:hasSFSymbol()



    return self._symbolLayer ~= nil and self._symbolImageLayer == nil
end






function DynamicLocalNotification:hasCustomImage()



    return self._symbolLayer ~= nil and self._symbolImageLayer ~= nil
end







function DynamicLocalNotification:_calculateLayout(width, height)


    local symbolFrame
    local titleFrame
    local bodyFrame
    local closeButtonFrame

    local maxY = 0
    local xPadding = 44
    local yPadding = 40

    local leadingSidePadding = xPadding
    local trailingSidePadding = xPadding

    if self._symbolLayer then
        if not self._symbolImageLayer then
            local symbolWidth, symbolHeight = self._symbolLayer:getBoundingRect()._width, self._symbolLayer:getBoundingRect()._height
            symbolFrame = APL.Rect.new(16, 0, math.max(symbolWidth, 78), math.max(symbolHeight, 68))
        end

        symbolFrame = symbolFrame or APL.Rect.new(16, 0, 78, 68)

        APL.Log.info(DynamicLocalNotification, function() return "Using symbol frame: " .. APL.LuaUtils.prettyPrint(symbolFrame) end)
        leadingSidePadding = symbolFrame._x + symbolFrame._width + 16
    end

    if self._button then
        local buttonWidth, buttonHeight = self._button:preferredContentSize()
        closeButtonFrame = APL.Rect.new(width - buttonWidth - 20, 20, buttonWidth, buttonHeight)


        trailingSidePadding = 16 + buttonWidth + 20
        maxY = closeButtonFrame:getMaxY()
    end

    local textBounds = APL.Rect.new(leadingSidePadding, yPadding, width - leadingSidePadding - trailingSidePadding, height - (2 * yPadding))

    if self._titleLayer then
        local title = self._titleLayer:getAttributedString()
        titleFrame = APL.Rect.new(textBounds._x, textBounds._y, title:getBoundingRect(textBounds:getSize()):getSize())

        textBounds._y = titleFrame:getMaxY() + 8
        textBounds._height = textBounds._height - titleFrame._height - 8
        maxY = math.max(maxY, titleFrame:getMaxY())
    end

    if self._bodyLayer then
        local body = self._bodyLayer:getAttributedString()
        bodyFrame = APL.Rect.new(textBounds._x, textBounds._y, body:getBoundingRect(textBounds:getSize()):getSize())

        maxY = math.max(maxY, bodyFrame:getMaxY())
    end

    local bounds = APL.Rect.new(0, 0, width, maxY + yPadding)

    symbolFrame = symbolFrame and symbolFrame:centeredYInRect(bounds)
    return Layout.new(width, height, bounds, titleFrame, bodyFrame, closeButtonFrame, symbolFrame)
end








function DynamicLocalNotification:preferredContentSize(width, height)




    if self._layout and self._layout.width == width and self._layout.height == height then
        return self._layout.bounds
    end

    return self:_calculateLayout(width, height).bounds:getSize()
end






function DynamicLocalNotification:getRootLayer()


    return self._rootLayer
end






function DynamicLocalNotification:destroy()


    self._state:destroy()
    self._state = nil

    self._rootLayer:destroy()
    self._rootLayer = nil

    if self._titleLayer then
        self._titleLayer:destroy()
        self._titleLayer = nil
    end

    if self._bodyLayer then
        self._bodyLayer:destroy()
        self._bodyLayer = nil
    end

    if self._symbolImageLayer then
        self._symbolImageLayer:destroy()
        self._symbolImageLayer = nil
    end

    if self._symbolLayer then
        self._symbolLayer:destroy()
        self._symbolLayer = nil
    end

    if self._shadow then
        self._shadow:destroy()
        self._shadow = nil
    end

    if self._button then
        self._button:destroy()
        self._button = nil
    end
end

return APL.LuaUtils.readOnly(DynamicLocalNotification)
