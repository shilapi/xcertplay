-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Enums = require "Enums"

local DynamicAppearanceImage = APL.LuaUtils.namedObject(
    "DynamicAppearanceImage",
    { "lightMode", "table" },
    { "darkMode", "table" }
)







function DynamicAppearanceImage.fromJson(json)


    return DynamicAppearanceImage.new(
        json.lightMode,
        json.darkMode
    )
end








function DynamicAppearanceImage.getTextureForAppearanceMode(image, mode)



    local image = (mode == Enums.AppearanceMode.LIGHT) and image.lightMode or image.darkMode

    return APL.Asset.loadNamedTexture(image)
end

return APL.LuaUtils.readOnly(DynamicAppearanceImage)