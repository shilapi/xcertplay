-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local DigiBarColorsConfiguration = require "DigiBarColorsConfiguration"
local DigiBarLinearStyle = require "DigiBarLinearStyle"
local DigiBarRadialStyle = require "DigiBarRadialStyle"
local DigiBarRedlineConfiguration = require "DigiBarRedlineConfiguration"
local TicksConfiguration = require "TicksConfiguration"
local DigiBarRectangularStyle = require "DigiBarRectangularStyle"

local DigiBarConfiguration = APL.LuaUtils.namedObject(
    "DigiBarConfiguration",
    { "colorsConfiguration", "DigiBarColorsConfiguration" },
    { "style", "*" }, -- Either DigiBarRadialStyle, DigiBarLinearStyle, or DigiBarRectangularStyle
    { "trackLimitGap", "number" },
    { "redlineConfiguration", "DigiBarRedlineConfiguration?" },



    { "minDotThreshold", "number" }
)
DigiBarConfiguration.fromJson = function(json)


    local trackConfiguration
    if json.style.radial then
        trackConfiguration = DigiBarRadialStyle.fromJson(json.style.radial.configuration)
    elseif json.style.linear then
        trackConfiguration = DigiBarLinearStyle.fromJson(json.style.linear.configuration)
    elseif json.style.rectangular then
        trackConfiguration = DigiBarRectangularStyle.fromJson(json.style.rectangular.configuration)
    else

    end

    return DigiBarConfiguration.new(
        DigiBarColorsConfiguration.fromJson(json.colorsConfiguration),
        trackConfiguration,
        json.trackLimitGap,
        json.redlineConfiguration and DigiBarRedlineConfiguration.fromJson(json.redlineConfiguration),
        json.minDotThreshold
    )
end

return APL.LuaUtils.readOnly(DigiBarConfiguration)