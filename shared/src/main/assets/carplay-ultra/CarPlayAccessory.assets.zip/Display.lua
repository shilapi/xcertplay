-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Enums = require "Enums"
local LayoutInfo = require "LayoutInfo"

local Display = APL.LuaUtils.makeObject({ _type = "Display" })

Display.ID = APL.LuaUtils.readOnly({
    CLUSTER   = Enums.DisplayPanelIdentifier.CLUSTER_DISPLAY,
    CENTER    = Enums.DisplayPanelIdentifier.CENTER_DISPLAY,
    PASSENGER = "Passenger_Display"
})













function Display.new(id, width, height, layouts, notifications, shadows, fontManager)








    local self = APL.LuaUtils.newObject(Display, {
        _id = id,
        _width = width,
        _height = height,
        _layouts = layouts or {},
        _layoutsByID = {},
        _layoutsByKind = {},
        _notifications = notifications,
        _shadows = shadows,
        _fontManager = fontManager or APL.LuaUtils.NIL
    })

    APL.LuaUtils.forEach(layouts, function(layout)
        local kind = layout:getKind()
        local id = layout:getID()
        local name = layout:getDisplayName()

        APL.Log.info(Display, function() return "Found %s layout \"%s\" (%s)", kind, name, id end)

        self._layoutsByID[id] = layout

        local layouts = self._layoutsByKind[kind] or {}
        layouts[#layouts+1] = layout
        self._layoutsByKind[kind] = layouts
    end)

    return self
end






function Display:destroy()


    self._layouts = nil
    self._layoutsByID = nil
    self._layoutsByKind = nil
end






function Display:getBounds()
    return 0, 0, self._width, self._height
end






function Display:getID()
    return self._id
end






function Display:getNotifications()
    return self._notifications
end






function Display:getShadows()
    return self._shadows
end






function Display:getFontManager()
    return self._fontManager
end







function Display:getLayout(layoutID)



    return self._layoutsByID[layoutID] or APL.LuaUtils.first(self._layouts, function(layout)
        return layout:getDisplayName() == layoutID
    end)
end







function Display:getLayouts(kind)



    return kind == nil and self._layouts or (self._layoutsByKind[kind] or {})
end

return APL.LuaUtils.readOnly(Display)
