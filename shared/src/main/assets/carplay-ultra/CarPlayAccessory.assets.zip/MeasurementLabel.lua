-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Constants = require "Constants"
local MeasurementLabelConfiguration = require "MeasurementLabelConfiguration"
local VehicleDataUpdater = require "VehicleDataUpdater"

local MeasurementLabel = APL.LuaUtils.makeObject({ _type = "MeasurementLabel" })


local ALLOWED_TYPES = {
    MeasurementLabel = true
}
local function validateClassName(self)
    return ALLOWED_TYPES[APL.LuaUtils.getClassName(self)]
end













function MeasurementLabel.new(configuration, appearanceState, name, initialState, normalState, imagesByState)






    name = name or ""
    initialState = initialState or MeasurementLabelConfiguration.DEFAULT_STATE
    normalState = normalState or MeasurementLabelConfiguration.DEFAULT_STATE
    imagesByState = imagesByState or {}

    local self = APL.LuaUtils.newObject(MeasurementLabel, {
        _configuration = configuration,
        _alignment = configuration.alignment,
        _rootLayer = APL.LuaUtils.NIL,
        _iconLayer = APL.LuaUtils.NIL,
        _image = APL.LuaUtils.NIL,
        _valueLayer = APL.LuaUtils.NIL,
        _unitLayer = APL.LuaUtils.NIL,
        _unit = APL.LuaUtils.NIL,
        _redacted = false,
        _appearanceState = appearanceState,
        _value = APL.LuaUtils.NIL,
        _state = initialState,
        _normalState = normalState,
        _imagesByState = imagesByState,
        _needsLayout = false, -- for layout updates not tracked by textlayoutManager such as root layer frame changing
        _valueUpdater = APL.LuaUtils.NIL -- a function that properly updates the value layer
    })

    local valueLayerBuilder
    if configuration.trailingString then
        valueLayerBuilder = MeasurementLabel.createTextLayer
        self._valueUpdater = function(value, skipUpdateLayout)
            local text = tostring(value) .. configuration.trailingString
            self._valueLayer:setText(text, skipUpdateLayout)
        end
    else
        valueLayerBuilder = MeasurementLabel.createNumberLayer
        self._valueUpdater = function(value, skipUpdateLayout)
            self._valueLayer:setNumber(value, skipUpdateLayout)
        end
    end



    local valueLabelStartingWidth = APL.AttributedString.new("8888" .. (configuration.trailingString or ""), configuration.font)
        :getBoundingRect()
        :getSize()

    self._valueLayer = valueLayerBuilder(configuration, name)
        :setFrame(APL.Rect.new(0, 0, valueLabelStartingWidth, configuration.font:getHeight()), true)
        :setAlignment(MeasurementLabelConfiguration.ALIGNMENT.LEFT, true)

    if configuration.valueTracking then
        self._valueLayer:getAttributedString():setTracking(configuration.valueTracking)
    end

    local unitFont = configuration.unitFont or configuration.font
    self._unitLayer = APL.TextLayer.new(unitFont, name .. ":Unit")
        :setAlignment(MeasurementLabelConfiguration.ALIGNMENT.LEFT, true)
    self:setUnitLabel(self:_getUnitLabel() or "", true)

    self._iconLayer = APL.ImageLayer.new()
        :setVisible(false)

    self._rootLayer = APL.Layer.new()
        :setName("MeasurementLabel:" .. name)
        :addSublayer(self._valueLayer)
        :addSublayer(self._unitLayer)
        :addSublayer(self._iconLayer)

    self:_updateWithState(self._appearanceState, self._state, self._redacted)

    return self
end








function MeasurementLabel.createNumberLayer(configuration, name)
    local ValueLayerType = configuration.font:isStable() and APL.StableNumberLayer or APL.NumberLayer

    return ValueLayerType.new(configuration.font, name .. ":Value")
        :setMaximumFractionDigits(configuration.precision, true)
        :setMinFractionDigits(configuration.minFractionDigits, true)
        :setMinIntegerDigits(configuration.minIntegerDigits, true)
end








function MeasurementLabel.createTextLayer(configuration, name)
    return APL.TextLayer.new(configuration.font, name .. ":Value")
end






function MeasurementLabel:destroy()


    self._rootLayer:destroy()
end







function MeasurementLabel.isSubclass(instance)
    return validateClassName(instance)
end






function MeasurementLabel:getRootLayer()


    return self._rootLayer
end








function MeasurementLabel:setFrame(frame, skipUpdateLayout)




    self._rootLayer:setFrame(frame)

    self:setNeedsLayout()

    if not skipUpdateLayout then
        self:updateLayoutIfNeeded()
    end

    return self
end








function MeasurementLabel:sizeThatFits(width, height)


    local alignment = self._alignment

    self._alignment = MeasurementLabelConfiguration.ALIGNMENT.LEFT
    local maxXOffset = self:_layoutSubviews(APL.Rect.new(0, 0, width, height))
    self._alignment = alignment

    return maxXOffset, self._configuration.font:getHeight()
end








function MeasurementLabel:setValue(value, skipUpdateLayout)




    self:_setValueState(self._appearanceState, value, self._state)

    if not skipUpdateLayout then
        self:updateLayoutIfNeeded()
    end

    return self
end








function MeasurementLabel:setAppearanceState(appearanceState, skipUpdateLayout)




    self:_setValueState(appearanceState, self._value, self._state)

    if not skipUpdateLayout then
        self:updateLayoutIfNeeded()
    end

    return self
end









function MeasurementLabel:setState(state, skipUpdateLayout)




    self:_setValueState(self._appearanceState, self._value, state)

    if not skipUpdateLayout then
        self:updateLayoutIfNeeded()
    end

    return self
end









function MeasurementLabel:_setValueState(appearanceState, value, state)





    if self._value ~= value then
        if value and value ~= VehicleDataUpdater.INVALID then
            self:_updateWithValue(value)
        end
        self._value = value
    end

    local redacted = self._value == VehicleDataUpdater.INVALID
    if self._redacted ~= redacted or self._state ~= state or self._appearanceState ~= appearanceState then
        self._redacted = redacted
        self._valueLayer:setRedacted(redacted, true)

        self._state = state
        self._appearanceState = appearanceState
        self:_updateWithState(appearanceState, state, redacted)
    end

    return self
end







function MeasurementLabel:_updateWithValue(value)





    local numberValue = value / self._configuration.divider
    self._valueUpdater(numberValue, true)

    return self
end








function MeasurementLabel:setUnit(unit, skipUpdateLayout)




    if self._unit == unit then
        return self
    end

    self._unit = unit
    self:setUnitLabel(self:_getUnitLabel() or "", skipUpdateLayout)

    return self
end








function MeasurementLabel:setUnitLabel(label, skipUpdateLayout)




    self:_setUnitLabel(label)

    if not skipUpdateLayout then
        self:updateLayoutIfNeeded()
    end

    return self
end







function MeasurementLabel:_setUnitLabel(label)



    self._unitLayer
        :setText(label, true)
        :setVisible(#label > 0)

    return self
end






function MeasurementLabel:getImageLayer()


    return self._iconLayer
end








function MeasurementLabel:setImage(image, skipUpdateLayout)




    if self._image == image then
        return self
    end

    self:_setImage(image)

    if not skipUpdateLayout then
        self:updateLayoutIfNeeded()
    end

    return self
end







function MeasurementLabel:_setImage(image)




    local oldImageID = self._image and APL.Asset.getImageAssetIdentifier(self._image)
    local newImageID = image and APL.Asset.getImageAssetIdentifier(image)
    local updated = oldImageID ~= newImageID
    if updated then
        self._image = image

        if newImageID then
            local texture = APL.Asset.loadNamedTexture(image)

            local width, height = texture:getSize()
            self._iconLayer
                :setTexture(texture)
                :setFrame(APL.Rect.new(0, 0, width, height))
                :setVisible(true)
        else
            self._iconLayer
                :setTexture(nil)
                :setVisible(false)
        end

        self:setNeedsLayout()
    end

    return updated
end








function MeasurementLabel:setAlignment(alignment, skipUpdateLayout)




    if self._alignment == alignment then
        return self
    end

    self._alignment = alignment

    self:setNeedsLayout()

    if not skipUpdateLayout then
        self:updateLayoutIfNeeded()
    end

    return self
end









function MeasurementLabel:_updateWithState(appearanceState, state, redacted)





    local image = self:_getImageForState(state)
    self:setImage(image, true)

    local iconColorID = self._configuration:iconColorForState((not redacted or state ~= self._normalState) and state or nil)
    self._iconLayer:setTint(appearanceState:getSolidColor(iconColorID))

    local valueColorID = self._configuration:valueColorForState(not redacted and state or nil)
    self._valueLayer:setForegroundColor(appearanceState:getSolidColor(valueColorID), true)

    local unitColorID = self._configuration:unitColorForState(not redacted and state or nil)
    self._unitLayer:setForegroundColor(appearanceState:getSolidColor(unitColorID), true)

    return self
end








function MeasurementLabel:setRedacted(redacted, skipUpdateLayout)




    if self._redacted == redacted then
        return self
    end

    self._redacted = redacted
    self._valueLayer:setRedacted(redacted, true)

    self:_updateWithState(self._appearanceState, self._state, redacted)

    if not skipUpdateLayout then
        self:updateLayoutIfNeeded()
    end

    return self
end






function MeasurementLabel:isRedacted()


    return self._redacted
end






function MeasurementLabel:getFont()


    return self._configuration.font
end






function MeasurementLabel:getValueLayer()


    return self._valueLayer
end






function MeasurementLabel:getUnitLayer()


    return self._unitLayer
end






function MeasurementLabel:getConfiguration()


    return self._configuration
end






function MeasurementLabel:needsLayout()


    return self._valueLayer:needsLayout() or self._unitLayer:needsLayout() or self._needsLayout
end






function MeasurementLabel:setNeedsLayout()


    self._needsLayout = true

    return self
end






function MeasurementLabel:updateLayoutIfNeeded()


    if self:needsLayout() then
        self:updateLayout()
    end

    return self
end






function MeasurementLabel:updateLayout()


    local _, _, width, height = self._rootLayer:getFrame()
    local bounds = APL.Rect.new(0, 0, width, height)
    self:_layoutSubviews(bounds)

    return self
end







function MeasurementLabel:_layoutSubviews(bounds)



    self._unitLayer:updateLayoutIfNeeded()
    self._valueLayer:updateLayoutIfNeeded()

    local imageLayerWidth = 0
    local imageLayerHeight = 0
    local imageSpacing = self._configuration.imagePadding or 0
    local texture = self._iconLayer:getTexture()
    if texture then
        imageLayerWidth, imageLayerHeight = texture:getSize()
    end

    local unitLayerBoundingRect = self._unitLayer:getBoundingRect()
    local valueLayerBoundingRect = self._valueLayer:getBoundingRect()
    local spacing = self._configuration.labelSpacing
    local unitLayerWidth = unitLayerBoundingRect._width
    local valueLabelWidth = valueLayerBoundingRect._width


    local x, y, width, height = self._valueLayer:getFrame()
    if width < valueLabelWidth then
        self._valueLayer:setFrame(APL.Rect.new(x, y, valueLabelWidth, height))
    end





    valueLabelWidth = (unitLayerWidth > 0 and valueLabelWidth > 0) and valueLabelWidth + spacing or valueLabelWidth

    local textWidth = valueLabelWidth + unitLayerWidth
    local imageWidth = imageLayerWidth > 0 and imageLayerWidth + (textWidth > 0 and (imageSpacing + spacing) or 0) or 0
    local totalWidth = imageWidth + textWidth

    local xOffset = 0
    if self._alignment == MeasurementLabelConfiguration.ALIGNMENT.CENTER then
        xOffset = math.max(0, bounds._width - totalWidth) / 2
    elseif self._alignment == MeasurementLabelConfiguration.ALIGNMENT.RIGHT then
        xOffset = math.max(0, bounds._width - totalWidth)
    elseif self._alignment == MeasurementLabelConfiguration.ALIGNMENT.CENTER_VALUE then
        xOffset = math.max(0, bounds._width / 2 - imageWidth - valueLabelWidth / 2)
    end

    if texture then
        local yOffset = (bounds._height - imageLayerHeight) / 2
        self._iconLayer:setFrame(APL.Rect.new(xOffset, yOffset, imageLayerWidth, imageLayerHeight))
        xOffset = xOffset + imageWidth
    end

    local valueYOffset = self._configuration.valueYOffset
    local valueLayerYOffset = 0
    local unitLayerY = 0
    local unitLayerHeight = 0
    if self._configuration.offsetType == MeasurementLabelConfiguration.OFFSET_TYPE.CENTER then
        local textYOffset = (bounds._height - self._configuration.font:getHeight()) / 2
        unitLayerHeight = self._configuration.font:getHeight()
        valueLayerYOffset = textYOffset + valueYOffset
        unitLayerY = textYOffset
    elseif self._configuration.offsetType == MeasurementLabelConfiguration.OFFSET_TYPE.BASELINE then
        local frame = APL.Rect.new(self._rootLayer:getBounds())
        unitLayerHeight = unitLayerBoundingRect._height
        if valueLayerBoundingRect._height > frame._height then

            valueLayerYOffset = -valueYOffset
            unitLayerY = y + frame._height - unitLayerHeight - valueYOffset
        else
            local currentBaseline = frame._height - self._valueLayer:getFont():getBaselineOffset()
            local diff = valueYOffset - currentBaseline
            valueLayerYOffset = -diff

            local unitLayerSpacing = frame._height - unitLayerBoundingRect._height
            unitLayerY = unitLayerSpacing - valueYOffset
        end
    end



    self._valueLayer:setTransform(APL.Transform.newWithTranslation(xOffset, valueLayerYOffset))
    xOffset = xOffset + valueLabelWidth


    local _, _, width, _ = self._valueLayer:getFrame()
    width = math.max(width, unitLayerWidth)
    self._unitLayer:setFrame(APL.Rect.new(xOffset, unitLayerY, width, unitLayerHeight))
    self._needsLayout = false

    return totalWidth
end






function MeasurementLabel:_getUnitLabel()


    local label
    if self._unit and self._configuration.unitLabels then
        label = self._configuration.unitLabels[self._unit]
    end

    return label or self._configuration.defaultUnitLabel
end







function MeasurementLabel:_getImageForState(state)



    if state == nil then
        return self._imagesByState[MeasurementLabelConfiguration.DEFAULT_STATE]
    end

    return self._imagesByState[state] or self._imagesByState[MeasurementLabelConfiguration.DEFAULT_STATE]
end

return APL.LuaUtils.readOnly(MeasurementLabel)
