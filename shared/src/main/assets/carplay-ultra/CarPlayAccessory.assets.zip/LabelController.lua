-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"
local VehicleDataUpdater = require "VehicleDataUpdater"
local VehicleDataSubscriber = require "VehicleDataSubscriber"

local LabelController = APL.LuaUtils.makeObject({ _type = "LabelController" })










function LabelController.new(valueForUpdate, valueDataIdentifier, unitDataIdentifier, stateDataIdentifier)





    local self = APL.LuaUtils.newObject(LabelController, {
        _valueDataIdentifier = valueDataIdentifier,
        _unitDataIdentifier = unitDataIdentifier or APL.LuaUtils.NIL,
        _stateDataIdentifier = stateDataIdentifier or APL.LuaUtils.NIL,
        _valueForUpdate = valueForUpdate,
        _rawUpdateHandler = APL.LuaUtils.NIL,
        _unitUpdateHandler = APL.LuaUtils.NIL,
        _vehicleDataSubscriber = VehicleDataSubscriber.new(),
        _updateHandlers = {},
        _value = APL.LuaUtils.NIL,
        _unit = APL.LuaUtils.NIL
    })

    return self
end






function LabelController:destroy()


    self._vehicleDataSubscriber:destroy()
end






function LabelController:description()


    return "LabelController - valueDataidentifier: (" .. self._valueDataIdentifier .. ", unitDataIdentifier: " .. (self._unitDataIdentifier and self._unitDataIdentifier or "No unit data identifier") ..")"
end







function LabelController:setUpdateHandler(f)



    self._updateHandlers[f] = true

    if self._vehicleDataSubscriber:hasSubscription() then
        self:_notifyHandlers({ [f] = true })
    end

    return self
end







function LabelController:setVehicleDataUpdater(vehicleDataUpdater)



    if vehicleDataUpdater == nil then
        self._vehicleDataSubscriber:removeSubscription()
        return true
    end

    local identifiers = { self._valueDataIdentifier, self._unitDataIdentifier, self._stateDataIdentifier }

    local validIdentifiers, subscriber = vehicleDataUpdater:subscribe(identifiers, function(update, previous)
        local value, unit = self._valueForUpdate(update, previous, self._valueDataIdentifier, self._unitDataIdentifier, self._stateDataIdentifier)

        if self._value == value and self._unit == unit then
            return
        end

        self._value = value
        self._unit = unit
        self:_notifyHandlers()
    end)

    self._vehicleDataSubscriber:updateSubscription(vehicleDataUpdater, subscriber)

    local valid = #validIdentifiers == #identifiers
    return valid
end






function LabelController:_notifyHandlers(handlers)



    local handlers = handlers or self._updateHandlers

    for handler, _ in pairs(handlers) do
        handler(self._value, self._unit)
    end

    return self
end

return APL.LuaUtils.readOnly(LabelController)
