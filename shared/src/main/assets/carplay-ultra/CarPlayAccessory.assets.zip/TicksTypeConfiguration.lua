






local APL = require "APL.APL"

local TicksTypeConfiguration = APL.LuaUtils.namedObject(
    "TicksTypeConfiguration",
    { "ticksCount", "number" },
    { "tickWidth", "number" },
    { "tickWidthInset", "number" },
    { "tickLength", "number" },
    { "tickInset", "number" },
    { "lineCap", "number" },
    { "primaryColorID", "table" },
    { "secondaryColorID", "table" },
    { "tertiaryColorID", "table?" },
    { "redlineCrossedColorID", "table?" },
    { "hideFirstTick", "boolean" },
    { "redlineColorStatic", "boolean" } --- If set, the redline will be fully visible, even if progress exceeds it.
)

function TicksTypeConfiguration.fromJson(json)









    local function createColor(colorComponents)
        return APL.LuaUtils.createColor(table.unpack(colorComponents))
    end

    return TicksTypeConfiguration.new(
        json.ticksCount,
        json.tickWidth,
        json.tickWidthInset,
        json.tickLength,
        json.tickInset,
        json.lineCap,
        APL.LuaUtils.numberedKeys(json.primaryColorID),
        APL.LuaUtils.numberedKeys(json.secondaryColorID),
        APL.LuaUtils.numberedKeys(json.tertiaryColorID),
        APL.LuaUtils.numberedKeys(json.redlineCrossedColorID),
        json.hideFirstTick,
        json.redlineColorStatic
    )
end

return APL.LuaUtils.readOnly(TicksTypeConfiguration)