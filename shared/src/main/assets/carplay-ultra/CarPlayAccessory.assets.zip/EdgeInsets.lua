-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"

local EdgeInsets = { _type = "EdgeInsets" }

local EdgeInsets = APL.LuaUtils.namedObject(
    "EdgeInsets",
    { "top", "number" },
    { "leading", "number" },
    { "trailing", "number" },
    { "bottom", "number" }
)







function EdgeInsets.fromJson(jsonRepresentation)



    return EdgeInsets.new(
        jsonRepresentation[1],
        jsonRepresentation[2],
        jsonRepresentation[3],
        jsonRepresentation[4]
    )
end


return APL.LuaUtils.readOnly(EdgeInsets)