-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"
local VehicleDataUpdater = require "VehicleDataUpdater"
local VehicleDataSubscriber = require "VehicleDataSubscriber"

local StateController = APL.LuaUtils.makeObject({ _type = "StateController" })








function StateController.new(dataIdentifier, initialState)


    local self = APL.LuaUtils.newObject(StateController, {
        _dataIdentifier = dataIdentifier,
        _updateHandlers = {},
        _initialState = if initialState ~= nil then initialState else APL.LuaUtils.NIL,
        _lastState = APL.LuaUtils.NIL,
        _vehicleDataSubscriber = VehicleDataSubscriber.new(),
    })

    return self
end






function StateController:destroy()


    self._vehicleDataSubscriber:destroy()
end






function StateController:description()


    return "StateController (" .. self._dataIdentifier .. ")"
end







function StateController:setUpdateHandler(f)



    self._updateHandlers[f] = true

    if self._vehicleDataSubscriber:hasSubscription() then
        self:_notifyHandlers({ [f] = true })
    end

    return self
end






function StateController:getState()





    local result = if self._lastState ~= nil then self._lastState else self._initialState
    return result
end







function StateController:setVehicleDataUpdater(vehicleDataUpdater)



    if vehicleDataUpdater == nil then
        self._vehicleDataSubscriber:removeSubscription()
        return true
    end

    local identifiers = { self._dataIdentifier }

    local validIdentifiers, subscriber = vehicleDataUpdater:subscribe(identifiers, function(update)
        local state = update[self._dataIdentifier]

        state = state == VehicleDataUpdater.INVALID and nil or state
        if self._lastState == state then
            return
        end

        self._lastState = state
        self._initialState = nil -- reset initial state now that we got a first value
        self:_notifyHandlers()
    end)

    self._vehicleDataSubscriber:updateSubscription(vehicleDataUpdater, subscriber)

    local valid = #validIdentifiers == #identifiers
    return valid
end






function StateController:_notifyHandlers(handlers)



    if self._lastState == nil then
        return
    end

    local handlers = handlers or self._updateHandlers

    for handler, _ in pairs(handlers) do
        handler(self._lastState)
    end

    return self
end

return APL.LuaUtils.readOnly(StateController)
