-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"
local Log = require "APL.Log"

local LocalNotificationState = LuaUtils.makeObject({ _type = "LocalNotificationState" })

local SymbolNameAndColor = LuaUtils.namedObject(
    "LocalNotificationState.SymbolNameAndColor",
    { "name", "string" },
    { "color", "number" }
)

function SymbolNameAndColor.isEqual(lhs, rhs)
    return lhs.name == rhs.name and lhs.color == rhs.color
end

LocalNotificationState.SymbolNameAndColor = LuaUtils.readOnly(SymbolNameAndColor)



local TextContent = LuaUtils.namedObject(
    "LocalNotificationState.TextContent",
    { "title", "string" },
    { "body", "string" },
    { "symbolNameAndColor", "LocalNotificationState.SymbolNameAndColor" }
)

function TextContent.isEqual(lhs, rhs)
    return lhs.title == rhs.title and lhs.body == rhs.body and LocalNotificationState.SymbolNameAndColor:isEqual(lhs.symbol, rhs.symbol)
end

LocalNotificationState.TextContent = LuaUtils.readOnly(TextContent)











function LocalNotificationState.new(identifier, userDismissible, on, displayZoneIdentifier, textContent)






    local self = LuaUtils.newObject(LocalNotificationState, {
        identifier = identifier,
        userDismissible = userDismissible,
        on = on,
        displayZoneIdentifier = displayZoneIdentifier, -- Enums.DisplayZoneIdentifier.ZONE_1 or Enums.DisplayZoneIdentifier.ZONE_2
        textContent = textContent or LuaUtils.NIL,
    })

    return self
end






function LocalNotificationState:destroy()

end







function LocalNotificationState:equals(notification)



    return self.identifier == notification.identifier and
        self.userDismissible == notification.userDismissible and
        self.on == notification.on and
        self.displayZoneIdentifier == notification.displayZoneIdentifier and
        (
            (self.textContent == nil and notification.textContent == nil) or
            (self.textContent ~= nil and notification.textContent ~= nil and LocalNotificationState.TextContent.isEqual(self.textContent, notification.textContent))
        )
end






function LocalNotificationState:copy()


    return LocalNotificationState.new(self.identifier, self.userDismissible, self.on, self.displayZoneIdentifier, self.textContent)
end






function LocalNotificationState:description()


    return LuaUtils.prettyPrint(self)
end

return LuaUtils.readOnly(LocalNotificationState)
