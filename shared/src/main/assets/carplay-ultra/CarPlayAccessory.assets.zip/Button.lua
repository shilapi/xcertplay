-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local PressEvent = require "PressEvent"
local DynamicAppearanceImage = require "DynamicAppearanceImage"

local Button = APL.LuaUtils.makeObject({ _type = "Button" })












function Button.new(image, focusedImage, appearanceState, focusSystem, actionHandler, acceptBackEvent)







    acceptBackEvent = acceptBackEvent or true

    local self = APL.LuaUtils.newObject(Button, {
        _enabled = false,
        _image = image,
        _focusedImage = focusedImage,
        _actionHandler = actionHandler,
        _rootLayer = APL.LuaUtils.NIL,
        _focusSystem = focusSystem,
        _focused = false,
        _isPressed = false,
        _requiresFocusEffect = false,
        _appearanceMode = appearanceState.appearance,
        _tweens = {
            opacity = 1.0,
            scale = 1.0
        },
        _acceptBackEvent = acceptBackEvent
    })

    self._rootLayer = APL.ImageLayer.new()

    self:_updateAppearance()

    return self
end







function Button:handleEvents(events)



    for _, event in pairs(events) do
        local eventType = event:getType()

        if eventType == PressEvent.EVENT_TYPE.SELECT then
            local wasPressed = self._isPressed
            local isPressed = event:getPhase() == PressEvent.PHASE.BEGIN
            self:setIsPressed(isPressed)

            if wasPressed == true and isPressed == false then
                APL.Log.info(Button, function() return "Button was pressed" end)
                self._actionHandler()
            end
        elseif self._acceptBackEvent and eventType == PressEvent.EVENT_TYPE.BACK and event:getPhase() == PressEvent.PHASE.END then
            APL.Log.info(Button, function() return "Button was pressed" end)
            self._actionHandler()
        end
    end

    return self
end







function Button:setEnabled(enabled)



    if self._enabled ~= enabled then
        self._enabled = enabled

        if enabled then
            self._focusSystem:addFocusItem(self)
        else
            self._focusSystem:removeFocusItem(self)
        end
    end

    return self
end







function Button:setFrame(frame)



    self._rootLayer:setFrame(frame)

    self:_updateBounds()

    return self
end







function Button:setAppearanceState(state)



    if self._appearanceMode ~= state.appearance then
        self._appearanceMode = state.appearance
        self:_updateAppearance()
    end

    return self
end







function Button:setFocused(focused)



    if self._focused ~= focused then
        self._focused = focused
        self:_updateAppearance()
    end

    return self
end







function Button:setIsPressed(pressed)



    if self._isPressed ~= pressed then

        local opacity = pressed and 0.5 or 1.0
        local scale = pressed and 0.96 or 1.0

        APL.flux.to(self._tweens, pressed and 0.0 or 0.47, { opacity = opacity, scale = scale })
            :ease("bezier", 0.25, 0.1, 0.25, 1)
            :onupdate(function(vars)
                self._rootLayer
                    :setOpacity(vars.opacity)
                    :setTransform(APL.Transform.newWithScale(vars.scale, vars.scale))
            end)
        self._isPressed = pressed
    end

    return self
end







function Button:setRequiresFocusEffect(requiresFocusEffect)



    if self._requiresFocusEffect ~= requiresFocusEffect then
        self._requiresFocusEffect = requiresFocusEffect
        self:_updateAppearance()
    end

    return self
end






function Button:preferredContentSize()

    local texture = DynamicAppearanceImage.getTextureForAppearanceMode(self._image, self._appearanceMode)
    return texture:getSize()
end






function Button:getRootLayer()


    return self._rootLayer
end






function Button:destroy()


    APL.flux.clear(self._tweens)

    if self._enabled then
        self._focusSystem:removeFocusItem(self)
    end

    self._focusSystem = nil

    self._image = nil
    self._focusedImage = nil
    self._actionHandler = nil

    self._rootLayer:destroy()
end






function Button:_updateAppearance()


    local showFocusedState = self._focused and self._requiresFocusEffect
    local image = showFocusedState and self._focusedImage or self._image
    local texture = DynamicAppearanceImage.getTextureForAppearanceMode(image, self._appearanceMode)

    self._rootLayer:setTexture(texture)

    self:_updateBounds()

    return self
end






function Button:_updateBounds()


    local frame = APL.Rect.new(self._rootLayer:getFrame())
    local bounds = APL.Rect.new(0, 0, self._rootLayer:getTexture():getSize()):centeredInRect(frame)

    self._rootLayer:setBounds(bounds)

    return self
end

return APL.LuaUtils.readOnly(Button)
