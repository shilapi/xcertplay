-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local DigiBarRadialStyle = require "DigiBarRadialStyle"
local DigiBarLinearStyle = require "DigiBarLinearStyle"


local DigiBarMarkerConfiguration = APL.LuaUtils.namedObject(
    "DigiBarMarkerConfiguration",
    { "style", "*" }, -- Bar style. Either DigiBarRadialStyle or DigiBarLinearStyle
    { "type", "*" }   -- Marker type: DigiBarMarkerConfiguration.Dot, DigiBarMarkerConfiguration.Tick or DigiBarMarkerConfiguration.Label
)


DigiBarMarkerConfiguration.Dot = APL.LuaUtils.namedObject(
    "DigiBarMarkerConfiguration.Dot",
    { "radius", "number" },
    { "styles", "table" } -- Int to DigiBarMarkerConfiguration.Dot.Style
)



DigiBarMarkerConfiguration.Dot.Style = APL.LuaUtils.namedObject(
    "DigiBarMarkerConfiguration.Dot.Style",
    { "type", "number" }, --- DigiBarMarkerConfiguration.Dot.Style.TYPE
    { "colorID", "string?" } -- A color associated with DigiBarMarkerConfiguration.Dot.Style.Type.COLOR. Nil if type is "PUNCH_HOLE"
)


DigiBarMarkerConfiguration.Dot.Style.TYPE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "PUNCH_HOLE",
    "COLOR"
}))


DigiBarMarkerConfiguration.Tick = APL.LuaUtils.namedObject(
    "DigiBarMarkerConfiguration.Tick",
    { "width", "number" },
    { "length", "number" },
    { "lineCap", "number" },
    { "styles", "table" }  -- Int to DigiBarMarkerConfiguration.Dot.Style
)


DigiBarMarkerConfiguration.Label = APL.LuaUtils.namedObject(
    "DigiBarMarkerConfiguration.Label",
    { "font", "string" },
    { "colorIDs", "table" },        -- stateful label text colorIDs
    { "backgroundColorIDs", "table" },   -- stateful label background colorIDs
    { "padding", "number?" },
    { "desiredLabelWidths", "table" },
    { "desiredLabelHeight", "number" },
    { "cornerRadius", "number" }
)

DigiBarMarkerConfiguration.Dot.Style.fromJson = function(json)
    if json.color then
        return DigiBarMarkerConfiguration.Dot.Style.new(
            DigiBarMarkerConfiguration.Dot.Style.TYPE.COLOR,
            json.color.ID
        )
    elseif json.mask then
        return DigiBarMarkerConfiguration.Dot.Style.new(
            DigiBarMarkerConfiguration.Dot.Style.TYPE.PUNCH_HOLE
        )
    else

    end
end

DigiBarMarkerConfiguration.Dot.fromJson = function(json)
    return DigiBarMarkerConfiguration.Dot.new(
        json.radius,
        APL.LuaUtils.numberedKeys(APL.LuaUtils.map(json.styles, DigiBarMarkerConfiguration.Dot.Style.fromJson))
    )
end

DigiBarMarkerConfiguration.Tick.fromJson = function(json)
    return DigiBarMarkerConfiguration.Tick.new(
        json.width,
        json.length,
        json.lineCap,
        APL.LuaUtils.numberedKeys(APL.LuaUtils.map(json.styles, DigiBarMarkerConfiguration.Dot.Style.fromJson))
    )
end

DigiBarMarkerConfiguration.Label.fromJson = function(json)




    return DigiBarMarkerConfiguration.Label.new(
        json.font.name,
        APL.LuaUtils.numberedKeys(json.textColorIDs),
        APL.LuaUtils.numberedKeys(json.backgroundColorIDs),
        nil,
        APL.LuaUtils.numberedKeys(json.desiredLabelWidths),
        json.desiredLabelHeight,
        json.cornerRadius
    )
end

DigiBarMarkerConfiguration.fromJson = function(json)
    local trackConfiguration
    if json.style.radial then
        trackConfiguration = DigiBarRadialStyle.fromJson(json.style.radial.configuration)
    elseif json.style.linear then
        trackConfiguration = DigiBarLinearStyle.fromJson(json.style.linear.configuration)
    else

    end

    local markerJson = json.type.type
    local markerType
    if markerJson.dot then
        markerType = DigiBarMarkerConfiguration.Dot.fromJson(markerJson.dot.configuration)
    elseif markerJson.tick then
        markerType = DigiBarMarkerConfiguration.Tick.fromJson(markerJson.tick.configuration)
    elseif markerJson.label then
        markerType = DigiBarMarkerConfiguration.Label.fromJson(markerJson.label.configuration)
    else

    end

    return DigiBarMarkerConfiguration.new(
        trackConfiguration,
        markerType
    )
end

return APL.LuaUtils.readOnly(DigiBarMarkerConfiguration)