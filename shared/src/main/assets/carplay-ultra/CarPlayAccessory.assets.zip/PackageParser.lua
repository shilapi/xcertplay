-- Copyright © 2021-2026 Apple, Inc. All rights reserved.







local APL = require "APL.APL"
local Display = require "Display"
local FontUtils = require "FontUtils"
local LayoutInfo = require "LayoutInfo"
local LocalNotificationData = require "LocalNotificationData"
local ShadowConfiguration = require "ShadowConfiguration"

local PackageParser = APL.LuaUtils.makeObject({ _type = "PackageParser" })







function PackageParser.new(package)


    local self = APL.LuaUtils.newObject(PackageParser, {
        _document = package
    })

    return self
end






function PackageParser:getVersion()


    return self._document.version
end







function PackageParser:getDisplay(displayID)



    local displays = self._document.displays


    local displayData = APL.LuaUtils.first(displays, function(packageDisplay)
        return packageDisplay.id == displayID
    end)


    local layouts = APL.LuaUtils.map(displayData.layouts or {}, function(layoutData)
        return self:_parseLayout(layoutData)
    end)

    local notifications = APL.LuaUtils.map(displayData.localNotifications or {}, function(notification)
        return LocalNotificationData.fromJson(notification)
    end)

    local shadows = APL.LuaUtils.map(displayData.shadows or {}, function(shadow)
        return ShadowConfiguration.fromJson(shadow)
    end)

    local size = displayData.size

    local fontManager
    if displayData.vectorFontManager and APL.VectorFont.isFeatureSupported() then
        fontManager = FontUtils.createVectorFontManager(displayData.vectorFontManager)
    end

    return Display.new(displayID, size[1], size[2], layouts, notifications, shadows, fontManager)
end







function PackageParser:_parseLayout(layout)



    local zones = APL.LuaUtils.map(layout.zones, function(zone)
        local components = APL.LuaUtils.map(zone.components, PackageParser.createComponentInfo)

        return {
            frame = APL.LuaUtils.merge(zone.frame[1], zone.frame[2]),
            id = zone.id,
            displayName = zone.displayName,
            components = components,
            shape = zone.zoneShape,
            type = zone.type,
            zoneRegion = zone.zoneRegion
        }
    end)

    return LayoutInfo.new(
        layout.id,
        layout.displayName,
        zones,
        layout.layoutType,
        layout.layoutStyleID
    )
end







function PackageParser.createComponentInfo(component)


    return {
        slots = APL.LuaUtils.compactMap(component.slots, PackageParser._createSlotInfo),
        id = component.id,
        displayName = component.name,
        type = component.type
    }
end







function PackageParser._createSlotInfo(slot)



    if not slot.instrument or not slot.frame then
        return nil
    end

    local instrument = PackageParser._createInstrument(slot.instrument)
    if instrument or slot.parentPositionId then
        return {
            frame = APL.LuaUtils.merge(slot.frame[1], slot.frame[2]),
            zIndex = slot.zIndex,
            instrument = instrument, -- nil for video stream child gauges
            positionId = slot.positionId,
            parentPositionId = slot.parentPositionId,
            style = slot.style
        }
    end

    return nil
end







function PackageParser._createInstrument(instrument)


    local _instrument = {
        globalConfiguration = instrument.configuration,
    }


    local placeholder = instrument.kind.placeholder
    if placeholder and placeholder.asset then
        _instrument.kind = "placeholder"
        _instrument.asset = placeholder.asset
        _instrument.visibilityConfiguration = placeholder.visibilityConfiguration
        return _instrument
    end


    local gauge = instrument.kind.gauge
    if gauge and gauge.configuration then
        local config = gauge.configuration
        if config.rendersLocally then
            _instrument.kind = "gauge"
            _instrument.style = config.style
            _instrument.visibilityConfiguration = config.visibilityConfiguration
            return _instrument
        end
    end


    local indicator = instrument.kind.indicator
    if indicator and indicator.configuration then


        if APL.LuaUtils.query(indicator, "configuration.style.critical") then
            _instrument.kind = "indicator"
            _instrument.configuration = indicator.configuration
            return _instrument
        end
    end


    local popover = instrument.kind.widgetPopover
    if popover and popover.configuration.location then


        if APL.LuaUtils.query(popover, "configuration.location.localRenderer") then
            _instrument.kind = "widgetPopover"
            _instrument.configuration = popover.configuration
            return _instrument
        end
    end


    local inputStream = instrument.kind.inputStream
    if inputStream and inputStream.identifier then
        _instrument.kind = "inputStream"
        _instrument.streamIdentifier = inputStream.identifier
        _instrument.visibilityConfiguration = inputStream.visibilityConfiguration
        return _instrument
    end


    local punchThrough = instrument.kind.punchThrough
    if punchThrough and punchThrough.dataIdentifier then
        _instrument.kind = "punchThrough"
        _instrument.dataIdentifier = punchThrough.dataIdentifier
        _instrument.streamIdentifier = punchThrough.identifier
        return _instrument
    end

    if instrument.kind.punchThroughType then
        _instrument.kind = "punchThroughType"
        _instrument.type = instrument.kind.punchThroughType.type
        return _instrument
    end


    return nil
end






function PackageParser:destroy()


    self._document = nil
end

return APL.LuaUtils.readOnly(PackageParser)
