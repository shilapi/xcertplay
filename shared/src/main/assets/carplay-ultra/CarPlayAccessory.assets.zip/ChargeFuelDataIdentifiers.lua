-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local ChargeFuelDataIdentifiers = APL.LuaUtils.namedObject(
    "ChargeFuelDataIdentifiers",
    { "levelDataIdentifier", "string" },
    { "portSideIndicatorDataIdentifier", "string" },
    { "levelMarkerLowDataIdentifier", "string" },
    { "levelStateDataIdentifier", "string" }
)







function ChargeFuelDataIdentifiers.fromJson(json)


    return ChargeFuelDataIdentifiers.new(
        json.levelDataIdentifier,
        json.portSideIndicatorDataIdentifier,
        json.levelMarkerLowDataIdentifier,
        json.levelStateDataIdentifier
    )
end

return APL.LuaUtils.readOnly(ChargeFuelDataIdentifiers)
