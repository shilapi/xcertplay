-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local MeasurementLabelConfiguration = require "MeasurementLabelConfiguration"
local VehicleDataUpdater = require "VehicleDataUpdater"

local RemainingRangeTextConfiguration = APL.LuaUtils.namedObject(
    "RemainingRangeTextConfiguration",
    { "remainingRangeDataIdentifier", "string" },
    { "unitDataIdentifier", "string" },
    { "labelConfiguration", "MeasurementLabelConfiguration" }
)

function RemainingRangeTextConfiguration.fromJson(jsonRepresentation)


    return RemainingRangeTextConfiguration.new(
        jsonRepresentation.remainingRangeDataIdentifier,
        jsonRepresentation.unitDataIdentifier,
        MeasurementLabelConfiguration.fromJson(jsonRepresentation.labelConfiguration)
    )
end

local ChargeFuelLevelGaugeConfiguration = APL.LuaUtils.namedObject(
    "ChargeFuelLevelGaugeConfiguration",
    { "levelDataIdentifier", "string" },
    { "levelStateDataIdentifier", "string" },
    { "levelMarkerLowDataIdentifier", "string" },
    { "portSideIndicatorDataIdentifier", "string" },
    { "remainingRangeTextConfiguration", "RemainingRangeTextConfiguration?" },
    { "progressColorID", "string" },
    { "trackColorID", "string" },
    { "lowLevelColorID", "string" },
    { "criticallyLowLevelColorID", "string" },
    { "normalLevelIndicatorColorID", "string" },
    { "lowLevelIndicatorColorID", "string" },
    { "criticallyLowLevelIndicatorColorID", "string" },
    { "redactedIndicatorColorID", "string" },
    { "portSideIndicatorImages", "table" }
)

ChargeFuelLevelGaugeConfiguration.RemainingRangeTextConfiguration = RemainingRangeTextConfiguration







function ChargeFuelLevelGaugeConfiguration.fromJson(jsonRepresentation)


    local remainingRangeTextConfiguration
    if jsonRepresentation.remainingRangeTextConfiguration then
        remainingRangeTextConfiguration = RemainingRangeTextConfiguration.fromJson(jsonRepresentation.remainingRangeTextConfiguration)
    end

    local portSideIndicatorImages = {}

    for state, image in pairs(jsonRepresentation.portSideIndicatorImages) do




        local stateNumber = tonumber(state)


        portSideIndicatorImages[stateNumber] = image
    end

    return ChargeFuelLevelGaugeConfiguration.new(
        jsonRepresentation.levelDataIdentifier,
        jsonRepresentation.levelStateDataIdentifier,
        jsonRepresentation.levelMarkerLowDataIdentifier,
        jsonRepresentation.portSideIndicatorDataIdentifier,
        remainingRangeTextConfiguration,
        jsonRepresentation.progressColorID,
        jsonRepresentation.trackColorID,
        jsonRepresentation.lowLevelColorID,
        jsonRepresentation.criticallyLowLevelColorID,
        jsonRepresentation.normalLevelIndicatorColorID,
        jsonRepresentation.lowLevelIndicatorColorID,
        jsonRepresentation.criticallyLowLevelIndicatorColorID,
        jsonRepresentation.redactedIndicatorColorID,
        portSideIndicatorImages
    )
end

return APL.LuaUtils.readOnly(ChargeFuelLevelGaugeConfiguration)