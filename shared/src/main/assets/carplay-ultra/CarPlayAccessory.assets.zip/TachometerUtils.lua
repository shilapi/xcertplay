-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"
local Enums = require "Enums"
local Ticks = require "Ticks"
local Units = require "Units"
local VehicleDataUpdater = require "VehicleDataUpdater"

local TachometerUtils = { _type = "TachometerUtils" }


TachometerUtils.MIN_LABELS_COUNT = 5
TachometerUtils.MAX_LABELS_COUNT = 12
TachometerUtils.LABEL_INTERVALS = { 1000, 2000, 4000, 5000, 10000 }

TachometerUtils.DETACHED_REGION = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "NOMINAL",
    "REDLINE"
}))










function TachometerUtils.progressForUpdate(maxRPM, rmpDataIdentifier, uiSceneStateDataIdentifier)




    return TachometerUtils._progressForUpdate(maxRPM, rmpDataIdentifier, uiSceneStateDataIdentifier)
end









function TachometerUtils.progressForRedlineUpdate(maxRPM, redlineDataIdentifier)



    return TachometerUtils._progressForUpdate(maxRPM, redlineDataIdentifier)
end









function TachometerUtils.rpmTextForUpdate(update, previous, rpmDataIdentifier)




    local rpm = APL.LuaUtils.merge(previous, update)[rpmDataIdentifier]

    return rpm
end










function TachometerUtils._progressForUpdate(maxRPM, rmpDataIdentifier, uiSceneStateDataIdentifier)





    local adjustedMaxRPM = Ticks.getMaxValueWithLabelsCount(
        maxRPM,
        TachometerUtils.MIN_LABELS_COUNT,
        TachometerUtils.MAX_LABELS_COUNT,
        TachometerUtils.LABEL_INTERVALS
    )


    local lastRpmValue = 0

    return function(update, previous)

        if uiSceneStateDataIdentifier then
            local uiSceneState = update[uiSceneStateDataIdentifier] or previous[uiSceneStateDataIdentifier]

            if uiSceneState.state ~= Enums.UISceneState.DRIVE then
                return 0
            end
        end

        APL.Log.debug(TachometerUtils, function() return "update: " .. APL.LuaUtils.prettyPrint(update, false, 2) end)

        lastRpmValue = update[rmpDataIdentifier] or previous[rmpDataIdentifier] or lastRpmValue
        if lastRpmValue == VehicleDataUpdater.INVALID then
            return nil
        end


        return lastRpmValue / adjustedMaxRPM
    end
end












function TachometerUtils.progressForDetachedUpdate(maxRPMValues, rpmDataIdentifier, redlineDataIdentifier, rpmMaxDataIdentifier, uiSceneStateDataIdentifier, detachedRegion)







    local maxRPM = maxRPMValues[rpmMaxDataIdentifier]


    local lastRPMRedlineValue = maxRPMValues[redlineDataIdentifier] or 0
    local lastRpmValue = 0

    return function(update, cached)
        lastRpmValue = update[rpmDataIdentifier] or lastRpmValue
        lastRPMRedlineValue = update[redlineDataIdentifier] or lastRPMRedlineValue


         local uiSceneState = update[uiSceneStateDataIdentifier] or cached[uiSceneStateDataIdentifier]

         if uiSceneState.state ~= Enums.UISceneState.DRIVE then
             return 0
         end

        if lastRpmValue == VehicleDataUpdater.INVALID then
            return nil
        end




        local progress = lastRpmValue / maxRPM
        local maxValue = lastRPMRedlineValue / maxRPM
        local progressDetached
        if detachedRegion == TachometerUtils.DETACHED_REGION.NOMINAL then
            progressDetached = math.min(progress, maxValue)
        elseif detachedRegion == TachometerUtils.DETACHED_REGION.REDLINE then

            progressDetached = math.min(math.max(progress + 0.00001, maxValue), 1)
        end



        return math.max(0, progressDetached)
    end
end

return APL.LuaUtils.readOnly(TachometerUtils)