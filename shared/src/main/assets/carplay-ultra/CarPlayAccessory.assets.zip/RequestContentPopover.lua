-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Button = require "Button"
local Constants = require "Constants"
local DynamicAppearanceImage = require "DynamicAppearanceImage"
local Popover = require "Popover"
local RequestContentState = require "RequestContentState"
local Signpost = require "APL.Signpost"
local Shadow = require "Shadow"

local RequestContentPopover = APL.LuaUtils.makeObject({ _type = "RequestContentPopover" })














function RequestContentPopover.new(inputStream, contentController, focusSystem, appearanceController, instrument, cornerRadius, shadowConfig, preventPopoverPresentation)









    local self = APL.LuaUtils.newObject(RequestContentPopover, {
        _rootLayer = APL.LuaUtils.NIL,
        _popoverState = APL.LuaUtils.NIL, -- The current RequestContentState state.
        _inputStream = inputStream,
        _contentController = contentController,
        _appearanceController = appearanceController,
        _activePopover = APL.LuaUtils.NIL,
        _tweens = { opacity = 0, x = 1, y = 1}, -- Table to track animation values (opacity, x scale, y scale)
        _cornerRadius = cornerRadius,
        _closeButton = APL.LuaUtils.NIL,
        _subscription = APL.LuaUtils.NIL,
        _shadow = APL.LuaUtils.NIL,
        _preventPopoverPresentation = preventPopoverPresentation
    })

    self._rootLayer = APL.Layer.new()

    if shadowConfig then
        self._shadow = Shadow.new(shadowConfig)
        self._shadow
            :getRootLayer()
            :setVisible(false)
            :addToSuperLayer(self._rootLayer)
    end

    local configuration = instrument.configuration.location.localRenderer.configuration
    local closeButtonImage = DynamicAppearanceImage.fromJson(configuration.closeButton)
    local focusedCloseButtonImage = DynamicAppearanceImage.fromJson(configuration.focusedCloseButton)

    self._closeButton = Button.new(closeButtonImage, focusedCloseButtonImage, appearanceController:getState(), focusSystem, function()
        self._contentController:dismissContent()
    end)
    self._activePopover = Popover.new(self._inputStream, self._cornerRadius)

    self._activePopover:getRootLayer()
        :setVisible(false)
        :setOpacity(0)
        :addToSuperLayer(self._rootLayer)


    self._subscription = self._contentController:subscribe(function(requestContentState)
        local shouldShowPopover = requestContentState.on and requestContentState.contentURL == "inputStream://?identifier=" .. self._inputStream._streamIdentifier

        local updatedPopoverState = RequestContentState.new(
            requestContentState.contentURL,
            shouldShowPopover,
            requestContentState.userDismissible,
            requestContentState.zoneRegion
        )

        self:_setPopoverState(updatedPopoverState)
    end)



    self._appearanceController:setUpdateHandler(function(state)
        self._closeButton:setAppearanceState(state)
    end)

    return self
end






function RequestContentPopover:destroy()


    if self._subscription then
        self._contentController:unsubscribe(self._subscription)
    end
    self._contentController = nil

    self._activePopover:destroy()
    self._activePopover = nil

    if self._shadow then
        self._shadow:destroy()
        self._shadow = nil
    end

    self._rootLayer:destroy()
    self._rootLayer = nil

    APL.flux.clear(self._tweens)
end






function RequestContentPopover:getRootLayer()


    return self._rootLayer
end






function RequestContentPopover:getState()


    return self._popoverState
end







function RequestContentPopover:_setPopoverState(popoverState)



    local preventPopoverPresentation = self._preventPopoverPresentation()

    APL.Log.info(RequestContentPopover, function() return "Popover state changing from " ..  APL.LuaUtils.prettyPrint(self._popoverState) .. " to state " .. APL.LuaUtils.prettyPrint(popoverState) .. " preventing: " .. tostring(preventPopoverPresentation) end)

    if popoverState.on then

        if not preventPopoverPresentation then
            self._activePopover
                :setCloseButton(popoverState.userDismissible and self._closeButton or nil)
                :setEnabled(popoverState.userDismissible and true or false)

            if self._activePopover:getRootLayer():getOpacity() == 1 and self._activePopover:getRootLayer():getVisible() then

                return self
            end
            self:_present()
        elseif self._activePopover:getRootLayer():getVisible() then
            APL.Log.info(RequestContentPopover, function() return "Presentation prevented. Dismissing popover: " .. self._inputStream._streamIdentifier end)
            self:_dismiss(false)
        end
    elseif self._activePopover:getRootLayer():getVisible() then
        self:_dismiss()
    end

    self._popoverState = popoverState

    return self
end







function RequestContentPopover:setFrame(frame)



    self._rootLayer:setFrame(frame)

    local frame = APL.Rect.new(self._rootLayer:getBounds())
    self._activePopover:setFrame(frame)

    if self._shadow then
        self._shadow:setContentFrame(frame)
    end

    return self
end






function RequestContentPopover:description()


    return "RequestContentPopover" .. APL.LuaUtils.prettyPrint(self._popoverState)
end








function RequestContentPopover:_present()


    local zoneRegion = self._contentController:getZoneRegion()
    APL.Log.info(RequestContentPopover, function() return "RequestContentPopover starting present animation for zone: " .. zoneRegion end)
    local signpostId = Signpost.beginInterval("RequestContentPopover present animation started for zone: " .. zoneRegion)

    if not self._activePopover:getRootLayer():getVisible() then

        self._tweens.opacity = 0
        self._tweens.x = 0.9
        self._tweens.y = 0.9
    end

    self._activePopover:getRootLayer()
        :setVisible(true)
        :setOpacity(self._tweens.opacity)
        :addToSuperLayer(self._rootLayer)

    self._inputStream:setVisible(true)

    if self._shadow then
        self._shadow
            :getRootLayer()
            :setVisible(true)
            :setOpacity(self._tweens.opacity)
    end

    APL.flux.to(self._tweens, Constants.POPOVER_ANIMATION_DURATION, { opacity = 1, x = 1, y = 1 })
        :ease("bezier", table.unpack(Constants.POPOVER_CURVE))
        :onupdate(function(t)
            self._activePopover:getRootLayer()
                :setOpacity(t.opacity)
                :setTransform(APL.Transform.newWithScale(t.x, t.y))

            if self._shadow then
                self._shadow
                    :getRootLayer()
                    :setOpacity(t.opacity)
                self._shadow:setContentFrame(APL.Rect.new(self._activePopover:getRootLayer():getFrame()))
            end
        end)
        :oncomplete(function()
            APL.Log.info(RequestContentPopover, function() return "Completed presentation animation for zone: " .. zoneRegion end)
            Signpost.endInterval(signpostId, "RequestContentPopover present animation completed for zone: " .. zoneRegion)
        end)

    return self
end









function RequestContentPopover:_dismiss(animated)



    local animated = animated == nil and true or animated
    local zoneRegion = self._contentController:getZoneRegion()
    APL.Log.info(RequestContentPopover, function() return "RequestContentPopover starting dismissal animation for zone: " .. zoneRegion end)
    local signpostId = Signpost.beginInterval("RequestContentPopover dismiss animation started for zone: " .. zoneRegion)

    self._activePopover:setEnabled(false)

    local hide = function()
        self._activePopover:getRootLayer()
            :setOpacity(0)
            :setVisible(false)
            :removeFromSuperlayer()
        self._inputStream:setVisible(false)

        if self._shadow then
            self._shadow
                :getRootLayer()
                :setVisible(false)
        end
    end

    if not animated then
        hide()
        return self
    end

    APL.flux.to(self._tweens, Constants.POPOVER_ANIMATION_DURATION, { opacity = 0, x = 1, y = 1 })
        :ease("bezier", table.unpack(Constants.POPOVER_CURVE))
        :onupdate(function(t)
            self._activePopover:getRootLayer()
                :setOpacity(t.opacity)
                :setTransform(APL.Transform.newWithScale(t.x, t.y))

            if self._shadow then
                self._shadow
                    :getRootLayer()
                    :setOpacity(t.opacity)
                self._shadow:setContentFrame(APL.Rect.new(self._activePopover:getRootLayer():getFrame()))
            end
        end)
        :oncomplete(function()
            APL.Log.info(RequestContentPopover, function() return "Completed dismissal animation for zone: " .. zoneRegion end)
            Signpost.endInterval(signpostId, "RequestContentPopover dismiss animation completed for zone: " .. zoneRegion)
            hide()
        end)

    return self
end

return APL.LuaUtils.readOnly(RequestContentPopover)
