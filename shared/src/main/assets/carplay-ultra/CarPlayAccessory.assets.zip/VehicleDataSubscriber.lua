-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local APL = require "APL.APL"






local VehicleDataSubscriber = APL.LuaUtils.makeObject({ _type = "VehicleDataSubscriber" })






function VehicleDataSubscriber.new()
    local self = APL.LuaUtils.newObject(VehicleDataSubscriber, {
        _unsubscribe = APL.LuaUtils.NIL, -- function
    })

    return self
end






function VehicleDataSubscriber:destroy()


    self:removeSubscription()
end






function VehicleDataSubscriber:hasSubscription()
    return self._unsubscribe ~= nil
end




function VehicleDataSubscriber:removeSubscription()


    if self._unsubscribe then
        self._unsubscribe()
        self._unsubscribe = nil
    end

    return self
end










function VehicleDataSubscriber:updateSubscription(vehicleDataUpdater, subscriber)




    self:removeSubscription()

    self._unsubscribe = function()
        vehicleDataUpdater:unsubscribe(subscriber)
    end

    return self
end

return APL.LuaUtils.readOnly(VehicleDataSubscriber)