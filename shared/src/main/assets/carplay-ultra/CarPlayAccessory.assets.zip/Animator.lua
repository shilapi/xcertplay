-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local APL = require "APL.APL"

local Animator = APL.LuaUtils.makeObject({ _type = "Animator" })






function Animator.new()
    local self = APL.LuaUtils.newObject(Animator, {
        _animationThread = APL.LuaUtils.NIL,
        _flux = APL.flux.group(),
        _onStart = APL.LuaUtils.NIL,
        _onComplete = APL.LuaUtils.NIL,
        _threads = {}
    })

    return self
end






function Animator:destroy()


    self:stop()
end







function Animator:onStart(onStart)



    local _onStart = self._onStart
    self._onStart = _onStart and function(...) _onStart(...) onStart(...) end or onStart

    return self
end







function Animator:onComplete(onComplete)



    local _onComplete = self._onComplete
    self._onComplete = _onComplete and function(...) _onComplete(...) onComplete(...) end or onComplete

    return self
end











function Animator:anim(obj, duration, vars)





    if type(obj) == "function" then
        obj(self)
        return self
    elseif APL.LuaUtils.getClassName(obj) == "Thread" then
        self._threads[#self._threads+1] = obj
        return self
    end

    return self._flux:to(obj, duration, vars)
end












function Animator:animScale(layer, duration, fromX, fromY, toX, toY)








    return self:anim({ x = fromX, y = fromY }, duration, { x = toX or 1, y = toY or 1 })
        :onupdate(function(tween)

            if not APL.Layer.isSubclass(layer) then
                return
            end

            layer:setTransform(APL.Transform.newWithScale(tween.x, tween.y))
        end)
end












function Animator:animPosition(layer, duration, fromX, fromY, toX, toY)








    return self:anim({ x = fromX, y = fromY }, duration, { x = toX, y = toY })
        :onupdate(function(tween)

            if not APL.Layer.isSubclass(layer) then
                return
            end

            layer:setPosition(tween.x, tween.y)
        end)
end










function Animator:animOpacity(layer, duration, from, to)






    return self:anim({ opacity = from }, duration, { opacity = to })
        :onupdate(function(tween)

            if not APL.Layer.isSubclass(layer) then
                return
            end

            layer:setOpacity(tween.opacity)
        end)
end






function Animator:start()




    self._animationThread = APL.Thread.new(function()
        if self._onStart then
            self._onStart(self)
        end


        for _, thread in ipairs(self._threads) do

            if APL.LuaUtils.getClassName(thread) == "Thread" then
                thread:start()
            end
        end

        local startTime = CP.PTS
        while self._flux:isBusy() or not APL.Thread.joined(self._threads) do
            local currentTime = CP.PTS
            local diff = (currentTime - startTime)
            self._flux:update(diff)
            startTime = currentTime

            APL.Thread.yield()
        end

        if self._onComplete then
            self._onComplete()
        end

        self._animationThread = nil
    end)

    self._animationThread:start()

    return self
end






function Animator:stop()


    if not self._animationThread then
        return
    end

    self._animationThread:stop()
    self._animationThread = nil

    return self
end






function Animator:join()


    if not self._animationThread then
        return self
    end

    self._animationThread:join()

    return self
end

return APL.LuaUtils.readOnly(Animator)