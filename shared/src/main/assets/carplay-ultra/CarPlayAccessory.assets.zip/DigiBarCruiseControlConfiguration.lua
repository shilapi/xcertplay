-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local DigiBarConfiguration = require "DigiBarConfiguration"


local DigiBarCruiseControlConfiguration = APL.LuaUtils.namedObject(
    "DigiBarCruiseControlConfiguration",

    { "cruiseControlBarConfiguration", "DigiBarConfiguration" },

    { "trackConfiguration", "DigiBarConfiguration" },

    { "type", "number" }
)






DigiBarCruiseControlConfiguration.BAR_TYPE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "FOREGROUND",
    "BACKGROUND",
    "DETACHED",
}))

DigiBarCruiseControlConfiguration.fromJson = function(json)


    return DigiBarCruiseControlConfiguration.new(
        DigiBarConfiguration.fromJson(json.cruiseControlBarConfiguration),
        DigiBarConfiguration.fromJson(json.trackConfiguration),
        json.type
    )
end

return APL.LuaUtils.readOnly(DigiBarCruiseControlConfiguration)