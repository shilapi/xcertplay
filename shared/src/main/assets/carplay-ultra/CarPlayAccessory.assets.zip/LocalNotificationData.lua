-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local LocalNotificationData = APL.LuaUtils.namedObject(
    "LocalNotificationData",
    { "image", "table" },
    { "userDismissible", "boolean" }
)

function LocalNotificationData.fromJson(jsonRepresentation)





    return LocalNotificationData.new(
        jsonRepresentation.image,
        jsonRepresentation.userDismissible
    )
end

return APL.LuaUtils.readOnly(LocalNotificationData)