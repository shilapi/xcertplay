-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Constants = require "Constants"
local VehicleDataUpdater = require "VehicleDataUpdater"
local VehicleDataSubscriber = require "VehicleDataSubscriber"

local TextGauge = APL.LuaUtils.makeObject({ _type = "TextGauge" })










function TextGauge.new(configuration, appearanceController, textController, tintController)





    local initialTextState, _ = next(configuration.statefulText)

    local textLayer = APL.TextLayer.new(configuration.font, "TextGauge:" .. tostring(configuration.dataIdentifier))
        :setAlignment(configuration.alignment)

    local self = APL.LuaUtils.newObject(TextGauge, {
        _textLayer = textLayer,
        _configuration = configuration,
        _appearanceState = appearanceController:getState(),
        _textState = initialTextState,
        _tintState = 0,
        _redacted = false,
        _vehicleDataSubscriber = VehicleDataSubscriber.new(),
    })

    if textController then
        textController:setUpdateHandler(function(state)
            self._redacted = state == VehicleDataUpdater.INVALID
            self._textState = state
            self:_updateWithState(state, self._tintState, self._appearanceState, self._redacted)
        end)
    end

    if tintController then
        tintController:setUpdateHandler(function(state)
            self._tintState = state
            self:_updateWithState(self._textState, state, self._appearanceState, self._redacted)
        end)
    end

    appearanceController:setUpdateHandler(function(state)
        self._appearanceState = state
        self:_updateWithState(self._textState, self._tintState, state, self._redacted)
    end)

    return self
end






function TextGauge:destroy()


    self._vehicleDataSubscriber:destroy()
    self._textLayer:destroy()
end







function TextGauge:setFrame(frame)



    local baselineSpacing = self._configuration.baselineSpacing
    if baselineSpacing then
        local glyphHeight = self._textLayer:getBoundingRect()._height
        local baselineSpacingDiff = frame._height - glyphHeight
        local adjustedY = baselineSpacingDiff - baselineSpacing
        self._textLayer:setFrame(APL.Rect.new(frame._x, adjustedY, frame._width, glyphHeight))
        return self
    end

    self._textLayer:setFrame(frame)

    return self
end






function TextGauge:getRootLayer()


    return self._textLayer
end










function TextGauge:_updateWithState(textState, tintState, appearanceState, redacted)


    local colorID = self._configuration.colorIDs[tintState] or self._configuration.colorIDs[0]
    local textColor = appearanceState:getSolidColor(colorID)

    if redacted then
        textColor = APL.LuaUtils.setAlpha(textColor, Constants.REDACTED_ALPHA)
        if self._configuration.redactedColorID then
            textColor = appearanceState:getSolidColor(self._configuration.redactedColorID)
        end
        self._textLayer:setForegroundColor(textColor)

        if self._configuration.redactedOverride then
            self._textLayer:setText(self._configuration.redactedOverride)
            return self
        end

        self._textLayer:setRedacted(true)
        return self
    end
    self._textLayer:setRedacted(false)

    self._textLayer:setForegroundColor(textColor)
    self._textLayer:setText(self._configuration.statefulText[tostring(textState or 0)])

    return self
end






function TextGauge:description()


    return "TextGauge " .. APL.LuaUtils.prettyPrint(self)
end

return APL.LuaUtils.readOnly(TextGauge)
