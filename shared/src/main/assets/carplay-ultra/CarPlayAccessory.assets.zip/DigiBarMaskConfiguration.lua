-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local DigiBarLinearStyle = require "DigiBarLinearStyle"
local DigiBarRadialStyle = require "DigiBarRadialStyle"


local DigiBarMaskConfiguration = APL.LuaUtils.namedObject(
    "DigiBarMaskConfiguration",
    { "style", "*" }, -- Either DigiBarRadialStyle or DigiBarLinearStyle
    { "widthExtension", "number" },
    { "blendMode", "number" }
)

DigiBarMaskConfiguration.fromJson = function(json)


    local trackConfiguration
    if json.style.radial then
        trackConfiguration = DigiBarRadialStyle.fromJson(json.style.radial.configuration)
    elseif json.style.linear then
        trackConfiguration = DigiBarLinearStyle.fromJson(json.style.linear.configuration)
    else

    end

    return DigiBarMaskConfiguration.new(trackConfiguration, json.widthExtension, json.blendMode)
end

return APL.LuaUtils.readOnly(DigiBarMaskConfiguration)