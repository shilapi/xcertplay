-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local PillLabel = APL.LuaUtils.makeObject({ _type = "PillLabel" })







function PillLabel.new(font, name)


    local self = APL.LuaUtils.newObject(PillLabel, {
        _rootLayer = APL.LuaUtils.NIL,
        _labelLayer = APL.LuaUtils.NIL,

        _desiredLabelWidths = { 48, 58, 68 }, -- widths by number of characters being displayed
        _desiredLabelHeight = 40,
        _cornerRadius = 12,
    })

    self._labelLayer = APL.TextLayer.new(font, "PillLabel:" .. name)
        :setAlignment(APL.AttributedString.ALIGNMENT.CENTER)

    self._rootLayer = APL.ShapeLayer.new()
        :addSublayer(self._labelLayer)

    return self
end






function PillLabel:destroy()


    self._rootLayer:destroy()
end







function PillLabel:setText(text)



    self._labelLayer:setText(text)

    return self
end







function PillLabel:setPillColor(color)



    self._rootLayer:setFillColor(color)

    return self
end







function PillLabel:setTextColor(color)



    self._labelLayer:setForegroundColor(color)

    return self
end







function PillLabel:setFrame(frame)



    local bounds = APL.Rect.new(0, 0, frame._width, frame._height)

    local pillPath = APL.Path.new()
        :roundedRectangleIn(bounds, self._cornerRadius)

    self._rootLayer
        :setFrame(frame)
        :setPath(pillPath)

    self._labelLayer:setFrame(bounds)

    return self
end






function PillLabel:preferredContentSize()



    local characters = string.len(self._labelLayer:getText())
    local width = self._desiredLabelWidths[math.max(1, math.min(#self._desiredLabelWidths, characters))]

    return width, self._desiredLabelHeight
end






function PillLabel:getRootLayer()


    return self._rootLayer
end

return APL.LuaUtils.readOnly(PillLabel)
