-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"







local DigiBarColorsConfiguration = APL.LuaUtils.namedObject(
    "DigiBarColorsConfiguration",
    { "activeColorIDs", "table?" },
    { "trackColorIDs", "DigiBarColorsConfiguration.TrackColorIDs?" }
)

DigiBarColorsConfiguration.TrackColorIDs = APL.LuaUtils.namedObject(
    "DigiBarColorsConfiguration.TrackColorIDs",
    { "colorIDs", "table" },
    { "overlimitColorIDs", "table?" }
)

DigiBarColorsConfiguration.fromJson = function(json)
    local activeColorIDs = APL.LuaUtils.numberedKeys(json.activeColorIDs)

    local trackColorIDs
    if json.trackColorIDs then

        local colorIDs = APL.LuaUtils.numberedKeys(json.trackColorIDs.colorIDs)

        local overlimitColorIDs = APL.LuaUtils.numberedKeys(json.trackColorIDs.overlimitColorIDs)


        trackColorIDs = DigiBarColorsConfiguration.TrackColorIDs.new(colorIDs, overlimitColorIDs)
    end



    return DigiBarColorsConfiguration.new(
        activeColorIDs,
        trackColorIDs
    )
end

return APL.LuaUtils.readOnly(DigiBarColorsConfiguration)
