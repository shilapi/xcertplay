-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"



local GaugeColor = {
    _type = "GaugeColor",


    primary = "#FFFFFFFF",    -- (255, 255, 255)
    secondary = "#353233FF",  -- (53, 50, 51)
    tertiary = "#19191AFF",   -- (25, 25, 26)
    background = "#111112FF", -- (17, 17, 18)


    black = "#000000FF",  -- (0, 0, 0)
    blue = "#007CFFFF",   -- (0, 124, 255)
    grey = "#ABA8ABFF",   -- (171, 168, 171)
    whiteGrey = "#DBDBDBFF",   -- (175, 175, 183)
    clear = "#00000000",  -- (0, 0, 0)
    cyan = "#56CAFDFF",   -- (86, 202, 253)
    green = "#00E372FF",  -- (0, 227, 114)
    orange = "#FF9700FF", -- (255, 151, 0)
    pink = "#FF2D58FF",   -- (255, 45, 88)
    purple = "#7A7DFFFF", -- (122, 125, 255)
    red = "#FF372BFF",    -- (255, 55, 43)
    teal = "#00FAEFFF",   -- (0, 250, 239)
    yellow = "#FFE91BFF", -- (255, 233, 27)
    white = "#FFFFFFFF"   -- (255, 255, 255)
}

return APL.LuaUtils.readOnly(GaugeColor)
