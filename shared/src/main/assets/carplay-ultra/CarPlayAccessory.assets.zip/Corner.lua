-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local CORNER = {

    MINX_MINY = 1,
    MAXX_MINY = 2,
    MINX_MAXY = 4,
    MAXX_MAXY = 8,
}

CORNER.CORNER_TYPES = APL.LuaUtils.getKeys(CORNER)






function CORNER.isMaxY(corner)
    return (corner == CORNER.MAXX_MAXY) or (corner == CORNER.MINX_MAXY)
end

return APL.LuaUtils.readOnly(CORNER)