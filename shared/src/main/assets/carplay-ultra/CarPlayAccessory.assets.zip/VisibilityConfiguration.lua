-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local VisibilityConfiguration = APL.LuaUtils.namedObject(
    "VisibilityConfiguration",
    function(
        rules: table -- A list of rules (VisibilityRule)
    )
        return {
            rules = rules
        }
    end
)

VisibilityConfiguration.Animation = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Animation",
    function(
        bezierCurve: table,
        delay: number,
        duration: number
    )
        return {
            bezierCurve = bezierCurve,
            delay = delay,
            duration = duration
        }
    end
)
VisibilityConfiguration.Animation.fromJson = function(json)
    local bezierCurve = json.bezierCurve

    return VisibilityConfiguration.Animation.new(json.bezierCurve, json.delay, json.duration)
end
VisibilityConfiguration.Animation.copy = function(self)
    return VisibilityConfiguration.Animation.new(
        APL.LuaUtils.duplicate(self.bezierCurve),
        self.delay,
        self.duration
    )
end

function VisibilityConfiguration.Animation.equals(lhs, rhs)




    local equals = function(op1, op2)
        if #op1 ~= #op2 then
            return false
        end

        for i, v in op1 do
            if v ~= op2[i] then
                return false
            end
        end

        return true
    end

    return lhs ~= nil and rhs ~= nil
        and lhs.delay == rhs.delay
        and lhs.duration == rhs.duration
        and equals(lhs.bezierCurve, rhs.bezierCurve)
end

VisibilityConfiguration.Rule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule",
    function(

        showAnimation: VisibilityConfiguration.Animation,


        hideAnimation: VisibilityConfiguration.Animation,




        transmissionMode: any?, -- VisibilityConfiguration.Rule.TransmissionModeRule?,




        tickmarksSpeedUnit: any?, -- VisibilityConfiguration.Rule.TickmarksSpeedUnitRule?,




        speedLimiter: any?, -- VisibilityConfiguration.Rule.SpeedLimiterRule?,




        remainingRange: any?, -- VisibilityConfiguration.Rule.RemainingRangeRule?,


        layoutMode: any?, -- VisibilityConfiguration.Rule.LayoutModeRule?,


        invalidData: any?, -- VisibilityConfiguration.Rule.InvalidDataRule?,


        secondarySpeed: any?, -- VisibilityConfiguration.Rule.SecondarySpeedRule?,


        temperatureLabel: any?, -- VisibilityConfiguration.Rule.TemperatureLabelRule?



        activityState: any?, -- VisibilityConfiguration.Rule.ActivityStateRule?


        powerConsumption: any?, --VisibilityConfiguration.Rule.PowerConsumptionRule?



        emphasizedEngineGauge: any?, -- VisibilityConfiguration.Rule.EmphasizedEngineGaugeRule?


        sideIndicator: any?, -- VisibilityConfiguration.Rule.SideIndicatorRule?


        driveMode: any? -- -- VisibilityConfiguration.Rule.DriveModeRule?
    )
        return {
            showAnimation = showAnimation,
            hideAnimation = hideAnimation,
            transmissionMode = transmissionMode,
            tickmarksSpeedUnit = tickmarksSpeedUnit,
            speedLimiter = speedLimiter,
            remainingRange = remainingRange,
            layoutMode = layoutMode,
            invalidData = invalidData,
            secondarySpeed = secondarySpeed,
            temperatureLabel = temperatureLabel,
            activityState = activityState,
            powerConsumption = powerConsumption,
            emphasizedEngineGauge = emphasizedEngineGauge,
            sideIndicator = sideIndicator,
            driveMode = driveMode
        }
    end
)

VisibilityConfiguration.Rule.TRANSMISSION_MODE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "NUMERIC",
    "NONNUMERIC"
}))

VisibilityConfiguration.Rule.REMAINING_RANGE_RULE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "FULL",
    "ICON_ONLY"
}))

VisibilityConfiguration.Rule.TICKMARKS_SPEED_UNIT = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "NO_UNIT",
    "MPH",
    "KMH"
}))

VisibilityConfiguration.Rule.RemainingRangeRule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule.RemainingRangeRule",
    function(
        rule: number,
        dataIdentifier: string
    )
        return {
            rule = rule,
            dataIdentifier = dataIdentifier
        }
    end
)
VisibilityConfiguration.Rule.RemainingRangeRule.fromJson = function(json)


    return VisibilityConfiguration.Rule.RemainingRangeRule.new(
        json.rule,
        json.dataIdentifier
    )
end

VisibilityConfiguration.Rule.TransmissionModeRule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule.TransmissionModeRule",
    function(
        rule: number,
        dataIdentifier: string
    )
        return {
            rule = rule,
            dataIdentifier = dataIdentifier
        }
    end
)
VisibilityConfiguration.Rule.TransmissionModeRule.fromJson = function(json)


    return VisibilityConfiguration.Rule.TransmissionModeRule.new(
        json.rule,
        json.dataIdentifier
    )
end

VisibilityConfiguration.Rule.TickmarksSpeedUnitRule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule.TickmarksSpeedUnitRule",
    function(
        rule: number,
        showSecondarySpeedIdentifier: string,
        vehicleSpeedUnitIdentifier: string
    )
        return {
            rule = rule,
            showSecondarySpeedIdentifier = showSecondarySpeedIdentifier,
            vehicleSpeedUnitIdentifier = vehicleSpeedUnitIdentifier
        }
    end
)
VisibilityConfiguration.Rule.TickmarksSpeedUnitRule.fromJson = function(json)


    return VisibilityConfiguration.Rule.TickmarksSpeedUnitRule.new(
        json.rule,
        json.showSecondarySpeedIdentifier,
        json.vehicleSpeedUnitIdentifier
    )
end

VisibilityConfiguration.Rule.SPEED_LIMITER_MODE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "CRUISE_CONTROL",
    "SPEED_LIMITED",
    "SPEED_LIMITED_OR_CRUISE_CONTROL_SET",
    "CRUISE_CONTROL_ACTIVATED"
}))

VisibilityConfiguration.Rule.SpeedLimiterRule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule.SpeedLimiterRule",
    function(
        rule: number, -- VisibilityConfiguration.SPEED_LIMITER_MODE
        autoHideAnimation: VisibilityConfiguration.Animation?,
        speedLimitedIdentifier: string,
        cruiseControlStateIdentifier: string
    )
        return {
            rule = rule,
            autoHideAnimation = autoHideAnimation,
            speedLimitedIdentifier = speedLimitedIdentifier,
            cruiseControlStateIdentifier = cruiseControlStateIdentifier
        }
    end
)
VisibilityConfiguration.Rule.SpeedLimiterRule.fromJson = function(json)


    return VisibilityConfiguration.Rule.SpeedLimiterRule.new(
        json.rule,
        json.autoHideAnimation and VisibilityConfiguration.Animation.fromJson(json.autoHideAnimation) or nil,
        json.speedLimitedIdentifier,
        json.cruiseControlStateIdentifier
    )
end

VisibilityConfiguration.Rule.LayoutModeRule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule.LayoutModeRule",
    function(
        level: number,
        opacity: number
    )
        return {
            level = level,
            opacity = opacity
        }
    end
)
VisibilityConfiguration.Rule.LayoutModeRule.fromJson = function(json)


    return VisibilityConfiguration.Rule.LayoutModeRule.new(json.level, json.opacity)
end

VisibilityConfiguration.Rule.InvalidDataRule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule.InvalidDataRule",
    function(dataIdentifier: string)
        return {
            dataIdentifier = dataIdentifier
        }
    end
)
VisibilityConfiguration.Rule.InvalidDataRule.fromJson = function(json)


    return VisibilityConfiguration.Rule.InvalidDataRule.new(json.dataIdentifier)
end

VisibilityConfiguration.Rule.SecondarySpeedRule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule.SecondarySpeedRule",
    function(
        dataIdentifier: string,
        enabled: boolean
    )
        return {
            dataIdentifier = dataIdentifier,
            enabled = enabled
        }
    end
)
VisibilityConfiguration.Rule.SecondarySpeedRule.fromJson = function(json)


    return VisibilityConfiguration.Rule.SecondarySpeedRule.new(json.dataIdentifier, json.enabled)
end

VisibilityConfiguration.Rule.TEMPERATURE_LABEL_RULE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "FULL",
    "ICON_ONLY"
}))

VisibilityConfiguration.Rule.TemperatureLabelRule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule.TemperatureLabelRule",
    function(
        rule: number,
        dataIdentifier: string,
        minDataIdentifier: string,
        maxDataIdentifier: string
    )
    return {
        rule = rule,
        dataIdentifier = dataIdentifier,
        minDataIdentifier = minDataIdentifier,
        maxDataIdentifier = maxDataIdentifier
    }
    end
)
VisibilityConfiguration.Rule.TemperatureLabelRule.fromJson = function(json)


    return VisibilityConfiguration.Rule.TemperatureLabelRule.new(
        json.rule,
        json.temperatureDataIdentifier,
        json.temperatureMinDataIdentifier,
        json.temperatureMaxDataIdentifier
    )
end

VisibilityConfiguration.Rule.ActivityStateRule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule.ActivityStateRule",
    { "dataIdentifier", "string" },
    { "deactivatedValue", "number" },
    { "showWhenDeactivated", "boolean" }
)
VisibilityConfiguration.Rule.ActivityStateRule.fromJson = function(json)


    return VisibilityConfiguration.Rule.ActivityStateRule.new(
        json.dataIdentifier,
        json.deactivatedValue,
        json.showWhenDeactivated
    )
end

VisibilityConfiguration.Rule.PowerConsumptionRule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule.PowerConsumptionRule",
    { "dataIdentifier", "string" },
    { "showWhenPositive", "boolean" }
)
VisibilityConfiguration.Rule.PowerConsumptionRule.fromJson = function(json)


    return VisibilityConfiguration.Rule.PowerConsumptionRule.new(
        json.dataIdentifier,
        json.showWhenPositive
    )
end

VisibilityConfiguration.Rule.EmphasizedEngineGaugeRule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule.EmphasizedEngineGaugeRule",
    { "emphasizedEngineGaugeDataIdentifier", "string" },
    { "secondaryEngineGaugeHiddenDataIdentifier", "string" },
    { "gaugeType", "number" }, -- Refers to EmphasizedEngineGauge
    { "isSecondaryGauge", "boolean" }
)
VisibilityConfiguration.Rule.EmphasizedEngineGaugeRule.fromJson = function(json)


    return VisibilityConfiguration.Rule.EmphasizedEngineGaugeRule.new(
        json.emphasizedEngineGaugeDataIdentifier,
        json.secondaryEngineGaugeHiddenDataIdentifier,
        json.gaugeType,
        json.isSecondaryGauge
    )
end

VisibilityConfiguration.Rule.SIDE_INDICATOR_SIDE = APL.LuaUtils.readOnly({
    LEFT = 0,
    RIGHT = 1
})

VisibilityConfiguration.Rule.SideIndicatorRule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule.SideIndicatorRule",
    { "leftDataIdentifier", "string" },
    { "rightDataIdentifier", "string" },
    { "side", "number" } -- VisibilityConfiguration.Rule.SIDE_INDICATOR_SIDE
)
VisibilityConfiguration.Rule.SideIndicatorRule.fromJson = function(json)


    return VisibilityConfiguration.Rule.SideIndicatorRule.new(
        json.leftDataIdentifier,
        json.rightDataIdentifier,
        json.side
    )
end

VisibilityConfiguration.Rule.DriveModeRule = APL.LuaUtils.namedObject(
    "VisibilityConfiguration.Rule.DriveModeRule",
    { "dataIdentifier", "string" },
    { "showWhenHidden", "boolean" }
)
VisibilityConfiguration.Rule.DriveModeRule.fromJson = function(json)


    return VisibilityConfiguration.Rule.DriveModeRule.new(
        json.dataIdentifier,
        json.showWhenHidden
    )
end

VisibilityConfiguration.fromJson = function(json)

    local jsonRules = json and json.rules or {}
    local rules = APL.LuaUtils.map(jsonRules, function(rule)

        for _, v in pairs(rule) do
            return VisibilityConfiguration.Rule.new(
                VisibilityConfiguration.Animation.fromJson(v.showAnimation),
                VisibilityConfiguration.Animation.fromJson(v.hideAnimation),
                rule.transmissionMode and VisibilityConfiguration.Rule.TransmissionModeRule.fromJson(v.rule),
                rule.tickmarksSpeedUnit and VisibilityConfiguration.Rule.TickmarksSpeedUnitRule.fromJson(v.rule),
                rule.speedLimiter and VisibilityConfiguration.Rule.SpeedLimiterRule.fromJson(v.rule),
                rule.remainingRange and VisibilityConfiguration.Rule.RemainingRangeRule.fromJson(v.rule),
                rule.layoutMode and VisibilityConfiguration.Rule.LayoutModeRule.fromJson(v.rule),
                rule.invalidData and VisibilityConfiguration.Rule.InvalidDataRule.fromJson(v.rule),
                rule.secondarySpeed and VisibilityConfiguration.Rule.SecondarySpeedRule.fromJson(v.rule),
                rule.temperatureLabel and VisibilityConfiguration.Rule.TemperatureLabelRule.fromJson(v.rule),
                rule.activityState and VisibilityConfiguration.Rule.ActivityStateRule.fromJson(v.rule),
                rule.powerConsumption and VisibilityConfiguration.Rule.PowerConsumptionRule.fromJson(v.rule),
                rule.emphasizedEngineGauge and VisibilityConfiguration.Rule.EmphasizedEngineGaugeRule.fromJson(v.rule),
                rule.sideIndicator and VisibilityConfiguration.Rule.SideIndicatorRule.fromJson(v.rule),
                rule.driveMode and VisibilityConfiguration.Rule.DriveModeRule.fromJson(v.rule)
            )
        end
    end)

    return VisibilityConfiguration.new(rules)
end

return APL.LuaUtils.readOnly(VisibilityConfiguration)
