-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local APL = require "APL.APL"
local flux = require "APL.flux"

local ValueAnimator = APL.LuaUtils.makeObject({ _type = "ValueAnimator" })







function ValueAnimator.new(f)


    local self = APL.LuaUtils.newObject(ValueAnimator, {
        _f = f,
        _tweens = {},
        _flux = APL.LuaUtils.NIL,
        _interrupted = false
    })

    return self
end






function ValueAnimator:destroy()


    if self._flux then
        self._flux:stop()
    end
end






function ValueAnimator:stop()


    if self._flux then
        self._flux:stop()
        self._flux = nil
        self._interrupted = true
    end
end









function ValueAnimator:animate(value, duration, animationDamping)




    duration = duration or 0
    animationDamping = animationDamping == true

    self._tweens.value = self._tweens.value or value

    if self._flux then
        self._flux:stop()
        self._flux = nil
    end

    local wasInterrupted = self._interrupted
    self._interrupted = false



    if self._tweens.value == value or (duration <= 0 and not animationDamping) or wasInterrupted then
        self._tweens.value = value
        self._f(value)
        return self
    end

    if animationDamping then
        duration = ValueAnimator.dampingDuration(value, self._tweens.value, duration)
    end

    self._flux = flux.to(self._tweens, duration, { value = value })
        :onupdate(function()
            self._f(self._tweens.value)
        end)

    return self
end









function ValueAnimator.dampingDuration(newValue, previousValue, minDuration)




    local dampingThreshold = 0.04 -- 10.8 degrees of the radial progress.
    local maxDuration = 0.25

    local delta = math.abs(previousValue - newValue)
    local deltaRatioSquared = (delta / dampingThreshold) * (delta / dampingThreshold)
    local dampRatio = 1 - math.min(1, deltaRatioSquared)
    local dampingDuration = minDuration + dampRatio * (maxDuration - minDuration)

    return dampingDuration
end






function ValueAnimator:getLastValue()


    return self._tweens.value
end


return APL.LuaUtils.readOnly(ValueAnimator)
