-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local AppearanceController = require "AppearanceController"
local DigiBarCommonLayoutUtils = require "DigiBarCommonLayoutUtils"
local DigiBarBackgroundConfiguration = require "DigiBarBackgroundConfiguration"
local GaugeColor = require "GaugeColor"
local DigiBarLinearLayout = require "DigiBarLinearLayout"
local DigiBarRadialLayout = require "DigiBarRadialLayout"
local Layer = require "APL.Layer"

local DigiBarBackground = APL.LuaUtils.makeObject({ _type = "DigiBarBackground" })












function DigiBarBackground.newDigiBarBackground(appearanceController, stateController, startController, endController, configuration, name) -- TODO: Consolidate DigiBarProgressGauge and this because they're very similar







    local trackLayout
    if configuration.type == DigiBarBackgroundConfiguration.TYPE.RADIAL then
        if configuration.radialType == DigiBarBackgroundConfiguration.RADIAL_TYPE.DIGIBAND then
            trackLayout = DigiBarCommonLayoutUtils.getDigiBandBackgroundLayout(configuration.style)
        elseif configuration.radialType == DigiBarBackgroundConfiguration.RADIAL_TYPE.PLATTER then
            trackLayout = DigiBarBackground.getPlatterLayout(configuration.style)
        elseif configuration.radialType == DigiBarBackgroundConfiguration.RADIAL_TYPE.DIGIRING or configuration.radialType == DigiBarBackgroundConfiguration.RADIAL_TYPE.DIGIBAND_INTEGRATED then
            trackLayout = DigiBarCommonLayoutUtils.getDigiBarLayoutExtended(configuration.style, DigiBarRadialLayout, 0, 0, 0)
        else

        end
    elseif configuration.type == DigiBarBackgroundConfiguration.TYPE.LINEAR then
        trackLayout = DigiBarCommonLayoutUtils.getDigiBarLayoutExtended(configuration.style, DigiBarLinearLayout, 0, 0, 0)
    else

    end

    local layer, setFrame, setState, setProgressValue = DigiBarBackground._createDigiBarBackground(configuration, trackLayout, name)

    local lastState = stateController and stateController:getState()
    local lastAppearance = appearanceController:getState()
    if stateController then
        stateController:setUpdateHandler(function(state)
            lastState = state
            setState(lastState, lastAppearance)
        end)
    end

    appearanceController:setUpdateHandler(function(state)
        lastAppearance = state
        setState(lastState, lastAppearance)
    end)

    local lastStrokeStart = 0
    local lastStrokeEnd = 1
    if startController then


        startController:setUpdateHandler(function(value)
            lastStrokeStart = value
            setProgressValue(lastStrokeStart, lastStrokeEnd)
        end)
    end
    if endController then


        endController:setUpdateHandler(function(value)
            lastStrokeEnd = value
            setProgressValue(lastStrokeStart, lastStrokeEnd)
        end)
    end

    return DigiBarBackground._create({ stateController, startController, endController }, layer, setFrame, setState, setProgressValue)
end











function DigiBarBackground._create(controllers, rootLayer, setFrame, setState, setProgressValue)






    return APL.LuaUtils.newObject(DigiBarBackground, {
        _controllers = controllers,
        _rootLayer = rootLayer,
        _setFrame = setFrame,
        _setProgressValue = setProgressValue,
        _setState = setState
    })
end








function DigiBarBackground.getPlatterLayout(barStyle)


    return function(frame)

        local inset = barStyle.platterInset
        local digiBarFrame = frame
            :insetBy(inset, inset, inset, inset)
            :centeredMinSquare()
        local circlePath = APL.Path.new()
            :ellipseIn(digiBarFrame:minSquare())

        return digiBarFrame, circlePath
    end
end









function DigiBarBackground._createDigiBarBackground(backgroundConfiguration, getTrackLayout, name)




    local rootLayer = APL.Layer.new()
        :setName(name)
    local colorIDs = backgroundConfiguration.colorIDs

    local setBackgroundFrames = {}
    local setStates = {}
    if backgroundConfiguration.blurConfiguration then
        local radius = backgroundConfiguration.blurConfiguration.radius
        local blurLayer

        if radius > 0 then
            local blur = APL.BlurFilter.new()
                :setRadius(radius)
                :setNormalizedEdges(true)
            blurLayer = APL.BackdropLayer.new()
                :addFilter(blur)
                :addToSuperLayer(rootLayer)
        end

        local colorID = backgroundConfiguration.blurConfiguration.colorID

        local blurColorLayer = APL.Layer.new()
            :addToSuperLayer(rootLayer)

        setStates[#setStates+1] = function(_, appearanceState)
            local color = colorID and appearanceState:getSolidColor(colorID) or GaugeColor.clear
            blurColorLayer:setBackgroundColor(color)
        end

        setBackgroundFrames[#setBackgroundFrames+1] = function(frame)
            if blurLayer then
                blurLayer:setFrame(frame)
            end
            if blurColorLayer then
                blurColorLayer:setFrame(frame)
            end
        end
    end
    if colorIDs then
        local colorLayer = APL.Layer.new()
        setBackgroundFrames[#setBackgroundFrames+1] = function(frame)
            colorLayer:setFrame(frame)
        end
        setStates[#setStates+1] = function(state, appearanceState)
            local color = state and colorIDs[state] or colorIDs[0]
            colorLayer:setBackgroundColor(appearanceState:getSolidColor(color))
        end
        rootLayer:addSublayer(colorLayer)
    end

    local digiBarMask = APL.ShapeLayer.new()
    rootLayer:setMask(digiBarMask)

    local setMaskFrame = function(trackFrame, path, lineWidth, lineCap)
        digiBarMask
            :setFrame(trackFrame)
            :setPath(path)
        if lineWidth then
           digiBarMask
                :setLineWidth(lineWidth)
                :setLineCap(lineCap)
                :setStrokeColor(GaugeColor.white)
        else
            digiBarMask:setFillColor(GaugeColor.white)
        end
    end

    local setFrame = function(frame)
        local bounds = APL.Rect.new(0, 0, frame:getSize())
        local trackFrame, path, lineWidth, lineCap, centerOffset = getTrackLayout(bounds)

        APL.LuaUtils.forEach(setBackgroundFrames, function(f)
            local horizontalExtension = lineWidth or 0
            local verticalExtension = lineWidth or 0

            if centerOffset and lineWidth and centerOffset > lineWidth then
                verticalExtension = centerOffset
            end
            f(bounds:insetBy(-horizontalExtension, -verticalExtension, -horizontalExtension, -verticalExtension))
        end)
        setMaskFrame(trackFrame, path, lineWidth, lineCap)
        rootLayer:setFrame(frame)
    end

    local function setProgressValue(strokeStart, strokeEnd)
        digiBarMask
            :setStrokeStart(strokeStart)
            :setStrokeEnd(strokeEnd)
    end

    local setState = function(state, appearance)
        APL.LuaUtils.forEach(setStates, function(f)
            f(state, appearance)
        end)
    end

    return rootLayer, setFrame, setState, setProgressValue
end






function DigiBarBackground:destroy()


    self._rootLayer:destroy()
end







function DigiBarBackground:setFrame(frame)



    self._setFrame(frame)

    return self
end






function DigiBarBackground:getRootLayer()


    return self._rootLayer
end






function DigiBarBackground:description()


    return "DigiBarBackground " .. self:getRootLayer()._nativeLayer.name
end

return APL.LuaUtils.readOnly(DigiBarBackground)