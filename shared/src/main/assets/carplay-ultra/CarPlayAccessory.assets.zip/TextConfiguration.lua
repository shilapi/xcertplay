-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local RasterFont = require "APL.RasterFont"

local TextConfiguration = APL.LuaUtils.namedObject(
    "TextConfiguration",
    { "font", "RasterFont" },
    { "colorIDs", "table" },
    { "statefulText", "table" },
    { "dataIdentifier", "string?" },
    { "colorDataIdentifier", "string?" },
    { "alignment", "number" },
    { "baselineSpacing", "number?" },
    { "redactedOverride", "string?" },
    { "redactedColorID", "string?" }
)

TextConfiguration.fromJson = function(json)
    return TextConfiguration.new(
        RasterFont.new(json.font.name),
        APL.LuaUtils.numberedKeys(json.colorIDs),
        json.statefulText,
        json.dataIdentifier,
        json.colorDataIdentifier,
        json.alignment,
        json.baselineSpacing,
        json.redactedOverride,
        json.redactedColorID
    )
end

return APL.LuaUtils.readOnly(TextConfiguration)
