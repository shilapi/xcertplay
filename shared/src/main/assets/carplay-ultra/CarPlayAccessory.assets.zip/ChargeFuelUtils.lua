-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"
local Units = require "Units"
local UnitUtils = require "UnitUtils"
local VehicleDataUpdater = require "VehicleDataUpdater"

local ChargeFuelUtils = { _type = "ChargeFuelUtils" }










function ChargeFuelUtils.remainingRangeForUpdate(update, previous, remainingRangeDataIdentifier, unitDataIdentifier)





    local update = APL.LuaUtils.merge(previous, update)
    local range = update[remainingRangeDataIdentifier]
    local unit = update[unitDataIdentifier]


    if range == nil or unit == nil or range == VehicleDataUpdater.INVALID then
        return range, unit
    end

    return range[unit], unit
end










function ChargeFuelUtils.fuelEfficiencyForUpdate(update, previous, fuelEfficiencyDataIdentifier, unitDataIdentifier)





    local update = APL.LuaUtils.merge(previous, update)
    local trips = update[fuelEfficiencyDataIdentifier]
    local unit = update[unitDataIdentifier]


    if trips == nil or unit == nil or trips == VehicleDataUpdater.INVALID then
        return trips, unit
    end

    return trips, unit
end









function ChargeFuelUtils.chargeLevelForUpdate(update, previous, chargeLevelDataIdentifier)




    local chargeLevel = APL.LuaUtils.merge(previous, update)[chargeLevelDataIdentifier]

    return chargeLevel, 0
end








function ChargeFuelUtils.progressNormalizer(valueDataIdentifier)
    return function(update)
        local value = update[valueDataIdentifier]
        if value == nil or value == VehicleDataUpdater.INVALID then
            return nil
        end



        value = math.max(0, math.min(value, 100))

        return value / 100
    end
end

return APL.LuaUtils.readOnly(ChargeFuelUtils)