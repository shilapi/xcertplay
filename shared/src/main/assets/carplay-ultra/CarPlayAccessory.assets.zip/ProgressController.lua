-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"
local Constants = require "Constants"
local VehicleDataUpdater = require "VehicleDataUpdater"
local VehicleDataSubscriber = require "VehicleDataSubscriber"
local ValueAnimator = require "ValueAnimator"

local ProgressController = APL.LuaUtils.makeObject({ _type = "ProgressController" })












function ProgressController.new(dataIdentifiers, progressForUpdate, animationDuration, animationDamping)





    local self = APL.LuaUtils.newObject(ProgressController, {
        _dataIdentifiers = dataIdentifiers,
        _progressForUpdate = progressForUpdate,
        _animator = APL.LuaUtils.NIL,
        _lastValue = APL.LuaUtils.NIL,
        _updateHandlers = {},
        _vehicleDataSubscriber = VehicleDataSubscriber.new(),
        _animationDuration = animationDuration or 0,
        _animationDamping = animationDamping == true
    })

    self._animator = ValueAnimator.new(function(v)
        self:_notifyHandlers(v)
    end)

    return self
end






function ProgressController:destroy()


    self._animator:destroy()
    self._vehicleDataSubscriber:destroy()
end






function ProgressController:description()


    return "ProgressController (" .. APL.LuaUtils.joinStrings(self._dataIdentifiers, ", ") .. ")"
end






function ProgressController:getValue()


    return self._animator:getLastValue()
end







function ProgressController:setUpdateHandler(f)



    self._updateHandlers[f] = true

    if self._vehicleDataSubscriber:hasSubscription() then

        local lastValue = self._animator:getLastValue()
        if lastValue then
            self:_notifyHandlers(lastValue, { [f] = true })
        end
    end

    return self
end







function ProgressController:setVehicleDataUpdater(vehicleDataUpdater)



    if vehicleDataUpdater == nil then
        self._vehicleDataSubscriber:removeSubscription()
        self._animator:stop()



        if self._lastValue ~= self._animator:getLastValue() then
            self._lastValue = nil
        end
        return true
    end

    local validIdentifiers, subscriber = vehicleDataUpdater:subscribe(self._dataIdentifiers, function(update, previous)
        local update = #self._dataIdentifiers > 1 and APL.LuaUtils.merge(previous, update) or update
        local value = self._progressForUpdate(update, previous)



        if value == nil then
            self._animator:stop()
            value = 0
        end


        if self._lastValue == value then
            return
        end

        self._animator:animate(value, self._animationDuration, self._animationDamping)
        self._lastValue = value
    end)

    self._vehicleDataSubscriber:updateSubscription(vehicleDataUpdater, subscriber)

    local valid = #validIdentifiers == #self._dataIdentifiers
    return valid
end






function ProgressController:_notifyHandlers(value, handlers)




    local handlers = handlers or self._updateHandlers

    for handler, _ in pairs(handlers) do
        handler(value)
    end

    return self
end

return APL.LuaUtils.readOnly(ProgressController)
