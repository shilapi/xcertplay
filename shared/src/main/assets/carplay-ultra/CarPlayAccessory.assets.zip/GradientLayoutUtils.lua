-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local GradientLayoutUtils = { _type = "GradientLayoutUtils" }

local APL = require "APL.APL"
local AngleConfiguration = require "AngleConfiguration"

local EPSILON = 0.000001










function GradientLayoutUtils.createLayout(style, progressColors, width, extension)





    if style.angleConfiguration then
        return GradientLayoutUtils.createRadialLayout(style.angleConfiguration, progressColors, extension)
    elseif style.linearConfiguration then
        local r = GradientLayoutUtils.createLinearLayout(style.linearConfiguration, progressColors, width, extension)
        return r
    else
        APL.Log.error("GradientLayoutUtils.createLayout: bad style" .. tostring(style))

    end
end










function GradientLayoutUtils.createLinearLayout(linearConfiguration, progressColors, width, extension)





    local normalizedExtension = extension / width
    local tickProgressColors = APL.LuaUtils.map(progressColors, function(progressColor)
        local progress, color = table.unpack(progressColor)
        return { progress, color }
    end)

    APL.Log.debug(GradientLayoutUtils, function() return "tickProgressColors" .. APL.LuaUtils.prettyPrint(tickProgressColors) end)

    return {
        startPoint = { 1, 0.5 },
        endPoint = { 0, 0.5 },
        stops = GradientLayoutUtils._getSharpEdgesGradientStops(1, not linearConfiguration.isRTL, tickProgressColors)
    }
end









function GradientLayoutUtils.createRadialLayout(angleConfiguration, progressColors, extensionAngle)




    local minAngle = GradientLayoutUtils._getGradientAngle(angleConfiguration.minimumAngle)
    local minAngleExtended = minAngle + (angleConfiguration.clockwise and 1 or -1) * extensionAngle / 2
    local endpointX = 0.5 + 0.5 * math.cos(minAngleExtended)
    local endpointY = 0.5 - 0.5 * math.sin(minAngleExtended)

    local normalizedExtension = extensionAngle / AngleConfiguration.getNormalizedMinMaxAngleDelta(angleConfiguration)

    local tickProgressColors = APL.LuaUtils.map(progressColors, function(progressColor)
        local progress, color = table.unpack(progressColor)
        return { GradientLayoutUtils._progressWithRadialExtension(normalizedExtension, progress), color }
    end)
    local progressMax = AngleConfiguration.getNormalizedMinMaxAngleDelta(angleConfiguration) / APL.MathUtils.tau
    return {
        startPoint = { 0.5, 0.5 },
        endPoint = { endpointX, endpointY },
        stops = GradientLayoutUtils._getSharpEdgesGradientStops(progressMax, angleConfiguration.clockwise, tickProgressColors)
    }
end











function GradientLayoutUtils._getSharpEdgesGradientStops(progressMax, clockwiseOrLeftToRight, progressColors, epsilon)





    epsilon = epsilon or EPSILON
    local gradientMin
    local gradientMax


    if clockwiseOrLeftToRight then
        gradientMin = 1
        gradientMax = 1 - progressMax
        epsilon = -epsilon
    else
        gradientMin = 0
        gradientMax = progressMax
    end


    local getProgressGradientStop = function(gradientMin, gradientMax, progress, epsilon)
        if progress == 0 then
            return gradientMin
        else
            local gradientProgress = (gradientMax - gradientMin) * progress
            return math.min(1, math.max(0, (gradientMin + gradientProgress + epsilon)))
        end
    end

    local result = {}
    local previousProgress = -1

    for _, progressColor in pairs(progressColors) do
        local progress, color = table.unpack(progressColor)



        if progress > previousProgress + math.abs(epsilon) then
            result[getProgressGradientStop(gradientMin, gradientMax, previousProgress, epsilon)] = color
            result[getProgressGradientStop(gradientMin, gradientMax, progress, 0)] = color
            previousProgress = progress
        end
    end

    return result
end








function GradientLayoutUtils._progressWithRadialExtension(normalizedExtension, progress)



    if progress == 0 then
        return 0
    elseif progress == 1 then
        return normalizedExtension + progress
    else
        return normalizedExtension / 2 + progress
    end
end








function GradientLayoutUtils._progressWithLinearExtension(normalizedExtension, progress)



    progress = progress * (1 - normalizedExtension)
    if progress == 0 then
        return 0
    elseif progress == 1 then
        return normalizedExtension + progress
    else
        return normalizedExtension / 2 + progress
    end
end







function GradientLayoutUtils._getGradientAngle(angle)




    return math.abs(angle) ~= math.pi and -angle or math.pi + EPSILON
end

return APL.LuaUtils.readOnly(GradientLayoutUtils)
