-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local APL = require "APL.APL"
local Component = require "Component"
local Constants = require "Constants"
local Colors = require "GaugeColor"

local Zone = APL.LuaUtils.makeObject({ _type = "Zone" })












function Zone.new(id, components, frame, zoneType, shape, zoneRegion)







    local self = APL.LuaUtils.newObject(Zone, {
        _id = id,
        _isDCA = false,
        _components = components,
        _componentsById = {},
        _frame = frame,
        _activeComponentID = APL.LuaUtils.NIL,
        _rootLayer = APL.LuaUtils.NIL,
        _primaryComponentsRootLayer = APL.LuaUtils.NIL,
        _zoneRegion = zoneRegion or APL.LuaUtils.NIL
    })

    if zoneType.dca then
        self._isDCA = true
        APL.Log.info(Zone, function() return "Zone " .. tostring(id) .. " is DCA: " .. APL.LuaUtils.prettyPrint(zoneType, false, 2) end)
    end

    for _, component in ipairs(components) do
        self._componentsById[component._id] = component
    end





    local applyShape = function(layer, shape)
        APL.Log.debug(Zone, function() return "Shape for zone " .. self._id .. ": " .. APL.LuaUtils.prettyPrint(shape) end)
        if shape and shape.rectangular and shape.rectangular.cornerRadius  then
            layer
                :setBackgroundColor("#00000001") -- Workaround for rdar://105732918 (Calling setMask or setCornerRadius on a layer is causing artifacts)
                :setCornerRadius(shape.rectangular.cornerRadius)
                :setMaskToBounds(true)
        elseif shape and shape.circular then
            local bounds = APL.Rect.new(layer:getBounds())


            local path = APL.Path.new()
                :ellipseIn(bounds:centeredMinSquare())
                :closeSubpath()


            local mask = APL.ShapeLayer.new()
                :setFrame(bounds)
                :setPath(path)
                :setFillColor(Colors.white)
                :setFillRule(APL.ShapeLayer.FILLRULE.NONZERO)

            layer
                :setBackgroundColor("#00000001") -- Workaround for rdar://105732918 (Calling setMask or setCornerRadius on a layer is causing artifacts)
                :setMask(mask)
        else
            layer:setMaskToBounds(true)
        end
    end

    self._rootLayer = APL.Layer.new()
        :setFrame(frame)

    local bounds = APL.Rect.new(0, 0, frame._width, frame._height)
    APL.Log.debug(Zone, function() return "Zone %s bounds: %s", self._id, APL.LuaUtils.prettyPrint(bounds) end)



    self._primaryComponentsRootLayer = APL.Layer.new()
        :setFrame(bounds)
        :addToSuperLayer(self._rootLayer)



    if self._isDCA then
        applyShape(self._primaryComponentsRootLayer, shape)
    end


    local sortComponentByPriority = function(tbl, lhs, rhs)




        return tbl[lhs]:getZOrderPriority() < tbl[rhs]:getZOrderPriority()
    end

    for _, component in APL.LuaUtils.spairs(self._components, sortComponentByPriority) do
        local isOverlay = component:getType() == Component.TYPE.OVERLAY

        component
            :getRootLayer()
            :setVisible(isOverlay) -- Overlay components are always visible but initally showing nothing





        if not isOverlay and self._isDCA then
            applyShape(component:getRootLayer(), shape)
        end


        component:getRootLayer()
            :addToSuperLayer(isOverlay and self._rootLayer or self._primaryComponentsRootLayer)
    end


    if not self._isDCA then
        local component = APL.LuaUtils.first(self._components, function(component)
            return component:getType() == Component.TYPE.PRIMARY
        end)
        if component then
            self:setActiveComponent(component:getID())
        end
    else

        self._primaryComponentsRootLayer
            :setOpacity(0)
            :setVisible(false)

        self:setActiveComponent(nil)
    end

    return self
end






function Zone:destroy()


    APL.LuaUtils.forEach(self._components, function(component)
        component:destroy()
    end)

    self._primaryComponentsRootLayer:destroy()
    self._rootLayer:destroy()
end






function Zone:getZoneRegion()


    return self._zoneRegion
end






function Zone:getID()


    return self._id
end






function Zone:isDCA()


    return self._isDCA
end






function Zone:getComponentsByID()


    return self._componentsById
end






function Zone:getActiveComponent()


    return self._activeComponentID and self._componentsById[self._activeComponentID] or nil
end






function Zone:getPrimaryComponentIDs()


    return APL.LuaUtils.compactMap(self._components, function(component)
        if component:getType() ~= Component.TYPE.PRIMARY then
            return nil
        end

        return component:getID()
    end)
end









function Zone:setActiveComponent(componentID, animated, duration)





    local oldActiveComponent = self:getActiveComponent()
    local newActiveComponent = componentID and self._componentsById[componentID] or nil
    local oldActiveComponentID = oldActiveComponent and oldActiveComponent:getID() or nil

    if componentID == oldActiveComponentID then
        return false
    end

    if oldActiveComponent then
        self:_hideComponent(oldActiveComponent, animated, duration)
    end

    if newActiveComponent then


        self:_showComponent(newActiveComponent, animated, duration)
        self._activeComponentID = componentID


        if self._isDCA then
            APL.Log.info(Zone, function() return "Resetting transform for new active component: %s", tostring(componentID) end)
            newActiveComponent:getRootLayer()
                :setTransform(APL.Transform.newWithIdentity())
        end
    else

        self._activeComponentID = nil
    end

    APL.Log.info(Zone, function() return "Setting Zone " .. self._id .." active component: " .. tostring(oldActiveComponentID) .. " -> " .. tostring(componentID) .. " (result: " .. tostring(self._activeComponentID) .. ")" end)

    return true
end






function Zone:getRootLayer()


    return self._rootLayer
end









function Zone:showDCA(duration, delay, f)


    duration = duration or 0

    delay = delay or 0

    if self._isDCA then
        APL.Log.info(Zone, function() return "Showing DCA zone: " .. self._id end)

        if duration > 0 or delay > 0 then
            self._primaryComponentsRootLayer
                :animOpacity(1, duration)
                :ease("bezier", table.unpack(Constants.REMOTEUI_CURVE))
                :delay(delay)
                :onstart(function()




                    self._primaryComponentsRootLayer:setVisible(true)



                    local activeComponent = self:getActiveComponent()
                    if activeComponent then
                        APL.Log.info(Zone, function() return "Showing component on DCA zone " .. self._id end)
                        self:_showComponent(activeComponent, false)
                    end

                    f()
                end)
        else
            self._primaryComponentsRootLayer
                :setVisible(true)
                :setOpacity(1)
            f()
        end
    end

    return self
end







function Zone:hideDCA(duration)


    duration = duration or 0

    if self._isDCA then
        APL.Log.info(Zone, function() return "Hiding DCA zone: " .. self._id end)

        if duration > 0 then
            self._primaryComponentsRootLayer
                :animOpacity(0, duration, function()
                    self._primaryComponentsRootLayer:setVisible(false)




                    if self:getActiveComponent() then
                        self:_hideComponent(self:getActiveComponent(), false)
                    end
                end)
                :ease("bezier", table.unpack(Constants.REMOTEUI_CURVE))
        else
            self._primaryComponentsRootLayer
                :setVisible(false)
                :setOpacity(0)
        end
    end

    return self
end









function Zone:_showComponent(component, animated, duration)





    if component then
        APL.Log.info(Zone, function() return "Showing component: " .. component:description() end)

        if animated then
            component:setVisible(true)


            component:getRootLayer()
                :animOpacity(1, duration)
                :ease("bezier", table.unpack(Constants.REMOTEUI_CURVE))
        else

            component:setVisible(true, 1)
        end
    end

    return self
end









function Zone:_hideComponent(component, animated, duration)





    if component then
        APL.Log.info(Zone, function() return "Hiding component: " .. component:description() end)

        if animated then
            component:getRootLayer()
                :animOpacity(0, duration, function()
                    component:setVisible(false)
                end)
                :ease("bezier", table.unpack(Constants.REMOTEUI_CURVE))
        else

            component:setVisible(false, 1)
        end
    end

    return self
end

return APL.LuaUtils.readOnly(Zone)
