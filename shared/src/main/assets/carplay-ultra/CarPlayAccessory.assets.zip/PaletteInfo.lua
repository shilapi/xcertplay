-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Enums = require "Enums"
local ColorType = require "ColorType"


local PaletteInfo = APL.LuaUtils.namedObject(
    "PaletteInfo",
    { "id", "string" },
    { "displayName", "string" },
    { "colors", "table" }
)







function PaletteInfo.fromJson(json)



    return PaletteInfo.new(
        json.id,
        json.displayName,
        APL.LuaUtils.map(json.colors, ColorType.fromJson)
    )
end

return APL.LuaUtils.readOnly(PaletteInfo)
