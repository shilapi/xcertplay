-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"

local TransmissionState = LuaUtils.namedObject(
    "TransmissionState",
    {"mode", "number?"},
    {"position", "number?"}
)






function TransmissionState:canShowNumericalGearPosition()


    return self.mode ~= nil and self.position and self.position > 0
end






function TransmissionState:canShowRedactedState()


    return self.mode == nil or self.position == nil
end

return LuaUtils.readOnly(TransmissionState)
