-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local ChargeFuelLevelGaugeConfiguration = require "ChargeFuelLevelGaugeConfiguration"
local Constants = require "Constants"
local Enums = require "Enums"
local DriverAssistanceUtils = require "DriverAssistanceUtils"
local MeasurementLabel = require "MeasurementLabel"
local MeasurementLabelConfiguration = require "MeasurementLabelConfiguration"
local Units = require "Units"
local UnitUtils = require "UnitUtils"
local VehicleDataUpdater = require "VehicleDataUpdater"

local MeasurementLabelGauge = APL.LuaUtils.makeObject({ _type = "MeasurementLabelGauge" })













function MeasurementLabelGauge.new(measurementLabelConfiguration, controllers, appearanceController, name, initialState, normalState, imagesByState)








    local label = MeasurementLabel.new(measurementLabelConfiguration, appearanceController:getState(), name, initialState, normalState, imagesByState)

    local self = APL.LuaUtils.newObject(MeasurementLabelGauge, {
        _label = label,
        _controllers = controllers,
    })

    appearanceController:setUpdateHandler(function(state)
        self._label:setAppearanceState(state)
    end)

    return self
end









function MeasurementLabelGauge.newPrimarySpeed(measurementLabelConfiguration, controller, appearanceController)




    local self = MeasurementLabelGauge.new(measurementLabelConfiguration, { controller }, appearanceController, "PrimarySpeed")

    controller:setUpdateHandler(function(value, unit)
        self._label
            :setValue(value, true)
            :setUnit(unit, true)
            :updateLayoutIfNeeded()
    end)

    return self
end









function MeasurementLabelGauge.newSpeedUnit(measurementLabelConfiguration, controller, appearanceController)




    local self = MeasurementLabelGauge.new(measurementLabelConfiguration, { controller }, appearanceController, "SpeedUnit")

    self._label:getValueLayer():setCanRedactWhenMissingNumber(false)

    controller:setUpdateHandler(function(value, unit)

        self._label
            :setRedacted(value == VehicleDataUpdater.INVALID, true)
            :setUnit(unit, true)
            :updateLayoutIfNeeded()
    end)

    return self
end











function MeasurementLabelGauge.newRemainingChargeRange(measurementLabelConfiguration, rangeController, stateController, portSideController, appearanceController)






    local portSideIndicatorImage = measurementLabelConfiguration.statefulImages[portSideController:getState()]
    local self = MeasurementLabelGauge.new(
        measurementLabelConfiguration,
        { rangeController, stateController, portSideController },
        appearanceController,
        "RemainingChargeRange",
        stateController:getState() or Enums.FuelLevelState.NORMAL,
        Enums.FuelLevelState.NORMAL,
        { [Enums.FuelLevelState.NORMAL] = portSideIndicatorImage }
    )

    rangeController:setUpdateHandler(function(value, unit)
        self._label
            :setValue(value, true)
            :setUnit(unit, true)
            :updateLayoutIfNeeded()
    end)

    stateController:setUpdateHandler(function(state)
        self._label:setState(state)
    end)

    return self
end










function MeasurementLabelGauge.newTemperature(configuration, labelController, stateController, appearanceController)





    local self = MeasurementLabelGauge.new(
        configuration,
        { labelController, stateController },
        appearanceController,
        "EngineTemperature",
        stateController:getState() or Enums.TemperatureState.NORMAL,
        Enums.TemperatureState.NORMAL,
        configuration.statefulImages
    )

    labelController:setUpdateHandler(function(value, unit)
        self._label
            :setValue(value, true)
            :setUnit(unit, true)
            :updateLayoutIfNeeded()
    end)

    stateController:setUpdateHandler(function(state)
        self._label:setState(state)
    end)

    return self
end









function MeasurementLabelGauge.newOutsideTemperature(configuration, controller, appearanceController)




    local self = MeasurementLabelGauge.new(configuration, { controller }, appearanceController, "OutsideTemperature")

    controller:setUpdateHandler(function(value, unit)
        self._label
            :setValue(value, true)
            :setUnit(unit, true)
            :updateLayoutIfNeeded()
    end)

    return self
end











function MeasurementLabelGauge.newSpeedLimiter(configuration, labelController, stateController, speedLimitedStateController, appearanceController)






    local self = MeasurementLabelGauge.new(configuration, { labelController, stateController, speedLimitedStateController }, appearanceController, "SpeedLimiter")

    labelController:setUpdateHandler(function(value)
        self._label:setValue((value and math.floor(value)) or nil)
    end)

    local lastState
    local lastSpeedLimited
    local function setState()
        if lastState ~= nil and lastSpeedLimited ~= nil then
            self._label:setState(DriverAssistanceUtils.getState(lastState, lastSpeedLimited))
        end
    end

    stateController:setUpdateHandler(function(state)
        lastState = state
        setState()
    end)

    speedLimitedStateController:setUpdateHandler(function(speedLimited)
        lastSpeedLimited = speedLimited
        setState()
    end)

    return self
end









function MeasurementLabelGauge.newGenericLabel(measurementLabelConfiguration, controller, appearanceController, name)





    local self = MeasurementLabelGauge.new(measurementLabelConfiguration, { controller }, appearanceController, name)

    controller:setUpdateHandler(function(value, unit)
        self._label
            :setValue(value, true)
            :setUnit(unit, true)
            :updateLayoutIfNeeded()
    end)

    return self
end










function MeasurementLabelGauge.newFuelEfficiency(measurementLabelConfiguration, controller, appearanceController, name, identifier)






    local self = MeasurementLabelGauge.new(measurementLabelConfiguration, { controller }, appearanceController, name)

    controller:setUpdateHandler(function(value, unit)

        local labelValue = VehicleDataUpdater.INVALID
        if value and value ~= VehicleDataUpdater.INVALID then
            local fuelEfficiency = value[identifier]


            if fuelEfficiency and fuelEfficiency ~= VehicleDataUpdater.INVALID then
                labelValue = UnitUtils.convertFuelEfficiency(fuelEfficiency, Units.FuelEfficiency.MILLILITERS_PER_100_KILOMETERS, unit)
            end
        end

        self._label
            :setValue(labelValue, true)
            :setUnit(unit, true)
            :updateLayoutIfNeeded()
    end)

    return self
end






function MeasurementLabelGauge:destroy()

end








function MeasurementLabelGauge:setFrame(frame, skipUpdateLayout)




    self._label:setFrame(frame, skipUpdateLayout)

    return self
end






function MeasurementLabelGauge:getRootLayer()


    return self._label:getRootLayer()
end






function MeasurementLabelGauge:description()


    return "MeasurementLabelGauge " .. self._label:getRootLayer()._nativeLayer.name
end








function MeasurementLabelGauge:setUnit(unit, skipUpdateLayout)




    self._label:setUnit(unit, skipUpdateLayout)

    return self
end








function MeasurementLabelGauge:setValue(value, skipUpdateLayout)



    self._label:setValue(value, skipUpdateLayout)

    return self
end








function MeasurementLabelGauge:setRedacted(redacted, skipUpdateLayout)



    self._label:setRedacted(redacted, skipUpdateLayout)

    return self
end

return APL.LuaUtils.readOnly(MeasurementLabelGauge)
