-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Constants = require "Constants"
local DriverAssistanceUtils = require "DriverAssistanceUtils"
local VehicleDataUpdater = require "VehicleDataUpdater"
local VisibilityConfiguration = require "VisibilityConfiguration"
local TransmissionState = require "TransmissionState"
local Units = require "Units"
local VisibilityRule = require "VisibilityRule"
local VehicleDataSubscriber = require "VehicleDataSubscriber"



local VisibilityRulesCatalog = APL.LuaUtils.makeObject({ _type = "VisibilityRulesCatalog" })










function VisibilityRulesCatalog.transmissionVisible(parameters, showAnimation, hideAnimation, rule)





    local state = parameters.update[rule.dataIdentifier]


    if state == nil then
        return nil
    end



    local canShow = state:canShowRedactedState() or state:canShowNumericalGearPosition()

    local visible = (rule.rule == VisibilityConfiguration.Rule.TRANSMISSION_MODE.NUMERIC and canShow) or
        (rule.rule == VisibilityConfiguration.Rule.TRANSMISSION_MODE.NONNUMERIC and not canShow)

    return VisibilityRule.Result.newWithVisibility(visible, visible and showAnimation or hideAnimation)
end










function VisibilityRulesCatalog.remainingRangeVisible(parameters, showAnimation, hideAnimation, rule)





    local iconOnly = parameters.update[rule.dataIdentifier]
    if iconOnly == nil then
        return nil
    end



    local visible =
        (rule.rule == VisibilityConfiguration.Rule.REMAINING_RANGE_RULE.FULL and not iconOnly) or
        (rule.rule == VisibilityConfiguration.Rule.REMAINING_RANGE_RULE.ICON_ONLY and iconOnly)

    return VisibilityRule.Result.newWithVisibility(visible, visible and showAnimation or hideAnimation)
end










function VisibilityRulesCatalog.tickmarksUnitVisible(parameters, showAnimation, hideAnimation, rule)





    local showSecondarySpeed = parameters.update[rule.showSecondarySpeedIdentifier]

    if showSecondarySpeed == nil then showSecondarySpeed = parameters.previous[rule.showSecondarySpeedIdentifier] end

    if showSecondarySpeed == nil then

        return VisibilityRule.Result.newWithVisibility(false, hideAnimation)
    end

    local unit = parameters.update[rule.vehicleSpeedUnitIdentifier]

    if unit == nil then unit = parameters.previous[rule.vehicleSpeedUnitIdentifier] end

    if unit == nil then

        return VisibilityRule.Result.newWithVisibility(false, hideAnimation)
    end

    local visible =
        (not showSecondarySpeed and rule.rule == VisibilityConfiguration.Rule.TICKMARKS_SPEED_UNIT.NO_UNIT) or
        (showSecondarySpeed and rule.rule == VisibilityConfiguration.Rule.TICKMARKS_SPEED_UNIT.MPH and unit == Units.Speed.MILES_PER_HOUR) or
        (showSecondarySpeed and rule.rule == VisibilityConfiguration.Rule.TICKMARKS_SPEED_UNIT.KMH and unit == Units.Speed.KILOMETERS_PER_HOUR)

    return VisibilityRule.Result.newWithVisibility(visible, visible and showAnimation or hideAnimation)
end










function VisibilityRulesCatalog.speedLimiterVisible(parameters, showAnimation, hideAnimation, rule)






    local speedLimited = parameters.update[rule.speedLimitedIdentifier]
    if speedLimited == nil then speedLimited = parameters.previous[rule.speedLimitedIdentifier] end
    local cruiseControlState = parameters.update[rule.cruiseControlStateIdentifier]
    if cruiseControlState == nil then cruiseControlState = parameters.previous[rule.cruiseControlStateIdentifier] end

    local cruiseControlEnabled =
        cruiseControlState == DriverAssistanceUtils.CRUISE_CONTROL_STATE.INACTIVE or
        cruiseControlState == DriverAssistanceUtils.CRUISE_CONTROL_STATE.ACTIVE

    local autoHideAnimation = (cruiseControlState ~= DriverAssistanceUtils.CRUISE_CONTROL_STATE.INACTIVE and not speedLimited) and rule.autoHideAnimation or nil
    local speedLimiterRule = rule.rule


    local visible =
        (speedLimited and speedLimiterRule == VisibilityConfiguration.Rule.SPEED_LIMITER_MODE.SPEED_LIMITED and cruiseControlEnabled) or
        (not speedLimited and speedLimiterRule == VisibilityConfiguration.Rule.SPEED_LIMITER_MODE.CRUISE_CONTROL) or
        (speedLimiterRule == VisibilityConfiguration.Rule.SPEED_LIMITER_MODE.SPEED_LIMITED_OR_CRUISE_CONTROL_SET and cruiseControlEnabled) or
        (not speedLimited and speedLimiterRule == VisibilityConfiguration.Rule.SPEED_LIMITER_MODE.CRUISE_CONTROL_ACTIVATED and cruiseControlEnabled)
    local animation = visible and showAnimation or hideAnimation

    return VisibilityRule.Result.new(visible and 1 or 0, animation, autoHideAnimation)
end










function VisibilityRulesCatalog.layoutModeVisible(parameters, showAnimation, hideAnimation, rule)













    local opacity =
        rule.level < parameters.layoutMode and 1
        or rule.level == parameters.layoutMode and rule.opacity
        or 0
    local animation = opacity > 0 and showAnimation or hideAnimation
    return VisibilityRule.Result.new(opacity, animation)
end










function VisibilityRulesCatalog.invalidDataVisible(parameters, showAnimation, hideAnimation, rule)





    local value = parameters.update[rule.dataIdentifier]


    if value == nil then
        return nil
    end

    local visible = value ~= VehicleDataUpdater.INVALID

    return VisibilityRule.Result.newWithVisibility(visible, visible and showAnimation or hideAnimation)
end










function VisibilityRulesCatalog.secondarySpeedVisible(parameters, showAnimation, hideAnimation, rule)





    local secondarySpeedEnabled = parameters.update[rule.dataIdentifier]


    if secondarySpeedEnabled == nil then
        return nil
    end


    local visible = (secondarySpeedEnabled == rule.enabled)

    return VisibilityRule.Result.newWithVisibility(visible, visible and showAnimation or hideAnimation)
end










function VisibilityRulesCatalog.temperatureLabelVisible(parameters, showAnimation, hideAnimation, rule)





    local temperature = parameters.update[rule.dataIdentifier]


    if temperature == nil then
        return nil
    end

    local minTemperature = parameters.update[rule.minDataIdentifier]
    local maxTemperature = parameters.update[rule.maxDataIdentifier]


    if minTemperature == nil then minTemperature = parameters.previous[rule.minDataIdentifier] end
    if maxTemperature == nil then maxTemperature = parameters.previous[rule.maxDataIdentifier] end


    if maxTemperature == nil or minTemperature == nil then
        return nil
    end


    if minTemperature == VehicleDataUpdater.INVALID or maxTemperature == VehicleDataUpdater.INVALID or temperature == VehicleDataUpdater.INVALID then
        return VisibilityRule.Result.newWithVisibility(true, showAnimation)
    end

    local inRange = minTemperature <= temperature and temperature <= maxTemperature


    local visible =
        (rule.rule == VisibilityConfiguration.Rule.TEMPERATURE_LABEL_RULE.FULL and inRange) or
        (rule.rule == VisibilityConfiguration.Rule.TEMPERATURE_LABEL_RULE.ICON_ONLY and not inRange)

    return VisibilityRule.Result.newWithVisibility(visible, visible and showAnimation or hideAnimation)
end










function VisibilityRulesCatalog.activityStateVisible(parameters, showAnimation, hideAnimation, rule)





    local value = parameters.update[rule.dataIdentifier]


    if value == nil then
        return nil
    end

    local visible
    if rule.showWhenDeactivated then
        visible = value == rule.deactivatedValue
    else
        visible = value ~= rule.deactivatedValue
    end

    return VisibilityRule.Result.newWithVisibility(visible, visible and showAnimation or hideAnimation)
end










function VisibilityRulesCatalog.powerConsumptionVisible(parameters, showAnimation, hideAnimation, rule)





    local value = parameters.update[rule.dataIdentifier]


    if value == nil then
        return nil
    end

    local visible
    if value == VehicleDataUpdater.INVALID then

        visible = not rule.showWhenPositive
    elseif rule.showWhenPositive then
        visible = value > 0
    else
        visible = value <= 0
    end

    return VisibilityRule.Result.newWithVisibility(visible, visible and showAnimation or hideAnimation)
end










function VisibilityRulesCatalog.emphasizedEngineGaugeVisible(parameters, showAnimation, hideAnimation, rule)





    local emphasizedEngine = parameters.update[rule.emphasizedEngineGaugeDataIdentifier]
    local isSecondaryGaugeHidden = parameters.update[rule.secondaryEngineGaugeHiddenDataIdentifier]


    if emphasizedEngine == nil then emphasizedEngine = parameters.previous[rule.emphasizedEngineGaugeDataIdentifier] end
    if isSecondaryGaugeHidden == nil then isSecondaryGaugeHidden = parameters.previous[rule.secondaryEngineGaugeHiddenDataIdentifier] end

    local visible
    if rule.isSecondaryGauge then

        visible = ((rule.gaugeType ~= emphasizedEngine) and not isSecondaryGaugeHidden)
    else

        visible = (rule.gaugeType == emphasizedEngine)
    end

    return VisibilityRule.Result.newWithVisibility(visible, visible and showAnimation or hideAnimation)
end










function VisibilityRulesCatalog.sideIndicatorVisible(parameters, showAnimation, hideAnimation, rule)





    local left = parameters.update[rule.leftDataIdentifier]
    local right = parameters.update[rule.rightDataIdentifier]


    if left == nil then left = parameters.previous[rule.leftDataIdentifier] end
    if right == nil then right = parameters.previous[rule.rightDataIdentifier] end

    APL.Log.info(VisibilityRulesCatalog, function() return string.format("left: %s, right: %s", left, right) end)

    local visible
    if rule.side == VisibilityConfiguration.Rule.SIDE_INDICATOR_SIDE.LEFT then
        visible = left ~= 0
    elseif rule.side == VisibilityConfiguration.Rule.SIDE_INDICATOR_SIDE.RIGHT then
        visible = right ~= 0
    else
        APL.Log.error(VisibilityRulesCatalog, function() return string.format("Invalid side indicator side: %s", rule.side) end)

    end

    return VisibilityRule.Result.newWithVisibility(visible, visible and showAnimation or hideAnimation)
end










function VisibilityRulesCatalog.driveModeVisible(parameters, showAnimation, hideAnimation, rule)





    local hidden = parameters.update[rule.dataIdentifier]

    if hidden == nil then hidden = parameters.previous[rule.dataIdentifier] end


    local visible
    if rule.showWhenHidden then
        visible = hidden
    else
        visible = not hidden
    end
    return VisibilityRule.Result.newWithVisibility(visible, visible and showAnimation or hideAnimation)
end

return APL.LuaUtils.readOnly(VisibilityRulesCatalog)
