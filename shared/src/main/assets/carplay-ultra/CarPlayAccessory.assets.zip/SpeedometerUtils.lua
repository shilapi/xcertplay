-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"
local Enums = require "Enums"
local Ticks = require "Ticks"
local Units = require "Units"
local UnitUtils = require "UnitUtils"
local VehicleDataUpdater = require "VehicleDataUpdater"

local SpeedometerUtils = { _type = "SpeedometerUtils" }


SpeedometerUtils.MIN_LABELS_COUNT = 5
SpeedometerUtils.MAX_LABELS_COUNT = 13
SpeedometerUtils.LABEL_INTERVALS = { 10, 20, 30, 40, 50, 100, 200 }














function SpeedometerUtils.progressForUpdate(maxSpeeds, speedDataIdentifier, unitDataIdentifier, uiSceneStateDataIdentifier, useMetersPerHour)






    local maxSpeedsWithLabels = SpeedometerUtils.getMaxSpeedWithLabelsCount(maxSpeeds)

    return function(update, previous)

        local uiSceneState = update[uiSceneStateDataIdentifier] or previous[uiSceneStateDataIdentifier]

        if uiSceneState.state ~= Enums.UISceneState.DRIVE then
            return 0
        end

        local speeds = update[speedDataIdentifier]
        local unit = update[unitDataIdentifier]
        if speeds == VehicleDataUpdater.INVALID then
            return nil
        end

        return SpeedometerUtils._getNormalizedValue(speeds, maxSpeedsWithLabels.maxSpeeds, unit, useMetersPerHour)
    end
end







function SpeedometerUtils.getMaxSpeedWithLabelsCount(maxSpeeds)


    local maxSpeedsValues = {
        maxSpeeds = {},
        labelsCount = {}
    }
    for unit, maxSpeed in pairs(maxSpeeds) do
        local adjustedMaxSpeed, labelsCount = Ticks.getMaxValueWithLabelsCount(
            maxSpeed,
            SpeedometerUtils.MIN_LABELS_COUNT,
            SpeedometerUtils.MAX_LABELS_COUNT,
            SpeedometerUtils.LABEL_INTERVALS
        )
        maxSpeedsValues.maxSpeeds[unit] = adjustedMaxSpeed
        maxSpeedsValues.labelsCount[unit] = labelsCount
    end

    return maxSpeedsValues
end













function SpeedometerUtils._getNormalizedValue(speeds, maxSpeeds, unit, useMetersPerHour)





    local speed
    if useMetersPerHour then
        local rawSpeed = speeds and speeds[Units.Speed.METERS_PER_HOUR]
        if not rawSpeed then

            APL.Log.error(SpeedometerUtils, function() return "Speed in meters/hour must be provided" end)
            rawSpeed = 0
        end
        speed = UnitUtils.convertSpeed(rawSpeed, Units.Speed.METERS_PER_HOUR, unit)
    else
        speed = speeds and speeds[unit]
        if not speed then

            APL.Log.error(SpeedometerUtils, function() return "Speed in unit (" .. tostring(unit) .. ") must be provided" end)
            speed = 0
        end
    end

    local maxSpeed = maxSpeeds[unit]

    local normalizedSpeed = speed / maxSpeed

    if normalizedSpeed < 0 or normalizedSpeed > 1 then
        APL.Log.error(SpeedometerUtils, function() return string.format("Normalized speed (%d) must be in [0..1] range. speed: (%d), maxSpeed: (%d) ", normalizedSpeed, speed, maxSpeed) end)
    end

    return math.max(math.min(normalizedSpeed, 1), 0)
end










function SpeedometerUtils.displaySpeedForUpdate(update, previous, speedDataIdentifier, unitDataIdentifier)





    local update = APL.LuaUtils.merge(previous, update)
    local speed = update[speedDataIdentifier]
    local unit = update[unitDataIdentifier]


    if speed == nil or unit == nil or speed == VehicleDataUpdater.INVALID then
        return speed, unit
    end
    return speed[unit], unit
end










function SpeedometerUtils.alternativeSpeedForUpdate(update, previous, speedDataIdentifier, unitDataIdentifier)





    local update = APL.LuaUtils.merge(previous, update)
    local speed = update[speedDataIdentifier]
    local unit = update[unitDataIdentifier]
    unit = UnitUtils.getAlternateSpeedUnit(unit)


    if speed == nil or unit == nil or speed == VehicleDataUpdater.INVALID then
        return speed, unit
    end

    return speed[unit], unit
end

return APL.LuaUtils.readOnly(SpeedometerUtils)