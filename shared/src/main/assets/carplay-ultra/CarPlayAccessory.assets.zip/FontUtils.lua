-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Log = require "APL.Log"
local Asset = require "APL.Asset"

local FontUtils = { _type = "FontUtils" }







function FontUtils.createVectorFont(jsonRepresentation)


    return APL.VectorFont.new(
        jsonRepresentation.asset.postScriptName,
        jsonRepresentation.asset.familyName,
        jsonRepresentation.asset.traits,
        jsonRepresentation.asset.weight,
        jsonRepresentation.pointSize
    )
end







function FontUtils.createVectorFontManager(jsonRepresentation)






    local fontsByFamily = {}
    for family, fonts in pairs(jsonRepresentation.fontsByFamily) do


        fontsByFamily[family] = APL.LuaUtils.map(fonts, function(font)

            return APL.VectorFont.new(font.postScriptName, font.familyName, font.traits, font.weight)
        end)
    end


    local symbolLookupTable = {}

    local success1, success2, old_to_new, unicode_to_name

    APL.Log.measure(FontUtils, "Measuring symbol resources parsing", true, function()
        success1, old_to_new = pcall(function()
            local nameAliasResource = jsonRepresentation.fontResources.nameAliasResource and jsonRepresentation.fontResources.nameAliasResource.filename
            local assetPath = Asset.getAssetPath(nameAliasResource)
            Log.info(FontUtils, function() return "Parsing " .. assetPath end)


            return CP.parsePlist(CP.createAssetRAW(assetPath))
        end)
        success2, unicode_to_name = pcall(function()
            local unicodeResource = jsonRepresentation.fontResources.unicodeResource and jsonRepresentation.fontResources.unicodeResource.filename
            local assetPath = Asset.getAssetPath(unicodeResource)
            Log.info(FontUtils, function() return "Parsing " .. assetPath end)


            return CP.parsePlist(CP.createAssetRAW(assetPath))
        end)
    end)

    APL.Log.measure(FontUtils, "Measuring symbol lookup creation", true, function()
        if success1 and success2 then
            local name_to_unicode = {}


            for key, value in pairs(unicode_to_name) do
                name_to_unicode[value] = key
            end





            for key, value in pairs(old_to_new) do
                symbolLookupTable[key] = name_to_unicode[value] or value
            end
            for key, value in pairs(name_to_unicode) do
                if not symbolLookupTable[key] then
                    symbolLookupTable[key] = value
                end
            end
        else
            Log.info(FontUtils, function() return "Unable to parse font resources" end)
        end
    end)

    return APL.VectorFontManager.new(
        fontsByFamily,
        jsonRepresentation.cascades,
        jsonRepresentation.defaultCascade,
        nil,
        symbolLookupTable
    )
end

return APL.LuaUtils.readOnly(FontUtils)
