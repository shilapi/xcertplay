
-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local AngleConfiguration = require "AngleConfiguration"
local PowermeterDataIdentifiers = require "PowermeterDataIdentifiers"

local ConcentricRingsConfiguration = APL.LuaUtils.namedObject(
    "ConcentricRingsConfiguration",
    { "dataIdentifiers", "PowermeterDataIdentifiers" },     -- Data identifiers to listen to
    { "ringsNumber", "number" },
    { "ringWidth", "number" },
    { "ringsGap", "number" },
    { "targetDigiBarWidth", "number" },
    { "targetDigiBarInset", "number" },
    { "spacing", "number" },
    { "inset", "number" },
    { "colorID", "string" },
    { "primaryAngleConfiguration", "AngleConfiguration" },
    { "secondaryAngleConfiguration", "AngleConfiguration" }
)







function ConcentricRingsConfiguration.fromJsonPowermeter(json)


    return ConcentricRingsConfiguration.new(
        PowermeterDataIdentifiers.fromJson(json.dataIdentifiers),
        json.ringsNumber,
        json.ringWidth,
        json.ringsGap,
        json.targetDigiBarWidth,
        json.targetDigiBarInset,
        json.spacing,
        json.inset,
        json.colorID,
        AngleConfiguration.fromJson(json.primaryAngleConfiguration),
        AngleConfiguration.fromJson(json.secondaryAngleConfiguration)
    )
end

return APL.LuaUtils.readOnly(ConcentricRingsConfiguration)