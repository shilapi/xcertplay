-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local NinePartImage = APL.LuaUtils.makeObject({ _type = "NinePartImage" })







function NinePartImage.new(config)


    local self = APL.LuaUtils.newObject(NinePartImage, {
        _rootLayer = APL.Layer.new(),
        _topLeftCorner = APL.LuaUtils.NIL,
        _topEdge = APL.LuaUtils.NIL,
        _topRightCorner = APL.LuaUtils.NIL,
        _leftEdge = APL.LuaUtils.NIL,
        _middle = APL.LuaUtils.NIL,
        _rightEdge = APL.LuaUtils.NIL,
        _bottomLeftCorner = APL.LuaUtils.NIL,
        _bottomEdge = APL.LuaUtils.NIL,
        _bottomRightCorner = APL.LuaUtils.NIL,
    })

    self._topLeftCorner = APL.ImageLayer.new()
        :setTexture(APL.Asset.loadNamedTexture(config.topLeftCorner))
        :addToSuperLayer(self._rootLayer)
    self._topEdge = APL.ImageLayer.new()
        :setTexture(APL.Asset.loadNamedTexture(config.topEdge))
        :addToSuperLayer(self._rootLayer)
    self._topRightCorner = APL.ImageLayer.new()
        :setTexture(APL.Asset.loadNamedTexture(config.topRightCorner))
        :addToSuperLayer(self._rootLayer)

    self._leftEdge = APL.ImageLayer.new()
        :setTexture(APL.Asset.loadNamedTexture(config.leftEdge))
        :addToSuperLayer(self._rootLayer)
    self._middle = config.middle and APL.ImageLayer.new()
        :setTexture(APL.Asset.loadNamedTexture(config.middle))
        :addToSuperLayer(self._rootLayer)
    self._rightEdge = APL.ImageLayer.new()
        :setTexture(APL.Asset.loadNamedTexture(config.rightEdge))
        :addToSuperLayer(self._rootLayer)

    self._bottomLeftCorner = APL.ImageLayer.new()
        :setTexture(APL.Asset.loadNamedTexture(config.bottomLeftCorner))
        :addToSuperLayer(self._rootLayer)
    self._bottomEdge = APL.ImageLayer.new()
        :setTexture(APL.Asset.loadNamedTexture(config.bottomEdge))
        :addToSuperLayer(self._rootLayer)
    self._bottomRightCorner = APL.ImageLayer.new()
        :setTexture(APL.Asset.loadNamedTexture(config.bottomRightCorner))
        :addToSuperLayer(self._rootLayer)

    return self
end






function NinePartImage:destroy()


    self._topLeftCorner:destroy()
    self._topLeftCorner = nil
    self._topEdge:destroy()
    self._topEdge = nil
    self._topRightCorner:destroy()
    self._topRightCorner = nil

    self._leftEdge:destroy()
    self._leftEdge = nil
    if self._middle then
        self._middle:destroy()
        self._middle = nil
    end
    self._rightEdge:destroy()
    self._rightEdge = nil

    self._bottomLeftCorner:destroy()
    self._bottomLeftCorner = nil
    self._bottomEdge:destroy()
    self._bottomEdge = nil
    self._bottomRightCorner:destroy()
    self._bottomRightCorner = nil

    self._rootLayer:destroy()
    self._rootLayer = nil
end







function NinePartImage:setFrame(frame)



    local _, _, oldWidth, oldHeight = self._rootLayer:getFrame()
    self._rootLayer:setFrame(frame)

    if oldWidth ~= frame._width or oldHeight ~= frame._height then
        self:_resize(frame._width, frame._height)
    end

    return self
end






function NinePartImage:getRootLayer()


    return self._rootLayer
end






function NinePartImage:getMinimiumSize()


    local cornerWidth, cornerHeight = self._topLeftCorner:getTexture():getSize()

    return (cornerWidth * 2), (cornerHeight * 2)
end







function NinePartImage:_resize(width, height)






    local cornerWidth, cornerHeight = self._topLeftCorner:getTexture():getSize()
    local horizontalEdgeWidth, horizontalEdgeHeight = self._topEdge:getTexture():getSize()
    local verticalEdgeWidth, verticalEdgeHeight = self._leftEdge:getTexture():getSize()

    local horizontalEdgeLength = width - (2 * cornerWidth)
    local verticalEdgeLength = height - (2 * cornerHeight)

    if horizontalEdgeLength < 0 then
        APL.Log.warn(NinePartImage, function() return "Invalid image width" end)
        horizontalEdgeLength = 0
    end

    if verticalEdgeLength < 0 then
        APL.Log.warn(NinePartImage, function() return "Invalid image height" end)
        verticalEdgeLength = 0
    end

    local rightColumnXOffset = cornerWidth + horizontalEdgeLength
    local bottomRowYOffset = cornerHeight + verticalEdgeLength


    self._topLeftCorner:setFrame(APL.Rect.new(0, 0, cornerWidth, cornerHeight))
    self._topEdge:setFrame(APL.Rect.new(cornerWidth, 0, horizontalEdgeLength, horizontalEdgeHeight))
    self._topRightCorner:setFrame(APL.Rect.new(rightColumnXOffset, 0, cornerWidth, cornerHeight))


    self._leftEdge:setFrame(APL.Rect.new(0, cornerHeight, verticalEdgeWidth, verticalEdgeLength))
    if self._middle then
        self._middle:setFrame(APL.Rect.new(cornerWidth, cornerHeight, horizontalEdgeLength, verticalEdgeLength))
    end
    self._rightEdge:setFrame(APL.Rect.new(rightColumnXOffset, cornerHeight, verticalEdgeWidth, verticalEdgeLength))


    self._bottomLeftCorner:setFrame(APL.Rect.new(0, bottomRowYOffset, cornerWidth, cornerHeight))
    self._bottomEdge:setFrame(APL.Rect.new(cornerWidth, bottomRowYOffset, horizontalEdgeLength, horizontalEdgeHeight))
    self._bottomRightCorner:setFrame(APL.Rect.new(rightColumnXOffset, bottomRowYOffset, cornerWidth, cornerHeight))

    return self
end

return APL.LuaUtils.readOnly(NinePartImage)