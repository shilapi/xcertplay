-- Copyright © 2021-2026 Apple, Inc. All rights reserved.












local APL = require "APL.APL"
local Constants = require "Constants"
local Signpost = require "APL.Signpost"
local VehicleDataUpdater = require "VehicleDataUpdater"
local VehicleDataSubscriber = require "VehicleDataSubscriber"
local RequestContentState = require "RequestContentState"

local RequestTemporaryContentController = APL.LuaUtils.makeObject({ _type = "RequestTemporaryContentController" })








function RequestTemporaryContentController.new(zoneRegion, displayPanelIdentifier)



    local self = APL.LuaUtils.newObject(RequestTemporaryContentController, {
        _zoneRegion = zoneRegion, -- Enums.DisplayZoneIdentifier.ZONE_1 or Enums.DisplayZoneIdentifier.ZONE_2
        _displayPanelIdentifier = displayPanelIdentifier, -- "Cluster_Display"
        _requestContentState = APL.LuaUtils.NIL, -- The most recent state set by the RequestTemporaryContent service
        _dynamicContentState = APL.LuaUtils.NIL, -- The most recent state set by the DynamicContentElement service
        _requestTemporaryContentDataIdentifier = VehicleDataUpdater.DATAIDENTIFIERS.requestTemporaryContent,
        _dynamicContentElementDataIdentifier = VehicleDataUpdater.DATAIDENTIFIERS.dynamicContentElement,
        _vehicleDataSubscriber = VehicleDataSubscriber.new(),
        _vehicleDataUpdater = APL.LuaUtils.NIL,
        _lastValue = APL.LuaUtils.NIL,
        _requestContentSubscribers = {}
    })

    return self
end






function RequestTemporaryContentController:getZoneRegion()


    return self._zoneRegion
end






function RequestTemporaryContentController:getDisplayPanelIdentifier()


    return self._displayPanelIdentifier
end







function RequestTemporaryContentController:destroy()


    self._vehicleDataSubscriber:destroy()
    self._vehicleDataSubscriber = nil
    self._vehicleDataUpdater = nil
    self._requestContentSubscribers = nil
end







function RequestTemporaryContentController:setVehicleDataUpdater(vehicleDataUpdater)



    if vehicleDataUpdater == nil then
        self._vehicleDataSubscriber:removeSubscription()
        self._requestContentState = nil
        return true
    end

    local identifiers = { self._requestTemporaryContentDataIdentifier, self._dynamicContentElementDataIdentifier }
    local validIdentifiers, subscriber = vehicleDataUpdater:subscribe(identifiers, function(update)
        self:_updateSubscribers(update)
    end)

    self._vehicleDataSubscriber:updateSubscription(vehicleDataUpdater, subscriber)
    self._vehicleDataUpdater = vehicleDataUpdater

    return #validIdentifiers == #identifiers
end






function RequestTemporaryContentController:publishLatestValues()


    local value = self:_getLatestState()
    if value and value ~= self._lastValue then
        self._lastValue = value
        self:_setPrimaryValue(self._lastValue)
    end

    return self
end







function RequestTemporaryContentController:_updateSubscribers(update)


    local data = update[self._requestTemporaryContentDataIdentifier]

    local valuesForDisplayPanel = data and data[self._displayPanelIdentifier] or nil
    local requestContentState = valuesForDisplayPanel and valuesForDisplayPanel[self._zoneRegion] or nil
    if requestContentState ~= nil then



        self._requestContentState = requestContentState
    end

    local elementData = update[self._dynamicContentElementDataIdentifier]

    local valuesForDisplayPanel = elementData and elementData[self._displayPanelIdentifier] or nil
    local dynamicContentState = valuesForDisplayPanel and valuesForDisplayPanel[self._zoneRegion] or nil
    if dynamicContentState ~= nil then



        self._dynamicContentState = dynamicContentState
    end

    local value = self:_getLatestState()

    if value and (not self._lastValue or not self._lastValue:equals(value)) then
        self._lastValue = value
        self:_setPrimaryValue(value)
    end

    return self
end






function RequestTemporaryContentController:_getLatestState()


    if not self._requestContentState then
        return nil
    end

    local contentURL = self._requestContentState.contentURL
    local userDismissible = false

    if self._dynamicContentState and self._requestContentState.contentURL == "dynamicContentElement://" then
        contentURL = self._dynamicContentState.contentURL
        userDismissible = self._dynamicContentState.userDismissible
    end

    local state = RequestContentState.new(
        contentURL,
        self._requestContentState.on,
        userDismissible,
        self._requestContentState.zoneRegion
    )

    return state
end






function RequestTemporaryContentController:isZoneSupported()



    local _, data = next(self._vehicleDataUpdater:getData({ self._requestTemporaryContentDataIdentifier }))
    local valuesForDisplayPanel = data and data[self._displayPanelIdentifier] or nil
    return valuesForDisplayPanel and valuesForDisplayPanel[self._zoneRegion] ~= nil or false
end






function RequestTemporaryContentController:description()


    return "RequestTemporaryContentController: " .. APL.LuaUtils.prettyPrint(self._lastValue)
end









function RequestTemporaryContentController:_setPrimaryValue(state)



    APL.Log.info(RequestTemporaryContentController, function() return "Publishing latest values to subscribers" end)
    for subscriber, _ in pairs(self._requestContentSubscribers) do
        subscriber.f(state, table.unpack(subscriber.args))
    end

    return self
end








function RequestTemporaryContentController:subscribe(f, ...)



    local subscriber = APL.LuaUtils.readOnly({
        f = f,
        args = {...}
    })

    self._requestContentSubscribers[subscriber] = true

    return subscriber
end







function RequestTemporaryContentController:unsubscribe(subscriber)



    self._requestContentSubscribers[subscriber] = nil

    return self
end









function RequestTemporaryContentController:dismissContent()


    if self._vehicleDataUpdater then
        local _, requestContentStates = next(self._vehicleDataUpdater:getData({ self._requestTemporaryContentDataIdentifier }))
        requestContentStates = requestContentStates[self._displayPanelIdentifier]

        for _, requestContent in pairs(requestContentStates) do
            if requestContent.on and self._requestContentState.zoneRegion == requestContent.zoneRegion then
                APL.Log.info(RequestTemporaryContentController, function() return "User dismissed requestContent. Current requestContent URL: " .. APL.LuaUtils.prettyPrint(requestContent) end)

                local newState = requestContent:copy()
                newState.on = false
                self._vehicleDataUpdater:setData({ [self._requestTemporaryContentDataIdentifier] = newState })
            end
        end
    end

    return self
end

return APL.LuaUtils.readOnly(RequestTemporaryContentController)