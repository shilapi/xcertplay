-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Constants = require "Constants"

local MeasurementLabelConfiguration = APL.LuaUtils.namedObject(
    "MeasurementLabelConfiguration",
    { "font", "RasterFont" },
    { "iconColorIDs", "table" },
    { "valueColorIDs", "table" },
    { "unitColorIDs", "table" },
    { "iconRedactedColorID", "string" },
    { "valueRedactedColorID", "string" },
    { "unitRedactedColorID", "string" },
    { "precision", "number" },
    { "minFractionDigits", "number" },
    { "minIntegerDigits", "number" },
    { "divider", "number" },
    { "alignment", "number" },
    { "labelSpacing", "number" },
    { "valueYOffset", "number" },
    { "offsetType", "number" },
    { "valueTracking", "number?" },
    { "defaultUnitLabel", "string?" },
    { "unitLabels", "table?" },
    { "statefulImages", "table?" },
    { "imagePadding", "number?" },
    { "unitFont", "RasterFont?" },
    { "trailingString", "string?" }
)

MeasurementLabelConfiguration.ALIGNMENT = APL.LuaUtils.readOnly {
    LEFT = 1,
    RIGHT = 2,
    CENTER = 3,

    CENTER_VALUE = 4
}


MeasurementLabelConfiguration.OFFSET_TYPE = APL.LuaUtils.readOnly {

    CENTER = 1,

    BASELINE = 2
}

MeasurementLabelConfiguration.DEFAULT_STATE = 0







function MeasurementLabelConfiguration.fromJson(jsonRepresentation)




    local font = APL.RasterFont.new(jsonRepresentation.font.name)

    local unitLabels
    if jsonRepresentation.unitLabels then
        unitLabels = {}

        for unit, label in pairs(jsonRepresentation.unitLabels) do
            local unitNumber = tonumber(unit)



            unitLabels[unitNumber] = label
        end
    end

    return MeasurementLabelConfiguration.new(
        font,
        APL.LuaUtils.numberedKeys(jsonRepresentation.colorIDs.iconColorIDs),
        APL.LuaUtils.numberedKeys(jsonRepresentation.colorIDs.valueColorIDs),
        APL.LuaUtils.numberedKeys(jsonRepresentation.colorIDs.unitColorIDs),
        jsonRepresentation.colorIDs.iconRedactedColorID,
        jsonRepresentation.colorIDs.valueRedactedColorID,
        jsonRepresentation.colorIDs.unitRedactedColorID,
        jsonRepresentation.precision,
        jsonRepresentation.minFractionDigits or jsonRepresentation.precision, -- Default to precision to add trailing zeros.
        jsonRepresentation.minIntegerDigits or 1, -- Default to 1 to avoid leading zeros.
        jsonRepresentation.divider,
        jsonRepresentation.alignment,
        jsonRepresentation.labelSpacing,
        jsonRepresentation.valueYOffset,
        jsonRepresentation.offsetType,
        jsonRepresentation.valueTracking,
        jsonRepresentation.defaultUnitLabel,
        unitLabels,
        APL.LuaUtils.numberedKeys(jsonRepresentation.statefulImages),
        jsonRepresentation.imagePadding,
        jsonRepresentation.unitFont and APL.RasterFont.new(jsonRepresentation.unitFont.name),
        jsonRepresentation.trailingString
    )
end







function MeasurementLabelConfiguration:iconColorForState(state)



    if state == nil then
        return self.iconRedactedColorID
    end

    return self.iconColorIDs[state] or self.iconColorIDs[MeasurementLabelConfiguration.DEFAULT_STATE]
end







function MeasurementLabelConfiguration:valueColorForState(state)



    if state == nil then
        return self.valueRedactedColorID
    end

    return self.valueColorIDs[state] or self.valueColorIDs[MeasurementLabelConfiguration.DEFAULT_STATE]
end







function MeasurementLabelConfiguration:unitColorForState(state)



    if state == nil then
        return self.unitRedactedColorID
    end

    return self.unitColorIDs[state] or self.unitColorIDs[MeasurementLabelConfiguration.DEFAULT_STATE]
end

return APL.LuaUtils.readOnly(MeasurementLabelConfiguration)