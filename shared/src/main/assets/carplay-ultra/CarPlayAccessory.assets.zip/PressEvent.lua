-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Enums = require "Enums"

local PressEvent = APL.LuaUtils.makeObject({ _type = "PressEvent" })

PressEvent.PHASE = APL.LuaUtils.readOnly({
    BEGIN = 0,
    END   = 1,
})
local PHASES = APL.LuaUtils.getValues(PressEvent.PHASE)

PressEvent.EVENT_TYPE = APL.LuaUtils.readOnly({
    SELECT   = Enums.UIInputDevicePurpose.SELECT,
    BACK     = Enums.UIInputDevicePurpose.BACK,
})
local EVENT_TYPES = APL.LuaUtils.getValues(PressEvent.EVENT_TYPE)








function PressEvent.new(eventType, phase)



    local self = APL.LuaUtils.newObject(PressEvent, {
        _eventType = eventType,
        _phase = phase
    })

    return self
end






function PressEvent:destroy()

end






function PressEvent:getType()


    return self._eventType
end






function PressEvent:getPhase()


    return self._phase
end

return APL.LuaUtils.readOnly(PressEvent)