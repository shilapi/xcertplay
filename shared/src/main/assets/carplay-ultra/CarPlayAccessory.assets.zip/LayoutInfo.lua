-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Palette = require "Palette"

local LayoutInfo = APL.LuaUtils.makeObject({ _type = "LayoutInfo" })

LayoutInfo.KIND = APL.LuaUtils.readOnly({
    PRIMARY = "primary",
    OVERLAY = "overlay",
    UNDERLAY = "underlay"
})

local KIND_TYPES = APL.LuaUtils.makeSet(APL.LuaUtils.getValues(LayoutInfo.KIND))










function LayoutInfo.new(id, displayName, zones, kind, layoutStyleID)






    local self = APL.LuaUtils.newObject(LayoutInfo, {
        _id = id,
        _displayName = displayName,
        _zones = zones,
        _kind = string.lower(kind),
        _layoutStyleID = layoutStyleID or APL.LuaUtils.NIL
    })

    return self
end






function LayoutInfo:getID()


    return self._id
end






function LayoutInfo:getDisplayName()


    return self._displayName
end






function LayoutInfo:getKind()


    return self._kind
end






function LayoutInfo:getZones()


    return self._zones
end







function LayoutInfo:getDefaultPaletteID(theme)



    local paletteID = theme.defaultPaletteIDs[self._layoutStyleID]

    APL.Log.warn(LayoutInfo, function() return "theme.defaultPaletteIDs: " .. self._layoutStyleID .. " " .. APL.LuaUtils.prettyPrint(theme.defaultPaletteIDs) end)

    if not paletteID then
        APL.Log.warn(LayoutInfo, function() return "No default palette ID found for layout: " .. self._id end)
    end

    return paletteID
end









function LayoutInfo:getPalette(theme, paletteID)




    paletteID = paletteID or self:getDefaultPaletteID(theme)
    local paletteInfo = theme.palettes[paletteID]


    local layoutStyle = self._layoutStyleID and theme.layoutStyles[self._layoutStyleID]

    if not layoutStyle then
        APL.Log.warn(LayoutInfo, function() return "No LayoutStyle found for id: " .. tostring(self._layoutStyleID or "nil") end)
    end


    local overrides = layoutStyle and layoutStyle.overridesByPaletteID[paletteID] or nil
    return Palette.new(paletteInfo.id, paletteInfo.displayName, paletteInfo.colors, overrides)
end






function LayoutInfo.isValidKind(kind)
    return KIND_TYPES[string.lower(kind)] ~= nil
end






function LayoutInfo:destroy()


end

return APL.LuaUtils.readOnly(LayoutInfo)
