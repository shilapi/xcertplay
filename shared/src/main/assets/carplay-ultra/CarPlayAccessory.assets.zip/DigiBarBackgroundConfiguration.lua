-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local DigiBarLinearStyle = require "DigiBarLinearStyle"
local DigiBarRadialStyle = require "DigiBarRadialStyle"
local BlurConfiguration = require "BlurConfiguration"


local DigiBarBackgroundConfiguration = APL.LuaUtils.namedObject(
    "DigiBarBackgroundConfiguration",

    { "type", "number" },

    { "radialType", "number?" },

    { "style", "*" },

    { "blurConfiguration", "BlurConfiguration?" },

    { "colorIDs", "table?" }
)

DigiBarBackgroundConfiguration.RADIAL_TYPE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "DIGIBAND",
    "PLATTER",
    "DIGIRING",
    "DIGIBAND_INTEGRATED",
}))

DigiBarBackgroundConfiguration.TYPE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "RADIAL",
    "LINEAR"
}))

DigiBarBackgroundConfiguration.fromJson = function(json)


    local trackConfiguration
    local barType
    local radialType
    if json.style.radial then
        barType = DigiBarBackgroundConfiguration.TYPE.RADIAL
        trackConfiguration = DigiBarRadialStyle.fromJson(json.style.radial.configuration)
        radialType = json.style.radial.type
    elseif json.style.linear then
        trackConfiguration = DigiBarLinearStyle.fromJson(json.style.linear.configuration)
        barType = DigiBarBackgroundConfiguration.TYPE.LINEAR
    else

    end

    local colorIDs = APL.LuaUtils.numberedKeys(json.colorIDs)


    return DigiBarBackgroundConfiguration.new(
        barType,
        radialType,
        trackConfiguration,
        json.blurConfiguration and BlurConfiguration.new(
            json.blurConfiguration.radius,
            json.blurConfiguration.colorID
        ),
        colorIDs
    )
end

return APL.LuaUtils.readOnly(DigiBarBackgroundConfiguration)