-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"

local RequestContentState = LuaUtils.makeObject({ _type = "RequestContentState" })










function RequestContentState.new(contentURL, on, userDismissible, zoneRegion)





    local self = LuaUtils.newObject(RequestContentState, {
        contentURL = contentURL,
        on = on,
        userDismissible = userDismissible,
        zoneRegion = zoneRegion -- Enums.DisplayZoneIdentifier.ZONE_1 or Enums.DisplayZoneIdentifier.ZONE_2
    })

    return self
end






function RequestContentState:destroy()

end







function RequestContentState:equals(requestContent)



    return self.contentURL == requestContent.contentURL and
        self.on == requestContent.on and
        self.userDismissible == requestContent.userDismissible and
        self.zoneRegion == requestContent.zoneRegion
end






function RequestContentState:copy()


    return RequestContentState.new(self.contentURL, self.on, self.userDismissible, self.zoneRegion)
end






function RequestContentState:description()


    return LuaUtils.prettyPrint(self)
end

return LuaUtils.readOnly(RequestContentState)
