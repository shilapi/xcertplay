-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local FontUtils = require "FontUtils"

local DynamicLocalNotificationConfiguration = APL.LuaUtils.namedObject(
    "DynamicLocalNotificationConfiguration",
    { "titleFont" , "VectorFont" },
    { "bodyFont" , "VectorFont" },
    { "symbolFont" , "VectorFont" },
    { "titleColorID" , "string" },
    { "bodyColorID" , "string" },
    { "backgroundColorID" , "string" },
    { "cornerRadius" , "number" }
)

function DynamicLocalNotificationConfiguration.fromJson(jsonRepresentation)


    return DynamicLocalNotificationConfiguration.new(
        FontUtils.createVectorFont(jsonRepresentation.titleFont),
        FontUtils.createVectorFont(jsonRepresentation.bodyFont),
        FontUtils.createVectorFont(jsonRepresentation.symbolFont),
        jsonRepresentation.titleColorID,
        jsonRepresentation.bodyColorID,
        jsonRepresentation.backgroundColorID,
        jsonRepresentation.cornerRadius
    )
end

return APL.LuaUtils.readOnly(DynamicLocalNotificationConfiguration)