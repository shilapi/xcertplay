-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local ForecastSpeedConfiguration = APL.LuaUtils.namedObject(
    "ForecastSpeedConfiguration",
    { "stateDataIdentifier", "string" },
    { "speedDataIdentifier", "string" },
    { "activeColorID", "string" },
    { "speedLabelActiveColorID", "string" }
)







function ForecastSpeedConfiguration.fromJson(jsonRepresentation)


    return ForecastSpeedConfiguration.new(
        jsonRepresentation.stateDataIdentifier,
        jsonRepresentation.speedDataIdentifier,
        jsonRepresentation.activeColorID,
        jsonRepresentation.speedLabelActiveColorID
    )
end

return APL.LuaUtils.readOnly(ForecastSpeedConfiguration)
