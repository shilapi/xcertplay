-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local FocusToken = APL.LuaUtils.makeObject({ _type = "FocusToken" })






function FocusToken.new()

    local self = APL.LuaUtils.newObject(FocusToken, {
        _tokenID = math.random(1, 10000),
        _locallyOwned = true
    })

    APL.Log.info(FocusToken, function() return "Creating new focus token: " .. self._tokenID end)

    return self
end






function FocusToken:destroy()


    APL.Log.info(FocusToken, function() return "Destroying focus token: " .. self._tokenID  end)

    self._tokenID = 0
    self._locallyOwned = false
end






function FocusToken:hasOwnership()


    return self._locallyOwned
end






function FocusToken:release()



    APL.Log.info(FocusToken, function() return "Releasing focus token: " .. self._tokenID end)

    self._locallyOwned = false

    return self
end






function FocusToken:acquire()



    APL.Log.info(FocusToken, function() return "Acquiring focus token: " .. self._tokenID end)

    self._locallyOwned = true

    return self
end






function FocusToken:getTokenID()


    return self._tokenID
end

return APL.LuaUtils.readOnly(FocusToken)