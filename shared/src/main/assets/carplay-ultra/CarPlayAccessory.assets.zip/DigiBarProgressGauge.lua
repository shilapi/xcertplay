-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local AngleConfiguration = require "AngleConfiguration"
local ConcentricRingsUtils = require "ConcentricRingsUtils"
local DigiBarCommonLayoutUtils = require "DigiBarCommonLayoutUtils"
local DigiBarCruiseControl = require "DigiBarCruiseControl"
local DigiBarRadialLayout = require "DigiBarRadialLayout"
local DriverAssistanceUtils = require "DriverAssistanceUtils"
local GaugeColor = require "GaugeColor"
local Layer = require "APL.Layer"
local ProgressBarGaugeParameters = require "ProgressBarGaugeParameters"
local Ticks = require "Ticks"

local DigiBarProgressGauge = APL.LuaUtils.makeObject({ _type = "DigiBarProgressGauge" })

DigiBarProgressGauge.EPSILON = 0.0000001















function DigiBarProgressGauge.newDigiBarProgressBar(configuration, appearanceController, strokeStartController, strokeEndController, stateController, name, progressValueModifier)









    local barStyle = configuration.style
    local colorIDs = configuration.colorsConfiguration.activeColorIDs

    local lastAppearanceState = appearanceController:getState()
    local lastColor = DigiBarCommonLayoutUtils.getSolidColor(colorIDs, lastAppearanceState)()
    local layer, setLayerFrame = DigiBarProgressGauge._createMaskedProgressLayer(barStyle, lastColor, 0, name)

    local lastFrame
    local setFrame = function(frame)
        lastFrame = frame
        setLayerFrame(frame)
    end

    local lastMultiplier = 0
    local function setProgressValue(strokeStart, strokeEnd)
        local frame = lastFrame
        if not frame then
            return
        end

        layer
            :setStrokeStart(strokeStart)
            :setStrokeEnd(strokeEnd)


        local multiplier = DigiBarProgressGauge._minDotMultiplier(math.abs(strokeEnd), configuration.minDotThreshold)
        if lastMultiplier ~= multiplier then
            lastMultiplier = multiplier
            local r, g, b, a = APL.LuaUtils.parseColor(lastColor, false)
            local newA = a * multiplier * multiplier
            local color = APL.LuaUtils.createColor(r, g, b, newA)
            local lineWidth = multiplier * barStyle.trackWidth
            layer
                :setLineWidth(lineWidth)
                :setStrokeColor(color)
        end
    end

    local lastState
    local function setState()
        local getColor = DigiBarCommonLayoutUtils.getSolidColor(colorIDs, lastAppearanceState)
        lastColor = getColor(lastState)
        layer:setStrokeColor(lastColor)
    end

    local lastStrokeStart = 0
    local lastStrokeEnd = 1
    if strokeStartController then
        strokeStartController:setUpdateHandler(function(value)
            lastStrokeStart = progressValueModifier and progressValueModifier(value) or value
            setProgressValue(lastStrokeStart, lastStrokeEnd)
        end)
    end
    if strokeEndController then
        strokeEndController:setUpdateHandler(function(value)
            lastStrokeEnd = progressValueModifier and progressValueModifier(value) or value
            setProgressValue(lastStrokeStart, lastStrokeEnd)
        end)
    end

    appearanceController:setUpdateHandler(function(state)
        lastAppearanceState = state
        setState()
    end)
    if stateController then
        stateController:setUpdateHandler(function(state)
            lastState = state
            setState()
        end)
    end

    return DigiBarProgressGauge._create({ strokeEndController, strokeStartController, stateController }, layer, setFrame, setProgressValue)
end














function DigiBarProgressGauge.newDigiBarRedlineProgress(configuration, rpmProgressController, redlineProgressController, appearanceController, stateController, name, progressValueModifier)








    local redlineConfiguration = configuration.redlineConfiguration
    local redlineBarStyle = redlineConfiguration.style

    local redlineBuilder, rpmProgressBarBuilder
    local styleName = APL.LuaUtils.getClassName(redlineBarStyle)
    if styleName == "DigiBarRadialStyle" or styleName == "DigiBarLinearStyle" then
        redlineBuilder = DigiBarProgressGauge.createDigiBarRedline
        rpmProgressBarBuilder = DigiBarProgressGauge.newDigiBarProgressBar
    elseif styleName == "DigiBarRectangularStyle" then
        redlineBuilder = DigiBarProgressGauge.createRectangularRedline
        rpmProgressBarBuilder = DigiBarProgressGauge.newRectangularGauge
    end


    local redlineBar, setFrameRedline, setProgressRedline, setRedlineAppearanceState = redlineBuilder(configuration, redlineConfiguration.colorIDs, name)
    local redlineCrossed, setFrameCrossed, setProgressCrossed, setCrossedRedlineAppearanceState = redlineBuilder(configuration, redlineConfiguration.crossedColorIDs, name)
    local rpmProgressBar = rpmProgressBarBuilder(configuration, appearanceController, nil, rpmProgressController, nil, name, progressValueModifier)
    local rpmProgressLayer = rpmProgressBar
        :getRootLayer()
        :setBlendMode(APL.Layer.BLEND_MODE.DESTOUT)






    redlineCrossed:addSublayer(redlineBar)
    redlineBar:addSublayer(rpmProgressLayer)

    local setFrame = function(frame)
        setFrameRedline(APL.Rect.new(0, 0, frame:getSize()))
        setFrameCrossed(frame)
        rpmProgressBar:setFrame(APL.Rect.new(0, 0, frame:getSize()))
    end

    local setProgressValue = function(value)
        rpmProgressBar:setProgress(value)
    end

    redlineProgressController:setUpdateHandler(function(value)
        setProgressRedline(value)
        setProgressCrossed(value)
    end)


    local lastState = stateController and stateController:getState()
    local lastAppearanceState = appearanceController:getState()
    appearanceController:setUpdateHandler(function(state)
        lastAppearanceState = state
        setRedlineAppearanceState(lastAppearanceState, lastState)
        setCrossedRedlineAppearanceState(state)
    end)

    if stateController then
        stateController:setUpdateHandler(function(state)
            lastState = state
            setRedlineAppearanceState(lastAppearanceState, lastState)
        end)
    end

    return DigiBarProgressGauge._create({ rpmProgressController, redlineProgressController }, redlineCrossed, setFrame, setProgressValue)
end









function DigiBarProgressGauge.createDigiBarRedline(configuration, colors, name)




    local redlineBar, setLayerFrame, setAppearanceState = DigiBarProgressGauge._createProgressLayer(configuration.redlineConfiguration.style, colors, 0, name)

    local lastFrame
    local setFrame = function(frame)
        lastFrame = frame
        setLayerFrame(frame)
    end

    local setProgressValue = function(value)
        local frame = lastFrame
        if not frame then
            return
        end
        redlineBar:setStrokeEnd(1)
        local progress = value - DigiBarProgressGauge.EPSILON
        redlineBar:setStrokeStart(progress)
    end

    return redlineBar, setFrame, setProgressValue, setAppearanceState
end









function DigiBarProgressGauge.createRectangularRedline(configuration, colors, name)




    local redlineBarStyle = configuration.redlineConfiguration.style
    local redlineBar = APL.Layer.new()
        :setName(name)
    local progressLayer = APL.Layer.new()
        :addToSuperLayer(redlineBar)
        :setCornerRadius(redlineBarStyle.cornerRadius)
        :setCornerCurve(redlineBarStyle.cornerCurve)

    local setAppearanceState = function(appearanceState, state)
        local color = DigiBarCommonLayoutUtils.getSolidColor(colors, appearanceState)(tonumber(state))
        progressLayer:setBackgroundColor(color)
    end

    local lastStart = 0
    local referenceFrame

    local updateProgressLayerFrame = function()
        if not referenceFrame then
            return
        end

        progressLayer:setFrame(DigiBarProgressGauge._rectangleProgressAsFrame(referenceFrame, lastStart, 1))
    end

    local setProgressValue = function(value)
        lastStart = value
        updateProgressLayerFrame()
    end

    local setFrame = function(frame)
        redlineBar:setFrame(frame)
        referenceFrame = APL.Rect.new(0, 0, frame:insetBy(configuration.trackLimitGap, 0, configuration.trackLimitGap, 0):getSize())
        updateProgressLayerFrame()
    end

    return redlineBar, setFrame, setProgressValue, setAppearanceState
end












function DigiBarProgressGauge.newDigiBandGradientProgressBar(configuration, progressController, appearanceController, stateController, name)






    local barStyle = configuration.style
    local layout = DigiBarRadialLayout
    local colorIDs = configuration.colorIDs
    local gradientLayout = layout.gradientLayout

    local digiBarMask = APL.ShapeLayer.new()
        :setStrokeColor(GaugeColor.white)
        :setLineWidth(barStyle.trackWidth)
        :setLineCap(APL.ShapeLayer.LINECAP.SQUARE)

    local gradientConfig = {
        startPoint = gradientLayout.startPoint,
        endPoint = gradientLayout.endPoint,
        stops = DigiBarCommonLayoutUtils.getGradientColor(colorIDs, appearanceController:getState())().stops
    }
    local bar = APL.GradientLayer.new(gradientLayout.kind)
        :setStartPoint(table.unpack(gradientConfig.startPoint))
        :setEndPoint(table.unpack(gradientConfig.endPoint))
        :setStops(gradientConfig.stops)
        :setBlendMode(APL.Layer.BLEND_MODE.PLUSLIGHTER)
        :setMask(digiBarMask)

    local setFrame = function(frame)


        bar:setFrame(frame)
        local trackFrame, path = DigiBarCommonLayoutUtils.getDigiBandBackgroundLayout(barStyle)(frame)
        digiBarMask
            :setFrame(trackFrame)
            :setPath(path)
    end

    local setProgressState = function()
        local progress = progressController:getValue() or 0
        local state = stateController and stateController:getState() or 0
        local appearanceState = appearanceController:getState()
        local colorID = state and colorIDs[state] or colorIDs[0]
        local color = appearanceState:getSolidColor(colorID)
        local endAngle = barStyle.angleConfiguration:getNormalizedAngleForProgress(progress)
        local pointX = 0.5 + 0.5 * math.cos(endAngle)
        local pointY = 0.5 - 0.5 * math.sin(endAngle)


        local tweenColor = function(startColor, endColor, progress)


            local startColorTable = { APL.LuaUtils.parseColor(startColor, false) }
            local endColorTable = { APL.LuaUtils.parseColor(endColor, false) }
            return APL.LuaUtils.createColor(
                startColorTable[1] + (endColorTable[1] - startColorTable[1]) * progress,
                startColorTable[2] + (endColorTable[2] - startColorTable[2]) * progress,
                startColorTable[3] + (endColorTable[2] - startColorTable[2]) * progress,
                startColorTable[4] + (endColorTable[4] - startColorTable[4]) * progress
            )
        end




        local delta = AngleConfiguration.getNormalizedMinMaxAngleDelta(barStyle.angleConfiguration)
        local fullOpacityProgress = 0.5
        local fixedColor = GaugeColor.clear
        local fixedStopOffsetFrom = 0.25
        local fixedStop = math.min(0.999, fixedStopOffsetFrom + delta / (2 * math.pi) * progress)

        local darkestProgressColor = APL.LuaUtils.setAlpha(color, 0.2)
        local brightestProgressColor = color

        local stops = {
            [0.0001] = tweenColor(darkestProgressColor, brightestProgressColor, math.min(1, progress / fullOpacityProgress)),
            [fixedStop] = fixedColor,
            [0.9999] = GaugeColor.clear
        }

        bar
            :setStartPoint(table.unpack(gradientLayout.startPoint))
            :setEndPoint(pointX, pointY)
            :setStops(stops)
    end

    progressController:setUpdateHandler(setProgressState)
    if stateController then
        stateController:setUpdateHandler(setProgressState)
    end
    appearanceController:setUpdateHandler(setProgressState)

    return DigiBarProgressGauge._create({ progressController, stateController }, bar, setFrame, setProgressState)
end

















function DigiBarProgressGauge.newTicks(progressController, appearanceController, redlineController, unitController, stateController, parameters, mode, name, progressValueModifier)









    local unit = unitController and unitController:getState() or 1


    local params = APL.LuaUtils.map(parameters, function(p)
        return Ticks.Parameters.new(p.configuration, p.configuration.style, p.ticksLayoutConfiguration, p.labelValues, 0)
    end)
    local layer, setFrame, setValue, setState, setUnit = Ticks.create(params, appearanceController:getState(), unitController and unitController:getState() or 1, mode)

    local setProgressState = function()

        local startValue = 0
        local progressValue = progressController:getValue() or 0
        local values = progressValueModifier and progressValueModifier(progressValue) or { startValue, progressValue }
        startValue, progressValue = table.unpack(values)


        local stateValue = stateController and stateController:getState() or 0
        local appearanceState = appearanceController:getState()
        local value = Ticks.Value.new(progressValue, redlineController and redlineController:getValue(), startValue)
        local state = Ticks.State.new(appearanceState, stateValue)
        setValue(value, state)
    end

    progressController:setUpdateHandler(setProgressState)

    if redlineController then
        redlineController:setUpdateHandler(setProgressState)
    end

    if unitController then
        unitController:setUpdateHandler(setUnit)
    end

    if stateController then
        stateController:setUpdateHandler(function(state)
            setState(Ticks.State.new(appearanceController:getState(), state))
        end)
    end

    appearanceController:setUpdateHandler(function(state)
        setState(Ticks.State.new(state, stateController and stateController:getState()))
    end)

    return DigiBarProgressGauge._create({ progressController, redlineController, unitController, stateController }, layer, setFrame, setProgressState)
end











function DigiBarProgressGauge.newCruiseControl(configuration, speedController, targetSpeedController, appearanceController, stateController)






    local params = ProgressBarGaugeParameters.new(configuration, nil, nil)
    local layer, setFrame, setValue, setState = DigiBarCruiseControl.createDigiBarCruiseControl(params)

    local lastValue = DigiBarCruiseControl.Value.new(0, 0)

    local function setProgressValue(value)
        lastValue = value
        setValue(value)
    end

    speedController:setUpdateHandler(function(speed)
        lastValue.vehicleSpeed = speed
        setProgressValue(lastValue)
    end)

    targetSpeedController:setUpdateHandler(function(targetSpeed)
        lastValue.targetSpeed = targetSpeed
        setProgressValue(lastValue)
    end)

    local lastState
    local lastAppearanceState
    appearanceController:setUpdateHandler(function(state)
        lastAppearanceState = state
        setState(lastState, lastAppearanceState)
    end)

    stateController:setUpdateHandler(function(state)
        lastState = DriverAssistanceUtils.getState(state, false)
        setState(lastState, lastAppearanceState)
    end)

    return DigiBarProgressGauge._create({ speedController, targetSpeedController, stateController }, layer, setFrame, setProgressValue, setState)
end











function DigiBarProgressGauge.newDigiBarProgressMask(configuration, progressController, name, progressValueModifier)





    local barStyle = configuration.style

    local layer, setLayerFrame = DigiBarProgressGauge._createMaskedProgressLayer(barStyle, GaugeColor.white, configuration.widthExtension, name)
    layer:setBlendMode(configuration.blendMode)

    local lastFrame
    local setFrame = function(frame)
        lastFrame = frame
        setLayerFrame(frame)
    end

    local function setProgressValue(value)


        local frame = lastFrame
        if not frame then
            return
        end

        layer:setStrokeEnd(progressValueModifier and progressValueModifier(value) or value)
    end

    if progressController then
        progressController:setUpdateHandler(setProgressValue)
    else
        layer:setStrokeEnd(1)
    end

    return DigiBarProgressGauge._create({ progressController }, layer, setFrame, setProgressValue)
end











function DigiBarProgressGauge.newConcentricRings(configuration, progressController, appearanceController, name)






    local ringsMaskLayer = APL.ShapeLayer.new()
        :setLineWidth(configuration.ringWidth)
        :setStrokeColor(GaugeColor.primary)
        :setLineCap(APL.ShapeLayer.LINECAP.ROUND)

    local ringsBaseLayer = APL.Layer.new()
        :setMask(ringsMaskLayer)

    local lastFrame
    local setFrame = function(frame)
        lastFrame = frame

        local ringsFrame, ringsMaskFrame, path, transform = ConcentricRingsUtils.layoutParameters(frame, configuration, 0)
        ringsBaseLayer:setFrame(ringsFrame)
        ringsMaskLayer
            :setFrame(ringsMaskFrame)
            :setPath(path)
            :setTransform(transform)
    end

    local function setProgressValue(value)


        local frame = lastFrame
        if not frame then
            return
        end
        local width = frame:getSize()
        local trackingDigiRingRadius = DigiBarRadialLayout.getTrackRadius(
            width,
            configuration.targetDigiBarWidth,
            configuration.targetDigiBarInset
        )

        local transform = ConcentricRingsUtils._getRotationTransform(
            value,
            trackingDigiRingRadius,
            configuration.targetDigiBarWidth,
            configuration.primaryAngleConfiguration,
            configuration.secondaryAngleConfiguration
        )
        ringsMaskLayer:setTransform(transform)
    end

    local function setAppearanceState(state)
        local color = state:getSolidColor(configuration.colorID)
        ringsBaseLayer:setBackgroundColor(color)
    end

    progressController:setUpdateHandler(setProgressValue)
    appearanceController:setUpdateHandler(setAppearanceState)

    return DigiBarProgressGauge._create({ progressController }, ringsBaseLayer, setFrame, setProgressValue)
end












function DigiBarProgressGauge.newRectangularGauge(configuration, appearanceController, startController, endController, stateController, name, progressValueModifier)








    APL.Log.debug(DigiBarProgressGauge, function() return "Creating DigiBarProgressGauge with configuration: " .. APL.LuaUtils.prettyPrint(configuration, false, 3) end)
    local style = configuration.style




    local rootLayer = APL.Layer.new()
        :setName(name)
    local progressLayer = APL.Layer.new()
        :addToSuperLayer(rootLayer)

    local mask
    if style.roundEdges then
        mask = APL.Layer.new()
            :setBackgroundColor(GaugeColor.white)
            :setCornerRadius(style.cornerRadius)
            :setCornerCurve(style.cornerCurve)
        rootLayer
            :setMask(mask)
    end

    if not style.roundEdges then
        progressLayer
            :setCornerRadius(style.cornerRadius)
            :setCornerCurve(style.cornerCurve)
    end

    local backdropLayer
    if style.blurConfiguration then
        local blur = APL.BlurFilter.new()
            :setRadius(style.blurConfiguration.radius)
            :setNormalizedEdges(true)
            :setHardEdges(true)
        backdropLayer = APL.BackdropLayer.new()
            :setCornerRadius(style.cornerRadius)
            :setCornerCurve(style.cornerCurve)
            :setMaskToBounds(true)
            :addFilter(blur)
            :addToSuperLayer(progressLayer)
    end

    local lastAppearance = appearanceController:getState()
    local lastState = stateController and stateController:getState() or 0
    local colorIDs = configuration.colorsConfiguration.activeColorIDs
    local setState = function()
        if not colorIDs then
            return
        end

        local color = DigiBarCommonLayoutUtils.getSolidColor(colorIDs, lastAppearance)(tonumber(lastState))
        progressLayer:setBackgroundColor(color)
    end

    local referenceFrame
    local lastStart = startController and startController:getValue() or 0
    local lastEnd = endController and endController:getValue() or 1
    local setProgressFrame = function()
        if not referenceFrame then
            return
        end

        local newFrame = DigiBarProgressGauge._rectangleProgressAsFrame(referenceFrame, lastStart, lastEnd)
        progressLayer:setFrame(newFrame)
        if style.blurConfiguration then
            backdropLayer:setFrame(newFrame)
        end
    end

    appearanceController:setUpdateHandler(function(state)
        lastAppearance = state
        setState()
    end)

    if stateController then
        stateController:setUpdateHandler(function(state)
            lastState = state
            setState()
        end)
    end

    if startController then
        startController:setUpdateHandler(function(value)
            if style.isRTL then
                lastEnd = 1 - value
            else
                lastStart = value
            end
            setProgressFrame()
        end)
    end

    local setProgressValue = function(value)
        local updatedValue = progressValueModifier and progressValueModifier(value) or value
        if style.isRTL then
            lastStart = 1 - updatedValue
        else
            lastEnd = updatedValue
        end
        setProgressFrame()
    end

    if endController then
        endController:setUpdateHandler(setProgressValue)
    end

    local setFrame = function(frame)
        rootLayer:setFrame(frame)
        referenceFrame = APL.Rect.new(0, 0, frame:getSize())

        if style.roundEdges then
            mask:setFrame(0, 0, frame:getSize())
        end

        setProgressFrame()
    end

    return DigiBarProgressGauge._create({}, rootLayer, setFrame, setProgressValue, setState)
end










function DigiBarProgressGauge._create(controllers, rootLayer, setFrame, setProgressValue, setState)






    return APL.LuaUtils.newObject(DigiBarProgressGauge, {
        _controllers = controllers,
        _rootLayer = rootLayer,
        _setFrame = setFrame,
        _setProgressValue = setProgressValue,
        _setState = setState
    })
end











function DigiBarProgressGauge._createProgressLayer(barStyle, colors, widthExtension, name)




    local barLayout = DigiBarCommonLayoutUtils.getDigiBarLayout(barStyle)

    local layer = APL.ShapeLayer.new()
        :setName(name)

    local function setFrame(frame)
        local barFrame, path, lineWidth, lineCap = barLayout.getBarLayout(barStyle, frame, 0, widthExtension)
        layer
            :setFrame(barFrame)
            :setPath(path)
            :setLineWidth(lineWidth)
            :setLineCap(lineCap)
    end

    local setAppearanceState = function(appearanceState, state)
        local statefulColors = DigiBarCommonLayoutUtils.getSolidColor(colors, appearanceState)
        local color = statefulColors(state)
        layer:setStrokeColor(color)
    end

    return layer, setFrame, setAppearanceState
end










function DigiBarProgressGauge._createMaskedProgressLayer(barStyle, color, widthExtension, name)






    local barLayout = DigiBarCommonLayoutUtils.getDigiBarLayout(barStyle)
    local layer = APL.ShapeLayer.new()
        :setName(name)
        :setStrokeColor(color)
        :setStrokeEnd(0)

    local function setFrame(frame)
        do
            local barFrame, path, lineWidth, lineCap = barLayout.getBarLayout(barStyle, frame, 0, widthExtension)
            layer
                :setFrame(barFrame)
                :setPath(path)
                :setLineWidth(lineWidth)
                :setLineCap(lineCap)
        end
    end

    return layer, setFrame
end









function DigiBarProgressGauge._minDotMultiplier(value, threshold)





    return (threshold > 0 and value < threshold)
        and (value / threshold)
        or 1
end










function DigiBarProgressGauge._rectangleProgressAsFrame(referenceFrame, startValue, endValue)




    local newX = referenceFrame._x + (referenceFrame._width * startValue)
    local newWidth = (referenceFrame._x + (referenceFrame._width * endValue)) - newX
    local newFrame = APL.Rect.new(newX, referenceFrame._y, newWidth, referenceFrame._height)
    return newFrame
end






function DigiBarProgressGauge:destroy()


    self._rootLayer:destroy()
end







function DigiBarProgressGauge:setFrame(frame)



    self._setFrame(frame)

    return self
end






function DigiBarProgressGauge:getRootLayer()


    return self._rootLayer
end






function DigiBarProgressGauge:description()


    return "DigiBarProgressGauge " .. self:getRootLayer()._nativeLayer.name
end

return APL.LuaUtils.readOnly(DigiBarProgressGauge)
