






local APL = require "APL.APL"
local OrnamentTextConfiguration = require("OrnamentTextConfiguration")

local TickLabelsConfiguration = APL.LuaUtils.namedObject(
    "TickLabelsConfiguration",
    { "inset", "number" },
    { "zeroLabelInset", "number" },
    { "maxLabelsCount", "number" },
    { "labelsFontName", "string" },
    { "continuousFill", "boolean" },
    { "hideFirstLabel", "boolean" },
    { "labelDivider", "number" },
    { "edgeLabelsShiftCount", "number" },
    { "primaryLabelColorID", "table" },
    { "secondaryLabelColorID", "table" },
    { "tertiaryLabelColorID", "table?" },
    { "labelOverrides", "table?" },
    { "ornamentTextConfiguration", "OrnamentTextConfiguration?" }
)

function TickLabelsConfiguration.fromJson(json)








    return TickLabelsConfiguration.new(
        json.inset,
        json.zeroLabelInset,
        json.maxLabelsCount,
        json.labelsFont.name,
        json.continuousFill,
        json.hideFirstLabel,
        json.labelDivider,
        json.edgeLabelsShiftCount,
        APL.LuaUtils.numberedKeys(json.labelColors.primaryColorID),
        APL.LuaUtils.numberedKeys(json.labelColors.secondaryColorID),
        APL.LuaUtils.numberedKeys(json.labelColors.tertiaryColorID),
        json.labelOverrides,
        json.ornamentTextConfiguration and OrnamentTextConfiguration.fromJson(json.ornamentTextConfiguration) or nil
    )
end

return APL.LuaUtils.readOnly(TickLabelsConfiguration)