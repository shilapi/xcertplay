-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local AngleConfiguration = require "AngleConfiguration"

local DigiBarRadialStyle = APL.LuaUtils.namedObject(
    "DigiBarRadialStyle",
    { "angleConfiguration", "AngleConfiguration" },
    { "trackWidth", "number" },
    { "trackInset", "number" },
    { "trackLineCap", "number" },
    { "platterInset", "number" }
)







function DigiBarRadialStyle.fromJson(jsonRepresentation)


    return DigiBarRadialStyle.new(
        AngleConfiguration.fromJson(jsonRepresentation.angleConfiguration),
        jsonRepresentation.trackWidth,
        jsonRepresentation.trackInset,
        jsonRepresentation.trackLineCap,
        jsonRepresentation.platterInset
    )
end

return APL.LuaUtils.readOnly(DigiBarRadialStyle)