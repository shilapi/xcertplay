-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"


local BlurConfiguration = APL.LuaUtils.namedObject(
    "BlurConfiguration",
    { "radius", "number" },

    { "colorID", "string" }
)

return APL.LuaUtils.readOnly(BlurConfiguration)