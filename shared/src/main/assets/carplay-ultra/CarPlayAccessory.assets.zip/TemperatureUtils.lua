-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"
local Units = require "Units"
local UnitUtils = require "UnitUtils"
local VehicleDataUpdater = require "VehicleDataUpdater"

local TemperatureUtils = { _type = "TemperatureUtils" }

TemperatureUtils.InitialValues = APL.LuaUtils.namedObject(
    "TemperatureUtils.InitialValues",
    { "temperature", "number?" },
    { "temperatureMin", "number" },
    { "temperatureMax", "number" },
    { "temperatureState", "number" },
    { "coldTemperatureMarker", "number?" },
    { "hotTemperatureMarker", "number?" },
    { "unit", "number" } -- one of Units.Temperature
)








function TemperatureUtils.getInitialVehicleDataValues(vehicleDataUpdater, configuration)



    local data = vehicleDataUpdater:getData({
        configuration.temperatureDataIdentifier,
        configuration.temperatureMinDataIdentifier,
        configuration.temperatureMaxDataIdentifier,
        configuration.temperatureStateDataIdentifier,
        configuration.coldTemperatureMarkerDataIdentifier,
        configuration.hotTemperatureMarkerDataIdentifier,
        configuration.temperatureUnitDataIdentifier
    })

    local temperature = data[configuration.temperatureDataIdentifier]
    local temperatureMin = data[configuration.temperatureMinDataIdentifier]
    local temperatureMax = data[configuration.temperatureMaxDataIdentifier]
    local temperatureState = data[configuration.temperatureStateDataIdentifier]
    local coldTemperatureMarker = data[configuration.coldTemperatureMarkerDataIdentifier]
    local hotTemperatureMarker = data[configuration.hotTemperatureMarkerDataIdentifier]
    local unit = data[configuration.temperatureUnitDataIdentifier]
    if temperature == nil then
        APL.Log.error(TemperatureUtils, function() return "Missing initial value for data: " .. configuration.temperatureDataIdentifier end)
        return nil
    elseif temperature == VehicleDataUpdater.INVALID then
        temperature = nil
    end
    if temperatureMin == nil then
        APL.Log.error(TemperatureUtils, function() return "Missing initial value for data: " .. configuration.temperatureMinDataIdentifier end)
        return nil
    end
    if temperatureMax == nil then
        APL.Log.error(TemperatureUtils, function() return "Missing initial value for data: " .. configuration.temperatureMaxDataIdentifier end)
        return nil
    end
    if temperatureState == nil then
        APL.Log.error(TemperatureUtils, function() return "Missing initial value for data: " .. configuration.temperatureStateDataIdentifier end)
        return nil
    end
    if unit == nil then
        APL.Log.error(TemperatureUtils, function() return "Missing initial value for data: " .. VehicleDataUpdater.DATAIDENTIFIERS.temperatureUnit end)
        return nil
    end

    return TemperatureUtils.InitialValues.new(temperature, temperatureMin, temperatureMax, temperatureState, coldTemperatureMarker, hotTemperatureMarker, unit)
end









function TemperatureUtils.progressNormalizer(initialValues, valueDataIdentifier)


    return function(update)
        local value = update[valueDataIdentifier]
        if value == nil or value == VehicleDataUpdater.INVALID then
            return nil
        end

        return TemperatureUtils.getNormalizedTemperature(
            value,
            initialValues.temperatureMin,
            initialValues.temperatureMax
        )
    end
end










function TemperatureUtils.temperatureDisplayTextForUpdate(update, previous, temperatureDataIdentifier, unitDataIdentifier)





    local update = APL.LuaUtils.merge(previous, update)
    local temperature = update[temperatureDataIdentifier]
    local unit = update[unitDataIdentifier]


    if temperature == nil or unit == nil or temperature == VehicleDataUpdater.INVALID then
        return temperature, unit
    end

    temperature = UnitUtils.convertTemperature(temperature, Units.Temperature.CELSIUS, unit)




    if unit == Units.Temperature.FAHRENHEIT then
        temperature = APL.LuaUtils.round(temperature)
    end

    return temperature, unit
end









function TemperatureUtils.getNormalizedTemperature(temperature, min, max)




    local temperatureDelta = math.abs(max - min)
    return math.max(0, math.min(1, (temperature - min) / temperatureDelta))
end

return APL.LuaUtils.readOnly(TemperatureUtils)