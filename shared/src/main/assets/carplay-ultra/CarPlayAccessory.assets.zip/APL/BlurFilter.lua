-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Filter = require "APL.Filter"
local LuaUtils = require "APL.LuaUtils"

local BlurFilter = LuaUtils.makeObject({ _type = "BlurFilter" }, Filter)






function BlurFilter.new()
    local self = LuaUtils.newObject(BlurFilter, {}, Filter.new(CP.DPBlurFilter.create()))
    return self
end






function BlurFilter:destroy()


    Filter.destroy(self)
end







function BlurFilter:setRadius(radius)



    self._nativeFilter.radius = radius

    return self
end







function BlurFilter:setHardEdges(hardEdges)



    self._nativeFilter.hardEdges = hardEdges

    return self
end







function BlurFilter:setNormalizedEdges(normalizedEdges)



    self._nativeFilter.normalizedEdges = normalizedEdges

    return self
end

return LuaUtils.readOnly(BlurFilter)
