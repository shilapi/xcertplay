-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Layer = require "APL.Layer"
local LuaUtils = require "APL.LuaUtils"

local ImageLayer = LuaUtils.makeObject({ _type = "ImageLayer" }, Layer)






function ImageLayer.new()
    local self = LuaUtils.newObject(ImageLayer, {
        _texture = LuaUtils.NIL, -- current texture
    }, Layer.new(CP.DPImageLayer.create()))

    return self
end






function ImageLayer:destroy()


    if self._texture and self:getVisible() then
       self._texture:unbind(self._nativeLayer)
    end

    self._texture = nil

    Layer.destroy(self)
end






function ImageLayer:getTint()


    local color = self._nativeLayer.tint
    return LuaUtils.createColor(color.r, color.g, color.b, color.a)
end







function ImageLayer:setTint(color)



    if color then
        local r, g, b, a  = LuaUtils.parseColor(color, false)
        local color = CP.DPColor(r, g, b, a)
        self._nativeLayer.tint = color
    else
        self._nativeLayer.tint = CP.DPColor(1, 1, 1, 1)
    end

    return self
end






function ImageLayer:getTexture()


    return self._texture
end







function ImageLayer:setTexture(texture)



    if self._texture == texture then
        return self
    end

    if self:getVisible() and self._texture then
        self._texture:unbind(self._nativeLayer)
    end

    self._texture = texture

    if self:getVisible() and texture then
        texture:bind(self._nativeLayer)
    end

    return self
end







function ImageLayer:setVisible(isVisible)



    if isVisible then
        if not self:getVisible() and self._texture then
            self._texture:bind(self._nativeLayer)
        end
    else
        if self:getVisible() and self._texture then
            self._texture:unbind(self._nativeLayer)
        end
    end

    Layer.setVisible(self, isVisible)

    return self
end

return LuaUtils.readOnly(ImageLayer)
