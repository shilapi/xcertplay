-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"

local ErrorHandler = LuaUtils.makeObject({ _type = "ErrorHandler" })

local _layer

function ErrorHandler.hasForwardedError()
    return _layer ~= nil
end

function ErrorHandler.forwardError(_error)
    local screen = CP.enumerateOutputStreams()[1]
    if not _layer and screen and CP.isForegrounded then
        local Path = require "APL.Path"
        local ShapeLayer = require "APL.ShapeLayer"
        _layer = ShapeLayer.new()
            :setLineWidth(5)
            :setStrokeColor("#FF0000FF")
            :setFillColor("#FF0000FF")
            :setLineCap(ShapeLayer.LINECAP.ROUND)

        local path = Path.new()
            :moveTo(screen.width/20, screen.height/20)
            :lineTo(screen.width * (1-1/20), screen.height * (1-1/20))
            :moveTo(screen.width * (1-1/20), screen.height/20)
            :lineTo(screen.width/20, screen.height * (1-1/20))

        _layer:setPath(path)

        CP.setRootLayer(screen.identifier, _layer:getNativeLayer())
    end

    error(_error)
end

return LuaUtils.readOnly(ErrorHandler)