-- Copyright © 2021-2026 Apple, Inc. All rights reserved.








local JSON = require "APL.json"

local Config = { _type = "Config" }

Config.NIL = {}

Config.DEFAULT_PARAMS = {
    OPTIMIZATION = {

        ENABLED = true,
    },
    LOG = {

        LEVEL = Config.NIL,

        LEVELS = Config.NIL,
    },
    SIGNPOSTS = {

        ENABLED = false,
    },
    STARTUP = {
        LAYOUT = {

            ID = Config.NIL,


            NAME = Config.NIL
        }
    },
    DEBUGGING = {
        TRANSITIONS = {

            VISUAL_FEEDBACK = false,


            MISSING_VIDEO_FRAME_COLOR = "#FF000033",


            MISSING_METADATA_COLOR = "#FFFFFF33",


            OLD_METADATA_COLOR = "#00FF0033",


            DROP_END_COMMAND = false,


            FAKE_LATE_VIDEO = false,
        }
    },
    TESTING = {
        ANIMATIONS = {

            QUICK = false
        }
    }
}

Config.PERSISTENCE_NAME = "config"

local _json = nil
local _overrides = {}










function Config.load(filename)


    local result, str = pcall(function()
        return CP.createAssetRAW(filename)
    end)


    if not result then
        return
    end

    if Config.loadFromString(str) then
        print("Config: Successfully loaded '" .. filename .. "' [" .. str .. "]")
    end
    str = nil
end







function Config.loadFromString(str)


    local _str = (str == nil or #str == 0) and "{}" or str
    local result, json = pcall(function() return JSON.decode(_str) end)
    if not result then
        print("Invalid json: " .. tostring(str or "<nil>"))
        return false
    end

    _json = json
    return true
end









function Config.applyOverrides(tbl, persist)



    _overrides = tbl or {}

    if persist then
        CP.savePersistentStorage(Config.PERSISTENCE_NAME, _overrides)
    end
end






function Config.readParam(name)



    local splitString = function(s, delimiter)



        local result = {}

        local from  = 1
        local delim_from, delim_to = string.find(s, delimiter, from, true)
        while delim_from do
            table.insert(result, string.sub(s, from, delim_from - 1))
            from = delim_to + 1
            delim_from, delim_to = string.find(s, delimiter, from, true)
        end
        table.insert(result, string.sub(s, from))

        return result
    end


    local findValue = function(tbl, path, required)
        local result = tbl
        local components = splitString(path, ".")
        for _, v in ipairs(components) do

            result = result and result[v]
        end
        if result == Config.NIL then
            result = nil
        end
        return result
    end


    local result = findValue(_overrides, name)
    if result == nil then

        result = findValue(_json, name)
    end


    if result == nil then
        result = findValue(Config.DEFAULT_PARAMS, name, true)
    end

    return result
end








function Config.reset(defaults, overrides)




    local oldDefaults = {}
    for key, value in pairs(Config.DEFAULT_PARAMS) do
        oldDefaults[key] = value
    end

    Config.DEFAULT_PARAMS = defaults
    _overrides = overrides or {}


    return oldDefaults
end


Config.load("Config.json")


pcall(function()
    local overrides = CP.loadPersistentStorage(Config.PERSISTENCE_NAME)
    Config.applyOverrides(overrides, false)
end)



return setmetatable(Config, {
    __index = Config,
    __newindex = function()
        error("write to read-only Config table")
    end
})
