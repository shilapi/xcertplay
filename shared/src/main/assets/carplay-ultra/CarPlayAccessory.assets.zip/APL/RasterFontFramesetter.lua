-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"
local Rect = require "APL.Rect"
local Transform = require "APL.Transform"
local AttributedString = require "APL.AttributedString"
local RasterFontFrame = require "APL.RasterFontFrame"

local RasterFontFramesetter = LuaUtils.makeObject({ _type = "RasterFontFramesetter" })

local function textPairIter(text)
    local iterator, data, index1 = utf8.codes(text)
    local index2 = index1 + 1 -- drop the first element

    return function()
        local val1
        local val2
        index1, val1 = iterator(data, index1)
        index2, val2 = iterator(data, index2)

        val1 = index1 and utf8.char(val1)
        val2 = index2 and utf8.char(val2)

        return (index1 or index2) and val1, val2 or nil
    end
end







function RasterFontFramesetter.new(string)



    local self = LuaUtils.newObject(RasterFontFramesetter, {
        _string = string,
    })

    return self
end






function RasterFontFramesetter:destroy()


    self._string:destroy()
    self._string = nil
end







function RasterFontFramesetter:layoutFrame(container)
    local text = self._string:getString()
    local alignment = self._string:getAlignment()
    local tracking = self._string:getTracking()
    local font = self._string:getFont()

    local layout = {}
    local transforms = {}

    local xOffset, yOffset, width, height = container._x, container._y, container._width, container._height
    local fontLayoutData = font:getLayoutData()
    local kerningTable = fontLayoutData.kerningTable
    local charData = fontLayoutData.characters
    local widths = font._widths



    local totalWidth = 0
    local character

    local i = 1
    for character, nextCharacter in textPairIter(text) do
        local advance = font:getCharacterAdvance(character) + tracking
        totalWidth = totalWidth + advance + self:getKerningValue(character, nextCharacter, kerningTable, i)
        i = i + 1
    end

    if character and not font:isMonospacedForCharacter(character) then
        local advance = font:getCharacterAdvance(character) + tracking
        totalWidth = totalWidth - advance + widths[character]
    end


    local originX = xOffset
    local originY = yOffset


    if alignment == AttributedString.ALIGNMENT.CENTER then
        originX = ((width - totalWidth) / 2) + xOffset
    elseif alignment == AttributedString.ALIGNMENT.RIGHT then
        originX = width - totalWidth + xOffset
    end




    local characterOriginY = originY + (height - fontLayoutData.height) / 2

    local minX = originX
    local maxH = 0

    local texFrame = function(textureBB)
        local x = textureBB[1][1]
        local y = textureBB[1][2]
        local w = textureBB[2][1]
        local h = textureBB[2][2]
        return Rect.new(x,y,w,h)
    end

    i = 1
    for character, nextCharacter in textPairIter(text) do
        local characterFrame = font:getCharacterBoundingBox(character)
        local characterAdvanceX = font:getCharacterAdvance(character) + tracking
        local kerningValue = self:getKerningValue(character, nextCharacter, kerningTable, i)

        layout[i] = texFrame(charData[character].textureBoundingBox)


        transforms[i] = Transform.newWithTranslation(originX + characterFrame._x - 1, characterOriginY - 1)
        maxH = math.max(maxH, characterFrame._height)

        originX = originX + characterAdvanceX + kerningValue
        i = i + 1
    end

    local boundingBox = Rect.new(minX, characterOriginY, totalWidth, maxH)
    return RasterFontFrame.new(text, font, container, layout, transforms, boundingBox, self._string:requiresContainerRasterization())
end










function RasterFontFramesetter:getKerningValue(left, right, kerningTable, index)
    if self._string:getKerning() and kerningTable then
        local kerningTableRow = kerningTable[left]
        return kerningTableRow and kerningTableRow[right] or 0
    end

    return 0
end






function RasterFontFramesetter:supportsContextualAlternates()



    return false
end

return LuaUtils.readOnly(RasterFontFramesetter)