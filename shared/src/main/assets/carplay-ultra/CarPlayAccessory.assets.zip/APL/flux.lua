


-- Copyright (c) 2016 rxi





local flux = { _version = "0.1.5" }

local LuaUtils = require "APL.LuaUtils"

flux.__index = flux
flux.tweens = {}
flux.easing = {
  linear = function(p) return p end,
  bezier = function(p, ...)
    local args = {...}

    local cachekey = ""
    for i=1, 4 do
      local v = args[i]

      cachekey = cachekey .. (#cachekey > 0 and "_" or "") .. tostring(v)
    end

    local result = function(p)
      local cx = 3 * args[1]
      local bx = 3 * (args[3] - args[1]) - cx
      local ax = 1 - cx - bx
      local cy = 3 * args[2]
      local by = 3 * (args[4] - args[2]) - cy
      local ay = 1 - cy - by

      local sampleX = function(t) return ((ax * t + bx) * t + cx) * t end
      local sampleY = function(t) return ((ay * t + by) * t + cy) * t end
      local sampleDerivativeX = function(t) return (3 * ax * t + 2 * bx) * t + cx end
      local sampleDerivativeY = function(t) return (3 * ay * t + 2 * by) * t + cy end
      local solveX = function(x, eps)
        local t0, t1, t2, x2, d2, i = 0, 0, 0, 0, 0, 0
        t2 = x

        for _ = 1, 8 do
          x2 = sampleX(t2) - x
          if math.abs(x2) < eps then
            return t2
          end
          d2 = sampleDerivativeX(t2)
          if math.abs(d2) < eps then
            break
          end
          t2 = t2 - x2 / d2
        end

        t0 = 0; t1 = 1; t2 = x
        if t2 < t0 then
          return t0
        end
        if t2 > t1 then
          return t1
        end

        i = 1024
        while t0 < t1 and i > 0 do
          i = i - 1
          x2 = sampleX(t2) - x
          if math.abs(x2) < eps then
            return t2
          end
          if x2 < 0 then
            t0 = t2
          else
            t1 = t2
          end
          t2 = (t1 - t0) * 0.5 + t0
        end
        return t2
      end

      local eps = 0.00000095367431640625
      local r = sampleY(solveX(p, eps))
      return math.floor(r / eps) * eps
    end


    local previous = math.floor(p * 60)
    local next = math.min(previous + 1, 60) / 60
    previous = previous / 60

    flux.easing.cache = flux.easing.cache or {}
    flux.easing.cache.bezier = flux.easing.cache.bezier or {}
    local cache = flux.easing.cache.bezier[cachekey] or {}
    flux.easing.cache.bezier[cachekey] = cache

    cache[previous] = cache[previous] or result(previous)
    cache[next] = cache[next] or result(next)

    if args[5] == false then
      return result(p)
    end

    return cache[previous] + (p - previous) * 60 * (cache[next] - cache[previous])
  end
}

local easing = {
  ease    = "p * p * (3.0 - 2.0 * p)",
  quad    = "p * p",
  cubic   = "p * p * p",
  quart   = "p * p * p * p",
  quint   = "p * p * p * p * p",
  expo    = "2 ^ (10 * (p - 1))",
  sine    = "-math.cos(p * (math.pi * .5)) + 1",
  circ    = "-(math.sqrt(1 - (p * p)) - 1)",
  back    = "p * p * (2.7 * p - 1.7)",
  elastic = "-(2^(10 * (p - 1)) * math.sin((p - 1.075) * (math.pi * 2) / .3))"
}

local makefunc = function(str, expr)
  local load = loadstring or load
  return load("return function(p) " .. str:gsub("%$e", expr) .. " end")()
end

LuaUtils.runWithUnlockedGlobals(function()
for k, v in pairs(easing) do
  flux.easing[k .. "in"] = makefunc("return $e", v)
  flux.easing[k .. "out"] = makefunc([[
    p = 1 - p
    return 1 - ($e)
  ]], v)
  flux.easing[k .. "inout"] = makefunc([[
    p = p * 2
    if p < 1 then
      return .5 * ($e)
    else
      p = 2 - p
      return .5 * (1 - ($e)) + .5
    end
  ]], v)
end
end)

local tween = {}
tween.__index = tween

local function makefsetter(field)
  return function(self, x)
    local mt = getmetatable(x)
    if type(x) ~= "function" and not (mt and mt.__call) then
      error("expected function or callable", 2)
    end
    local old = self[field]
    self[field] = old and function(...) old(...) x(...) end or x
    return self
  end
end

local function makesetter(field, checkfn, errmsg)
  return function(self, x, ...)
    if checkfn and not checkfn(x) then
      error(errmsg:gsub("%$x", tostring(x)), 2)
    end
    self[field] = x
    self[field .. "_args"] = {...}
    return self
  end
end

tween.ease  = makesetter("_ease",
                         function(x) return flux.easing[x] end,
                         "bad easing type '$x'")
tween.delay = makesetter("_delay",
                         function(x) return type(x) == "number" end,
                         "bad delay time; expected number")
tween.repeatcount = makesetter("_repeatcount",
                         function(x) return type(x) == "number" end,
                         "bad repeat count value; expected number")
tween.autoreverse = makesetter("_autoreverse",
                               function(x) return type(x) == "boolean" end,
                               "bad autoreverse value; expected boolean")
tween.onstart     = makefsetter("_onstart")
tween.onupdate    = makefsetter("_onupdate")
tween.oncomplete  = makefsetter("_oncomplete")

function tween.new(obj, time, vars)
  local self = setmetatable({}, tween)
  self.obj = obj
  self.rate = time > 0 and 1 / time or 0
  self.progress = time > 0 and 0 or 1
  self._delay = 0
  self._ease = "linear"
  self.interrupted = false
  self.vars = {}

  for k, v in pairs(vars) do
    if type(v) ~= "number" then
      error("bad value for key '" .. k .. "'; expected number")
    end
    self.vars[k] = v
  end
  return self
end

function tween:init()
  for k, v in pairs(self.vars) do
    local x = self.obj[k]
    if type(x) ~= "number" then
      error("bad value on object key '" .. k .. "'; expected number, got " .. type(x))
    end
    self.vars[k] = { start = x, target = v, diff = v - x }

  end
  self.inited = true
end

function tween:after(...)
  local t
  if select("#", ...) == 2 then
    t = tween.new(self.obj, ...)
  else
    t = tween.new(...)
  end
  t.parent = self.parent
  self:oncomplete(function()
    flux.add(self.parent, t)
  end)
  return t
end

function tween:stop()


  self.interrupted = true
end

function tween:join()
  while self:isBusy() do
    coroutine.yield()
  end
end

function tween:isBusy()
  return self.progress < 1 and not self.interrupted
end

function flux.group()
  return setmetatable({}, flux)
end

function flux:to(obj, time, vars)
  return flux.add(self, tween.new(obj, time, vars))
end

function flux:update(deltatime)
  for i = #self, 1, -1 do
    local t = self[i]
    if t.interrupted then
      flux.remove(self, i)
    elseif t._delay > 0 then
      t._delay = t._delay - deltatime
    else
      if not t.inited then
        flux._clear(self, t.obj, t.vars, t)
        t:init()
      end

      if t._onstart then
        t._onstart()
        t._onstart = nil
      end

      t.progress = t.progress + t.rate * deltatime
      local x = t.progress >= 1 and 1 or flux.easing[t._ease](t.progress, table.unpack(t._ease_args or {}))
      for k, v in pairs(t.vars) do
        t.obj[k] = v.start + x * v.diff
      end

      if t._onupdate then
        t._onupdate(t.obj)
      end

      if t.progress >= 1 then
        if t._repeatcount and (t._repeatcount > 1) then
          t.progress = 0
          t._repeatcount = t._repeatcount - 1

          if t._autoreverse then
            for _, v in pairs(t.vars) do
              v.diff = -v.diff
              v.start, v.target = v.target, v.start
            end
          end
        else
          flux.remove(self, i)

          if t._oncomplete then
            t._oncomplete(t.obj)
          end
        end
      end
    end
  end
end

function flux:isBusy()
  return #self > 0
end

function flux:join()
  while self:isBusy() do
    coroutine.yield()
  end
end

function flux:clear(obj, vars)
  return flux._clear(self, obj, vars or obj)
end

function flux:_clear(obj, vars, newtween)
  if not self[obj] then
    return
  end

  for t in pairs(self[obj]) do
    for k in pairs(vars) do


      if t.inited or t ~= newtween then
          t.vars[k] = nil
        end
      end


    if next(t.vars) == nil then
      t.interrupted = true
    end
  end

end

function flux:add(tween)

  local obj = tween.obj
  self[obj] = self[obj] or {}
  self[obj][tween] = true

  table.insert(self, tween)
  tween.parent = self
  return tween
end

function flux:remove(x)
  if type(x) == "number" then

    local obj = self[x].obj
    self[obj][self[x]] = nil
    if next(self[obj]) == nil then self[obj] = nil end

    return table.remove(self, x)
  end
  for i, v in ipairs(self) do
    if v == x then
      return flux.remove(self, i)
    end
  end
end

local bound = {
  to      = function(...) return flux.to(flux.tweens, ...) end,
  update  = function(...) return flux.update(flux.tweens, ...) end,
  clear   = function(...) return flux.clear(flux.tweens, ...) end,
  remove  = function(...) return flux.remove(flux.tweens, ...) end,
}
setmetatable(bound, flux)

return bound
