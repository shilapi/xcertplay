-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Layer = require "APL.Layer"
local LuaUtils = require "APL.LuaUtils"

local Filter = LuaUtils.makeObject({ _type = "Filter" }, Layer)

local allowedTypes = {
    BlurFilter = true,
    Filter = true
}


local function validateClassName(self)
    return allowedTypes[LuaUtils.getClassName(self)]
end






function Filter.new(nativeFilter)

    local allowedNativeTypes = {
        DPBlurFilter = true
    }


    local self = LuaUtils.newObject(Layer, {

        _nativeFilter = nativeFilter or CP.DPBlurFilter.create(),
    })

    return self
end






function Filter:destroy()


    self._nativeFilter:removeFromLayer()
    self._nativeFilter = nil
end







function Filter:setEnabled(enabled)



    self._nativeLayer.enabled = enabled

    return self
end

return LuaUtils.readOnly(Filter)
