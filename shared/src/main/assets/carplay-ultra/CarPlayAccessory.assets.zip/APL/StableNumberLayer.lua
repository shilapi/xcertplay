-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"
local NumberLayer = require "APL.NumberLayer"
local TextLayer = require "APL.TextLayer"
local Font = require "APL.Font"
local Rect = require "APL.Rect"
local AttributedString = require "APL.AttributedString"

local StableNumberLayer = LuaUtils.makeObject({ _type = "StableNumberLayer" }, NumberLayer)












































local function _getContainerID(number)
    local containerID = 0
    local offset = 0

    while number > 0 do
        local digit = number % 10
        number = math.floor(number / 10)

        if number > 0 then
            digit = digit == 1 and 1 or 0
        elseif offset < 100 then

            digit = digit < 2 and 1 or 2
        end

        if digit > 0 then
            containerID = containerID + (digit * offset)
        end

        offset = (offset > 0 and offset or 1) * 10
    end

    return containerID
end










local function getContainerID(number)


    if number < 200 then
        if number < 100 then
            if number >= 20 then
                return 20
            end

            return number < 10 and 0 or 10
        elseif number < 110 then
            return 100
        end

        return number >= 120 and 100 or 110
    elseif number < 300 then
        if number < 210 then
            return 200
        end

        return number >= 220 and 200 or 210
    end

    return _getContainerID(number)
end








function StableNumberLayer.new(font, name)



    local self = LuaUtils.newObject(StableNumberLayer, {
        _cachedContainers = {},
        _alignment = LuaUtils.NIL
    }, NumberLayer.new(font, name))

    self._alignment = self:getAttributedString():getAlignment()

    return self
end






function StableNumberLayer:destroy()


    NumberLayer.destroy(self)
end








function StableNumberLayer:setFrame(rect, skipUpdateLayout)





    TextLayer.setFrame(self, rect, skipUpdateLayout)

    self._cachedContainers = {}

    return self
end






function StableNumberLayer:updateLayout()




    local attributedString = self:getAttributedString()
    local number = self:getNumber()
    local isRedacted = self:isRedacted()

    local container
    local alignment


    if number == nil and not isRedacted then
        return self
    elseif isRedacted or number < 10 then
        local _, _, width, height = self:getFrame()
        container = Rect.new(0, 0, width, height)
        alignment = self._alignment
    else
        container = self:getCachedContainer(number)
        alignment = AttributedString.ALIGNMENT.LEFT
    end

    attributedString:setAlignment(alignment)

    self:setContainer(container, true)
    NumberLayer.updateLayout(self)

    return self
end






function StableNumberLayer:getBoundingRect()


    local number = self:getNumber()
    local isRedacted = self:isRedacted()
    if number ~= nil or isRedacted then
        if isRedacted or number < 10 then
            return self:getAttributedString():getBoundingRect()
        end

        return self:getCachedContainer(number)
    end

    return Rect.new(0, 0, 0, 0)
end








function StableNumberLayer:setAlignment(alignment, skipUpdateLayout)



    if self._alignment ~= alignment then
        self._alignment = alignment

        self._cachedContainers = {}

        self:setNeedsLayout()

        if not skipUpdateLayout then
            self:updateLayoutIfNeeded()
        end
    end

    return self
end






function StableNumberLayer:getCachedContainer(number)



    local bucketID = _getContainerID(number)
    local container = self._cachedContainers[bucketID]

    if container then
        return container
    end

    local _, _, width, height = self:getFrame()
    local defaultContainer = Rect.new(0, 0, width, height)

    local container = AttributedString.new(LuaUtils.numberToString(bucketID, self._maximumFractionDigits), self:getFont())
        :getBoundingRect()

    local alignedContainer = Rect.new(
        0,
        (height - container._height) / 2,
        container._width,
        container._height
    )

    if self._alignment == AttributedString.ALIGNMENT.CENTER then
        alignedContainer._x = (width - alignedContainer._width) / 2
    elseif self._alignment == AttributedString.ALIGNMENT.RIGHT then
        alignedContainer._x = width - alignedContainer._width
    end

    self._cachedContainers[bucketID] = alignedContainer
    return alignedContainer
end

return LuaUtils.readOnly(StableNumberLayer)
