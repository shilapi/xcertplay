-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"

local MathUtils = { _type = "MathUtils" }


MathUtils.tau = 2 * math.pi







function MathUtils.normalizeAngle(angle)
    return angle - (math.floor(angle / MathUtils.tau) * MathUtils.tau)
end








function MathUtils.normalizeRadialGaugeAngle(angle)


    local normalizedAngle = MathUtils.normalizeAngle(angle)
    if normalizedAngle > 3 / 2 * math.pi then
        return normalizedAngle - MathUtils.tau
    else
        return normalizedAngle
    end
end

return LuaUtils.readOnly(MathUtils)