-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"

local _defaultManager

local VectorFontManager = LuaUtils.namedObject(
    "VectorFontManager",
    { "fontsByFamily", "table" },
    { "cascades", "table" },
    { "defaultCascade", "table" },
    { "language", "string?" },
    { "symbolLookupTable", "table" }
)






function VectorFontManager.getDefaultManager()
    return _defaultManager or VectorFontManager.new({}, {}, {}, nil, {})
end






function VectorFontManager.setDefaultManager(manager)


    _defaultManager = manager
end








function VectorFontManager.getSymbolForName(manager, name)



    if not manager.symbolLookupTable then
        Log.error(VectorFontManager, function() return "No symbolLookupTable present" end)
    end

    return manager.symbolLookupTable and manager.symbolLookupTable[name]
end









function VectorFontManager.getCascade(manager, font, language)




    local language = language or manager.language
    local familyNameCascade = manager.cascades[language] or manager.defaultCascade
    local weight = font:getWeight()

    local cascade = {}
    for _, familyName in ipairs(familyNameCascade) do
        local fontsByFamily = manager.fontsByFamily[familyName] or {}
        local matchingFont

        for _, cascadeFont in ipairs(fontsByFamily) do
            if cascadeFont:getWeight() == weight then
                matchingFont = cascadeFont
                break
            end
        end

        if matchingFont then
            cascade[#cascade + 1] = matchingFont
        else
            Log.error(VectorFontManager, function() return "Unable to find matching font of family " .. familyName .. " while building cascade for " .. font:getName() .. " with language " .. tostring(language) end)
        end
    end

    return cascade
end

return LuaUtils.readOnly(VectorFontManager)