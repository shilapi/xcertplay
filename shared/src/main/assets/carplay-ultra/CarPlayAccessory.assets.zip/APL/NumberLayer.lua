-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local AttributedString = require "APL.AttributedString"
local Font = require "APL.Font"
local LuaUtils = require "APL.LuaUtils"
local TextLayer = require "APL.TextLayer"

local NumberLayer = LuaUtils.makeObject({ _type = "NumberLayer" }, TextLayer)

local allowedTypes = {
    NumberLayer = true,
    StableNumberLayer = true,
}


local function validateClassName(self)
    return allowedTypes[LuaUtils.getClassName(self)]
end








function NumberLayer.new(font, name)



    local self = LuaUtils.newObject(NumberLayer, {
        _number = LuaUtils.NIL,
        _maximumFractionDigits = 0,
        _minFractionDigits = 0,
        _minIntegerDigits = 0,
        _canRedactWhenMissingNumber = true,
    }, TextLayer.new(font, name))

    return self
end






function NumberLayer:destroy()


    TextLayer.destroy(self)
end






function NumberLayer:getNumber()


    return self._number
end








function NumberLayer:setNumber(number, skipUpdateLayout)




    if self._number ~= number then
        self._number = number

        local numberString = LuaUtils.numberToString(number, self._maximumFractionDigits, self._minFractionDigits, self._minIntegerDigits)
        self:setText(numberString, skipUpdateLayout)
    end

    return self
end








function NumberLayer:setMaximumFractionDigits(maximumFractionDigits, skipUpdateLayout)




    if self._maximumFractionDigits ~= maximumFractionDigits then
        self._maximumFractionDigits = maximumFractionDigits


        if self._number then
            local number = self._number
            self._number = nil
            self:setNumber(number, skipUpdateLayout)
        end
    end

    return self
end








function NumberLayer:setMinFractionDigits(minFractionDigits, skipUpdateLayout)




    if self._minFractionDigits ~= minFractionDigits then
        self._minFractionDigits = minFractionDigits


        if self._number then
            local number = self._number
            self._number = nil
            self:setNumber(number, skipUpdateLayout)
        end
    end

    return self
end








function NumberLayer:setMinIntegerDigits(minIntegerDigits, skipUpdateLayout)




    self._minIntegerDigits = minIntegerDigits

    if self._minIntegerDigits ~= minIntegerDigits then

        if self._number then
            local number = self._number
            self._number = nil
            self:setNumber(number, skipUpdateLayout)
        end
    end

    return self
end








function NumberLayer:setCanRedactWhenMissingNumber(canRedactWhenMissingNumber, skipUpdateLayout)




    if self._canRedactWhenMissingNumber ~= canRedactWhenMissingNumber then
        self._canRedactWhenMissingNumber = canRedactWhenMissingNumber

        if self:isRedacted() then
            self:_updateText()
        end

        if not skipUpdateLayout then
            self:updateLayoutIfNeeded()
        end
    end

    return self
end






function NumberLayer:getRedactedText()


    if self._number or self._canRedactWhenMissingNumber then
        return "--"
    end

    return ""
end

return LuaUtils.readOnly(NumberLayer)
