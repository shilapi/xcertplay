-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"

local fontTypes = {
    RasterFont = true,
    VectorFont = true
}

local Font = LuaUtils.makeObject({ _type = "Font" })







function Font.isFont(object)
    return fontTypes[LuaUtils.getClassName(object)] or false
end

return LuaUtils.readOnly(Font)