

















-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"
local Signpost = require "APL.Signpost"
local Thread = require "APL.Thread"

local Persistence = LuaUtils.makeObject({ _type = "Persistence" })













function Persistence.new(name)



    local self = LuaUtils.newObject(Persistence, {
        _name = name,
        data = {},
        _rawData = {},
        _flushAsyncThread = LuaUtils.NIL,
    })


    setmetatable(self.data, {
        __index = function(tbl, key)
            return self._rawData[key]
        end,
        __newindex = function(_, key, value)
            self._rawData[key] = value
            self:flushAsync()
        end
    })


    local status, result = pcall(function()
        return CP.loadPersistentStorage(name)
    end)
    self._rawData = status and result or {}

    if not status then
        Log.error(Persistence, function() return "Failed to load previous persistent storage " .. name end)
    end

    Log.info(Persistence, function() return "Loaded persistence: " .. LuaUtils.prettyPrint(self._rawData, false, 3) end)

    return self
end






function Persistence:destroy()



    if self._flushAsyncThread then
        self._flushAsyncThread:destroy()
    end


    self:flush()
end








function Persistence:clear()


    self._rawData = {}
    self:flushAsync()

    return self
end










function Persistence:flushAsync()


    if self._flushAsyncThread then
        return -- async flush already scheduled
    end
    self._flushAsyncThread = Thread.new(function()
        self._flushAsyncThread = nil
        self:flush()
    end)
    :setTag("persistence")
    :start()

    return self
end










function Persistence:flush()


    local status, result = Signpost.measure("Flushing persistence " .. self._name, function()
        local status, result = pcall(function()
            return CP.savePersistentStorage(self._name, self._rawData)
        end)

        return status, result
    end)

    if not status then
        Log.error(Persistence, function() return "Failed to flush persistent storage " .. self._name end)
    else
        Log.info(Persistence, function() return "Flushed persistent storage \"" .. self._name .. "\": " .. LuaUtils.prettyPrint(self._rawData) end)
    end

    return status and result or false
end

return LuaUtils.readOnly(Persistence)
