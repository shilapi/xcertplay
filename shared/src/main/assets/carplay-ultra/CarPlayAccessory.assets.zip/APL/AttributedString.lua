-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"
local Font = require "APL.Font"
local Rect = require "APL.Rect"
local Transform = require "APL.Transform"

local AttributedString = LuaUtils.makeObject({ _type = "AttributedString" })

AttributedString.ALIGNMENT = LuaUtils.readOnly {
    LEFT = 1,
    RIGHT = 2,
    CENTER = 3,
    FLEX = 4
}








function AttributedString.new(string, font)



    local self = LuaUtils.newObject(AttributedString, {
        _string = string,
        _font = font,
        _alignment = AttributedString.ALIGNMENT.LEFT,
        _tracking = 0,
        _kerning = true,
        _color = "#FFFFFFFF",
        _requiresContainerRasterization = false,
    })

    return self
end






function AttributedString:destroy()

end






function AttributedString:getString()


    return self._string
end







function AttributedString:setString(string)



    self._string = string

    return self
end






function AttributedString:getAlignment()


    return self._alignment
end







function AttributedString:setAlignment(alignment)



    self._alignment = alignment

    return self
end






function AttributedString:getFont()


    return self._font
end







function AttributedString:setFont(font)



    self._font = font

    return self
end






function AttributedString:getColor()


    return self._color
end







function AttributedString:setColor(color)



    self._color = color

    return self
end






function AttributedString:getTracking()


    return self._tracking
end







function AttributedString:setTracking(tracking)



    self._tracking = tracking

    return self
end






function AttributedString:getKerning()


    return self._kerning
end







function AttributedString:setKerning(kerning)



    self._kerning = kerning

    return self
end






function AttributedString:requiresContainerRasterization()


    return self._requiresContainerRasterization
end







function AttributedString:setRequiresContainerRasterization(requiresContainerRasterization)



    self._requiresContainerRasterization = requiresContainerRasterization

    return self
end






function AttributedString:getFramesetter()


    local framesetter = self._font:getFramesetter()
    return framesetter.new(self)
end








function AttributedString:getBoundingRect(width, height)




    local framesetter = self:getFramesetter()
    local frame = framesetter:layoutFrame(Rect.new(0, 0, width or 10000, height or 10000)) -- 10000 acts as math.huge but avoids some issues in the LR handling inf
    return Rect.new(0, 0, frame:getBoundingBox():getSize())
end






function AttributedString:getMaxHeight()


    return self._font:getHeight()
end

return LuaUtils.readOnly(AttributedString)

