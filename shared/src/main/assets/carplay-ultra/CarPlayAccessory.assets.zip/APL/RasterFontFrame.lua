-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Layer = require "APL.Layer"
local ImageLayer = require "APL.ImageLayer"
local LuaUtils = require "APL.LuaUtils"
local Rect = require "APL.Rect"
local Transform = require "APL.Transform"

local RasterFontFrame = LuaUtils.makeObject({ _type = "RasterFontFrame" })


RasterFontFrame.RenderedFrame = LuaUtils.makeObject({ _type = "RasterFontFrame.RenderedFrame" })













function RasterFontFrame.new(characters, font, container, characterTextureFrames, transforms, boundingBox, requiresContainerRasterization)








    local self = LuaUtils.newObject(RasterFontFrame, {
        _characters = characters,
        _font = font,
        _container = container,
        _characterTextureFrames = characterTextureFrames,
        _boundingBox = boundingBox,
        _transforms = transforms,
        _requiresContainerRasterization = requiresContainerRasterization,
    })

    return self
end






function RasterFontFrame:destroy()

end






function RasterFontFrame:getBoundingBox()


    return self._boundingBox
end







function RasterFontFrame:getCharacterFrame(i)



    local character = string.sub(self._characters, utf8.offset(self._characters, i), (utf8.offset(self._characters, i+1) or 0) - 1)
    return self._font:getCharacterBoundingBox(character):transform(self:getCharacterTransform(i))
end







function RasterFontFrame:getCharacterTransform(i)



    return self._transforms[i]
end








function RasterFontFrame:updateCharacterTransforms(transforms, boundingBox)




    self._transforms = transforms
    self._boundingBox = boundingBox

    return self
end












function RasterFontFrame:renderInto(layer, color, lastRendering)




    local containerLayer
    local characterLayers

    if lastRendering then
        if LuaUtils.getClassName(lastRendering) == "RasterFontFrame.RenderedFrame" then
            containerLayer, characterLayers = lastRendering:release()
        end

        lastRendering:destroy()
    end

    if not containerLayer then
        containerLayer = Layer.new()
            :setAnchorPoint(0, 0)
            :addToSuperLayer(layer)
    end
    characterLayers = characterLayers or {}

    local _, _, containerWidth, containerHeight = layer:getFrame()
    local containerFrame = Rect.new(0, 0, containerWidth, containerHeight)
    containerLayer:setFrame(containerFrame)

    local i = 1
    for _, codepoint in utf8.codes(self._characters) do
        local character = utf8.char(codepoint)
        local characterTextureFrame = self._characterTextureFrames[i]
        local characterTransform = self._transforms[i]

        local characterLayer = characterLayers[i]
        if not characterLayer then
            characterLayer = self:_createCharacterLayer(character, color)
            characterLayer.portal:addToSuperLayer(containerLayer)
        end


        if characterTextureFrame and characterTransform then
            characterLayer.portal
                :setVisible(true)
                :setBounds(characterTextureFrame)
                :setTransform(characterTransform)
        else
            characterLayer.portal:setVisible(false)
        end

        characterLayers[i] = characterLayer

        i = i + 1
    end


    for j = i, #characterLayers do
        characterLayers[j].portal:setVisible(false)
    end

    return RasterFontFrame.RenderedFrame.new(containerLayer, characterLayers, self._requiresContainerRasterization):setColor(color)
end






function RasterFontFrame:_createCharacterLayer(character)



    local atlas = self._font:getTextureAtlas()
    local atlas_w, atlas_h = atlas:getSize()

    local layer = Layer.new()
        :setMaskToBounds(true)
        :setAnchorPoint(0, 0)

    local atlas = ImageLayer.new()
        :setTexture(atlas)
        :setAnchorPoint(0, 0)
        :setBounds(Rect.new(0, 0, atlas_w, atlas_h))
        :addToSuperLayer(layer)

    return { portal = layer; image = atlas }
end











function RasterFontFrame.RenderedFrame.new(container, characterLayers, requiresContainerRasterization)




    local self = LuaUtils.newObject(RasterFontFrame.RenderedFrame, {
        _container = container,
        _characterLayers = characterLayers,
        _requiresContainerRasterization = requiresContainerRasterization
    })

    self._container
        :setShouldRasterize(requiresContainerRasterization)
        :setOpacity(1)

    return self
end







function RasterFontFrame.RenderedFrame:setColor(color)









    if self._requiresContainerRasterization then
        local r,g,b,a = LuaUtils.parseColor(color, false)
        color = LuaUtils.createColor(r,g,b,1)
        self._container:setOpacity(a)
    end

    for _, layer in ipairs(self._characterLayers) do
        layer.image:setTint(color)
    end

    return self
end





function RasterFontFrame.RenderedFrame:release()



    local container = self._container
    local characterLayers = self._characterLayers

    self._characterLayers = nil
    self._container = nil

    return container, characterLayers
end






function RasterFontFrame.RenderedFrame:destroy()


    if self._characterLayers then
        for _, layer in ipairs(self._characterLayers) do
            layer.portal:destroy()
            layer.image:destroy()
        end
    end

    if self._container then
        self._container:destroy()
    end

    self._characterLayers = nil
    self._container = nil
end

RasterFontFrame.RenderedFrame = LuaUtils.readOnly(RasterFontFrame.RenderedFrame)
return LuaUtils.readOnly(RasterFontFrame)