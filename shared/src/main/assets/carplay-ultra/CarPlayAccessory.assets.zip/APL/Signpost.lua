-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local Config = require "APL.Config"
local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"

local Signpost = LuaUtils.makeObject({ _type = "Signpost" })


local _availability = Config.readParam("SIGNPOSTS.ENABLED")
local _prefix = ""






function Signpost.setPrefix(prefix)


    _prefix = prefix == nil and "" or prefix .. " | "
end







function Signpost.emitEvent(label, ...)


    if not _availability then return end

    if #{...} > 0 then
        label = string.format(label, ...)
    end

    CP.signpostEmitEvent(_prefix .. label)
end











function Signpost.beginInterval(name)


    if not _availability then return 0 end

    return CP.signpostBeginInterval(_prefix .. name)
end







function Signpost.endInterval(signpost, name)



    if not _availability then return end

    CP.signpostEndInterval(signpost, _prefix .. name)
end













function Signpost.measure(name, f, ...)



    local signpostId
    local start
    if _availability then
        start = CP.getSystemUpTime()

        signpostId = CP.signpostBeginInterval(_prefix .. name .. " - Start")

    end


    local result = table.pack(f(...))

    if _availability then

        CP.signpostEndInterval(signpostId, _prefix .. name .. " - End")
        Log.log("Measured", name .. ": %.3f ms", (CP.getSystemUpTime() - start) * 1000)
    end

    return table.unpack(result)
end






function Signpost._overrideAvailability(availability)
    local previous = _availability
    _availability = availability
    return previous
end

return LuaUtils.readOnly(Signpost)