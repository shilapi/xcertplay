-- Copyright © 2021-2026 Apple, Inc. All rights reserved.














local LuaUtils = require "APL.LuaUtils"
local Thread = require "APL.Thread"

local Throttle = LuaUtils.makeObject({ _type = "Throttle" })


local _step = 1 / 60

local _stats = {
    internalYields = 0, -- yields because task ran too long
    externalYields = 0, -- extra yields because first yield took too long
}






function Throttle.getStats()
    return _stats
end






function Throttle.setStep(step)


    local Log = require "APL.Log"
    Log.info(Throttle, function() return "step set to " .. tostring(step) end)
    _step = step
end






function Throttle.getStep()
    return _step
end









function Throttle.new()
    local self = LuaUtils.newObject(Throttle, {
        _startTime = CP.getSystemUpTime(),
        _computeLimit = _step,
        _yieldLimit = _step * 2,
    })
    return self
end






function Throttle:destroy()


    self._startTime = nil
end










function Throttle:setComputeLimit(computeLimit)



    self._computeLimit = computeLimit

    return self
end










function Throttle:setYieldLimit(yieldLimit)



    self._yieldLimit = yieldLimit

    return self
end












function Throttle:maybeYield()




    if not Thread.current() then
        return -- cannot yield a non-thread context
    end

    local throttleTime = CP.getSystemUpTime()


    local computeSeconds = throttleTime - self._startTime
    if computeSeconds >= self._computeLimit then
        _stats.internalYields = _stats.internalYields + 1
        Thread.yield()





        local yieldSeconds = CP.getSystemUpTime() - throttleTime
        if yieldSeconds > self._yieldLimit then
            _stats.externalYields = _stats.externalYields + 1
            Thread.yield()
        end


        self._startTime = CP.getSystemUpTime()

        return true
    end

    return false
end


local outStreams = CP.enumerateOutputStreams()
if #outStreams > 0 and outStreams[1].frameDuration > 0 then
    Throttle.setStep(outStreams[1].frameDuration)
end

return LuaUtils.readOnly(Throttle)
