-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"
local Thread = require "APL.Thread"

local Timer = LuaUtils.makeObject({ _type = "Timer" })










function Timer.new(delay, count, f, ...)




    local self = LuaUtils.newObject(Timer, {
        _thread = LuaUtils.NIL,
        _isActive = true,
    })



    local args = { ... }
    self._thread = Thread.new(function()
        local iter = 1

        local previous = CP.getSystemUpTime()
        while self._isActive and iter <= count do
            local now = CP.getSystemUpTime()

            while now - previous < delay do
                Thread.yield()
                now = CP.getSystemUpTime()
            end

            previous = previous + delay

            f(table.unpack(args))  -- if this calls stop, will abort next loop iteration
            iter = iter + 1




            if LuaUtils.getClassName(self) ~= "Timer" then
                return  -- do not attempt to use object
            end
        end
        self._thread = nil
        self._isActive = false
    end):start()

    return self
end






function Timer:destroy()



    self:stop()
end










function Timer:stop()




    if self._thread and self._thread ~= Thread.current() then
        self._thread:destroy()
        self._thread = nil
    end



    self._isActive = false

    return self
end








function Timer:join()


    if self._thread then
        self._thread:join()
    end

    return self
end

return LuaUtils.readOnly(Timer)