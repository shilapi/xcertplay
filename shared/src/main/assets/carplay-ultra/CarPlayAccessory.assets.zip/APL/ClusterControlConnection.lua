-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"
local Thread = require "APL.Thread"

local ClusterControlConnection = LuaUtils.makeObject({ _type = "ClusterControlConnection" })






function ClusterControlConnection.new()
    local self = LuaUtils.newObject(ClusterControlConnection, {
        _nativeConnection = LuaUtils.NIL
    })

    local wrap = function(f)
        return function(self, ...)
            return f(...)
        end
    end

    self._nativeConnection = {
        status = wrap(CP.status),
        receive = wrap(CP.receiveMessage),
        send = wrap(CP.sendMessage),
        reset = wrap(CP.reset)
    }

    return self
end






function ClusterControlConnection:destroy()


    self._nativeConnection:reset()
end







function ClusterControlConnection:overrideNativeConnection(connection)



    self._nativeConnection = connection

    return self
end

















function ClusterControlConnection:status(timeout)




    local startTime = timeout and CP.getSystemUpTime() or nil
    while true do
        local readable, writable, error = self._nativeConnection:status()
        Log.trace(ClusterControlConnection, function() return "Status readable=%s, writable=%s, error=%s", tostring(readable), tostring(writable), error or "nil" end)



        if readable or writable or error ~= "timeout" then
            return readable, writable, error
        end


        if startTime and CP.getSystemUpTime() - startTime >= timeout then
            return false, false, "timeout"
        end


        Thread.yield()
    end
end
















function ClusterControlConnection:receiveMessage(timeout)




    local startTime = timeout and CP.getSystemUpTime() or nil
    while true do

        local result, error = self._nativeConnection:receive()



        if result or error ~= "timeout" then
            return result, error
        end


        if startTime and CP.getSystemUpTime() - startTime >= timeout then
            return nil, "timeout"
        end


        Thread.yield()
    end
end
















function ClusterControlConnection:sendMessage(data, timeout)





    local startTime = timeout and CP.getSystemUpTime() or nil
    while true do

        local result, error = self._nativeConnection:send(data)



        if result or error ~= "timeout" then
            return result, error
        end


        if startTime and CP.getSystemUpTime() - startTime >= timeout then
            return nil, "timeout"
        end


        Thread.yield()
    end
end












function ClusterControlConnection:reset()


    self._nativeConnection:reset()
    return self
end

return LuaUtils.readOnly(ClusterControlConnection)