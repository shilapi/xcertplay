-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Layer = require "APL.Layer"
local LuaUtils = require "APL.LuaUtils"

local Rect = require "APL.Rect"

local VectorFontFrame = LuaUtils.makeObject({ _type = "VectorFontFrame" })
VectorFontFrame.RenderedFrame = LuaUtils.makeObject({ _type = "VectorFontFrame.RenderedFrame" })








function VectorFontFrame.new(layout, container)


    local self = LuaUtils.newObject(VectorFontFrame, {
        _layout = layout,
        _container = container
    })

    return self
end






function VectorFontFrame:destroy()

end






function VectorFontFrame:getBoundingBox()


    local rect = self._layout:getLayoutMetric(0) -- 0 is the page, we only support one page.
    return Rect.new(rect.origin.x, rect.origin.y, rect.size.width, rect.size.height)
end







function VectorFontFrame:getCharacterFrame(i)




    local rect = self._layout:getGlyphMetric(i - 1).bounds
    return Rect.new(rect.origin.x, rect.origin.y, rect.size.width, rect.size.height)
end







function VectorFontFrame:getCharacterAdvance(i)




    return self._layout:getGlyphMetric(i - 1).advance
end











function VectorFontFrame:renderInto(layer, color, cache)





    if cache then
        cache:destroy()
        cache = nil
    end

    local layers = self._layout:createTextLayers(CP.DPPoint(self._container._x, self._container._y))
    local hostingLayer = Layer.new()
        :addToSuperLayer(layer)
        :setFrame(self._container)

    local nativeHost = hostingLayer:getNativeLayer()
    for _, textLayer in ipairs(layers) do
        nativeHost:addSublayer(textLayer)
    end

    return VectorFontFrame.RenderedFrame.new(hostingLayer, layers):setColor(color)
end








function VectorFontFrame.RenderedFrame.new(layer, nativeLayers)



    local self = LuaUtils.newObject(VectorFontFrame.RenderedFrame, {
        _layer = layer,
        _nativeLayers = nativeLayers
    })

    return self
end







function VectorFontFrame.RenderedFrame:setColor(color)



    local r, g, b, a  = LuaUtils.parseColor(color, false)
    local nativeColor = CP.DPColor(r, g, b, a)

    for _, textLayer in ipairs(self._nativeLayers) do
        textLayer.tint = nativeColor
    end

    return self
end






function VectorFontFrame.RenderedFrame:destroy()


    self._layer:destroy()
    self._layer = nil
end

VectorFontFrame.RenderedFrame = LuaUtils.readOnly(VectorFontFrame.RenderedFrame)
return LuaUtils.readOnly(VectorFontFrame)