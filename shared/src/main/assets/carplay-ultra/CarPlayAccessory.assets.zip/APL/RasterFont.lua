-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Asset = require "APL.Asset"
local JSON = require "APL.json"
local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"
local Rect = require "APL.Rect"
local Signpost = require "APL.Signpost"
local Texture = require "APL.Texture"
local TextureCache = require "APL.TextureCache"
local RasterFontFramesetter = require "APL.RasterFontFramesetter"
local StableRasterFontFramesetter = require "APL.StableRasterFontFramesetter"

local RasterFont = LuaUtils.makeObject({ _type = "RasterFont" })

local _fonts = {} -- Font cache








function RasterFont.new(name)


    local name = name or "default"

    Log.debug(RasterFont, function() return "Creating font: " .. tostring(name) end)


    if _fonts[name] then
        Log.debug(RasterFont, function() return "Returning cached font: " .. name end)
        return _fonts[name]
    end

    local self = LuaUtils.newObject(RasterFont, {
        _name = name or LuaUtils.NIL,
        _layoutData = LuaUtils.NIL,
        _atlas = LuaUtils.NIL,
        _widths = {}, -- character -> number
    })

    Signpost.measure("Loading font \"" .. name .. "\"", function()
        local fontBasename = Asset.lookupAssetFilename(name)


        self._layoutData = Asset.loadLua(fontBasename .. "/LayoutData")


        self._atlas = TextureCache.current():getTexture(fontBasename .. "/" .. name .. ".png")


        for character, characterLayoutMetadata in pairs(self._layoutData.characters) do

            local advance = characterLayoutMetadata.advance[1]
            local bbX = characterLayoutMetadata.boundingBox[1][1]
            local bbW = characterLayoutMetadata.boundingBox[2][1]
            self._widths[character] = characterLayoutMetadata.isWhitespace and advance or (bbX + bbW)
        end
    end)


    _fonts[name] = self

    Log.debug(RasterFont, function() return "Done creating font: " .. tostring(name) end)

    return self
end






function RasterFont:destroy()



    _fonts[self._name] = nil

    self._layoutData = nil
    self._atlas = nil
end






function RasterFont:getFramesetter()


    return self:isStable() and StableRasterFontFramesetter or RasterFontFramesetter
end






function RasterFont:getHeight()


    return self._layoutData.height
end






function RasterFont:getPointSize()


    return self._layoutData.pointSize
end






function RasterFont:getLineOriginY()


    return self._layoutData.lineOriginY
end






function RasterFont:getBaselineOffset()


    return self._layoutData.height - self._layoutData.lineOriginY
end







function RasterFont:getCharacterBoundingBox(character)



    local boundingBox = self._layoutData.characters[character].boundingBox

    local x = boundingBox[1][1]
    local y = boundingBox[1][2]
    local w = boundingBox[2][1]
    local h = boundingBox[2][2]
    return Rect.new(x,y,w,h)
end







function RasterFont:getCharacterAdvance(character)



    return self._layoutData.characters[character].advance[1]
end


















function RasterFont:getLayoutData()


    return self._layoutData
end






function RasterFont:getTextureAtlas()


    return self._atlas
end







function RasterFont:isMonospacedForCharacter(c)


    if self._layoutData.hasMonoSpacedDigits then



        return tonumber(c, 10) ~= nil
    end

    return self._layoutData.hasMonoSpaceFlag
end






function RasterFont:isStable()


    return self._layoutData.stable
end






function RasterFont:getName()
    return self._name
end

return LuaUtils.readOnly(RasterFont)
