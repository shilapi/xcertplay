-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local Effect = require "APL.Effect"
local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"
local RunQueue = require "APL.RunQueue"
local Thread = require "APL.Thread"

local Store = LuaUtils.makeObject({ _type = "Store" })








function Store.new(initialState, reducer)



    local self = LuaUtils.newObject(Store, {

        _reducer = reducer,


        _state = initialState,


        _subscribers = {},


        _effects = {},


        _runQueue = RunQueue.new(nil, "Store")
    })

    return self
end






function Store:destroy()



    self._runQueue:destroy()
end







function Store:subscribe(callback)



    self._subscribers[#self._subscribers+1] = callback

    return function()
        LuaUtils.removeByValue(self._subscriber, callback)
    end
end







function Store:dispatch(action)



    self._runQueue:post(function()
        Log.info(Store, function() return "Processing action: " .. LuaUtils.prettyPrint(action, false, 3) end)


        local effects = self._reducer(self._state, action, function(...)
            self:dispatch(...)
        end)




        Log.info(Store, function() return "New state: " .. LuaUtils.prettyPrint(self._state, false, 3) end)


        LuaUtils.forEach(self._subscribers, function(callback)
            callback(LuaUtils.readOnly(self._state))
        end)


        if effects ~= nil then
            LuaUtils.forEach(effects, function(effect)


                local cancellableID = effect:getCancellableID()
                local thread = effect:hasWork() and self._runQueue:postAsync(function()

                    local dispatch = function(action)
                        self:dispatch(action)
                    end


                    effect:work(dispatch)


                    if LuaUtils.getClassName(effect) == "Effect" then
                        effect:destroy()

                        if cancellableID then
                            self._effects[cancellableID] = nil
                        end
                    end
                end)

                if cancellableID then

                    local oldEffect, oldThread = table.unpack(self._effects[cancellableID] or {})
                    if oldThread then
                        oldThread:stop()
                        self._runQueue:deactivateThread(oldThread)
                    end

                    if oldEffect and LuaUtils.getClassName(oldEffect) == "Effect" then
                        oldEffect
                            :cancel()
                            :destroy()
                    end

                    if thread then

                        self._effects[cancellableID] = table.pack(effect, thread)
                    end
                end
            end)
        end
    end)

    return self
end










function Store:getState()




    return self._state
end

return LuaUtils.readOnly(Store)