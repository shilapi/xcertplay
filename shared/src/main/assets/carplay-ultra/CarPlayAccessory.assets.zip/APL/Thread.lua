-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local ErrorHandler = require "APL.ErrorHandler"
local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"

local Thread = LuaUtils.makeObject({ _type = "Thread" })




Thread.TRACEBACK_STACK_LIMIT = 5


local _activeThreads = {}






function Thread.current()
    local systemThread = coroutine.running()
    if systemThread then
        for thread, _ in pairs(_activeThreads) do
            if thread._systemThread == systemThread then
                return thread
            end
        end
    end
    return nil
end






function Thread.sleep(seconds)





    if seconds == 0 then
        Thread.yield()
    end


    local target = CP.getSystemUpTime() + seconds
    while target - CP.getSystemUpTime() > 0 do
        Thread.yield()
    end
end




function Thread.yield()
    coroutine.yield()
end




function Thread.joinAll(list)


    for _, thread in LuaUtils.enumerated(list) do
        thread:join()
    end
end




function Thread.joined(list)
    for _, thread in LuaUtils.enumerated(list) do

        if LuaUtils.getClassName(thread) == "Thread" and thread:isBusy() then
            return false
        end
    end

    return true
end




function Thread.killLingeringThreads()
    local currentThread = Thread.current()
    for thread, _ in pairs(_activeThreads) do
        if thread ~= currentThread then
            thread:destroy()
        end
    end
end












function Thread.reportLingeringThreads()
    local currentThread = Thread.current()
    for thread, _ in pairs(_activeThreads) do
        if thread ~= currentThread and not thread._allowLinger then
            local traceback = LuaUtils.joinStrings(thread:getTracebackStack(), "\n--\n")
            Log.error(Thread, function() return "Lingering thread, traceback:\n%s", traceback end)
        end
    end
end






function Thread.new(f, ...)


    local _f = function(...)
        local success, result = LuaUtils.safeCall(false, function(...)
            f(...)
        end, ...)
        if success == false then

            ErrorHandler.forwardError(result)
        end
    end

    local self = LuaUtils.newObject(Thread, {
        _func = _f,
        _args = {...},
        _task = LuaUtils.NIL,
        _systemThread = LuaUtils.NIL,


        _tracebackStack = LuaUtils.NIL,


        _allowLinger = false,


        _owner = LuaUtils.NIL,


        _tag = LuaUtils.NIL,
    })


    if Thread.TRACEBACK_STACK_LIMIT > 0 then
        local currentThread = Thread.current()
        if currentThread then
            self._tracebackStack = LuaUtils.duplicate(currentThread._tracebackStack)
        else
            self._tracebackStack = {}
        end
        table.insert(self._tracebackStack, debug.traceback())
        while #self._tracebackStack > Thread.TRACEBACK_STACK_LIMIT do
            table.remove(self._tracebackStack, 1)
        end
    end

    return self
end






function Thread:destroy()
    if LuaUtils.getClassName(self) == "__DESTROYED__" then
        Log.warn(Thread, function() return "Thread has already been destroyed, stack: "..LuaUtils.getStack(self) end)
    end



    self:stop()

    self._func = nil
    self._args = nil
end






function Thread:getAllowLinger()


    return self._allowLinger
end







function Thread:setAllowLinger(allowLinger)



    self._allowLinger = allowLinger

    return self
end







function Thread:setTag(tag)



    self._tag = tag

    if self._task then

        pcall(function()
            self._task.name = tag
        end)
    end

    return self
end













function Thread:start()



    if self._task then
        self._task:stop()
        self._task = nil
    end


    _activeThreads[self] = true


    self._owner = Thread.current() or 1


    self._task = CP.DPLuaTask.create()
    self._task:run(function()

        self._systemThread = coroutine.running()


        self._func(table.unpack(self._args))


        self._task:stop()
        self._task = nil
        self._systemThread = nil

        _activeThreads[self] = nil
    end)


    if self._tag then
        pcall(function()
            self._task.name = self._tag
        end)
    end


    return self
end








function Thread:stop()


    local suicide = self == Thread.current()


    self._owner = Thread.current() or 1


    if self._task then
        self._task:stop()
        self._task = nil
        self._systemThread = nil
    end


    _activeThreads[self] = nil


    if suicide then
        coroutine.yield()
    end

    return self
end









function Thread:join()


    assert(self ~= Thread.current())  -- cannot join on self



    while LuaUtils.getClassName(self) == "Thread" and self:isBusy() do
        coroutine.yield()
    end

    return self
end









function Thread:isBusy()


    if self._task and self._task:isBusy() then
        return true
    end
    return false
end









function Thread:isOwner()


    local currentThread = Thread.current() or 1
    if self._owner and self._owner == currentThread then
        return true
    end
    return false
end









function Thread:getTracebackStack()


    return self._tracebackStack
end













function Thread:resetTracebackStack(keepN)



    keepN = keepN or 0

    while #self._tracebackStack > keepN do
        table.remove(self._tracebackStack, 1)
    end

    return self
end

return LuaUtils.readOnly(Thread)