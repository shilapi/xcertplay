-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"
local RasterFontFramesetter = require "APL.RasterFontFramesetter"

local StableRasterFontFramesetter = LuaUtils.makeObject({ _type = "StableRasterFontFramesetter" }, RasterFontFramesetter)







function StableRasterFontFramesetter.new(string)




    local self = LuaUtils.newObject(StableRasterFontFramesetter, {}, RasterFontFramesetter.new(string))

    return self
end






function StableRasterFontFramesetter:destroy()


    RasterFontFramesetter.destroy(self)
end










function StableRasterFontFramesetter:getKerningValue(left, right, kerningTable, index)
    local length = utf8.len(self._string:getString())


    if length > 2 and index == 1 then
        return 0
    end

    return RasterFontFramesetter.getKerningValue(self, left, right, kerningTable, index)
end

return LuaUtils.readOnly(StableRasterFontFramesetter)