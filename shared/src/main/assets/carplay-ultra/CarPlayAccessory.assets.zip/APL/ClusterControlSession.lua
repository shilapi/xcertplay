-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local ClusterControlConnection = require "APL.ClusterControlConnection"
local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"
local Thread = require "APL.Thread"
local Throttle = require "APL.Throttle"
local Timer = require "APL.Timer"

local ClusterControlSession = LuaUtils.makeObject({ _type = "ClusterControlSession" })

local STATE = LuaUtils.readOnly(LuaUtils.makeEnum({
    "INITIALIZED",



    "AWAITING_RESET_COMPLETE",


    "READY"
}))

ClusterControlSession.MESSAGE_TYPE = LuaUtils.readOnly({
    RESET                 = 0x00,
    RESET_COMPLETE        = 0x01,
    COMMAND               = 0x02,
    COMMAND_ACK           = 0x03
})
local MESSAGE_TYPES = LuaUtils.getValues(ClusterControlSession.MESSAGE_TYPE)


ClusterControlSession.STATE = STATE

local PROTOCOL_VERSION = LuaUtils.readOnly({
    v1 = 1,
    v2 = 2  -- Introduced `id` in reset/reset complete to match paired phone with current session
})


ClusterControlSession.MAX_SUPPORTED_PROTOCOL_VERSION = PROTOCOL_VERSION.v2







function ClusterControlSession.new(remoteIdentifier)


    local self = LuaUtils.newObject(ClusterControlSession, {

        _remoteIdentifier = remoteIdentifier or LuaUtils.NIL,


        _resetCompleteWatchdog = LuaUtils.NIL,


        _resetCompleteWatchdogTimeout = 1,


        _connection = LuaUtils.NIL,
        _connectionThread = LuaUtils.NIL,



        _sessionSn = 0,


        _messageNextTxSn = 1,


        _messageLastAckSn = 0,


        _messageLastRxSn = 0,


        _dataHandler = LuaUtils.NIL, -- { f=function, args=... }


        _resetHandler = LuaUtils.NIL, -- { f=function, args=... }


        _readyHandler = LuaUtils.NIL, -- { f=function, args=... }


        _state = STATE.INITIALIZED,


        _outgoingMessageQueue = {},


        _connectionFactory = LuaUtils.NIL, -- { f=function, args=... }


        _protocolVersion = 0,
    })


    self._connectionFactory = {
        f = function() return ClusterControlConnection.new() end,
        args = {}
    }

    return self
end






function ClusterControlSession:destroy()


    self:_cancelResetCompleteWatchdog()

    if self._connectionThread then
        self._connectionThread:destroy()
    end

    if self._connection then
        self._connection:destroy()
    end
end







function ClusterControlSession:overrideConnectionFactory(f, ...)



    self._connectionFactory = {
        f = f,
        args = {...}
    }

    return self
end







function ClusterControlSession:setResetCompleteWatchdogTimeout(timeout)



    self._resetCompleteWatchdogTimeout = timeout

    return self
end






function ClusterControlSession:start()



    Log.info(ClusterControlSession, function() return "Starting ..." end)

    self:reset()

    self._connection = self._connectionFactory.f(table.unpack(self._connectionFactory.args))
    self._connectionThread = Thread.new(function()
        local throttle = Throttle.new()
        local skipYield
        while true do
            skipYield = false


            local readable, writable, error = self._connection:status(0)



            if error and error ~= "timeout" then
                self:reset()
            end


            if not error and writable then
                error = self:_sendNextMessage() -- will return nil if nothing to send, should never timeout otherwise
                if error then
                    self:reset()
                end
            end


            if not error and readable then
                error = self:_receiveMessage()


                if not error then
                    throttle:maybeYield()
                    skipYield = true
                elseif error ~= "timeout" then
                    self:reset()
                end
            end

            if not skipYield then
                Thread.yield()
                throttle = Throttle.new()
            end
        end
    end)
    :setTag("uisync_session")
    :start()

    return self
end










function ClusterControlSession:resetIfWaitingForResetComplete()


    if self._resetCompleteWatchdog then
        Log.warn(ClusterControlSession, function() return "Still waiting for reset complete, forcing reset ..." end)
        self:reset()
    end

    return self
end






function ClusterControlSession:reset()



    if self._state == STATE.AWAITING_RESET_COMPLETE and #self._outgoingMessageQueue == 1 then
        return
    end

    Log.warn(ClusterControlSession, function() return "Resetting..." end)



    if self._state ~= STATE.INITIALIZED then
        self._connection:reset()
    end


    local wasReady = self._state == STATE.READY
    self._state = STATE.AWAITING_RESET_COMPLETE

    if wasReady and self._resetHandler then

        self._resetHandler.f(table.unpack(self._resetHandler.args))
    end


    self._sessionSn = self._sessionSn + 1
    self._messageNextTxSn = 1
    self._messageLastAckSn = 0
    self._messageLastRxSn = 0
    self._protocolVersion = 0


    self._outgoingMessageQueue = {}
    table.insert(self._outgoingMessageQueue, {
        type = ClusterControlSession.MESSAGE_TYPE.RESET
    })


    self:_cancelResetCompleteWatchdog()

    return self
end






function ClusterControlSession:getIsReady()


    return self._state == STATE.READY
end












function ClusterControlSession:setDataHandler(f, ...)



    self._dataHandler = {
        f = f,
        args = {...}
    }

    return self
end














function ClusterControlSession:setResetHandler(f, ...)



    self._resetHandler = {
        f = f,
        args = {...}
    }

    return self
end










function ClusterControlSession:setReadyHandler(f, ...)



    self._readyHandler = {
        f = f,
        args = {...}
    }

    return self
end






function ClusterControlSession:sendCommand(payload)






    table.insert(self._outgoingMessageQueue, {
        type = ClusterControlSession.MESSAGE_TYPE.COMMAND,
        payload = payload
    })
end










function ClusterControlSession:_buildMessage(messageType, payload)




    local message = {
        type = messageType,
        ssn = self._sessionSn,
        psn = self._messageNextTxSn,
        asn = self._messageLastRxSn,
        data = payload
    }

    if messageType == ClusterControlSession.MESSAGE_TYPE.RESET then

        message.version = ClusterControlSession.MAX_SUPPORTED_PROTOCOL_VERSION
        message.id = self._remoteIdentifier
    elseif messageType == ClusterControlSession.MESSAGE_TYPE.RESET_COMPLETE then

        message.version = self._protocolVersion


        if self._protocolVersion >= PROTOCOL_VERSION.v2 then
            message.id = self._remoteIdentifier
        end
    end

    return message
end






function ClusterControlSession:_getNextMessage()



    if #self._outgoingMessageQueue > 0 then
        local message = self._outgoingMessageQueue[1]


        while message.type == ClusterControlSession.MESSAGE_TYPE.COMMAND_ACK and #self._outgoingMessageQueue > 1 do
            table.remove(self._outgoingMessageQueue, 1)
            message = self._outgoingMessageQueue[1]
        end

        return self:_buildMessage(message.type, message.payload)
    end

    return nil
end






function ClusterControlSession:_sendNextMessage()




    local message = self:_getNextMessage()
    if not message then
        return
    end

    Log.info(ClusterControlSession, function() return "Sending message: " .. LuaUtils.prettyPrint(message, false, 3) end)


    message.data = message.data and CP.createPlist(message.data)


    local _, error = self._connection:sendMessage(CP.createPlist(message), 0)
    if error then
        Log.error(ClusterControlSession, function() return "Failed to send message: " .. tostring(error) end)
        return error
    end


    if self._state == STATE.AWAITING_RESET_COMPLETE then
        self:_startResetCompleteWatchdog()
    end


    table.remove(self._outgoingMessageQueue, 1)
    self._messageNextTxSn = self._messageNextTxSn + 1
end






function ClusterControlSession:_receiveMessage()


    local data, error = self._connection:receiveMessage(0)
    if data then
        self:_handleIncomingRawData(data)
        return
    end

    if error then
        Log.error(ClusterControlSession, function() return "Failed to receive message: " .. tostring(error) end)
    end

    return error
end






function ClusterControlSession:_handleIncomingRawData(data)



    Log.trace(ClusterControlSession, function() return "Received message..." end)


    if #data == 0 then
        return
    end


    if self._state == STATE.INITIALIZED then
        Log.warn(ClusterControlSession, function() return "Ignoring message while in initialized state" end)
        return
    end


    local message = CP.parsePlist(data)
    if not message then
        Log.error(ClusterControlSession, function() return "unable to parse incoming data" end)
        return
    end

    Log.trace(ClusterControlSession, function() return "Message payload: %s", LuaUtils.prettyPrint(message) end)


    if message.type == ClusterControlSession.MESSAGE_TYPE.RESET then
        return self:_handleResetRequest(message)
    end


    if not message.ssn or message.ssn ~= self._sessionSn then
        Log.error(ClusterControlSession, function() return "Invalid ssn. Received %s, Expected %d", tostring(message.ssn or "nil"), self._sessionSn end)
        return
    end


    if message.type == ClusterControlSession.MESSAGE_TYPE.RESET_COMPLETE then
        return self:_handleResetComplete(message)
    end


    if not message.psn or message.psn < self._messageLastRxSn + 1 then
        Log.error(ClusterControlSession, function() return "Invalid old psn. Received %d, Expected %d", tostring(message.psn or "nil"), self._messageLastRxSn + 1 end)
        return
    end


    if message.psn > self._messageLastRxSn + 1 then
        Log.error(ClusterControlSession, function() return "Detected missing message psn. Received %d, Expected %d", tostring(message.psn), self._messageLastRxSn + 1 end)
        return self:reset()
    end


    self._messageLastRxSn = message.psn


    if not message.asn or message.asn < self._messageLastAckSn or message.asn >= self._messageNextTxSn then
        Log.error(ClusterControlSession, function() return "Invalid ack sn. Received %d, Expected in range [%d...%d)", tostring(message.asn or "nil"), self._messageLastAckSn, self._messageNextTxSn end)
        return
    end


    self._messageLastAckSn = message.asn


    if message.type ~= ClusterControlSession.MESSAGE_TYPE.COMMAND_ACK and not message.noAck then

        if #self._outgoingMessageQueue == 0 then
            table.insert(self._outgoingMessageQueue, 1, {
                type = ClusterControlSession.MESSAGE_TYPE.COMMAND_ACK
            })
        end
    end


    if message.type == ClusterControlSession.MESSAGE_TYPE.COMMAND and message.data then
        return self:_handleCommand(message.data)
    end
end






function ClusterControlSession:_handleResetRequest(message)


    Log.info(ClusterControlSession, function() return "Received reset from peer " .. LuaUtils.prettyPrint(message, false, 3) end)

    local version = message.version or PROTOCOL_VERSION.v1


    if version >= PROTOCOL_VERSION.v2 and self._remoteIdentifier and (not message.id or self._remoteIdentifier ~= message.id) then
        Log.error(ClusterControlSession, function() return "Received unexpected reset message id " .. tostring(message.id) .. ", expected " .. tostring(self._remoteIdentifier) end)


        self:_cancelResetCompleteWatchdog()
        return
    end


    if self._messageNextTxSn == 2 and self._state == STATE.AWAITING_RESET_COMPLETE then
        Log.warn(ClusterControlSession, function() return "Ignoring inital reset with message id " .. tostring(message.id) end)
        return
    end

    self:reset()
end






function ClusterControlSession:_handleResetComplete(message)


    Log.info(ClusterControlSession, function() return "Received reset complete from peer " .. LuaUtils.prettyPrint(message, false, 3) end)


    if self._state ~= STATE.AWAITING_RESET_COMPLETE then

        Log.error(ClusterControlSession, function() return "Received unexpected reset complete received while in state %d ... ignoring", self._state end)
        return
    end

    local version = message.version or PROTOCOL_VERSION.v1


    if version >= PROTOCOL_VERSION.v2 and self._remoteIdentifier and self._remoteIdentifier ~= message.id then
        Log.error(ClusterControlSession, function() return "Received unexpected reset complete message id " .. tostring(message.id) .. ", expected " .. tostring(self._remoteIdentifier) end)
        return
    end




    self._protocolVersion = math.min(version, ClusterControlSession.MAX_SUPPORTED_PROTOCOL_VERSION)
    Log.info(ClusterControlSession, function() return "Negotiated protocol version " .. tostring(self._protocolVersion) .. ", received from peer version " .. tostring(message.version) end)


    table.insert(self._outgoingMessageQueue, {
        type = ClusterControlSession.MESSAGE_TYPE.RESET_COMPLETE
    })

    Log.info(ClusterControlSession, function() return "Ready to send/receive data." end)



    self._state = STATE.READY
    self._messageLastRxSn = message.psn
    self._messageLastAckSn = message.asn
    self._remoteIdentifier = message.id


    self:_cancelResetCompleteWatchdog()

    if self._readyHandler then
        self._readyHandler.f(message.id, table.unpack(self._readyHandler.args))
    end
end








function ClusterControlSession:_handleCommand(data)



    Log.trace(ClusterControlSession, function() return "Received command..." end)

    if self._dataHandler then
        self._dataHandler.f(data, table.unpack(self._dataHandler.args))
    end
end








function ClusterControlSession:_startResetCompleteWatchdog()


    self:_cancelResetCompleteWatchdog()

    Log.info(ClusterControlSession, function() return "Starting Reset Complete Watchdog" end)

    self._resetCompleteWatchdog = Timer.new(self._resetCompleteWatchdogTimeout, 1, function()
        Log.warn(ClusterControlSession, function() return "Reset Complete Watchdog timed out!" end)
        self:reset()
    end)

    return self
end






function ClusterControlSession:_cancelResetCompleteWatchdog()


    if self._resetCompleteWatchdog then
        Log.info(ClusterControlSession, function() return "Cancelling Reset Complete Watchdog" end)

        self._resetCompleteWatchdog:destroy()
        self._resetCompleteWatchdog = nil
    end

    return self
end

return LuaUtils.readOnly(ClusterControlSession)
