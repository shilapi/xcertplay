-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = { _type = "LuaUtils" }

local Config = require "APL.Config"


local _optimized = Config.readParam("OPTIMIZATION.ENABLED")





LuaUtils.NIL = not _optimized and {} or nil


local _isLockGlobals = false


local _nzPow2 = {}
for i = 0, 31 do _nzPow2[2 ^ i] = true end


local _objectCreators = nil


local _objectTypes = nil


local _prettyPrintSortTableKeys = false






function LuaUtils.setPrettyPrintSortTableKeys(isSorted)
    _prettyPrintSortTableKeys = isSorted
end







function LuaUtils.setOptimized(isOptimized)
    _optimized = isOptimized
end






function LuaUtils.isOptimized()
    return _optimized
end






function LuaUtils.setTrackActiveObjects(isEnabled)
    if isEnabled then
        if not _objectCreators then
            _objectCreators = {}



            setmetatable(_objectCreators, { __mode = "k" })
        end
    else
        _objectCreators = nil
    end
end






function LuaUtils.setTrackObjectTypes(isEnabled)
    if isEnabled then
        if not _objectTypes then
            _objectTypes = {}
        end
    else
        _objectTypes = nil
    end
end
















function LuaUtils.getActiveObjectStatistics()
    if not _objectCreators then
        return nil, nil
    end
    local histogram = {}
    for k, v in pairs(_objectCreators) do
        histogram[k._type] = (histogram[k._type] or 0) + 1
    end
    return histogram, _objectCreators
end





































function LuaUtils.newObject(object, mutableKeys, parentInstance)







    if _optimized then
        return LuaUtils._fastNewObject(object, mutableKeys, parentInstance)
    end










    for k, _ in pairs(object) do

    end



    if parentInstance ~= nil then
        LuaUtils.forEach(parentInstance(), function(k)
            if k == "__immutableKeys" or k == "makeFieldReadOnly" or k == "_type" or k == "__made" or type(parentInstance[k]) == "function" then
                return
            end


            mutableKeys[k] = parentInstance[k] or LuaUtils.NIL
        end)
    end


    mutableKeys.__immutableKeys = {}
    mutableKeys.makeFieldReadOnly = function(self, key)


        mutableKeys.__immutableKeys[key] = true
    end

    local newObject = {}







    mutableKeys.destroy = function(...)





        object.destroy(...)


        mutableKeys.destroy = nil


        mutableKeys.__immutableKeys = {}
        for k, _ in pairs(mutableKeys) do
            mutableKeys[k] = nil
        end


        mutableKeys._type = "__DESTROYED__"
        mutableKeys._stack = debug.traceback()
    end

    mutableKeys.isKind = function(self, kind)
        return LuaUtils.isKind(self, kind)
    end

    setmetatable(newObject, {
        __index = function(tbl, key)

            local result = mutableKeys[key]
            if result ~= nil then
                if result == LuaUtils.NIL then
                    return nil
                end
                return result
            end


            local result, output = pcall(function()
                return object[key]
            end)
            if result and output ~= nil then
                return output
            end


            if key == "__callEnumerateKeys" then
                return true
            end

            error("object read: no such key '" .. key .. "'")
        end,
        __newindex = function(tbl, key, value)

            if mutableKeys[key] == nil then
                error("object write: no such mutable key '" .. key .. "'")
            end
            if mutableKeys.__immutableKeys[key] then
                error("object write: immutable key '" .. key .. "'")
            end


            if value == nil then
                value = LuaUtils.NIL
            end
            mutableKeys[key] = value
        end,
        __iter = function(_)
            local keys = LuaUtils.getKeys(mutableKeys)
            local i = 0
            return function()
                i = i + 1
                while keys[i] and mutableKeys[keys[i]] == LuaUtils.NIL do
                    i = i + 1
                end
                if keys[i] then
                    return keys[i], mutableKeys[keys[i]]
                end
            end
        end,
        __call = function()

            return LuaUtils.getKeys(mutableKeys)
        end,
        __tostring = function(_)
            return newObject._type .. "(" .. LuaUtils.prettyPrint(newObject) .. ")"
        end
    })


    if _objectCreators then
        _objectCreators[newObject] = debug.traceback()
    end

    return newObject
end

































function LuaUtils.makeObject(object, parentObject)






    if not _optimized then
    object.__made = true
    end


    if _objectTypes then
        if _objectTypes[object._type] then
            error("LuaUtils.makeObject: bad object, \"" .. tostring(object._type) .. "\" already used @ " .. tostring(_objectTypes[object._type]))
        end
        _objectTypes[object._type] = debug.traceback()
    end


    if parentObject then
        for k, v in parentObject do
            if object[k] == nil then
                object[k] = v
            end
        end
    end

    return object
end














function LuaUtils._fastNewObject(object, mutableKeys, parentInstance)
    if parentInstance then


        for k, v in parentInstance do
            mutableKeys[k] = v
        end
    end


    for k, v in object do
        mutableKeys[k] = v
    end

    mutableKeys.destroy = function(...)

        object.destroy(...)


        mutableKeys.destroy = nil

        mutableKeys._type = "__DESTROYED__"
        mutableKeys._stack = debug.traceback()
    end

    mutableKeys.isKind = function(self, kind)
        return LuaUtils.isKind(self, kind)
    end


    mutableKeys.makeFieldReadOnly = function() end


    if _objectCreators then
        _objectCreators[mutableKeys] = debug.traceback()
    end

    return mutableKeys
end









function LuaUtils.readOnly(tbl)



    if _optimized then

        return tbl
    end


    local treatAsNil = LuaUtils.NIL


    local tblCopy = LuaUtils.duplicate(tbl)


    for k, _ in pairs(tbl) do
        tbl[k] = nil
    end


    return setmetatable(tbl, {
        __index = function(_, key)
            if key == "NIL" then
                return treatAsNil
            end

            local result = tblCopy[key]
            if result ~= nil then
                if result == treatAsNil then
                    return nil
                end
                return result
            end


            if key == "__callEnumerateKeys" then
                return true
            end

            error("read from missing key '" .. key .. "'")
        end,
        __newindex = function(_, key, value)
            error("write to read-only table")
        end,
        __iter = function(_)
            local keys = LuaUtils.getKeys(tblCopy)
            local i = 0
            return function()
                i = i + 1
                while keys[i] and tblCopy[keys[i]] == LuaUtils.NIL do
                    i = i + 1
                end
                if keys[i] then
                    return keys[i], tblCopy[keys[i]]
                end
            end
        end,
        __call = function()
            return LuaUtils.getKeys(tblCopy)
        end,
        __tostring = function()
            return LuaUtils.prettyPrint(tblCopy)
        end
    })
end























































function LuaUtils.namedObject(name, ...)


    local args = {...}
    if _optimized or (#args > 0 and type(args[1]) == "function") then
        return LuaUtils._fastNamedObject(name, ...)
    end

    local properties = {...}
    local names = {}

    local Object = LuaUtils.makeObject({ _type = name })
    Object.new = function(...)
        local values = {...}
        local mutableKeys = {}
        for i, p in properties do
        local _type
            local property = p


            if type(p) == "table" then

                property = p[1]
                _type = p[2]

            end




            _type = _type or "*"


            local optional = false
            if LuaUtils.hasSuffix(_type, "?") then
                _type = string.sub(_type, 1, -2)
                optional = true
            end

            local value = values[i]


            if _type ~= "*" then


            elseif not optional then

            end

            mutableKeys[property] = value == nil and LuaUtils.NIL or value
            table.insert(names, property)
        end

        return LuaUtils.newObject(Object, mutableKeys)
    end

    Object.makeFieldsReadOnly = function(object)
        for _, name in names do
            object:makeFieldReadOnly(name)
        end
        return object
    end

    Object.destroy = function() end

    return Object
end








function LuaUtils._fastNamedObject(name, ...)
    local args = {...}
    if #args > 0 and type(args[1]) == "function" then

        local builder = args[1]

        local Object = {}
        Object.new = function(...)
            local result = builder(...)

            result._type = name
            return result
        end

        return Object
    end


    local properties = LuaUtils.map(args, function(property)
        return type(property) == "table" and property[1] or property
    end)

    local object = LuaUtils.makeObject({
        _type = name,
        destroy = function() end,
        makeFieldsReadOnly = function(self) return self end
    })


    object.new = function(...)
        local mutableKeys = {}
        for k, v in pairs({...}) do
            mutableKeys[properties[k]] = v
        end

        return LuaUtils.newObject(object, mutableKeys)
    end

    return object
end









function LuaUtils.lockGlobals()
    if _isLockGlobals then
        return  -- already locked
    end
    _isLockGlobals = true

    local existingKeys = {}
    for k, _ in pairs(_G) do
        existingKeys[k] = true
    end


    LuaUtils.safeCall(false, function()
    setmetatable(_G, {
        __index = function(tbl, key)



            if key == "self" then
                return nil
            end
            if not existingKeys[key] then
                error("no such global '" .. key .. "'")
            end
            return _G[key]
        end,
        __newindex = function(tbl, key, value)
            error("globals are locked, cannot create global variable '" .. key .. "'")
        end
    })
    end)
end












function LuaUtils.runWithUnlockedGlobals(f, ...)




    local mt = LuaUtils.safeCall(nil, function()
        local mt = getmetatable(_G)
        setmetatable(_G, nil)
        return mt
    end)

    local r = table.pack(f(...))



    if mt then
        LuaUtils.safeCall(false, function()
            setmetatable(_G, mt)
        end)
    end

    return table.unpack(r)
end









function LuaUtils.getClassName(object)
    local result = type(object)


    if result == "table" and object._type then
        result = object._type
    end


    if result == "userdata" then
        pcall(function()
            result = object:getClassName()
        end)
    end

    return result
end










function LuaUtils.isKind(instance, class)
    if type(instance) ~= "table" or type(class) ~= "table" then
        return false
    end


    return instance._type ~= nil and class._type ~= nil and instance._type == class._type
end












function LuaUtils.dumpProperties(object, skipFunctions, maxDepth)




    local maxDepth = maxDepth or 1
    if maxDepth then
        if maxDepth < 0 then
            return object
        end

        maxDepth = maxDepth - 1
    end

    if type(object) ~= "table" then
        return object
    end

    local skipFunctions = skipFunctions == nil or skipFunctions
    local result = {}

    if object.__callEnumerateKeys then
        for _, key in object() do
            if key == "__immutableKeys" or key == "__callEnumerateKeys" or key == "__made" then
                continue
            end

            if type(object[key]) == "function" and skipFunctions then
                continue
            end

            result[LuaUtils.dumpProperties(key, skipFunctions, maxDepth)] = object[key] == nil and "nil" or LuaUtils.dumpProperties(object[key], skipFunctions, maxDepth)
        end
    else
        for k, v in object do
            if type(v) == "function" and skipFunctions then
                continue
            end
            result[LuaUtils.dumpProperties(k, skipFunctions, maxDepth)] = LuaUtils.dumpProperties(v, skipFunctions, maxDepth)
        end
    end

    return result
end











function LuaUtils.getStack(obj)
    local result = type(obj)


    if result == "table" and obj._type == "__DESTROYED__" then
        result = obj._stack
    end

    return result
end










function LuaUtils.forEach(tbl, f, ...)



    for _, value in tbl do
        f(value, table.unpack({ ... }))
    end
end












function LuaUtils.map(tbl, f, ...)



    local r = {}

    for i, value in tbl do
        r[i] = f(value, table.unpack({ ... }))
    end

    return r
end












function LuaUtils.compactMap(tbl, f, ...)




    local r = {}

    for k, value in tbl do
        local result = f(value, table.unpack({ ... }))
        table.insert(r, result)
    end

    return r
end










function LuaUtils.flatMap(tbl, f, ...)



    local r = {}

    for _, value in tbl do
        local result = f(value, table.unpack({ ... }))
        if result then


            for _, value in result do
                table.insert(r, value)
            end
        end
    end

    return r
end










function LuaUtils.reduce(tbl, initial, f, ...)




    local r = initial
    local args = { ... }

    LuaUtils.forEach(tbl, function(value)
        r = f(r, value, table.unpack(args))
    end)

    return r
end











function LuaUtils.equals(op1, op2)
    if op1 == nil or op2 == nil or type(op1) ~= "table" then
        return op1 == op2
    end

    if type(op1) ~= type(op2) then
        return false
    end

    if getmetatable(op1) or getmetatable(op2) then

        return false
    end


    if #op1 ~= #op2 then
        return false
    end

    for k, v in op1 do
        if not LuaUtils.equals(v, op2[k]) then
            return false
        end
    end

    return LuaUtils.effectiveSize(op1) == LuaUtils.effectiveSize(op2)
end









function LuaUtils.filter(list, f, ...)




    local r = {}
    for _, value in ipairs(list) do
        if f(value, table.unpack({ ... })) then
            table.insert(r, value)
        end
    end
    return r
end








function LuaUtils.find(table, value)



    for _key, _value in table do
        if value == _value then
            return true, _key
        end
    end
    return false
end









function LuaUtils.first(tbl, f, ...)


    for _, value in tbl do
        if f(value, table.unpack({ ... })) then
            return value
        end
    end

    return nil
end









function LuaUtils.makeSet(tbl)


    local set = {}

    for _, value in tbl do
        set[value] = true
    end

    return set
end












function LuaUtils.makeEnum(list, asInt)




    local asInt = asInt == nil and true or asInt
    local enum = {}
    for k, value in ipairs(list) do
        if enum[value] then
            error("LuaUtils.makeEnum: list cannot contain duplicates")
        end
        enum[value] = asInt and k or tostring(value)
    end
    return enum
end







function LuaUtils.clear(tbl)


    for k, v in tbl do
        tbl[k] = nil
    end

    return tbl
end











function LuaUtils.subrange(list, first, last)





    return table.move(list, first, last or #list, 1, {})
end












function LuaUtils.query(tbl, path)



    local keys = LuaUtils.splitString(path, '.')
    if #keys == 0 or #keys[1] == 0 then
        return nil
    end

    if #keys == 1 then
        return tbl[keys[1]]
    end

    if type(tbl[keys[1]]) ~= "table" then
        return nil
    end

    return LuaUtils.query(tbl[keys[1]], LuaUtils.joinStrings(LuaUtils.subrange(keys, 2), '.'))
end








function LuaUtils.removeByValue(list, pruneValue)




    local r = {}
    for _, value in list do
        if value ~= pruneValue then
            table.insert(r, value)
        end
    end
    return r
end













function LuaUtils.effectiveSize(tbl)


    local count = 0
    for _, _ in tbl do
        count = count + 1
    end
    return count
end








function LuaUtils.merge(tbl1, tbl2)



    local r = LuaUtils.duplicate(tbl1)

    for key, value in pairs(tbl2) do
        if type(key) == "number" then

            table.insert(r, value)
        else

            r[key] = value
        end
    end
    return r
end







function LuaUtils.getValues(tbl)


    local result = {}
    for _, v in tbl do
        table.insert(result, v)
    end
    return result
end







function LuaUtils.recursiveGetValues(tbl)


    local result = {}
    for k, v in pairs(tbl) do
        if LuaUtils.getClassName(v) == "table" then
           for kk, v2 in pairs(LuaUtils.recursiveGetValues(v)) do
               result[k .. "." .. kk] = v2
           end
        else
            result[k] = v
        end
    end
    return result
end







function LuaUtils.getKeys(tbl)


    local keys = {}
    for k in pairs(tbl) do
        table.insert(keys, k)
    end

    return keys
end







function LuaUtils.getUniqueValues(tbl)


    return LuaUtils.getKeys(LuaUtils.makeSet(tbl))
end









function LuaUtils.insertAbove(list, item, sibling)




    local found = false
    local r = {}
    for _, value in ipairs(list) do
        if value ~= item then
            if value == sibling then
                found = true
                table.insert(r, item)
            end
            table.insert(r, value)
        end
    end

    if not found then

        return nil
    end
    return r
end









function LuaUtils.insertBelow(list, item, sibling)




    local found = false
    local r = {}
    for _, value in ipairs(list) do
        if value ~= item then
            table.insert(r, value)
            if value == sibling then
                found = true
                table.insert(r, item)
            end
        end
    end

    if not found then

        return nil
    end
    return r
end







function LuaUtils.isEmpty(tbl)


    return not next(tbl)
end







function LuaUtils.duplicate(tbl)


    local r = {}
    for key, value in pairs(tbl) do
        r[key] = value
    end
    return r
end







function LuaUtils.enumerated(tbl)



    return tbl
end







function LuaUtils.numberedKeys(tbl)


    if not tbl then
        return nil
    end
    local r = {}
    for key, value in pairs(tbl) do
        local numberedKey = tonumber(key)
        if numberedKey then
            r[numberedKey] = value
        else
            error("Cannot convert '" .. key .. "' to number")
        end
    end
    return r
end















function LuaUtils.spairs(tbl, order)




    local keys = {}
    for k in pairs(tbl) do
        table.insert(keys, k)
    end




    if order then
        table.sort(keys, function(k1, k2) return order(tbl, k1, k2) end)
    else
        table.sort(keys)
    end


    local i = 0
    return function()
        i = i + 1
        if keys[i] then
            return keys[i], tbl[keys[i]]
        end
    end
end








function LuaUtils.splitString(s, delimiter)



    local result = {}

    local from  = 1
    local delim_from, delim_to = string.find(s, delimiter, from, true)
    while delim_from do
        table.insert(result, string.sub(s, from, delim_from - 1))
        from = delim_to + 1
        delim_from, delim_to = string.find(s, delimiter, from, true)
    end
    table.insert(result, string.sub(s, from))

    return result
end









function LuaUtils.joinStrings(parts, joinStr, reverse)




    local reverse = reverse ~= nil and reverse or false
    local result = ""
    for i=1, #parts do
        if result:len() > 0 then
            result = result .. joinStr
        end
        result = result .. parts[reverse and (#parts + 1 - i) or i]
    end
    return result
end






function LuaUtils.trimNewlines(s)


    return s:gsub("\n+$", "")
end








function LuaUtils.hasPrefix(s, prefix)



    return string.sub(s, 1, string.len(prefix)) == prefix
end








function LuaUtils.hasSuffix(s, suffix)



    return s:len() >= suffix:len() and s:sub(-suffix:len()) == suffix
end







function LuaUtils.isColor(color)
    return type(color) == "string" and color:find("#") == 1 and color:len() == 9
end








function LuaUtils.round(x, precision)
    local y = 10^(precision or 0)
    return x >= 0
        and math.floor(x * y + 0.5) / y
        or math.ceil(x * y - 0.5) / y
end










function LuaUtils.numberToString(number, maxFractionDigits, minFractionDigits, minIntegerDigits)





    maxFractionDigits = maxFractionDigits or 0
    minFractionDigits = minFractionDigits or maxFractionDigits
    minIntegerDigits = minIntegerDigits or 0

    number = LuaUtils.round(number, maxFractionDigits)

    local formatString
    if minIntegerDigits > 0 then

        local signSymbolLength = number < 0 and 1 or 0
        local dotLength = maxFractionDigits > 0 and 1 or 0
        formatString = string.format("%%0%d.%df", minIntegerDigits + maxFractionDigits + signSymbolLength + dotLength, maxFractionDigits)
    else
        formatString = string.format("%%.%df", maxFractionDigits)
    end

    local numberString = string.format(formatString, number)


    local maxCharsToRemove = maxFractionDigits - minFractionDigits
    if maxFractionDigits > 0 and maxCharsToRemove > 0 then
        local charsToRemove = 0
        for i = #numberString, #numberString - maxCharsToRemove, -1 do
            local c = numberString:sub(i, i)
            if c == "0" then
                charsToRemove = charsToRemove + 1
            elseif c == "." then
                break
            end
        end
        local length  = #numberString - charsToRemove

        if length > 0 and numberString:sub(length, length) == "." then
            length = length - 1
        end
        numberString = numberString:sub(1, length)
    end

    return numberString
end








function LuaUtils.parseColor(color, premultiplyAlpha)



    color = tonumber(color:sub(2), 16)
    local r = LuaUtils.andBit(LuaUtils.rshiftBit(color, 24), 0xff) / 0xff
    local g = LuaUtils.andBit(LuaUtils.rshiftBit(color, 16), 0xff) / 0xff
    local b = LuaUtils.andBit(LuaUtils.rshiftBit(color,  8), 0xff) / 0xff
    local a = LuaUtils.andBit(color, 0xff) / 0xff
    if premultiplyAlpha then
        r = r * a
        g = g * a
        b = b * a
    end
    return r, g, b, a
end










function LuaUtils.createColor(r, g, b, a)





    local function hex(component)
        return string.format("%02x", math.max(0, math.min(math.floor(component * 0xff), 0xff)))
    end

    return "#" .. hex(r) .. hex(g) .. hex(b) .. hex(a)
end








function LuaUtils.setAlpha(color, alpha)



    local r, g, b, _ = LuaUtils.parseColor(color, false)
    return LuaUtils.createColor(r, g, b, alpha)
end
















function LuaUtils.lowpass(old, new, coefficient)




    return coefficient * new + (1.0 - coefficient) * (old or 0.)
end











function LuaUtils.prettyPrint(object, newlines, maxDepth, _indent)




    local object = object

    if object == nil then
        return "<nil>"
    end

    _indent = _indent or 1

    if type(object) == "string" then
        return "'" .. object .. "'"
    end

    if type(object) == "number" then
        return tostring(object)
    end

    if type(object) == "table" then
        local maxDepth = maxDepth or 1
        if maxDepth then
            if maxDepth < 0 then
                return "" .. type(object)
            end

            maxDepth = maxDepth - 1
        end

        local r = "{"
        local first = true
        local append = function(k, v)

            if not first then
                r = r .. ", "
            else
                r = r .. " "
            end
            first = false


            if newlines then
                r = r .. "\n"
                for _ = 1, _indent do
                    r = r .. "  "
                end
            end


            if k then

                k = type(k) == "string" and (string.find(k, " ", 1, true) and "[\""..k.."\"]" or k) or "["..LuaUtils.prettyPrint(k, newlines, maxDepth).."]"
                r = r .. k .. " = "
            end

            r = r .. LuaUtils.prettyPrint(v, newlines, maxDepth, _indent + 1)
        end


        if object.__callEnumerateKeys then
            object = LuaUtils.dumpProperties(object, true, maxDepth + 1)
        end


        if _prettyPrintSortTableKeys and #object ~= LuaUtils.effectiveSize(object) then

            local order = function(tbl, k1, k2)
                if type(k1) == "string" or type(k1) == "number" then
                    if type(k1) == type(k2) then
                        return k1 < k2
                    else
                        return true
                    end
                end

                return false
            end
            for k, v in LuaUtils.spairs(object, order) do
                if type(v) == "function" then
                    continue
                end

                append(k, v)
            end
        else
            for k, v in object do
                if type(v) == "function" then
                    continue
                end

                append(k, v)
            end
        end


        if not first then
            if newlines then
                r = r .. "\n"
                for _ = 1, (_indent - 1) do
                    r = r .. "  "
                end
            else
                r = r .. " "
            end
        end
        r = r .. "}"

        return r
    end

    return tostring(object)
end







function LuaUtils.bit(i)

    return 2 ^ (i - 1)
end










function LuaUtils.hasBit(x, b)


    return x % (b + b) >= b
end










function LuaUtils.setBit(x, b)


    return LuaUtils.hasBit(x, b) and x or x + b
end










function LuaUtils.clearBit(x, b)


    return LuaUtils.hasBit(x, b) and x - b or x
end







function LuaUtils.andBit(...)
    return bit32.band(...)
end







function LuaUtils.orBit(...)
    return bit32.bor(...)
end








function LuaUtils.lshiftBit(number, n)
    return bit32.lshift(number, n)
end








function LuaUtils.rshiftBit(number, n)
    return bit32.rshift(number, n)
end








function LuaUtils.validateClassName(instance, ...)
    local args = {...}
    for _, v in ipairs(args) do
        if LuaUtils.getClassName(instance) == v then
            return true
        end
    end


    return false
end









function LuaUtils.safeCall(failureResult, f, ...)




    local checkresult = function(ok, ...)
        if ok then
            return ... -- success, strip 'true' value
        else
            return failureResult, ... -- failure; failureResult + error
        end
    end

    return checkresult(xpcall(f, debug.traceback, ...))
end










function LuaUtils.urlQueryParameters(url)


    local queryStart = string.find(url, "?")
    if queryStart then
        local query = string.sub(url, queryStart + 1)
        local ret = {}
        for k,v in string.gmatch(query, "([^&=]-)=([^&=]*)") do
            ret[k] = v
        end

        return ret
    end

    return {}
end










function LuaUtils.cachedValue(cache, key, f, ...)




    local value = cache[key]
    if value == nil then
        value = f(...)
        cache[key] = value
    end

    return value
end






function toboolean(v)
    return v ~= nil and v ~= false
end



LuaUtils.lockGlobals()

return LuaUtils.readOnly(LuaUtils)
