-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local AttributedString = require "APL.AttributedString"
local flux = require "APL.flux"
local Font = require "APL.Font"
local ImageLayer = require "APL.ImageLayer"
local Layer = require "APL.Layer"
local LuaUtils = require "APL.LuaUtils"
local RasterFont = require "APL.RasterFont"
local Rect = require "APL.Rect"
local Texture = require "APL.Texture"
local Transform = require "APL.Transform"

local TextLayer = LuaUtils.makeObject({ _type = "TextLayer" }, Layer)


local function validateClassName(self)
    local allowedTypes = {
        TextLayer = true,
        NumberLayer = true,
        CurvedTextLayer = true,
        StableNumberLayer = true,
    }
    return allowedTypes[LuaUtils.getClassName(self)]
end













function TextLayer.new(font, name)



    font = font or RasterFont.new()

    local self = LuaUtils.newObject(TextLayer, {
        _text = "", -- Stored to manage the redaction state.
        _string = AttributedString.new("", font),
        _container = Rect.new(0, 0, 0, 0),
        _redacted = false,
        _textFrame = LuaUtils.NIL,
        _renderedText = LuaUtils.NIL,
        _needsLayout = false -- for layout updates not tracked by textlayoutManager such as color changing
    }, Layer.new())

    if name then
        self:setName(name)
    end

    return self
end






function TextLayer:destroy()


    flux.clear(self._tweens.foregroundColor or {})

    if self._textFrame then
        self._textFrame:destroy()
        self._textFrame = nil
    end

    if self._renderedText then
        self._renderedText:destroy()
        self._renderedText = nil
    end

    self._string:destroy()
    self._string = nil

    Layer.destroy(self)
end








function TextLayer:setFrame(rect, skipUpdateLayout)




    local frame = self._nativeLayer.frame
    self._nativeLayer.frame = rect:getNativeRect()


    if rect._width == frame.width and rect._height == frame.height then
        return self
    end

    self._container = Rect.new(0, 0, rect._width, rect._height)

    self:setNeedsLayout()

    if not skipUpdateLayout then
        self:updateLayout()
    end

    return self
end








function TextLayer:setText(text, skipUpdateLayout)




    if self._text ~= text then
        self._text = text

        self:_updateText()
            :setNeedsLayout()

        if not skipUpdateLayout then
            self:updateLayout()
        end
    end

    return self
end






function TextLayer:getText()


    return self._string:getString()
end








function TextLayer:setForegroundColor(color, skipUpdateLayout)




    flux.clear(self._tweens.foregroundColor or {})

    if self._string:getColor() ~= color then
        self._string:setColor(color)

        if self._renderedText then
            self._renderedText:setColor(color)
        end
    end

    return self
end








function TextLayer:animForegroundColor(color, duration)




    self._tweens.foregroundColor = self._tweens.foregroundColor or {}

    local startColor = self._string:getColor() and table.pack(LuaUtils.parseColor(self._string:getColor(), false)) or { 0, 0, 0, 0 }
    self._tweens.foregroundColor.r = startColor[1]
    self._tweens.foregroundColor.g = startColor[2]
    self._tweens.foregroundColor.b = startColor[3]
    self._tweens.foregroundColor.a = startColor[4]

    local rgba = color and table.pack(LuaUtils.parseColor(color, false)) or { 0, 0, 0, 0 }
    local targetColor = { r = rgba[1], g = rgba[2], b = rgba[3], a = rgba[4] }
    return flux.to(self._tweens.foregroundColor, duration, targetColor)
        :onupdate(function(tween)
            color = LuaUtils.createColor(tween.r, tween.g, tween.b, tween.a)
            self._string:setColor(color)

            if self._renderedText then
                self._renderedText:setColor(color)
            end
        end)
end








function TextLayer:setFont(font, skipUpdateLayout)




    self._string:setFont(font)

    self:setNeedsLayout()

    if not skipUpdateLayout then
        self:updateLayout()
    end

    return self
end






function TextLayer:getFont()


    return self._string:getFont()
end








function TextLayer:setAlignment(alignment, skipUpdateLayout)




    self._string:setAlignment(alignment)

    self:setNeedsLayout()

    if not skipUpdateLayout then
        self:updateLayout()
    end

    return self
end








function TextLayer:setRedacted(redacted, skipUpdateLayout)




    if self._redacted ~= redacted then
        self._redacted = redacted

        self._string:setRequiresContainerRasterization(redacted)

        self:_updateText()
            :setNeedsLayout()

        if not skipUpdateLayout then
            self:updateLayout()
        end
    end

    return self
end






function TextLayer:isRedacted()


    return self._redacted
end






function TextLayer:getRedactedText()


    local characters = #self._text

    if self._string:getFramesetter().supportsContextualAlternates() then
        return string.rep("\u{100BB7}", characters)
    end


    return characters > 0 and ("\u{100BB7}" .. string.rep("\u{100BB8}", characters - 1)) or ""
end






function TextLayer:getAttributedString()


    return self._string
end











function TextLayer:setAttributedString(attributedString, skipUpdateLayout)




    self._string = attributedString

    self._text = attributedString:getString()

    if self._textFrame then
        self._textFrame:destroy()
        self._textFrame = nil
    end

    if self._renderedText then
        self._renderedText:destroy()
        self._renderedText = nil
    end

    self:_updateText()
        :setNeedsLayout()

    if not skipUpdateLayout then
        self:updateLayout()
    end

    return self
end






function TextLayer:needsLayout()


    return self._needsLayout
end






function TextLayer:setNeedsLayout()


    self._needsLayout = true

    return self
end






function TextLayer:updateLayoutIfNeeded()


    if not self:needsLayout() then
        return self
    end

    self:updateLayout()

    return self
end






function TextLayer:updateLayout()




    if self._textFrame then
        self._textFrame:destroy()
    end

    self._textFrame = self:_layoutFrame()
    if self._textFrame then
        self._renderedText = self._textFrame:renderInto(self, self._string:getColor(), self._renderedText)
    else
        self._renderedText:destroy()
        self._renderedText = nil
    end

    self._needsLayout = false

    return self
end






function TextLayer:getBoundingRect()


    return self._textFrame and self._textFrame:getBoundingBox() or Rect.new(0, 0, 0, 0)
end








function TextLayer:setContainer(container, skipUpdateLayout)




    self._container = container

    self:setNeedsLayout()

    if not skipUpdateLayout then
        self:updateLayout()
    end

    return self
end






function TextLayer:getTextFrame()


    return self._textFrame
end






function TextLayer:_updateText()


    local text = self._redacted and self:getRedactedText() or self._text
    self._string:setString(text)

    return self
end






function TextLayer:_layoutFrame()





    local framesetter = self._string:getFramesetter()
    return framesetter:layoutFrame(self._container)
end

return LuaUtils.readOnly(TextLayer)
