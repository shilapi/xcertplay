-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local flux = require "APL.flux"
local Layer = require "APL.Layer"
local LuaUtils = require "APL.LuaUtils"

local ShapeLayer = LuaUtils.makeObject({ _type = "ShapeLayer" }, Layer)

ShapeLayer.FILLRULE = LuaUtils.readOnly({
    EVENODD = CP.DPShapeLayer.FILLRULE.EVENODD,
    NONZERO = CP.DPShapeLayer.FILLRULE.NONZERO,
})

ShapeLayer.LINECAP = LuaUtils.readOnly({
    ROUND = CP.DPShapeLayer.LINECAP.ROUND,
    SQUARE = CP.DPShapeLayer.LINECAP.SQUARE,
    BUTT = CP.DPShapeLayer.LINECAP.BUTT,
})

ShapeLayer.LINEJOIN = LuaUtils.readOnly({
    MITER = CP.DPShapeLayer.LINEJOIN.MITER,
    ROUND = CP.DPShapeLayer.LINEJOIN.ROUND,
    BEVEL = CP.DPShapeLayer.LINEJOIN.BEVEL,
})

local FILLRULE_TYPES = LuaUtils.getValues(ShapeLayer.FILLRULE)
local LINECAP_TYPES = LuaUtils.getValues(ShapeLayer.LINECAP)
local LINEJOIN_TYPES = LuaUtils.getValues(ShapeLayer.LINEJOIN)






function ShapeLayer.new()
    return LuaUtils.newObject(ShapeLayer, {}, Layer.new(CP.DPShapeLayer.create()))
end






function ShapeLayer:destroy()


     flux.clear(self._tweens.strokeColor or {})

     Layer.destroy(self)
end







function ShapeLayer:setPath(path)



    self._nativeLayer.path = path._nativePath

    return self
end







function ShapeLayer:setLineWidth(width)



    self._nativeLayer.lineWidth = width

    return self
end







function ShapeLayer:setStrokeColor(color)



    flux.clear(self._tweens.strokeColor or {})

    if color then
        local r, g, b, a = LuaUtils.parseColor(color, false)
        self._nativeLayer.strokeColor = CP.DPColor(r, g, b, a)
    else
        self._nativeLayer.strokeColor = CP.DPColor(0, 0, 0, 0)
    end

    return self
end








function ShapeLayer:animStrokeColor(color, duration)





    self._tweens.strokeColor = self._tweens.strokeColor or {}
    local startColor = self._nativeLayer.strokeColor
    self._tweens.strokeColor.r = startColor.r
    self._tweens.strokeColor.g = startColor.g
    self._tweens.strokeColor.b = startColor.b
    self._tweens.strokeColor.a = startColor.a

    local rgba = color and table.pack(LuaUtils.parseColor(color, false)) or { 0, 0, 0, 0 }
    local targetColor = { r = rgba[1], g = rgba[2], b = rgba[3], a = rgba[4] }

    return flux.to(self._tweens.strokeColor, duration, targetColor)
        :onupdate(function(tween)
            self._nativeLayer.strokeColor = CP.DPColor(tween.r, tween.g, tween.b, tween.a)
        end)
end







function ShapeLayer:setStrokeStart(value)



    flux.clear(self._tweens, { strokeStart = true })
    self._nativeLayer.strokeStart = value

    return self
end






function ShapeLayer:getStrokeStart()


    return self._nativeLayer.strokeStart
end







function ShapeLayer:setAntialiased(antialiased)



    self._nativeLayer.antialiased = antialiased

    return self
end








function ShapeLayer:animStrokeStart(newValue, duration)




    self._tweens.strokeStart = self._nativeLayer.strokeStart

    return flux.to(self._tweens, duration, { strokeStart = newValue })
        :onupdate(function()
            self._nativeLayer.strokeStart = self._tweens.strokeStart
        end)
end







function ShapeLayer:setStrokeEnd(value)



    flux.clear(self._tweens, { strokeEnd = true })
    self._nativeLayer.strokeEnd = value

    return self
end






function ShapeLayer:getStrokeEnd()


    return self._nativeLayer.strokeEnd
end








function ShapeLayer:animStrokeEnd(newValue, duration)




    self._tweens.strokeEnd = self._nativeLayer.strokeEnd

    return flux.to(self._tweens, duration, { strokeEnd = newValue })
        :onupdate(function()
            self._nativeLayer.strokeEnd = self._tweens.strokeEnd
        end)
end







function ShapeLayer:setFillColor(color)



    if color then
        local r, g, b, a = LuaUtils.parseColor(color, false)
        local color = CP.DPColor(r, g, b, a)
        self._nativeLayer.fillColor = color
    else
        self._nativeLayer.fillColor = CP.DPColor(0, 0, 0, 0)
    end

    return self
end







function ShapeLayer:setFillRule(rule)




    self._nativeLayer.fillRule = rule

    return self
end







function ShapeLayer:setLineCap(cap)




    self._nativeLayer.lineCap = cap

    return self
end







function ShapeLayer:setLineJoin(join)




    self._nativeLayer.lineJoin = join

    return self
end







function ShapeLayer:setMiterLimit(limit)



    self._nativeLayer.miterLimit = limit

    return self
end

return LuaUtils.readOnly(ShapeLayer)
