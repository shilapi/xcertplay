-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"

local Effect = LuaUtils.makeObject({ _type = "Effect" })











function Effect.new(work, cancel, cancellableID)



    local self = LuaUtils.newObject(Effect, {
        _work = work or LuaUtils.NIL,
        _cancel = cancel or LuaUtils.NIL,
        _cancellableID = cancellableID or LuaUtils.NIL
    })

    return self
end






function Effect:destroy()


    if self._cancel then
        self._cancel(false)
        self._cancel = nil
    end
end






function Effect:hasWork()


    return self._work ~= nil
end







function Effect:work(dispatch)



    if self._work then
        self._work(dispatch)
        self._work = nil
    end

    return self
end






function Effect:cancel()


    if self._cancel then
        self._cancel(true)
        self._cancel = nil
    end

    return self
end






function Effect:getCancellableID()


    return self._cancellableID
end

return LuaUtils.readOnly(Effect)