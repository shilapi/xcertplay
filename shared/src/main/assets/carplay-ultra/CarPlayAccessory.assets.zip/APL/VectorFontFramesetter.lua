-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local AttributedString = require "APL.AttributedString"
local LuaUtils = require "APL.LuaUtils"
local VectorFontFrame = require "APL.VectorFontFrame"

local VectorFontFramesetter = LuaUtils.makeObject({ _type = "VectorFontFramesetter" })

local NATIVE_ALIGNMENT = LuaUtils.readOnly({
    [AttributedString.ALIGNMENT.LEFT] = 0,
    [AttributedString.ALIGNMENT.RIGHT] = 1,
    [AttributedString.ALIGNMENT.CENTER] = 0.5
})







function VectorFontFramesetter.new(string)


    local self = LuaUtils.newObject(VectorFontFramesetter, {
        _string = string,
    })

    return self
end






function VectorFontFramesetter:destroy()

end







function VectorFontFramesetter:layoutFrame(container)



    local text = self._string:getString()
    local alignment = self._string:getAlignment()
    local tracking = self._string:getTracking()

    local font = self._string:getFont()
    local fontSize = font:getPointSize()
    local layout = CP.DPTextLayout()

    layout.pageWidth = container._width
    layout.pageHeight = container._height

    layout:addText(text, font:getNativeRepresentation())
    layout:setPageAlignment(0.5) -- Vertically center the text.
    layout:setAlignment(NATIVE_ALIGNMENT[alignment] or 0)
    layout:setTracking(tracking * 1000 / fontSize)

    return VectorFontFrame.new(layout, container)
end






function VectorFontFramesetter:supportsContextualAlternates()



    return true
end

return LuaUtils.readOnly(VectorFontFramesetter)