-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Log = { _type = "Log" }

local LuaUtils = require "APL.LuaUtils"
local CP = CP or require "CPMock" -- Mock CP bridge for exporting ASCPaths using Luau since Globals are locked per scripts

Log.LEVEL = LuaUtils.readOnly({
    TRACE = CP.LOGLEVELS.TRACE,
    DEBUG = CP.LOGLEVELS.DEBUG,
    INFO = CP.LOGLEVELS.INFO,
    WARNING = CP.LOGLEVELS.WARNING,
    ERROR = CP.LOGLEVELS.ERROR,
    NONE = CP.LOGLEVELS.NONE,
})

local LEVEL_NAMES = (function()
    local result = {}
    for k, v in Log.LEVEL do
        result[v] = k
    end
    return result
end)()


local _level = CP.getLogLevel()
local _prefix = ""
local _indent = 0
local _levelsByTag = {}






function Log.getLevel()
    return LEVEL_NAMES[_level]
end







function Log.setLevel(level, tag)




    local result, str = pcall(function()
        if type(level) == "string" then
            level = Log.LEVEL[level] or error("Invalid log level \"" .. level .. "\"")
        end

        if tag then
            tag = type(tag) == "string" and tag or tag._type
            _levelsByTag[tag] = level
            return
        end

        _level = level
        CP.setLogLevel(level)
    end)

    if not result then
        print("Error setting log level: " .. str or "unknown error")
    end

    return result
end






function Log.setPrefix(prefix)


    _prefix = prefix == nil and "" or prefix .. " | "
end
















function Log._log(level, tag, message, ...)




    local tag = type(tag) == "string" and tag or tag._type


    if _levelsByTag[tag] == nil and level < _level then
        return nil
    end

    if _levelsByTag[tag] ~= nil and level < _levelsByTag[tag] then
        return nil
    else


        level = _level
    end




    if type(message) == "function" then
        local result = table.pack(message())
        if #result == 1 then
            message = result[1]
        else
            message = string.format(result[1], select("2", table.unpack(result)))
        end

    elseif #{...} > 0 then
        message = string.format(message, ...)
    end

    CP.log(level, _prefix .. tag, "" .. message)


    return tag, message
end









function Log.trace(tag, message, ...)
    return Log._log(Log.LEVEL.TRACE, tag, message, ...)
end









function Log.debug(tag, message, ...)
    return Log._log(Log.LEVEL.DEBUG, tag, message, ...)
end









function Log.info(tag, message, ...)
    return Log._log(Log.LEVEL.INFO, tag, message, ...)
end









function Log.warn(tag, message, ...)
    return Log._log(Log.LEVEL.WARNING, tag, message, ...)
end









function Log.error(tag, message, ...)
    return Log._log(Log.LEVEL.ERROR, tag, message, ...)
end









function Log.log(tag, message, ...)
    return Log._log(Log.LEVEL.NONE, tag, message, ...)
end











function Log.measure(tag, message, bypassLogLevel, f, ...)






    if not bypassLogLevel and _level > Log.LEVEL.DEBUG then
        return f(...)
    end

    local startTime = CP.getSystemUpTime()


    local limit = 10
    if type(tag) ~= "string" then
        tag = LuaUtils.getClassName(tag)
    end
    tag = string.sub(tag .. string.rep(" ", limit - string.len(tag)), 1, limit)


    for i=0,_indent do message = " " .. message end

    Log.info(tag, message .. " started...")

    _indent = _indent + 1


    local result = table.pack(f(...))

    Log.info(tag, message .. " ended: " .. (CP.getSystemUpTime() - startTime) * 1000 .. " ms.")

    _indent = _indent - 1

    return table.unpack(result)
end


LuaUtils.runWithUnlockedGlobals(function()
    origPrint = print
    print = function(...)
        local arg = {...}
        local output = arg[1]
        if #arg > 1 then
            for i=2, #arg do
                output = output.."\t"..arg[i]
            end
        end
        Log._log(Log.LEVEL.NONE, "Lua", output);
    end
end)

return LuaUtils.readOnly(Log)
