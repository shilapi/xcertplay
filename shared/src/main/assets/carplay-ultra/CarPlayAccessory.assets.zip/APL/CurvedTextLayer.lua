-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local AttributedString = require "APL.AttributedString"
local CurvedTextLayoutManager = require "APL.CurvedTextLayoutManager"
local Font = require "APL.Font"
local Layer = require "APL.Layer"
local LuaUtils = require "APL.LuaUtils"
local TextLayer = require "APL.TextLayer"

local CurvedTextLayer = LuaUtils.makeObject({ _type = "CurvedTextLayer" }, TextLayer)








function CurvedTextLayer.new(font, name)


    local textLayoutManager = CurvedTextLayoutManager.new()

    local self = LuaUtils.newObject(CurvedTextLayer, {
        _layoutManager = textLayoutManager
    }, TextLayer.new(font, name))


    self:setAlignment(AttributedString.ALIGNMENT.CENTER)

    return self
end






function CurvedTextLayer:destroy()


    TextLayer.destroy(self)
end













function CurvedTextLayer:setLayoutAngles(leadingAngle, trailingAngle, skipUpdateLayout)





    local currentLeadingAngle, currentTrailingAngle = self._layoutManager:getAngles()
    if currentLeadingAngle ~= leadingAngle or currentTrailingAngle ~= trailingAngle then
        self._layoutManager
            :setLeadingAngle(leadingAngle)
            :setTrailingAngle(trailingAngle)

        self:setNeedsLayout()

        if not skipUpdateLayout then
            self:updateLayout()
        end
    end

    return self
end








function CurvedTextLayer:setClockwiseLayout(clockwise, skipUpdateLayout)




    if self._layoutManager:isClockwiseLayout() ~= clockwise then
        self._layoutManager:setClockwiseLayout(clockwise)

        self:setNeedsLayout()

        if not skipUpdateLayout then
            self:updateLayout()
        end
    end

    return self
end









function CurvedTextLayer:setOrigin(x, y, skipUpdateLayout)





    local currentX, currentY = self._layoutManager:getOrigin()
    if currentX ~= x or currentY ~= y then
        self._layoutManager:setOrigin(x, y)

        self:setNeedsLayout()

        if not skipUpdateLayout then
            self:updateLayout()
        end
    end

    return self
end








function CurvedTextLayer:setRadius(radius, skipUpdateLayout)




    if self._layoutManager:getRadius() ~= radius then
        self._layoutManager:setRadius(radius)

        self:setNeedsLayout()

        if not skipUpdateLayout then
            self:updateLayout()
        end
    end

    return self
end






function CurvedTextLayer:_layoutFrame()


    local framesetter = self._string:getFramesetter()
    local frame = framesetter:layoutFrame(self._container)
    self._layoutManager:applyLayout(self:getAttributedString(), frame)

    return frame
end

return LuaUtils.readOnly(CurvedTextLayer)
