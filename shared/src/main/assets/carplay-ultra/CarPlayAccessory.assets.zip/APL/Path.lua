-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"

local Path = LuaUtils.makeObject({ _type = "Path" })






function Path.new()
    local self = LuaUtils.newObject(Path, {

        _nativePath = CP.DPPath.create(),
    })

    return self
end






function Path:destroy()


    self._nativePath = nil
end








function Path:moveTo(x, y)




    self._nativePath:moveTo(CP.DPPoint(x, y))

    return self
end








function Path:lineTo(x, y)




    self._nativePath:lineTo(CP.DPPoint(x, y))

    return self
end










function Path:quadTo(x, y, cpx, cpy)






    self._nativePath:quadTo(CP.DPPoint(x, y), CP.DPPoint(cpx, cpy))

    return self
end












function Path:cubeTo(x, y, cp1x, cp1y, cp2x, cp2y)








    self._nativePath:cubeTo(CP.DPPoint(x, y), CP.DPPoint(cp1x, cp1y), CP.DPPoint(cp2x, cp2y))

    return self
end












function Path:arcTo(x, y, radius, startAngle, endAngle, clockwise)








    self._nativePath:arcTo(CP.DPPoint(x, y), radius, startAngle, endAngle, clockwise)

    return self
end






function Path:closeSubpath()


    self._nativePath:closeSubpath()

    return self
end






function Path:getNumPoints()


    return self._nativePath.numPoints
end







function Path:ellipseIn(rect)



    self._nativePath:ellipseInRect(rect:getNativeRect())

    return self
end







function Path:rectangleIn(rect)



    local minX = rect._x
    local minY = rect._y
    local maxX = rect._x + rect._width
    local maxY = rect._y + rect._height

    self:moveTo(minX, minY)
        :lineTo(maxX, minY)
        :lineTo(maxX, maxY)
        :lineTo(minX, maxY)
        :closeSubpath()

    return self
end









function Path:roundedRectangleIn(rect, cornerRadius)




    local CONTINUOUS_CURVES_SIZE_FACTOR = 1.528665
    local cornerSize = math.min(cornerRadius * CONTINUOUS_CURVES_SIZE_FACTOR, math.min(rect._width, rect._height) / 2)

    local minX = rect._x
    local minY = rect._y
    local maxX = rect._x + rect._width
    local maxY = rect._y + rect._height

    self:moveTo(minX + cornerSize, minY)
        :lineTo(maxX - cornerSize, minY)
        :quadTo(maxX, minY + cornerSize, maxX, minY)
        :lineTo(maxX, maxY - cornerSize)
        :quadTo(maxX - cornerSize, maxY, maxX, maxY)
        :lineTo(minX + cornerSize, maxY)
        :quadTo(minX, maxY - cornerSize, minX, maxY)
        :lineTo(minX, minY + cornerSize)
        :quadTo(minX + cornerSize, minY, minX, minY)

    return self
end

return LuaUtils.readOnly(Path)
