-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Layer = require "APL.Layer"
local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"
local Signpost = require "APL.Signpost"

local VideoLayer = LuaUtils.makeObject({ _type = "VideoLayer" }, Layer)

VideoLayer.STREAMSTATE = LuaUtils.readOnly({
    CLOSED = CP.DPVideoLayer.STREAMSTATE.CLOSED,
    SUBSCRIBED = CP.DPVideoLayer.STREAMSTATE.SUBSCRIBED,
    DATAAVAILABLE = CP.DPVideoLayer.STREAMSTATE.DATAAVAILABLE,
    UNSUBSCRIBED = CP.DPVideoLayer.STREAMSTATE.UNSUBSCRIBED,
    INVALID = CP.DPVideoLayer.STREAMSTATE.INVALID,
})

local _subscribable = false
local _videoLayers = nil







function VideoLayer.new(identifier)


    local self = LuaUtils.newObject(VideoLayer, {
        _identifier = identifier,
        _subscribed = false
    }, Layer.new(CP.DPVideoLayer.create(identifier)))

    if not _videoLayers then
        _videoLayers = {}



        setmetatable(_videoLayers, { __mode = "k" })
    end

    _videoLayers[self] = true

    return self
end






function VideoLayer:destroy()


    self:unsubscribe()

    _videoLayers[self] = nil

    Layer.destroy(self)
end








function VideoLayer.setSubscribable(subscribable)


    if _subscribable == subscribable then
        return
    end


    if subscribable then
        _subscribable = subscribable
    end

    for videoLayer in pairs(_videoLayers or {}) do
        Log.info(VideoLayer, function() return "Making `" .. videoLayer._identifier .. "` " .. (subscribable and "subscribable" or "unsubscribable") end)


        if subscribable then
            if videoLayer._subscribed then
                videoLayer:subscribe()
            end

        elseif videoLayer._subscribed then
            videoLayer:unsubscribe()
            videoLayer._subscribed = true -- unsubscribe resets it to set it back for when we become subscribable again
        end
    end

    _subscribable = subscribable
end






function VideoLayer:getStreamState()


    return self._nativeLayer.streamState
end






function VideoLayer:getCurrentPTS()


    return self._nativeLayer:getCurrentPTS()
end










function VideoLayer:getNextPTS()


    return self._nativeLayer:getNextPTS()
end








function VideoLayer:deferNextPTS()


    self._nativeLayer:deferNextPTS()
    return self
end






function VideoLayer:flush()


    self._nativeLayer:flush()
    return self
end






function VideoLayer:subscribe()


    Signpost.emitEvent("Subscribing to input stream " .. self._identifier)
    Log.info(VideoLayer, function() return "Subscribing to input stream `" .. self._identifier .. "`" end)

    self._subscribed = true

    if not _subscribable then
        Log.info(VideoLayer, function() return "Ignoring subscription request to `" .. self._identifier .. "`" end)
        return self
    end

    self._nativeLayer:subscribe()
    return self
end






function VideoLayer:unsubscribe()


    Signpost.emitEvent("Unsubscribing from input stream " .. self._identifier)
    Log.info(VideoLayer, function() return "Unsubscribing from input stream `" .. self._identifier .. "`" end)

    self._subscribed = false

    if not _subscribable then
        Log.info(VideoLayer, function() return "Ignoring unsubscription request to `" .. self._identifier .. "`" end)
        return self
    end

    if self:isSubscribed() then
        self._nativeLayer:unsubscribe()
    end

    return self
end






function VideoLayer:isSubscribed()


    return self._nativeLayer.active
end







function VideoLayer:setVisible(isVisible)



    if not self._nativeLayer.hidden == isVisible then
        Log.info(VideoLayer, function() return "Ignoring visibility update, video layer already " .. tostring(isVisible) .. " for `" .. self._identifier .. "`" end)
        return self
    end

    if isVisible then
        self:subscribe()
    else
        self:unsubscribe()
    end

    Layer.setVisible(self, isVisible)

    return self
end







function VideoLayer.isVisible(identifier)


    local visibility = false
    for videoLayer, _ in pairs(_videoLayers) do
        if videoLayer._identifier == identifier and videoLayer:getVisible() then
            return true
        end
    end

    return false
end

return LuaUtils.readOnly(VideoLayer)