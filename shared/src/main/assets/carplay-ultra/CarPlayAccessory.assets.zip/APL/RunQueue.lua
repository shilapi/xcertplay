-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local LuaUtils = require "APL.LuaUtils"
local Thread = require "APL.Thread"
local Throttle = require "APL.Throttle"

local RunQueue = LuaUtils.makeObject({ _type = "RunQueue" })











function RunQueue.new(maxNumEntries, name)



    local self = LuaUtils.newObject(RunQueue, {

        _runQueueHandler = LuaUtils.NIL,


        _maxNumEntries = maxNumEntries or LuaUtils.NIL,


        _name = name or LuaUtils.NIL,


        _runQueue = {},


        _activeThreads = {},
    })
    return self
end






function RunQueue:destroy()



    for thread, _ in pairs(self._activeThreads) do
        if thread ~= Thread.current() then
            thread:destroy()
        end
    end


    if self._runQueueHandler then
        self._runQueueHandler:destroy()
    end
end







function RunQueue:post(f, ...)




    if self._maxNumEntries then
        while #self._runQueue >= self._maxNumEntries do
            table.remove(self._runQueue, 1)
        end
    end


    local entry = { f = f, args = {...} }
    table.insert(self._runQueue, entry)


    if not self._runQueueHandler then
        self._runQueueHandler = Thread.new(function()
            while true do
                local throttle = Throttle.new()
                local didYield = false
                while #self._runQueue > 0 do
                    local entry = table.remove(self._runQueue, 1)
                    entry.f(table.unpack(entry.args))
                    didYield = throttle:maybeYield()
                end

                if not didYield then
                    Thread.yield()
                end
            end
        end)
        :setTag("run_queue " .. (self._name or ""))
        :start()
    end
end











function RunQueue:postAsync(f, ...)



    local args = { ... }
    local thread = Thread.new(function()
        f(table.unpack(args))



        if LuaUtils.getClassName(self) == "RunQueue" then
            self._activeThreads[Thread.current()] = nil  -- remove from set
        end
    end)
    thread:start()

    self._activeThreads[thread] = true

    return thread
end












function RunQueue:deactivateThread(thread)



    if self._activeThreads[thread] then
        self._activeThreads[thread] = nil
    end

    return self
end








function RunQueue:flush()


    local function getFirstKey(tbl)
        for k, v in pairs(tbl) do
            return k
        end
        return nil
    end



    while not LuaUtils.isEmpty(self._activeThreads) do
        local thread = getFirstKey(self._activeThreads)
        if thread ~= Thread.current() then
            thread:join()
        end
    end


    if self._runQueueHandler then
        while #self._runQueue > 0 do
            Thread.yield()
        end
    end

    return self
end

return LuaUtils.readOnly(RunQueue)
