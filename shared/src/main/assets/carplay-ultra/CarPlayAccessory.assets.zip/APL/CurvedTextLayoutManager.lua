-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local AttributedString = require "APL.AttributedString"
local LuaUtils = require "APL.LuaUtils"
local MathUtils = require "APL.MathUtils"
local Rect = require "APL.Rect"
local Transform = require "APL.Transform"

local CurvedTextLayoutManager = LuaUtils.makeObject({ _type = "CurvedTextLayoutManager" })






function CurvedTextLayoutManager.new()
    local self = LuaUtils.newObject(CurvedTextLayoutManager, {
        _radius = 0,
        _originX = 0,
        _originY = 0,
        _leadingAngle = 0,
        _trailingAngle = 0,
        _clockwiseLayout = true
    })

    return self
end






function CurvedTextLayoutManager:destroy()

end









function CurvedTextLayoutManager:setRadius(radius)



    self._radius = radius

    return self
end






function CurvedTextLayoutManager:getRadius()


    return self._radius
end











function CurvedTextLayoutManager:setOrigin(x, y)




    self._originX = x
    self._originY = y

    return self
end






function CurvedTextLayoutManager:getOrigin()


    return self._originX, self._originY
end









function CurvedTextLayoutManager:setLeadingAngle(angle)



    self._leadingAngle = MathUtils.normalizeAngle(angle)

    return self
end









function CurvedTextLayoutManager:setTrailingAngle(angle)



    self._trailingAngle = MathUtils.normalizeAngle(angle)

    return self
end






function CurvedTextLayoutManager:getAngles()


    return self._leadingAngle, self._trailingAngle
end







function CurvedTextLayoutManager:setClockwiseLayout(clockwise)



    self._clockwiseLayout = clockwise

    return self
end






function CurvedTextLayoutManager:isClockwiseLayout()


    return self._clockwiseLayout
end








function CurvedTextLayoutManager:applyLayout(string, frame)



    frame:updateCharacterTransforms(self:_calculateLayout(string, frame))

    return self
end








function CurvedTextLayoutManager:_calculateLayout(attrString, frame)



    local transforms = {}

    local text = attrString:getString()
    local font = attrString:getFont()
    local fontLayoutData = font:getLayoutData()

    local linearBoundingBox = self:_boundingBoxForText(text, font)
    local baseline = linearBoundingBox._y + linearBoundingBox._height
    local effectiveRadius = self:_effectiveRadius(baseline)

    local maxLinearXOffset = self:_maxLinearXOffset(effectiveRadius)

    local originX, originY = self:_positionForAngle(self._leadingAngle, effectiveRadius)
    local boundingRect = Rect.new(originX, originY, 0, 0)


    local linearXPosition = self:_alignmentOffset(attrString:getAlignment(), linearBoundingBox._width, maxLinearXOffset)
    local unusedSpace = maxLinearXOffset
    local additionalConstantSpacing = 0
    if attrString:getAlignment() == AttributedString.ALIGNMENT.FLEX then
        for _, codepoint in utf8.codes(text) do
            local character = utf8.char(codepoint)
            local characterLayoutMetadata = fontLayoutData.characters[character]
            unusedSpace = unusedSpace - characterLayoutMetadata.advance[1]
        end
        local textGaps = (string.len(text) - 1)
        additionalConstantSpacing = unusedSpace / (textGaps or 1)
    end

    local i = 1
    for _, codepoint in utf8.codes(text) do
        local character = utf8.char(codepoint)

        local characterTransform = frame:getCharacterTransform(i)
        local characterBoundingBox = font:getCharacterBoundingBox(character)
        local characterLinearXOffset = linearXPosition + (characterBoundingBox._width / 2) + characterBoundingBox._x
        local characterAdvanceX = font:getCharacterAdvance(character) + additionalConstantSpacing




        local characterMaxLinearXOffset = linearXPosition + characterBoundingBox:getMaxX()
        if characterMaxLinearXOffset > maxLinearXOffset then
            break
        end

        local characterAngle = self:_angleForOffset(characterLinearXOffset, effectiveRadius)
        local transform = self:_transformForPlacement(characterAngle, effectiveRadius, font:getBaselineOffset(), characterBoundingBox)

        local transformedFrame = characterBoundingBox:transform(transform)
        boundingRect = boundingRect:union(transformedFrame)

        transforms[i] = transform
        linearXPosition = linearXPosition + characterAdvanceX
        i = i + 1
    end

    return transforms, boundingRect
end







function CurvedTextLayoutManager:_maxLinearXOffset(radius)



    local angleDelta = MathUtils.normalizeAngle(self._leadingAngle - self._trailingAngle)


    if angleDelta == 0 then
        return radius * MathUtils.tau
    end

    if not self._clockwiseLayout then
        angleDelta = MathUtils.tau - angleDelta
    end


    return radius * angleDelta
end










function CurvedTextLayoutManager:_effectiveRadius(baseline)



    if self._clockwiseLayout then
        return self._radius
    end




    return self._radius - baseline
end








function CurvedTextLayoutManager:_angleForOffset(offset, radius)




    local offsetDirection = self._clockwiseLayout and -1 or 1


    return self._leadingAngle + ((offset * offsetDirection) / radius)
end










function CurvedTextLayoutManager:_transformForPlacement(angle, radius, baselineOffset, characterBoundingBox)






    local x, y = self:_positionForAngle(angle, radius)



    local angleOffset = self._clockwiseLayout and 0 or math.pi


    angle = angle + angleOffset - (math.pi / 2)

    local midX = characterBoundingBox._width / 2


    local anchorChange = Transform.newWithTranslation(-midX - 1, -baselineOffset - 1)
    local rotation = Transform.newWithRotation(angle)
    local translation = Transform.newWithTranslation(x, y)





    return anchorChange
        :concatenate(rotation)
        :concatenate(translation)
end








function CurvedTextLayoutManager:_positionForAngle(angle, radius)




    local originXOffset = self._originX
    local originYOffset = self._originY

    local x = originXOffset + radius * math.cos(angle)
    local y = originYOffset + radius * math.sin(angle)

    return x, y
end








function CurvedTextLayoutManager:_boundingBoxForText(text, font)



    local boundingBox = Rect.new(0, 0, 0, 0)


    local i = 1
    for _, codepoint in utf8.codes(text) do
        local character = utf8.char(codepoint)
        local characterBoundingBox = font:getCharacterBoundingBox(character)
        local characterWidth = font:getCharacterAdvance(character)
        if i == #text and characterBoundingBox._width > 0 then
            characterWidth = characterBoundingBox:getMaxX()
        end

        characterBoundingBox._x = boundingBox._width
        characterBoundingBox._width = characterWidth

        boundingBox = boundingBox:union(characterBoundingBox)
        i = i + 1
    end

    return boundingBox
end









function CurvedTextLayoutManager:_alignmentOffset(alignment, textWidth, maxTextWidth)






    local alignmentOffset = 0

    if alignment == AttributedString.ALIGNMENT.CENTER then
        local leftOverSpace = math.max(maxTextWidth - textWidth, 0)
        alignmentOffset = leftOverSpace / 2
    elseif alignment == AttributedString.ALIGNMENT.RIGHT then
        alignmentOffset = math.max(maxTextWidth - textWidth, 0)
    end

    return alignmentOffset
end

return LuaUtils.readOnly(CurvedTextLayoutManager)
