-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"

local Rect = LuaUtils.makeObject({ _type = "Rect" })

local Transform = require "APL.Transform"

Rect.ALIGNMENT = LuaUtils.readOnly(LuaUtils.makeEnum({
    "LEFT",
    "CENTER",
    "RIGHT",
    "TOP",
    "BOTTOM",
}))

Rect.SCALING = LuaUtils.readOnly(LuaUtils.makeEnum({
    "FILL",
    "ASPECTFIT",
    "ASPECTFILL",
}))

local ALIGNMENT_TYPES = LuaUtils.getValues(Rect.ALIGNMENT)
local SCALING_TYPES = LuaUtils.getValues(Rect.SCALING)










function Rect.new(x, y, width, height)





    local self = LuaUtils.newObject(Rect, {
        _x = x,
        _y = y,
        _width = width,
        _height = height
    })

    return self
end






function Rect:destroy()


    self._x = nil
    self._y = nil
    self._width = nil
    self._height = nil
end






function Rect:getBounds()


    return self._x, self._y, self._width, self._height
end






function Rect:getMaxX()


    return math.max(self._x, self._x + self._width)
end






function Rect:getMaxY()


    return math.max(self._y, self._y + self._height)
end






function Rect:getCenter()


    return self._x + self._width / 2, self._y + self._height / 2
end






function Rect:getSize()


    return self._width, self._height
end







function Rect:getMinSideSize()


    local minSide = math.min(math.abs(self._width), math.abs(self._height))
    local minWidth = self._width >= 0 and minSide or -minSide
    local minHeight = self._height >= 0 and minSide or -minSide
    return minWidth, minHeight
end










function Rect:centeredAt(x, y)




    return Rect.new(x - self._width / 2, y - self._height / 2, self._width, self._height)
end










function Rect:insetBy(left, top, right, bottom)






    return Rect.new(
        self._x + left,
        self._y + top,
        self._width - left - right,
        self._height - top - bottom
    )
end









function Rect:scaledBy(scaleWidth, scaleHeight)




    return Rect.new(
        self._x,
        self._y,
        self._width * scaleWidth,
        self._height * scaleHeight
    )
end









function Rect:scaleFactor(rect, scalingType)





    local ws = rect._width / self._width
    local hs = rect._height / self._height

    if scalingType == Rect.SCALING.FILL then
        return ws, hs
    elseif scalingType == Rect.SCALING.ASPECTFILL then
        local scale = math.max(ws, hs)
        return scale, scale
    else
        local scale = math.min(ws, hs)
        return scale, scale
    end
end







function Rect:centeredAtBottomOfRect(rectToBeCenteredIn)



    return Rect.new(
        rectToBeCenteredIn._x + (rectToBeCenteredIn._width - self._width) / 2,
        rectToBeCenteredIn._y + rectToBeCenteredIn._height - self._height,
        self._width,
        self._height
    )
end







function Rect:centeredInRect(rectToBeCenteredIn)



    return Rect.new(
        rectToBeCenteredIn._x + (rectToBeCenteredIn._width - self._width) / 2,
        rectToBeCenteredIn._y + (rectToBeCenteredIn._height - self._height) / 2,
        self._width,
        self._height
    )
end







function Rect:centeredXInRect(rectToBeCenteredIn)



    return Rect.new(
        rectToBeCenteredIn._x + (rectToBeCenteredIn._width - self._width) / 2,
        self._y,
        self._width,
        self._height
    )
end







function Rect:centeredYInRect(rectToBeCenteredIn)



    return Rect.new(
        self._x,
        rectToBeCenteredIn._y + (rectToBeCenteredIn._height - self._height) / 2,
        self._width,
        self._height
    )
end








function Rect:rectWithAlignment(containingRect, alignment)




    local xValue
    local yValue

    if alignment == Rect.ALIGNMENT.RIGHT then
        xValue = containingRect._x + containingRect._width - self._width
        yValue = containingRect._y + (containingRect._height - self._height) / 2
    elseif alignment == Rect.ALIGNMENT.LEFT then
        xValue = containingRect._x
        yValue = containingRect._y + (containingRect._height - self._height) / 2
    elseif alignment == Rect.ALIGNMENT.CENTER then
        return self:centeredInRect(containingRect)
    elseif alignment == Rect.ALIGNMENT.TOP then
        xValue = containingRect._x + (containingRect._width - self._width) / 2
        yValue = containingRect._y
    elseif alignment == Rect.ALIGNMENT.BOTTOM then
        xValue = containingRect._x + (containingRect._width - self._width) / 2
        yValue = containingRect._y + containingRect._height - self._height
    end

    return Rect.new(
        xValue,
        yValue,
        self._width,
        self._height
    )
end






function Rect:centeredMinSquare()


    local minWidth, minHeight = self:getMinSideSize()
    return Rect.new(self._x + (self._width - minWidth) / 2, self._y + (self._height - minHeight) / 2, minWidth, minHeight)
end






function Rect:minSquare()


    local minWidth, minHeight = self:getMinSideSize()
    return Rect.new(0, 0, minWidth, minHeight)
end







function Rect:equalTo(rect)



    return (self._x == rect._x) and (self._y == rect._y) and (self._width == rect._width) and (self._height == rect._height)
end







function Rect:union(rect)



    local rect1 = self:standardize()
    local rect2 = rect:standardize()

    local x = math.min(rect1._x, rect2._x)
    local y = math.min(rect1._y, rect2._y)
    local width = math.max(rect1:getMaxX(), rect2:getMaxX()) - x
    local height = math.max(rect1:getMaxY(), rect2:getMaxY()) - y

    return Rect.new(x, y, width, height)
end






function Rect:standardize()


    local x = self._x
    local y = self._y

    if self._width < 0 then
        x = x + self._width
    end

    if self._height < 0 then
        y = y + self._height
    end

    return Rect.new(x, y, math.abs(self._width), math.abs(self._height))
end








function Rect:transform(transform)



    local transformedRect = self:getNativeRect():applyTransform(transform:getNativeTransform())

    return Rect.new(transformedRect.origin.x, transformedRect.origin.y, transformedRect.size.width, transformedRect.size.height)
end









function Rect:getNativeRect()


    return CP.DPRect(self._x, self._y, self._width, self._height)
end






function Rect:description()


    return self:stringValue()
end






function Rect:stringValue()


    return "[" .. tostring(self._x) .. " " .. tostring(self._y) .. " " .. tostring(self._width) .. " " .. tostring(self._height) .. "]"
end

return LuaUtils.readOnly(Rect)
