-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Layer = require "APL.Layer"
local LuaUtils = require "APL.LuaUtils"

local GradientLayer = LuaUtils.makeObject({ _type = "GradientLayer" }, Layer)

GradientLayer.KIND = LuaUtils.readOnly({
    LINEAR = CP.DPGradientLayer.KIND.LINEAR,
    RADIAL = CP.DPGradientLayer.KIND.RADIAL,
    CONICAL = CP.DPGradientLayer.KIND.CONICAL,
})

local KIND_TYPES = LuaUtils.getValues(GradientLayer.KIND)







function GradientLayer.new(kind)



    local self = LuaUtils.newObject(GradientLayer, {

    }, Layer.new(CP.DPGradientLayer.create()))

    self._nativeLayer.type = kind or GradientLayer.KIND.LINEAR

    return self
end






function GradientLayer:destroy()


     Layer.destroy(self)
end







function GradientLayer:setKind(kind)




    self._nativeLayer.type = kind

    return self
end








function GradientLayer:setStartPoint(x, y)




    self._nativeLayer.startPoint = CP.DPPoint(x, y)

    return self
end






function GradientLayer:getStartPoint()


    local point = self._nativeLayer.startPoint
    return point.x, point.y
end








function GradientLayer:setEndPoint(x, y)




    self._nativeLayer.endPoint = CP.DPPoint(x, y)

    return self
end






function GradientLayer:getEndPoint()


    local point = self._nativeLayer.endPoint
    return point.x, point.y
end








function GradientLayer:setStops(stops)



    local gradientStops = {}
    for location, color in pairs(stops) do




        local r, g, b, a = LuaUtils.parseColor(color, false)
        gradientStops[#gradientStops + 1] = CP.DPGradientStop(CP.DPColor(r, g, b, a), location)
    end

    self._nativeLayer:setStops(gradientStops)

    return self
end







function GradientLayer:setColors(colors)




    for i,color in ipairs(colors) do


        local r, g, b, a = LuaUtils.parseColor(color, false)
        colors[i] = CP.DPColor(r, g, b, a)
    end

    self._nativeLayer:setColors(colors)

    return self
end






function GradientLayer:getNumStops()


    return self._nativeLayer.numStops
end

return LuaUtils.readOnly(GradientLayer)
