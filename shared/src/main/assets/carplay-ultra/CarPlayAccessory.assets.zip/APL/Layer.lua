-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"
local flux = require "APL.flux"
local Rect = require "APL.Rect"
local Transform = require "APL.Transform"

local Layer = LuaUtils.makeObject({ _type = "Layer" })

Layer.BLEND_MODE = LuaUtils.readOnly({
    COPY          = CP.DPLayer.BLEND.COPY,
    CLEAR         = CP.DPLayer.BLEND.CLEAR,
    SOURCEOVER    = CP.DPLayer.BLEND.SOURCEOVER,
    SOURCEIN      = CP.DPLayer.BLEND.SOURCEIN,
    SOURCEOUT     = CP.DPLayer.BLEND.SOURCEOUT,
    SOURCEATOP    = CP.DPLayer.BLEND.SOURCEATOP,
    DESTOVER      = CP.DPLayer.BLEND.DESTOVER,
    DESTIN        = CP.DPLayer.BLEND.DESTIN,
    DESTOUT       = CP.DPLayer.BLEND.DESTOUT,
    DESTATOP      = CP.DPLayer.BLEND.DESTATOP,
    ADDITIVE      = CP.DPLayer.BLEND.ADDITIVE,
    PLUSLIGHTER   = CP.DPLayer.BLEND.PLUSLIGHTER,
    EXCLUSIVEOR   = CP.DPLayer.BLEND.EXCLUSIVEOR,
    XOR           = CP.DPLayer.BLEND.XOR,
    SCREEN        = CP.DPLayer.BLEND.SCREEN,
    EXCLUSION     = CP.DPLayer.BLEND.EXCLUSION,
    MAXIMUM       = CP.DPLayer.BLEND.MAXIMUM,
    MINIMUM       = CP.DPLayer.BLEND.MINIMUM,
    SUBTRACTSRC   = CP.DPLayer.BLEND.SUBTRACTSRC,
    SUBTRACTDEST  = CP.DPLayer.BLEND.SUBTRACTDEST,
    COMPONENTMASK = CP.DPLayer.BLEND.COMPONENTMASK,
    NORMAL        = CP.DPLayer.BLEND.NORMAL,
})
local BLEND_MODES = LuaUtils.getValues(Layer.BLEND_MODE)

Layer.CORNER_CURVE = LuaUtils.readOnly({
    CIRCULAR   = CP.DPLayer.CURVE.CIRCULAR,
    CONTINUOUS = CP.DPLayer.CURVE.CONTINUOUS
})
local CORNER_CURVES = LuaUtils.getValues(Layer.CORNER_CURVE)

local allowedTypes = {
    CurvedTextLayer = true,
    BackdropLayer = true,
    GradientLayer = true,
    ImageLayer = true,
    Layer = true,
    NumberLayer = true,
    TextLayer = true,
    ShapeLayer = true,
    SnapshotLayer = true,
    StableNumberLayer = true,
    VideoLayer = true,
}


local function validateClassName(self)
    return allowedTypes[LuaUtils.getClassName(self)]
end











function Layer.new(nativeLayer)

    local allowedNativeTypes = {
        DPBackdropLayer = true,
        DPGradientLayer = true,
        DPImageLayer = true,
        DPLayer = true,
        DPShapeLayer = true,
        DPVideoLayer = true
    }


    local self = LuaUtils.newObject(Layer, {

        _nativeLayer = nativeLayer or CP.DPLayer.create(),

        _tweens = {},

        _name = LuaUtils.NIL, -- debug.traceback(),
    })

    return self
end







function Layer.isSubclass(instance)
    return validateClassName(instance)
end






function Layer:destroy()


    self._nativeLayer:removeFromSuperlayer()
    self._nativeLayer = nil
    flux.clear(self._tweens.bounds or {})
    flux.clear(self._tweens.position or {})
    flux.clear(self._tweens)
    self._tweens = nil
end







function Layer:setName(name)



    self._name = name
    self._nativeLayer.name = name

    return self
end






function Layer:getName()


    return self._name
end









function Layer:getNativeLayer()


    return self._nativeLayer
end









function Layer:getNativeSublayers()


    return self._nativeLayer:getSublayers()
end







function Layer:addSublayer(layer)



    self._nativeLayer:addSublayer(layer:getNativeLayer())

    return self
end







function Layer:isSublayer(layer)



    return LuaUtils.first(self._nativeLayer:getSublayers(), function(sublayer)
        return sublayer == layer:getNativeLayer()
    end) ~= nil
end








function Layer:insertSublayerAtIndex(layer, index)




    self._nativeLayer:insertSublayerAtIndex(layer:getNativeLayer(), index)

    return self
end








function Layer:insertSublayerBelow(layer, relativeToLayer)



    self._nativeLayer:insertSublayerBelow(layer:getNativeLayer(), relativeToLayer:getNativeLayer())

    return self
end






function Layer:removeSublayers()


    self._nativeLayer:removeSublayers()

    return self
end







function Layer:removeSublayer(layer)



    self._nativeLayer:removeSublayer(layer:getNativeLayer())

    return self
end







function Layer:addToSuperLayer(superLayer)



    superLayer:addSublayer(self)
    return self
end






function Layer:removeFromSuperlayer()


    self._nativeLayer:removeFromSuperlayer()

    return self
end








function Layer:replaceSublayer(layerOut, layerIn)




    if layerOut ~= layerIn then
        if layerOut and layerIn then
            self._nativeLayer:replaceSublayer(layerOut:getNativeLayer(), layerIn:getNativeLayer())
        else
            if layerOut then
                layerOut:removeFromSuperlayer()
            end

            if layerIn then
                self:addSublayer(layerIn)
            end
        end
    end

    return self
end






function Layer:getVisible()


    return not self._nativeLayer.hidden
end







function Layer:setVisible(isVisible)



    self._nativeLayer.hidden = not isVisible

    return self
end







function Layer:setOpacity(opacity)



    flux.clear(self._tweens, { opacity = true })
    self._nativeLayer.opacity = math.max(0, math.min(opacity, 1))

    return self
end






function Layer:getOpacity()


    return math.max(0, math.min(self._nativeLayer.opacity, 1))
end









function Layer:animOpacity(newOpacity, duration, onComplete)






    self._tweens.opacity = self._nativeLayer.opacity

    return flux.to(self._tweens, duration, { opacity = newOpacity })
        :onupdate(function(tween)
            self._nativeLayer.opacity = math.max(0, math.min(tween.opacity, 1))
        end)
        :oncomplete(function(...)
            if onComplete then
                onComplete(...)
            end
        end)
end










function Layer:setPosition(x, y)




    flux.clear(self._tweens.position or {})
    self._nativeLayer.position = CP.DPPoint(x, y)

    return self
end








function Layer:getPosition()


    local point = self._nativeLayer.position
    return point.x, point.y
end










function Layer:animPosition(newX, newY, duration, onComplete)






    self._tweens.position = self._tweens.position or {}
    self._tweens.position.x = self._nativeLayer.position.x
    self._tweens.position.y = self._nativeLayer.position.y

    return flux.to(self._tweens.position, duration, { x = newX, y = newY })
        :onupdate(function(tween)
            self._nativeLayer.position = CP.DPPoint(tween.x, tween.y)
        end)
        :oncomplete(function(...)
            if onComplete then
                onComplete(...)
            end
        end)
end








function Layer:setAnchorPoint(x, y)




    self._nativeLayer.anchorPoint = CP.DPPoint(x, y)

    return self
end








function Layer:getAnchorPoint()


    local point = self._nativeLayer.anchorPoint
    return point.x, point.y
end







function Layer:setFrame(...)


    local arg = {...}
    if #arg == 1 then

        self._nativeLayer.frame = arg[1]:getNativeRect()
    elseif #arg == 4 then




        self._nativeLayer.frame = CP.DPRect(...)
    else

    end

    return self
end






function Layer:getFrame()


    local rect = self._nativeLayer.frame
    return rect.origin.x, rect.origin.y, rect.size.width, rect.size.height
end







function Layer:setBounds(...)


    local arg = {...}
    if #arg == 1 then

        self._nativeLayer.bounds = arg[1]:getNativeRect()
    else




        self._nativeLayer.bounds = CP.DPRect(...)
    end

    flux.clear(self._tweens.bounds or {})

    return self
end






function Layer:getBounds()


    local rect = self._nativeLayer.bounds
    return rect.origin.x, rect.origin.y, rect.size.width, rect.size.height
end








function Layer:animBounds(rect, duration)




    self._tweens.bounds =  self._tweens.bounds or {}
    self._tweens.bounds.x = self._nativeLayer.bounds.origin.x
    self._tweens.bounds.y = self._nativeLayer.bounds.origin.y
    self._tweens.bounds.width = self._nativeLayer.bounds.size.width
    self._tweens.bounds.height = self._nativeLayer.bounds.size.height

    return flux.to(self._tweens.bounds, duration, { x = rect._x, y = rect._y, width = rect._width, height = rect._height })
        :onupdate(function(tween)
            local rect = CP.DPRect(tween.x, tween.y, tween.width, tween.height)
            self._nativeLayer.bounds = rect
        end)
end







function Layer:setBackgroundColor(color)



    if color then
        local r, g, b, a = LuaUtils.parseColor(color, false)
        local color = CP.DPColor(r, g, b, a)
        self._nativeLayer.backgroundColor = color
    else
        self._nativeLayer.backgroundColor = CP.DPColor(0, 0, 0, 0)
    end

    return self
end






function Layer:getBackgroundColor()


    local color = self._nativeLayer.backgroundColor
    if color then
        return LuaUtils.createColor(color.r, color.g, color.b, color.a)
    end
end







function Layer:setBorderWidth(borderWidth)



    self._nativeLayer.borderWidth = borderWidth
    return self
end






function Layer:getBorderWidth()


    return self._nativeLayer.borderWidth
end







function Layer:setBorderColor(color)



    if color then
        local r, g, b, a = LuaUtils.parseColor(color, false)
        local color = CP.DPColor(r, g, b, a)
        self._nativeLayer.borderColor = color
    else
        self._nativeLayer.borderColor = CP.DPColor(0, 0, 0, 0)
    end

    return self
end






function Layer:getBorderColor()


    local color = self._nativeLayer.borderColor
    if color then
        return LuaUtils.createColor(color.r, color.g, color.b, color.a)
    end

    return "#00000000"
end







function Layer:setMask(layer)



    self._nativeLayer:setMask(layer and layer:getNativeLayer() or nil)

    return self
end







function Layer:setTransform(transform)



    self._nativeLayer.transform = transform._nativeTransform

    return self
end







function Layer:setShouldRasterize(shouldRasterize)



    self._nativeLayer.shouldRasterize = shouldRasterize

    return self
end







function Layer:setMaskToBounds(maskToBounds)



    self._nativeLayer.maskToBounds = maskToBounds

    return self
end







function Layer:setBlendMode(blendMode)



    self._nativeLayer.blendMode = blendMode

    return self
end







function Layer:setGroupBlending(groupBlending)



    self._nativeLayer.groupBlending = groupBlending

    return self
end







function Layer:setCornerRadius(cornerRadius)



    self._nativeLayer.cornerRadius = cornerRadius

    return self
end







function Layer:setCornerCurve(cornerCurve)



    self._nativeLayer.cornerCurve = cornerCurve

    return self
end







function Layer:convertFrameToSuperLayer(layer)



    local r = CP.DPRect.withSize(self._nativeLayer.bounds.size)
    local t = self._nativeLayer:getTransformTo(layer._nativeLayer)


    if t then
        local transformedRect = r:applyTransform(t)
        return Rect.new(transformedRect.origin.x, transformedRect.origin.y, transformedRect.size.width, transformedRect.size.height)
    else
        return nil
    end
end







function Layer:addFilter(filter)



    self._nativeLayer:addFilter(filter._nativeFilter)

    return self
end

return LuaUtils.readOnly(Layer)
