-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Config = require "APL.Config"
local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"

local Asset = LuaUtils.makeObject({ _type = "Asset" })

local _displayID
local _manifest

Asset.optimized = Config.readParam("OPTIMIZATION.ENABLED")

local function _load(path, loadFunction, ...)
    local args = {...}
    local safeload = function(path)
        local status, result = pcall(function()
            return loadFunction(path, table.unpack(args))
        end)

        if status then
            return result
        end

        Log.error(Asset, function() return "Asset: unable to load asset at path: " .. path .. ", error: " .. tostring(result) end)

        return nil, result
    end

    local asset
    local result


    if _displayID then
        asset, result = safeload(_displayID .. "/" .. path)
    end


    if asset == nil then
        asset, result = safeload(path)
    end

    if asset == nil then

    end

    return asset
end








function Asset.setManifest(manifest, displayID)



    _displayID = displayID
    local manifestData = Asset.loadLua(manifest)


    _manifest = manifestData
end








function Asset.resetManifest()
    _manifest = {}
    _displayID = nil
end







function Asset.loadImage(path)


    return _load(path, CP.createAssetImage)
end







function Asset.loadRaw(path)


    return _load(path, CP.createAssetRAW)
end







function Asset._require(path)


    return _load(path, function(name) return require(name) end)
end







function Asset.loadLua(path)


    return Asset._require(path)
end







function Asset.loadNamedTexture(asset)





    local resolveFilename = function(asset)

        local assetIdentifier = LuaUtils.query(asset, "type.image._0.identifier")
        if assetIdentifier then
            return Asset.lookupAssetFilename(assetIdentifier)
        end


        local localized_image = LuaUtils.query(asset, "type.localizedImage._0")
        if not localized_image or type(localized_image) ~= "table" then
            return nil
        end

        if not localized_image.identifier or not localized_image.images then
            return nil
        end



        local assetDirectory = Asset.lookupAssetFilename(localized_image.identifier)
        if not assetDirectory then
            Log.error(Asset, function() return "Unable to find filename in manifest for asset " .. localized_image.identifier end)
            return nil
        end

        return assetDirectory .. "/" .. localized_image.images["en"]
    end

    local filename = resolveFilename(asset)
    if not filename then
        Log.error(Asset, function() return "Unable to load asset: ".. LuaUtils.prettyPrint(asset) end)
        return nil
    end

    Log.debug(Asset, function() return "Returning Image Texture for " .. filename end)

    local TextureCache = require "APL.TextureCache"
    return TextureCache.current():getTexture(filename)
end









function Asset.lookupAssetFilename(assetIdentifier)



    local manifestEntry = _manifest[assetIdentifier]
    if manifestEntry == nil then
        Log.error(Asset, function() return "_manifest " .. LuaUtils.prettyPrint(_manifest) end)
        return nil
    end

    return manifestEntry.path
end







function Asset.getAssetPath(assetIdentifier)



    local manifestEntry = _manifest[assetIdentifier]
    if manifestEntry == nil then
        Log.error(Asset, function() return "_manifest " .. LuaUtils.prettyPrint(_manifest) end)
        return nil
    end

    if _displayID then
        return _displayID .. "/" .. manifestEntry.path
    end

    return manifestEntry.path
end







function Asset.getImageAssetAttributes(asset)



    local asset = LuaUtils.query(asset, "type.image._0")

    if asset then
        return asset
    end


    local localized_image = LuaUtils.query(asset, "type.localizedImage._0")
    if not localized_image or type(localized_image) ~= "table" then
        return nil
    end

    if not localized_image.identifier or not localized_image.images then
        return nil
    end



    return localized_image.images["en"]
end







function Asset.getImageAssetIdentifier(asset)


    local attributes = Asset.getImageAssetAttributes(asset)

    return attributes and attributes.identifier
end

return LuaUtils.readOnly(Asset)
