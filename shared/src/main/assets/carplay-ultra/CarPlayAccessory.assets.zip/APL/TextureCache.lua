-- Copyright © 2021-2026 Apple, Inc. All rights reserved.







local Cache = require "APL.Cache"
local ImageLayer = require "APL.ImageLayer"
local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"
local Rect = require "APL.Rect"
local Texture = require "APL.Texture"
local Thread = require "APL.Thread"

local TextureCache = LuaUtils.makeObject({ _type = "TextureCache" })


local MAX_CAPACITY_MB        = 260
local MAX_EVICTION_TARGET_MB = 240
local MAX_BUSY_CAPACITY_MB   = 250

local __activeTextureCache






function TextureCache.new()
    Log.info(TextureCache, function() return "TextureCache.new" end)


    if __activeTextureCache then
        __activeTextureCache:destroy()
        __activeTextureCache = nil
        Log.info(TextureCache, function() return "current texture cache destroyed" end)
    else
        Log.info(TextureCache, function() return "no current texture cache" end)
    end

    local self = LuaUtils.newObject(TextureCache, {
        _cache = LuaUtils.NIL,
    })

    Log.info(TextureCache, function() return "Cache size: %d", MAX_BUSY_CAPACITY_MB end)


    self._cache = Cache.new(MAX_CAPACITY_MB, function(x) x:release() end)
        :setMaxBusyCapacity(MAX_BUSY_CAPACITY_MB)





    self._cache
        :setYieldOnEvict(true)
        :setEvictTarget(MAX_EVICTION_TARGET_MB)

    __activeTextureCache = self

    return self
end






function TextureCache:destroy()


    Log.info(TextureCache, function() return "destroying..." end)

    self._cache:destroy()

    __activeTextureCache = nil

    Log.info(TextureCache, function() return "destroyed" end)
end






function TextureCache.current()
    return __activeTextureCache or TextureCache.new()
end









function TextureCache:getTexture(filename)




    local texture = self._cache:get(filename)
    if texture then
        return texture
    end


    texture = Texture.new(filename)
    texture:setRefHandler(
        function(x) self._cache:pin(x) end,
        function(x) self._cache:unpin(x) end
    )


    texture = self._cache:put(filename, texture, texture:getSizeMB())


    return texture
end






function TextureCache:clearAllIdleEntries()


    local evictTarget = self._cache:getEvictTarget()
    local maxCapacity = self._cache:getMaxCapacity()

    self._cache:setMaxCapacity(0)
    self._cache:setEvictTarget(0)


    self._cache:setMaxCapacity(maxCapacity)
    self._cache:setEvictTarget(evictTarget)

    return self
end











function TextureCache:logBusyEntries()


    for _, texture in ipairs(self._cache:getAllItems()) do
        if self._cache:getState(texture) == Cache.STATE.BUSY then
            Log.info(TextureCache, function() return "busy item '%s'", texture:getName() end)
        end
    end

    local busy, max = self._cache:getLoad()
    Log.info(TextureCache, function() return "Cache load busy: %.2f/%d, max: %.2f/%d", busy, self._cache:getMaxBusyCapacity(), max, self._cache:getMaxCapacity() end)

    return self
end

return LuaUtils.readOnly(TextureCache)
