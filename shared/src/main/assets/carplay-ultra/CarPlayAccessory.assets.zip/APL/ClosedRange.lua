-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"

local ClosedRange = LuaUtils.makeObject({ _type = "ClosedRange" })








function ClosedRange.new(lowerBound, upperBound)



    local self = LuaUtils.newObject(ClosedRange, {
        _lowerBound = lowerBound,
        _upperBound = upperBound
    })

    return self
end






function ClosedRange:destroy()

end






function ClosedRange:getLowerBound()


    return self._lowerBound
end






function ClosedRange:getUpperBound()


    return self._upperBound
end






function ClosedRange:getLength()


    return self._upperBound - self._lowerBound
end








function ClosedRange:getNormalizedValue(value)



    return (self:getClampedValue(value) - self._lowerBound) / self:getLength()
end







function ClosedRange:getClampedValue(value)
    if self:getLength() > 0 then
        return math.max(math.min(value, self._upperBound), self._lowerBound)
    else
        return math.min(math.max(value, self._upperBound), self._lowerBound)
    end
end






function ClosedRange.equals(bounds0, bounds1)



    return bounds0._upperBound == bounds1._upperBound and bounds0._lowerBound == bounds1._lowerBound
end

return LuaUtils.readOnly(ClosedRange)
