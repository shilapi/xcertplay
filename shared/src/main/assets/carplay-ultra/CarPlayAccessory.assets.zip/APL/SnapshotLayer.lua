-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Layer = require "APL.Layer"
local LuaUtils = require "APL.LuaUtils"

local SnapshotLayer = LuaUtils.makeObject({ _type = "SnapshotLayer" }, Layer)







function SnapshotLayer.new(layer)


    return LuaUtils.newObject(SnapshotLayer, {
    }, Layer.new(CP.DPImageLayer.fromLayerTree(layer:getNativeLayer())))
end






function SnapshotLayer:destroy()


    Layer.destroy(self)
end

return LuaUtils.readOnly(SnapshotLayer)
