-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"

local Transform = LuaUtils.makeObject({ _type = "Transform" })












function Transform.new(a, b, c, d, tx, ty)







    local self = LuaUtils.newObject(Transform, {

        _nativeTransform = CP.DPAffineTransform(a, b, c, d, tx, ty),
    })

    return self
end






function Transform.newWithIdentity()
    return Transform.new(1, 0, 0, 1, 0, 0)
end








function Transform.newWithTranslation(x, y)



    local self = LuaUtils.newObject(Transform, {

        _nativeTransform = CP.DPAffineTransform.translate(x, y),
    })

    return self
end







function Transform.newWithRotation(radians)


    local self = LuaUtils.newObject(Transform, {

        _nativeTransform = CP.DPAffineTransform.rotate(radians)
    })

    return self
end








function Transform.newWithScale(x, y)



    local self = LuaUtils.newObject(Transform, {

        _nativeTransform = CP.DPAffineTransform.scale(x, y),
    })

    return self
end








function Transform:translate(x, y)




    self._nativeTransform = self._nativeTransform:add(x, y)

    return self
end







function Transform:concatenate(transform)



    self._nativeTransform = self._nativeTransform:multiply(transform._nativeTransform)

    return self
end






function Transform:getNativeTransform()


    return self._nativeTransform
end






function Transform:destroy()


    self._nativeTransform = nil
end

return LuaUtils.readOnly(Transform)
