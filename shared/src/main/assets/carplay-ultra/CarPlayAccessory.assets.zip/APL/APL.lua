

-- Copyright © 2021-2026 Apple, Inc. All rights reserved.


local LuaUtils = require "APL.LuaUtils"
local BridgeVersion = require "APL.BridgeVersion"


local APL = {
    _type = "APL",

    Asset = require "APL.Asset",
    AttributedString = require "APL.AttributedString",
    BackdropLayer = require "APL.BackdropLayer",
    BlurFilter = require "APL.BlurFilter",
    Cache = require "APL.Cache",
    ClosedRange = require "APL.ClosedRange",
    ClusterControlSession = require "APL.ClusterControlSession",
    Config = require "APL.Config",
    CurvedTextLayer = require "APL.CurvedTextLayer",
    CurvedTextLayoutManager = require "APL.CurvedTextLayoutManager",
    Effect = require "APL.Effect",
    ErrorHandler = require "APL.ErrorHandler",
    flux = require "APL.flux",
    Filter = require "APL.Filter",
    Font = require "APL.Font",
    GradientLayer = require "APL.GradientLayer",
    ImageLayer = require "APL.ImageLayer",
    JSON = require "APL.json",
    Layer = require "APL.Layer",
    Log = require "APL.Log",
    LuaUtils = require "APL.LuaUtils",
    MathUtils = require "APL.MathUtils",
    NumberLayer = require "APL.NumberLayer",
    Path = require "APL.Path",
    Persistence = require "APL.Persistence",
    RasterFont = require "APL.RasterFont",
    Rect = require "APL.Rect",
    RunQueue = require "APL.RunQueue",
    SemVer = require "APL.semver",
    ShapeLayer = require "APL.ShapeLayer",
    Signpost = require "APL.Signpost",
    SnapshotLayer = require "APL.SnapshotLayer",
    StableNumberLayer = require "APL.StableNumberLayer",
    Store = require "APL.Store",
    TextLayer = require "APL.TextLayer",
    Texture = require "APL.Texture",
    TextureCache = require "APL.TextureCache",
    Thread = require "APL.Thread",
    Throttle = require "APL.Throttle",
    Timer = require "APL.Timer",
    Transform = require "APL.Transform",
    VectorFont = require "APL.VectorFont",
    VectorFontManager = require "APL.VectorFontManager",
    VideoLayer = require "APL.VideoLayer",


    _minBridgeVersion = BridgeVersion.semver,
}

if not CP.version then
    error("Unable to get CP version, please update your environment.")
end


if not APL.SemVer(APL._minBridgeVersion) ^ APL.SemVer(CP.version)  then
    error("Bridge version " .. CP.version .. " is not matching script requirements: " .. APL._minBridgeVersion)
end


if APL.SemVer(APL._minBridgeVersion).prerelease ~= APL.SemVer(CP.version).prerelease then
    error("Bridge version " .. CP.version .. " is not matching script requirements: " .. APL._minBridgeVersion)
end

return APL.LuaUtils.readOnly(APL)
