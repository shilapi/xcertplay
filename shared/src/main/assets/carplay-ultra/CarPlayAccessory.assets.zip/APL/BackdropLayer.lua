-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Layer = require "APL.Layer"
local LuaUtils = require "APL.LuaUtils"

local BackdropLayer = LuaUtils.makeObject({ _type = "BackdropLayer" }, Layer)






function BackdropLayer.new()
    local self = LuaUtils.newObject(BackdropLayer, {}, Layer.new(CP.DPBackdropLayer.create()))
    return self
end






function BackdropLayer:destroy()


    Layer.destroy(self)
end

return LuaUtils.readOnly(BackdropLayer)
