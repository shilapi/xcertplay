-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Asset = require "APL.Asset"
local AttributedString = require "APL.AttributedString"
local LuaUtils = require "APL.LuaUtils"
local Rect = require "APL.Rect"
local SemVer = require "APL.semver"
local VectorFontFramesetter = require "APL.VectorFontFramesetter"
local VectorFontManager = require "APL.VectorFontManager"

local VectorFont = LuaUtils.makeObject({ _type = "VectorFont" })

local _nativeFontCache = {}











function VectorFont.new(postScriptName, familyName, traits, weight, size)







    local nativeFont = _nativeFontCache[postScriptName]
    if not nativeFont then
        local filename = Asset.getAssetPath(postScriptName)
        if not filename then

            return nil
        end

        nativeFont = CP.createAssetFont(filename)
        _nativeFontCache[postScriptName] = nativeFont
    end

    size = size or 12

    local self = LuaUtils.newObject(VectorFont, {
        _postScriptName = postScriptName,
        _familyName = familyName,
        _traits = traits,
        _weight = weight,
        _size = size,
        _nativeFont = nativeFont
    })

    return self
end






function VectorFont.isFeatureSupported()
    return SemVer(CP.version) >= SemVer("1.5.0")
end






function VectorFont:destroy()

end






function VectorFont:getFramesetter()


    return VectorFontFramesetter
end






function VectorFont:getPointSize()


    return self._size
end






function VectorFont:getNativeRepresentation()


    local fontManager = VectorFontManager.getDefaultManager()
    local cascade = fontManager:getCascade(self)

    local fontList = CP.DPTextFontList()
    fontList:addFont(self._nativeFont)
    for _, font in ipairs(cascade) do
        fontList:addFont(font._nativeFont)
    end

    local format = CP.DPTextFormat()
    format:setFontList(fontList)
    format.fontSize = self._size

    return format
end






function VectorFont:getName()


    return self._postScriptName
end






function VectorFont:getFamilyName()


    return self._familyName
end






function VectorFont:getTraits()


    return self._traits
end






function VectorFont:getWeight()


    return self._weight
end






function VectorFont:getBaselineOffset()


    local format = self:getNativeRepresentation()
    return format.ascent
end







function VectorFont:getCharacterBoundingBox(character)



    local frame = self:_createFrame(character)
    return frame:getCharacterFrame(1)
end







function VectorFont:getCharacterAdvance(character)



    local frame = self:_createFrame(character)
    return frame:getCharacterAdvance(0)
end







function VectorFont:_createFrame(character)



    local framesetter = AttributedString.new(character, self):getFramesetter()

    return framesetter:layoutFrame(Rect.new(0, 0, 10000, 10000))
end

return LuaUtils.readOnly(VectorFont)
