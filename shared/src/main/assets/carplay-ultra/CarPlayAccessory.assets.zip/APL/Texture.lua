-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local Asset = require "APL.Asset"
local Log = require "APL.Log"
local LuaUtils = require "APL.LuaUtils"
local SemVer = require "APL.semver"
local Signpost = require "APL.Signpost"

local Texture = LuaUtils.makeObject({ _type = "Texture" })







function Texture.new(filename)


    local asset = Signpost.measure("Loading image @ " .. filename, function()
        return Asset.loadImage(filename)
    end)

    if not asset then
        Log.error(Texture, function() return "Invalid asset for " .. filename end)
        return nil
    end

    return Texture.newWithAsset(asset, filename)
end








function Texture.newWithAsset(asset, filename)



    if not asset then
        Log.error(Texture, function() return "Invalid asset for " .. filename end)
        return nil
    end

    Log.info(Texture, function() return "Creating texture with asset @ " .. filename end)
    local width, height = asset:getSize()
    local data, len = asset:getData()
    local self = LuaUtils.newObject(Texture, {
        _filename = filename,
        _asset = asset,


        _onPin = LuaUtils.NIL,
        _onUnpin = LuaUtils.NIL,
        _refCount = 0,


        _nativeTexture = LuaUtils.NIL,


        _width = width,
        _height = height
    })
    Log.info(Texture, function() return "Created texture with asset @ " .. filename .. " (dimension = " .. tostring(self._width) .. "x" .. tostring(self._height) .. ", data = " .. tostring(data) .. ", size = " ..tostring(len) ..")" end)

    return self
end








function Texture.newWithImageName(imageName, appearance)


    local asset = Signpost.measure("Loading custom image: " .. imageName, function()
        return CP.createCustomPNG(imageName, appearance)
    end)

     if not asset then
        Log.error(Texture, function() return "Invalid asset for custom image: " .. imageName end)
        return nil
    end

    return Texture.newWithAsset(asset, imageName)
end






function Texture:destroy()


    self._nativeTexture = nil
    self._asset = nil
end






function Texture:getName()


    return self._filename
end








function Texture:addRef()


    self._refCount = self._refCount + 1

    if self._onPin and self._refCount == 1 then
        self._onPin(self)
    end

    return self
end








function Texture:removeRef()




    self._refCount = self._refCount - 1

    if self._onUnpin and self._refCount == 0 then
        self._onUnpin(self)
    end

    return self
end











function Texture:setRefHandler(onPin, onUnpin)




    self._onPin = onPin
    self._onUnpin = onUnpin

    return self
end






function Texture:getNativeTexture()


    if not self._nativeTexture then
        Log.info(Texture, function() return "Loading native texture for asset @ " .. self._filename end)
        local width, height = self._asset:getSize()
        local data, len = self._asset:getData()
        Log.info(Texture, function() return "(dimension = " .. tostring(width) .. "x" .. tostring(height) .. ", data = " .. tostring(data) .. ", size = " ..tostring(len) ..")" end)

        self._nativeTexture = CP.DPTexture.createFromImage(self._asset)
    end

    return self._nativeTexture
end







function Texture:bind(layer)



    self:addRef()
    layer.texture = self:getNativeTexture()

    return self
end







function Texture:unbind(layer)



    layer.texture = nil
    self:removeRef()

    return self
end






function Texture:getSize()


    return self._width, self._height
end






function Texture:getSizeMB()


    return self._width * self._height * 4 / 1024 / 1024
end








function Texture:release()



    self._nativeTexture = nil

    return self
end

return LuaUtils.readOnly(Texture)
