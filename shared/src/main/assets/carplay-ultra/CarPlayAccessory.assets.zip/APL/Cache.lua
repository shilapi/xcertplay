-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

















local LuaUtils = require "APL.LuaUtils"
local Log = require "APL.Log"
local Thread = require "APL.Thread"

local Cache = LuaUtils.makeObject({ _type = "Cache" })

Cache.STATE = LuaUtils.readOnly(LuaUtils.makeEnum({
    "FREE", -- Item is not yet loaded or has been releaded from idle state (evicted)
    "IDLE", -- Item is loaded but not in use, and subject to eviction (unpinned)
    "BUSY", -- Item is loaded and in use (pinned)
}, false))








function Cache.new(maxCapacity, evictFunction)



    local self = LuaUtils.newObject(Cache, {
        _maxCapacity = maxCapacity,
        _maxBusyCapacity = maxCapacity,
        _evictFunction = evictFunction,
        _evictTarget = maxCapacity,
        _isYieldOnEvict = false,






        _byKey = {},
        _byItem = {},


        _busySize = 0,
        _idleSize = 0,


        _busyCount = 0,
        _idleCount = 0,
        _freeCount = 0,


        _lruHead = LuaUtils.NIL,
        _lruTail = LuaUtils.NIL,


        _enforceMaxCapacityIsBusy = false,
    })

    return self
end






function Cache:destroy()



    self._maxCapacity = 0
    self:_enforceMaxCapacity()
end






function Cache:getMaxCapacity()


    return self._maxCapacity
end









function Cache:setMaxCapacity(maxCapacity)



    if maxCapacity == 0 then
        Log.warn(Cache, function() return "Setting max capacity to 0" end)
    end

    self._maxCapacity = maxCapacity
    self:_enforceMaxCapacity()

    return self
end






function Cache:getMaxBusyCapacity()


    return self._maxBusyCapacity
end












function Cache:setMaxBusyCapacity(maxBusyCapacity)




    self._maxBusyCapacity = maxBusyCapacity
    self:_enforceMaxCapacity()

    return self
end






function Cache:getEvictTarget()


    return self._evictTarget
end













function Cache:setEvictTarget(evictTarget)



    if evictTarget == 0 then
        Log.warn(Cache, function() return "Setting evict target to 0" end)
    end

    self._evictTarget = evictTarget
    self:_enforceMaxCapacity()

    return self
end






function Cache:getYieldOnEvict()


    return self._isYieldOnEvict
end












function Cache:setYieldOnEvict(isYieldOnEvict)



    self._isYieldOnEvict = isYieldOnEvict

    return self
end






function Cache:getLoad()


    return self._busySize, self._busySize + self._idleSize
end







function Cache:get(key)



    local entry = self._byKey[key]
    if entry then

        if entry.state == Cache.STATE.IDLE then
            self:_removeLru(entry)
            self:_insertLru(entry)
        end
        return entry.item
    end
    return nil
end















function Cache:put(key, item, size)









    local entry = self._byKey[key]
    if entry then
        return entry.item
    end

    local entry = {
        key = key,
        item = item,
        size = size,
        lruPrev = nil,
        lruNext = nil,
        state = nil,
    }


    self._byKey[key] = entry
    self._byItem[item] = entry


    entry.state = Cache.STATE.FREE
    self._freeCount = self._freeCount + 1

    return item
end







function Cache:remove(item)



    local entry = self._byItem[item]


    if entry.state == Cache.STATE.FREE then
        self._freeCount = self._freeCount - 1
    elseif entry.state == Cache.STATE.IDLE then
        self:_removeLru(entry)
        self._idleSize = self._idleSize - entry.size
        self._idleCount = self._idleCount - 1
    elseif entry.state == Cache.STATE.BUSY then
        self._busySize = self._busySize - entry.size
        self._busyCount = self._busyCount - 1
    end
    self._byKey[entry.key] = nil
    self._byItem[entry.item] = nil

    return item
end










function Cache:getAllItems()


    local r = {}

    for item, _ in pairs(self._byItem) do
        table.insert(r, item)
    end

    return r
end










function Cache:pin(item)



    local entry = self._byItem[item]

    Log.trace(Cache, function() return "Pinning %s", entry.key end)



    if entry.state == Cache.STATE.FREE then
        self._freeCount = self._freeCount - 1
    elseif entry.state == Cache.STATE.IDLE then
        self:_removeLru(entry)
        self._idleSize = self._idleSize - entry.size
        self._idleCount = self._idleCount - 1
    end
    self._busySize = self._busySize + entry.size
    self._busyCount = self._busyCount + 1
    entry.state = Cache.STATE.BUSY




    self:_enforceMaxCapacity()
end








function Cache:unpin(item)



    local entry = self._byItem[item]

    Log.trace(Cache, function() return "Unpinning %s", entry.key end)



    self._busySize = self._busySize - entry.size
    self._busyCount = self._busyCount - 1

    self:_insertLru(entry)
    self._idleSize = self._idleSize + entry.size
    self._idleCount = self._idleCount + 1
    entry.state = Cache.STATE.IDLE
end









function Cache:getState(item)



    local entry = self._byItem[item]

    return entry.state
end






function Cache:_removeLru(entry)



    if entry.lruPrev then
        entry.lruPrev.lruNext = entry.lruNext
    else
        self._lruHead = entry.lruNext
    end

    if entry.lruNext then
        entry.lruNext.lruPrev = entry.lruPrev
    else
        self._lruTail = entry.lruPrev
    end

    entry.lruPrev = nil
    entry.lruNext = nil
end






function Cache:_insertLru(entry)




    entry.lruNext = self._lruHead
    entry.lruPrev = nil
    if self._lruHead then
        self._lruHead.lruPrev = entry
    end
    self._lruHead = entry


    if not self._lruTail then
        self._lruTail = entry
    end
end




function Cache:_enforceMaxCapacity()



    local busy, max = self:getLoad()
    if self._lruTail and max <= self._maxCapacity then
        Log.trace(Cache, function() return "Cache load busy+idle: ".. tostring(busy) .. "/" .. tostring(max) .. "/" .. tostring(self:getMaxCapacity()) end)
        return
    end



    if self._enforceMaxCapacityIsBusy then
        return
    end
    self._enforceMaxCapacityIsBusy = true



    if self._busySize > self._maxBusyCapacity then
        for _, entry in pairs(self._byKey) do
            if entry.state == Cache.STATE.BUSY then
                Log.warn(Cache, function() return "busy item '%s'", entry.key end)
            end
        end

        error("Cache overflow " .. self._busySize .."/".. self._maxBusyCapacity)
    end



    local maxEvictions = math.max(self._idleCount * 2, 10)
    local didEvict = false

    while self._lruTail and self._busySize + self._idleSize > self._evictTarget do

        maxEvictions = maxEvictions - 1
        if maxEvictions < 0 then
            error("Cache thrashing")
        end


        local entry = self._lruTail



        self:_removeLru(entry)
        self._idleSize = self._idleSize - entry.size
        self._idleCount = self._idleCount - 1
        entry.state = Cache.STATE.FREE
        Log.debug(Cache, function() return "item %s is now FREE", entry.key end)

        self._freeCount = self._freeCount + 1


        self._evictFunction(entry.item)


        didEvict = true
    end

    self._enforceMaxCapacityIsBusy = false


    if didEvict and self._isYieldOnEvict and Thread.current() then
        Thread.yield()
    end
end

return LuaUtils.readOnly(Cache)
