-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local AngleConfiguration = require "AngleConfiguration"

local DigiBarRadialLayout = APL.LuaUtils.makeObject({ _type = "DigiBarRadialLayout" })

DigiBarRadialLayout.gradientLayout = {
    startPoint = { 0.5, 0.5 },
    endPoint = { 0, 1 },
    kind = APL.GradientLayer.KIND.CONICAL
}








function DigiBarRadialLayout.new(configuration)


    return APL.LuaUtils.newObject(DigiBarRadialLayout, {
        _configuration = configuration
    })
end






function DigiBarRadialLayout:destroy()

end











function DigiBarRadialLayout.getBarLayout(barStyle, frame, offset, widthExtension)





    local trackInset = barStyle.trackInset

    local barFrame = frame:centeredMinSquare()
    local _, _, length, _ = barFrame:getBounds()

    local radius = DigiBarRadialLayout.getTrackRadius(length, barStyle.trackWidth, trackInset) + offset
    local angles = barStyle.angleConfiguration

    local path = APL.Path.new()
        :arcTo(length / 2, length / 2, radius, -angles.minimumAngle, -angles.maximumAngle, angles.clockwise)

    return barFrame, path, barStyle.trackWidth + widthExtension, barStyle.trackLineCap
end









function DigiBarRadialLayout.getProgressCoordinates(barStyle, frame, value)




    local angle = DigiBarRadialLayout.getRotationAngle(barStyle, frame, value)
    local radius = DigiBarRadialLayout.getTrackRadius(frame._width, barStyle.trackWidth, barStyle.trackInset)

    local originOffsetX = frame._x + (frame._width / 2)
    local originOffsetY = frame._y + (frame._height / 2)

    local angleCosine = math.cos(angle)
    local angleSin = math.sin(angle)

    local x = (radius * angleCosine) + originOffsetX
    local y = (radius * angleSin) + originOffsetY

    return x, y
end









function DigiBarRadialLayout.getRotationAngle(barStyle, frame, value)




    local angleConfiguration = barStyle.angleConfiguration
    local direction = angleConfiguration.clockwise and 1 or -1


    local minAngle, maxAngle = angleConfiguration.minimumAngle, angleConfiguration.maximumAngle
    local extendedAngleConfiguration = AngleConfiguration.new(minAngle, maxAngle, angleConfiguration.clockwise)
    local extendedAngleDelta = AngleConfiguration.getNormalizedMinMaxAngleDelta(extendedAngleConfiguration)


    local progressAngle = minAngle + (value * extendedAngleDelta) * direction
    local directionalMaxAngle = minAngle + extendedAngleDelta * direction

    return angleConfiguration.clockwise
        and math.min(directionalMaxAngle, math.max(minAngle, progressAngle))
        or math.max(directionalMaxAngle, math.min(minAngle, progressAngle))
end









function DigiBarRadialLayout.getTrackRadius(frameWidth, trackWidth, trackInset)




    return frameWidth / 2 - trackWidth / 2 - trackInset
end

function DigiBarRadialLayout.getLineCapLength(barStyle)


    return DigiBarRadialLayout._getLineCapLength(barStyle.trackLineCap, barStyle.trackWidth)
end







function DigiBarRadialLayout._getLineCapLength(trackLineCap, trackWidth)



    if trackLineCap == APL.ShapeLayer.LINECAP.BUTT or trackLineCap == APL.ShapeLayer.LINECAP.SQUARE then
        return 0
    elseif trackLineCap == APL.ShapeLayer.LINECAP.ROUND then
        return trackWidth / 2
    else

    end

    return 0
end

return APL.LuaUtils.readOnly(DigiBarRadialLayout)