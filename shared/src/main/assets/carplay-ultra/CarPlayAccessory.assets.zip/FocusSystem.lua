-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local FocusSystem = APL.LuaUtils.makeObject({ _type = "FocusSystem" })






function FocusSystem.new()
    local self = APL.LuaUtils.newObject(FocusSystem, {
        _focusEnabled = false, -- Is the focus system currently enabled or not.
        _focusItems = {}, -- A set of focus items tracked by the system.
        _orderedItems = {}, -- A list of focus items in the order they were added to the system.
        _focusedItem = APL.LuaUtils.NIL, -- The currently focused item or nil.
        _hasFocusItemsUpdateHandler = APL.LuaUtils.NIL,
        _alwaysShowFocusEffects = false,
        _requiresFocusEffects = false,
    })

    return self
end






function FocusSystem:destroy()


    self._focusItems = nil
    self._orderedItems = nil
    self._focusedItem = nil
    self._hasFocusItemsUpdateHandler = nil
end







function FocusSystem:setEnabled(enabled)



    if self._focusEnabled ~= enabled then
        self._focusEnabled = enabled

        self:_recalculateFocus()
    end

    return self
end







function FocusSystem:handleEvents(events)



    if self._focusEnabled and self._focusedItem then
        self._focusedItem:handleEvents(events)
    end

    return self
end







function FocusSystem:setHasFocusItemsUpdateHandler(handler)



    self._hasFocusItemsUpdateHandler = handler

    return self
end






function FocusSystem:hasFocusItems()


    return next(self._focusItems) ~= nil
end






function FocusSystem:getFocusedItem()


    return self._focusedItem
end











function FocusSystem:addFocusItem(object)



    APL.Log.info(FocusSystem, function() return "Adding focus item: " .. APL.LuaUtils.getClassName(object) end)

    local hadFocusItems = next(self._focusItems) ~= nil

    if self._focusItems[object] then
        self._orderedItems = APL.LuaUtils.removeByValue(self._orderedItems, object)
    end

    self._focusItems[object] = true
    self._orderedItems[#self._orderedItems + 1] = object
    self:_recalculateFocus()

    if not hadFocusItems and self._hasFocusItemsUpdateHandler then
        self._hasFocusItemsUpdateHandler(true)
    end

    self:_updateRequiresFocusEffects(false)
    object:setRequiresFocusEffect(self._requiresFocusEffects)

    return self
end







function FocusSystem:removeFocusItem(object)



    local hadFocusItems = next(self._focusItems) ~= nil

    if self._focusItems[object] then
        APL.Log.info(FocusSystem, function() return "Removing focus item: " .. APL.LuaUtils.getClassName(object) end)
    else
        APL.Log.warn(FocusSystem, function() return "Attempted to remove untracked focus item: " .. APL.LuaUtils.getClassName(object) end)
    end

    self._focusItems[object] = nil

    self._orderedItems = APL.LuaUtils.removeByValue(self._orderedItems, object)

    if object == self._focusedItem then
        self:_recalculateFocus()
    end

    local hasFocusItems = next(self._focusItems) ~= nil
    if hadFocusItems and not hasFocusItems and self._hasFocusItemsUpdateHandler then
        self._hasFocusItemsUpdateHandler(false)
    end

    self:_updateRequiresFocusEffects(true)

    return self
end












function FocusSystem:setAlwaysShowFocusEffects(alwaysShowFocusEffects)



    if self._alwaysShowFocusEffects ~= alwaysShowFocusEffects then
        self._alwaysShowFocusEffects = alwaysShowFocusEffects
        APL.Log.info(FocusSystem, function() return "Focus effects will be shown " .. (alwaysShowFocusEffects and "all the time." or "as need.") end)

        self:_updateRequiresFocusEffects(true)
    end

    return self
end








function FocusSystem:_updateRequiresFocusEffects(informItems)



    local requiresFocusEffects = self._alwaysShowFocusEffects or #self._orderedItems > 1

    if self._requiresFocusEffects ~= requiresFocusEffects then
        self._requiresFocusEffects = requiresFocusEffects

        APL.Log.info(FocusSystem, function() return "Focus effects are " .. (requiresFocusEffects and "" or "not ") .. "required" end)

        if informItems then
            for item, _ in pairs(self._focusItems) do
                item:setRequiresFocusEffect(requiresFocusEffects)
            end
        end
    end

    return self
end









function FocusSystem:_recalculateFocus()


    APL.Log.info(FocusSystem, function() return "Recalculating focus with " .. #self._orderedItems .. " items" end)

    self:_moveFocus(self._orderedItems[#self._orderedItems])

    return self
end







function FocusSystem:_moveFocus(to)



    to = self._focusEnabled and to or nil

    local from = self._focusedItem
    if from == to then
        return false
    end

    if from then
        from:setFocused(false)
    end

    if to then
        to:setFocused(true)
    end

    self._focusedItem = to

    APL.Log.info(FocusSystem, function() return "Moved focus to " .. APL.LuaUtils.getClassName(to) end)

    return true
end

return APL.LuaUtils.readOnly(FocusSystem)
