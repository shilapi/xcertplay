-- Copyright © 2021-2026 Apple, Inc. All rights reserved.


local LuaUtils = require "APL.LuaUtils"

local Units = { _type = "Units" }

Units.UndefinedUnit = LuaUtils.readOnly({
    UNDEFINED = 0
})

Units.FuelEfficiency = LuaUtils.readOnly({
    LITERS_PER_100_KILOMETERS = 671,
    MILES_PER_GALLON = 672,
    MILES_PER_IMPERIAL_GALLON = 673,
    MILLILITERS_PER_100_KILOMETERS = 674,
})

Units.Length = LuaUtils.readOnly({
    KILOMETERS = 151,
    HECTOMETERS = 152,
    DECAMETERS = 153,
    METERS = 154,
    DECIMETERS = 155,
    CENTIMETERS = 156,
    MILLIMETERS = 157,
    MICROMETERS = 158,
    NANOMETERS = 159,
    PICOMETERS = 160,
    INCHES = 161,
    FEET = 162,
    YARDS = 163,
    MILES = 164,
})

Units.Speed = LuaUtils.readOnly({
    METERS_PER_SECOND = 1031,
    KILOMETERS_PER_HOUR = 1032,
    MILES_PER_HOUR = 1033,
    METERS_PER_HOUR = 1034,
})

Units.Temperature = LuaUtils.readOnly({
    FAHRENHEIT = 1081,
    CELSIUS = 1082,
    KELVIN = 1083,
})

return LuaUtils.readOnly(Units)