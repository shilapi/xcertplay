-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local Animator = require "Animator"
local APL = require "APL.APL"
local Constants = require "Constants"
local Enums = require "Enums"
local Display = require "Display"
local Layout = require "Layout"
local State = require "State"
local VehicleDataUpdater = require "VehicleDataUpdater"

local Workspace = APL.LuaUtils.makeObject({ _type = "Workspace" })


local STATE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "NONE",                   -- Black screen
    "LOGOS_TRANSITION",       -- Performing Logos startup animation and fading to black
    "STARTUP",                -- A Ghost state layout
    "DRIVE",                  -- A Drive state layout, disconnected or connected
    "ACCESSORY",              -- An Accessory state layout, disconnected or connected
    "EXIT"                    -- An Exit state layout
}, false))


local REMOTEUI_STATE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "DISCONNECTED",
    "CONNECTED",
    "TRANSITIONING", -- Waiting for layout change end event
    "LATE",          -- Late video frames was detected
    "IDLE",
}, false))




local WorkspaceState = APL.LuaUtils.namedObject(
    "WorkspaceState",
    { "remoteUIState", "string"             }, -- The state of the remoteUI (REMOTEUI_STATE)
    { "pendingUISceneState", "number?"      }, -- The last vehicle requested UISceneState (Enums.UISceneState)
    { "activeState", "string"               }, -- The active scene (STATE)
    { "isForegrounded", "boolean"           }, -- Whether this asset is visible and owns the root layer or not.
    { "appearance", "Appearance"            }  -- Currently set appearance
)






function WorkspaceState:isUISyncConnected()
    return self.remoteUIState ~= REMOTEUI_STATE.DISCONNECTED
end






function WorkspaceState:isTransitioning()
    return self.remoteUIState == REMOTEUI_STATE.TRANSITIONING
end






function WorkspaceState:isIdle()
    return self.remoteUIState == REMOTEUI_STATE.IDLE
end


Workspace.ACTION = APL.LuaUtils.readOnly({
    UISceneStateDidChange      = APL.LuaUtils.namedObject("UISceneStateDidChange", { "sceneState", "UISceneState" }),
    UISyncConnectionDidChange  = APL.LuaUtils.namedObject("UISyncConnectionDidChange", { "connected", "boolean" }),
    LayoutChangeDidStart       = APL.LuaUtils.namedObject("LayoutChangeDidStart", { "layoutID", "string?" },  { "activeComponentIDs", "table" }),
    LayoutChangeDidEnd         = APL.LuaUtils.namedObject("LayoutChangeDidEnd", { "layoutID", "string?" }),
    ForegroundStateDidChange   = APL.LuaUtils.namedObject("ForegroundStateDidChange", { "isForegrounded", "boolean" }),
    PaletteChange              = APL.LuaUtils.namedObject("PaletteChange", { "layoutID", "string" }, { "paletteID", "string" }),
    TargetAppearanceModeChange = APL.LuaUtils.namedObject("TargetAppearanceModeChange", { "targetAppearanceMode", "number" }),
    AppearancePreferenceChange = APL.LuaUtils.namedObject("AppearancePreferenceChange", { "preference", "number" }),
    CheckRemoteUIFreshness     = APL.LuaUtils.namedObject("CheckRemoteUIFreshness", { "PTS", "number" }, {"delay", "number?" }),
    UISyncForceDisconnect      = APL.LuaUtils.namedObject("UISyncForceDisconnect")
})

local CANCELIDS = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "REMOTEUI_FRESHNESS",
    "LAYOUT_TRANSITION",
    "LOGO_ANIMATION"
}))


local _ACTION = APL.LuaUtils.readOnly({
    LogoAnimationDidFinish = APL.LuaUtils.namedObject("LogoAnimationDidFinish")
})


local mapSceneState = function(sceneState)


    if sceneState.state == Enums.UISceneState.NONE then
        return STATE.NONE
    elseif sceneState.state == Enums.UISceneState.STARTUP then
        return STATE.STARTUP
    elseif sceneState.state == Enums.UISceneState.ACCESSORY_MODE then
        return STATE.ACCESSORY
    elseif sceneState.state == Enums.UISceneState.DRIVE then
        return STATE.DRIVE
    elseif sceneState.state == Enums.UISceneState.EXIT then
        return STATE.EXIT
    end


end


local mapLayoutMode = function(state)


    if state == STATE.NONE then
        return Layout.MODE.OFF
    elseif state == STATE.STARTUP then
        return Layout.MODE.OUTLINE
    elseif state == STATE.ACCESSORY then
        return Layout.MODE.ACCESSORY
    elseif state == STATE.DRIVE then
        return Layout.MODE.DRIVE
    elseif state == STATE.EXIT then
        return Layout.MODE.EXIT
    end
end


local shouldRemoteUIBeVisible = function(state)


    return state == STATE.DRIVE or state == STATE.ACCESSORY
end

Workspace.STATE = STATE











function Workspace.new(layoutController, vehicleDataUpdater, persistence, fastStart, displayID, appearance)







    local self = APL.LuaUtils.newObject(Workspace, {
        _store = APL.LuaUtils.NIL,
        _layoutController = layoutController,
        _vehicleDataUpdater = vehicleDataUpdater,
        _persistence = persistence,
        _displayID = displayID,
        _fastStart = fastStart
    })

    local initialState = WorkspaceState.new(
        REMOTEUI_STATE.DISCONNECTED,            -- remoteUIState
        nil,                                    -- pendingUISceneState
        STATE.NONE,                             -- activeState
        false,                                  -- isForegrounded
        appearance                              -- Appearance
    )

    self._store = APL.Store.new(initialState, function(...)
        return self:_reduce(...)
    end)

    return self
end






function Workspace:destroy()


    self._store:destroy()
end







function Workspace:send(action)



    self._store:dispatch(action)

    return self
end






function Workspace:getState()


    return self._store:getState()
end









function Workspace:_reduce(state, action, dispatch)





    local effects = {}

    if action:isKind(_ACTION.LogoAnimationDidFinish) then
        return self:_handleLogoAnimationDidFinish(state, action, dispatch)
    elseif action:isKind(Workspace.ACTION.LayoutChangeDidStart) then
        return self:_handleLayoutChangeDidStart(state, action, dispatch)
    elseif action:isKind(Workspace.ACTION.LayoutChangeDidEnd) then
        return self:_handleLayoutChangeDidEnd(state, action, dispatch)
    elseif action:isKind(Workspace.ACTION.UISceneStateDidChange) then
        return self:_handleSceneStateChange(state, action, dispatch)
    elseif action:isKind(Workspace.ACTION.UISyncConnectionDidChange) then
        return self:_handleConnectionChange(state, action, dispatch)
    elseif action:isKind(Workspace.ACTION.ForegroundStateDidChange) then
        return self:_handleForegroundStateChange(state, action, dispatch)
    elseif action:isKind(Workspace.ACTION.PaletteChange) then
        return self:_handlePaletteChange(state, action, dispatch)
    elseif action:isKind(Workspace.ACTION.TargetAppearanceModeChange) then
        return self:_handleTargetAppearanceModeChange(state, action, dispatch)
    elseif action:isKind(Workspace.ACTION.AppearancePreferenceChange) then
        return self:_handleAppearancePreferenceChange(state, action, dispatch)
    elseif action:isKind(Workspace.ACTION.UISyncForceDisconnect) then
        return self:_handleForceDisconnect(state, action, dispatch)
    elseif action:isKind(Workspace.ACTION.CheckRemoteUIFreshness) then
        return self:_handleCheckRemoteUIFreshness(state, action, dispatch)
    end

    APL.Log.warn(Workspace, function() return "Unknown action: " .. APL.LuaUtils.prettyPrint(action, false, 3) end)
    return nil
end












function Workspace:_handleLogoAnimationDidFinish(state, action, dispatch)





    if state.activeState ~= STATE.LOGOS_TRANSITION then
        APL.Log.warn(Workspace, function() return "Invalid state processing `LogoAnimationDidFinish`: " .. APL.LuaUtils.prettyPrint(state) end)
        return
    end


    if state.pendingUISceneState then
        dispatch(Workspace.ACTION.UISceneStateDidChange.new(state.pendingUISceneState))
        state.pendingUISceneState = nil
    else

        self._layoutController:activateLocalDriveUI(Layout.MODE.OUTLINE)
        state.activeState = STATE.STARTUP
    end
end









function Workspace:_handleLayoutChangeDidStart(state, action, dispatch)





    state.remoteUIState = REMOTEUI_STATE.TRANSITIONING
    APL.Log.info(Workspace, function() return "Layout change started, preparing layout " .. action.layoutID end)
    self._layoutController:prepareNextLayout(action.layoutID, action.activeComponentIDs)

    return {
        self:_createTransitionWatchdogEffect(),
        self:_cancelRemoteUIFreshnessWatchdogEffect()
    }
end









function Workspace:_handleLayoutChangeDidEnd(state, action, dispatch)






    if state.remoteUIState ~= REMOTEUI_STATE.TRANSITIONING then

        return
    end

    if action.layoutID then

        self._layoutController:swapLayout()



        if shouldRemoteUIBeVisible(state.activeState) then
            APL.Log.info(Workspace, function() return "Layout change ended, showing remote UI for layout " .. action.layoutID end)
            self._layoutController:showRemoteUI()
        end
    else
        APL.Log.warn(Workspace, function() return "Received Layout Change Ended command without layout ID!" end)
    end

    state.remoteUIState = REMOTEUI_STATE.IDLE

    return {

        self:_cancelTransitionWatchdogEffect()
    }
end









function Workspace:_handleSceneStateChange(state, action, dispatch)





    local sceneState = action.sceneState
    local effects = {}
    local activeState = state.activeState
    local targetState = mapSceneState(sceneState)
    local sceneStateOptions = sceneState.options or {}

    APL.Log.info(Workspace, function() return "Handling scene state change with Target Scene: " .. tostring(targetState) .. ", current state: " .. APL.LuaUtils.prettyPrint(state, false, 3) end)


    if activeState == targetState then
        APL.Log.warn(Workspace, function() return "Ignoring scene state " .. tostring(sceneState) .. ", scene is already in " .. activeState end)
        return
    end


    if not state.isForegrounded then
        state.pendingUISceneState = sceneState
        APL.Log.warn(Workspace, function() return "Saving scene state " .. tostring(sceneState) .. " while in background" end)
        return
    end


    if targetState == STATE.DRIVE or targetState == STATE.ACCESSORY then
        if State.canShowPairingAnimation() then
            if APL.LuaUtils.find(sceneStateOptions, Enums.UISceneOption.ALLOW_PAIRING_ANIMATION) then
                APL.Log.info(Workspace, function() return "Pairing animation allowed by vehicle on first launch." end)
                state.pendingUISceneState = sceneState
                targetState = STATE.STARTUP
            else
                APL.Log.info(Workspace, function() return "Pairing animation not allowed by vehicle on first launch." end)


                State.skipPairingAnimation()
            end
        else
            APL.Log.info(Workspace, function() return "Skip pairing animation." end)
        end
    end


    if targetState == STATE.STARTUP then
        self._layoutController:allowLayoutChange(false)



        if State.canShowPairingAnimation() then
            APL.Log.info(Workspace, function() return "Marking startup animation as being seen" end)
            State.skipPairingAnimation()
        end


        if self._displayID ~= Display.ID.CLUSTER then
            state.activeState = STATE.STARTUP
            return
        end


        if state.activeState == STATE.LOGOS_TRANSITION then
            APL.Log.warn(Workspace, function() return "Received UISceneState " .. tostring(sceneState) .. " but scene is already in logos transition" end)
            return
        end


        state.activeState = STATE.LOGOS_TRANSITION

        local animator = Animator.new()
            :onStart(function()
                APL.Log.info(Workspace, function() return "Started logo animation" end)


                self._layoutController:activateLocalDriveUI(Layout.MODE.OFF)


                self._layoutController:hideRemoteUI()
            end)
            :anim(function(animator)
                local skipPartnerLogoFadeIn = APL.LuaUtils.find(sceneStateOptions, Enums.UISceneOption.SKIP_STARTUP_FADE_IN)



                self._layoutController:showLogos(animator, skipPartnerLogoFadeIn)
            end)
            :onComplete(function()
                APL.Log.info(Workspace, function() return "Ended logo animation" end)
                dispatch(_ACTION.LogoAnimationDidFinish.new())
            end)

        effects[#effects+1] = APL.Effect.new(
                function()
                    animator
                        :start()
                        :join()
                end,
                function()
                    animator:destroy()
                end,
                CANCELIDS.LOGO_ANIMATION
            )

    else
        local animationInitialDelay = 0

        if state.activeState == STATE.LOGOS_TRANSITION then

            animationInitialDelay = Constants.UI_FADEIN_DELAY


            self._layoutController:hideLogos(Constants.LOGOS_ANIM_INTERRUPTION_FADEOUT_DURATION)


            effects[#effects+1] = APL.Effect.new(
                nil,
                nil,
                CANCELIDS.LOGO_ANIMATION
            )
        end


        self._layoutController:activateLocalDriveUI(
            mapLayoutMode(targetState),
            true,
            animationInitialDelay
        )

        if shouldRemoteUIBeVisible(targetState) then

            if state.remoteUIState == REMOTEUI_STATE.IDLE or state.remoteUIState == REMOTEUI_STATE.TRANSITIONING then
                self._layoutController:showRemoteUI(true, animationInitialDelay)

            elseif state.remoteUIState == REMOTEUI_STATE.CONNECTED then
                state.remoteUIState = REMOTEUI_STATE.TRANSITIONING
                self._layoutController:activateRemoteUI(state.appearance.targetAppearanceMode)


                effects[#effects+1] = self:_createTransitionWatchdogEffect()
            end


            self._layoutController:allowLayoutChange(true)
        else

            self._layoutController:hideRemoteUI()


            self._layoutController:allowLayoutChange(false)
        end

        state.activeState = targetState
    end

    return effects
end









function Workspace:_handleConnectionChange(state, action, dispatch)





    local connected = action.connected

    if state:isUISyncConnected() == connected then
        APL.Log.warn(Workspace, function() return "Connection state is already: " .. tostring(connected) end)
        return
    end

    local effects = {}
    local activeState = state.activeState


    if connected and not state.isForegrounded then
        APL.LuaUtils.safeCall(nil, function()
            APL.Signpost.emitEvent("UISync channel did connect. Asset ready to foreground.")
            CP.readyToEnterForeground()
        end)
    end

    if not connected then
        self._layoutController:hideRemoteUI(true, true)
        state.remoteUIState = REMOTEUI_STATE.DISCONNECTED
        effects[#effects+1] = self:_cancelTransitionWatchdogEffect()
    elseif shouldRemoteUIBeVisible(state.activeState) then
        state.remoteUIState = REMOTEUI_STATE.TRANSITIONING
        self._layoutController:activateRemoteUI(state.appearance.targetAppearanceMode)
        self._layoutController:allowLayoutChange(true)
        effects[#effects+1] = self:_createTransitionWatchdogEffect()
    else
        state.remoteUIState = REMOTEUI_STATE.CONNECTED


        self._layoutController:allowLayoutChange(true)


        self._layoutController:sendTargetAppearanceChange(state.appearance.targetAppearanceMode)
    end

    effects[#effects+1] = APL.Effect.new(
        function()
            self._layoutController:evalutateFocusTokenStatus(connected)
        end
    )
    effects[#effects+1] = self:_cancelRemoteUIFreshnessWatchdogEffect()

    return effects
end









function Workspace:_handleForegroundStateChange(state, action, dispatch)





    if state.isForegrounded ~= action.isForegrounded then
        state.isForegrounded = action.isForegrounded

        if state.isForegrounded then
            self._layoutController:sceneDidForeground()


            if state.pendingUISceneState then
                dispatch(Workspace.ACTION.UISceneStateDidChange.new(state.pendingUISceneState))
                state.pendingUISceneState = nil
            end
        end
    end
end









function Workspace:_handlePaletteChange(state, action, dispatch)





    local transitioning = state:isTransitioning()
    if transitioning then

        APL.Log.warn(Workspace, function() return "Changing palette during transition" end)
    end

    self._layoutController:handlePaletteChange(action.layoutID, action.paletteID, state.appearance:getResolvedAppearanceMode())
end









function Workspace:_handleTargetAppearanceModeChange(state, action, dispatch)





    self:_handleAppearanceChange(state.appearance, state.appearance:applyingTargetAppearanceMode(action.targetAppearanceMode), state)
end









function Workspace:_handleAppearancePreferenceChange(state, action, dispatch)





    self:_handleAppearanceChange(state.appearance, state.appearance:applyingPreference(action.preference), state)
end








function Workspace:_handleAppearanceChange(oldAppearance, newAppearance, state)






    state.appearance = newAppearance

    if state:isTransitioning() then

        APL.Log.warn(Workspace, function() return "Changing appearance during transition" end)
    end

    if newAppearance.preference ~= oldAppearance.preference then
        APL.Log.info(Workspace, function() return "Saving appearance setting to State: " .. tostring(newAppearance.preference) end)
        self._persistence.setAppearancePreference(newAppearance.preference)
    end

    if newAppearance.targetAppearanceMode ~= oldAppearance.targetAppearanceMode then
        APL.Log.info(Workspace, function() return "Send UISync with new targetAppearanceMode: " .. tostring(newAppearance.targetAppearanceMode) end)
        self._layoutController:sendTargetAppearanceChange(newAppearance.targetAppearanceMode)
    end

    local newResolvedAppearanceMode = newAppearance:getResolvedAppearanceMode()
    if newResolvedAppearanceMode ~= oldAppearance:getResolvedAppearanceMode() then
        APL.Log.info(Workspace, function() return "Write to appearanceMode ASC: " .. tostring(newResolvedAppearanceMode) end)
        self._vehicleDataUpdater:setData({ [VehicleDataUpdater.DATAIDENTIFIERS.appearanceMode] = newResolvedAppearanceMode })

        APL.Log.info(Workspace, function() return "Update layouts with new appearance: " .. tostring(newResolvedAppearanceMode) end)
        self._layoutController:handleAppearanceChange(newResolvedAppearanceMode)
    end
end









function Workspace:_handleForceDisconnect(state, action, dispatch)





    if action.expectedVideoPTS then
        state.expectedVideoPTS = action.expectedVideoPTS

        local iPhoneVideoStream = self._layoutController:_getIPhoneVideoStream()
        if iPhoneVideoStream then
            iPhoneVideoStream:flush()
        end
    end

    self._layoutController:resetClusterControlSession()
end









function Workspace:_handleCheckRemoteUIFreshness(state, action, dispatch)





    if state.remoteUIState ~= REMOTEUI_STATE.IDLE and state.remoteUIState ~= REMOTEUI_STATE.LATE then
        APL.Log.warn(Workspace, function() return "Ignore remote ui freshness test. State is not idle: " .. tostring(state.remoteUIState) end)
        return
    end


    local delay = action.delay
    if delay and delay > 0 then
        return {
            self:_createRemoteUIFreshnessWatchdogEffect(delay, action.PTS)
        }
    end

    local isFresh = self._layoutController:checkRemoteUIFreshness(action.PTS)
    if not isFresh then
        if isFresh == false then
            APL.Log.warn(Workspace, function() return "Video stream freshness is late." end)


            state.remoteUIState = REMOTEUI_STATE.LATE
            self._layoutController:hideRemoteUI()
        else
            APL.Log.warn(Workspace, function() return "Video stream freshness couldn't be determined, trying again later." end)
        end

        return {

            self:_createRemoteUIFreshnessWatchdogEffect(2, action.PTS)
        }
    else
        APL.Log.info(Workspace, function() return "Video stream freshness is ok" end)


        if shouldRemoteUIBeVisible(state.activeState) and state.remoteUIState == REMOTEUI_STATE.LATE then
            state.remoteUIState = REMOTEUI_STATE.IDLE
            self._layoutController:showRemoteUI()
        end
    end

    return {

        self:_cancelRemoteUIFreshnessWatchdogEffect()
    }
end











function Workspace:_createTransitionWatchdogEffect()


    return APL.Effect.new(
        function(dispatch)
            APL.Log.info(Workspace, function() return "Transition watchdog timer started" end)
            APL.Thread.sleep(2)
            APL.Log.warn(Workspace, function() return "Transition watchdog timer fired" end)

            dispatch(Workspace.ACTION.UISyncForceDisconnect.new())
        end,
        function(interrupted)
            if interrupted then
                APL.Log.info(Workspace, function() return "Transition watchdog timer cancelled" end)
            end
        end,
        CANCELIDS.LAYOUT_TRANSITION
    )
end






function Workspace:_cancelTransitionWatchdogEffect()
    return APL.Effect.new(nil, nil, CANCELIDS.LAYOUT_TRANSITION)
end








function Workspace:_createRemoteUIFreshnessWatchdogEffect(delay, pts)




    return APL.Effect.new(
        function(dispatch)
            APL.Log.info(Workspace, function() return "Video stream freshness watchdog started" end)
            APL.Thread.sleep(delay)
            APL.Log.warn(Workspace, function() return "Video stream freshness watchdog fired" end)

            dispatch(Workspace.ACTION.CheckRemoteUIFreshness.new(pts))
        end,
        function(interrupted)
            if interrupted then
                APL.Log.info(Workspace, function() return "Video stream freshness watchdog cancelled" end)
            end
        end,
        CANCELIDS.REMOTEUI_FRESHNESS
    )
end






function Workspace:_cancelRemoteUIFreshnessWatchdogEffect()
    return APL.Effect.new(nil, nil, CANCELIDS.REMOTEUI_FRESHNESS)
end

return APL.LuaUtils.readOnly(Workspace)
