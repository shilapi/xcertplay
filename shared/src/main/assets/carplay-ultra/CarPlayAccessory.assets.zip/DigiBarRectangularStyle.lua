-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local BlurConfiguration = require "BlurConfiguration"


local DigiBarRectangularStyle = APL.LuaUtils.namedObject(
    "DigiBarRectangularStyle",
    { "cornerRadius", "number" },
    { "cornerCurve", "number" },
    { "roundEdges", "boolean" },
    { "isRTL", "boolean" },
    { "blurConfiguration", "BlurConfiguration?" }
)







function DigiBarRectangularStyle.fromJson(json)


    return DigiBarRectangularStyle.new(
        json.cornerRadius,
        json.cornerCurve,
        json.roundEdges,
        json.isRTL,
        json.blurConfiguration and BlurConfiguration.new(
            json.blurConfiguration.radius,
            json.blurConfiguration.colorID
        )
    )
end

return APL.LuaUtils.readOnly(DigiBarRectangularStyle)