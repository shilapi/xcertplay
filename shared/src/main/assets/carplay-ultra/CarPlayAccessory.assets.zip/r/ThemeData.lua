return {
  defaultPaletteIDs = {
    Cobranded = "custom",
    DigiBand = "starlight",
    DigiBandWithTicks = "orange",
    DigiRing = "green",
    MapsMedia = "vibrant",
    Modular = "blue",
    NoStyle = "blue"
  },
  layoutStyles = {
    Cobranded = {
      custom = {
        ["radial.activeTickLabel"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#000000ff"
              }
            }
          }
        },
        ["radial.cruiseControlLabelBackground"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#1a3b33ff"
              }
            }
          }
        },
        ["radial.detailText"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#d7e3dbb2"
              }
            }
          }
        },
        ["radial.inactiveTickLabel"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffffff"
              }
            }
          }
        },
        ["radial.largeText"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffffff"
              }
            }
          }
        },
        ["radial.primaryActiveTicks"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#000000ff"
              }
            }
          }
        },
        ["radial.primaryInactive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#0b1b17ff"
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffffff"
              }
            }
          }
        },
        ["radial.redlineProgress"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#f81d1dff"
              }
            }
          }
        },
        ["radial.secondaryActiveTicks"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#000000ff"
              }
            }
          }
        },
        ["radial.secondaryInactive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#6d7c7a7f"
              }
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffff4c"
              }
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#9b1010ff"
              }
            }
          }
        },
        ["radial.secondaryTextRedacted"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#b0b0b0ff"
              }
            }
          }
        }
      }
    },
    DigiBand = {
      blue = {
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = nil,
              lightMode = {
                stops = {
                  ["0.0"] = "#1d658326"
                }
              }
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#54210eff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d59275ff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba800"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff8453ff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      green = {
        ["radial.activeTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = nil,
              lightMode = {
                stops = {
                  ["0.0"] = "#57603a33"
                }
              }
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#54210eff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b87a6bff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e6000"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#0000007f"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      midnight = {
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = nil,
              lightMode = {
                stops = {
                  ["0.0"] = "#404b653f"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#390703ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b27372ff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a200"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8d251dff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      orange = {
        ["radial.inactiveTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryDeactivated"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c26"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c3f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#6159574c"
                }
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#580a00ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#c3776fff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b3600"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7cff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c4c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      red = {
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#f7ad53ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = nil,
              lightMode = {
                stops = {
                  ["0.0"] = "#74747433"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#6b0101ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#a06969ff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a00"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff4c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      rose = {
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#5db2ffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.inactiveTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca1ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryDeactivated"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca126"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca13f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e606533"
                }
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca1ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#390703ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#bc7772ff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca100"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8d251dff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#db9db64c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca17f"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca14c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      starlight = {
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#1fbc34ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#fb971bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryDeactivated"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c5bcb426"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c5bcb433"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d473f"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#390703ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ba7972ff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd00"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8d251dff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      yellow = {
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#3ab7cbff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#fb971bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryDeactivated"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc26"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc3f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#dc301dff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#480803ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#c7827bff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded6300"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#dc301dff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#dc301dff"
                }
              },
              lightMode = nil
            }
          }
        }
      }
    },
    DigiBandWithTicks = {
      blue = {
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = nil,
              lightMode = {
                stops = {
                  ["0.0"] = "#1d658326"
                }
              }
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#54210eff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d59275ff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba800"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff8453ff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      green = {
        ["radial.activeTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = nil,
              lightMode = {
                stops = {
                  ["0.0"] = "#57603a33"
                }
              }
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#54210eff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b87a6bff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e6000"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#0000007f"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      midnight = {
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = nil,
              lightMode = {
                stops = {
                  ["0.0"] = "#404b653f"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#390703ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b27372ff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a200"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8d251dff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      orange = {
        ["radial.inactiveTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryDeactivated"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c26"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c3f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#6159574c"
                }
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#580a00ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#c3776fff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b3600"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7cff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c4c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      red = {
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#f7ad53ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = nil,
              lightMode = {
                stops = {
                  ["0.0"] = "#74747433"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#6b0101ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#a06969ff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a00"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff4c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      rose = {
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#5db2ffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.inactiveTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca1ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryDeactivated"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca126"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca13f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e606533"
                }
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca1ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#390703ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#bc7772ff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca100"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8d251dff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#db9db64c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca17f"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca14c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      starlight = {
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#1fbc34ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#fb971bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryDeactivated"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c5bcb426"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c5bcb433"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d473f"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#390703ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ba7972ff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd00"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8d251dff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      yellow = {
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#3ab7cbff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#fb971bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryDeactivated"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc26"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#dc301dff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#480803ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#c7827bff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded6300"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#dc301dff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.tertiaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#dc301dff"
                }
              },
              lightMode = nil
            }
          }
        }
      }
    },
    DigiRing = {
      blue = {
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff8453ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff8453ff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      green = {},
      midnight = {
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8d251dff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      orange = {
        ["radial.primaryDeactivated"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c26"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c4c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7cff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c4c"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      red = {
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#f7ad53ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryDeactivated"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a26"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a4c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff4c"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      rose = {
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#5db2ffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8d251dff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#db9db64c"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      starlight = {
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#1fbc34ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#fb971bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8d251dff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd4c"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      yellow = {
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#3ab7cbff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#fb971bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryDeactivated"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc26"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc4c"
                }
              },
              lightMode = nil
            }
          }
        }
      }
    },
    MapsMedia = {
      vibrant = {}
    },
    Modular = {
      blue = {
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff8453ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff8453ff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      green = {},
      midnight = {
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8d251dff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      multicolor = {
        ["modular.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.inactiveDotMarker"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.leftBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00b037ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00b037ff"
                }
              }
            }
          }
        },
        ["modular.leftBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00b0374c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00b0374c"
                }
              }
            }
          }
        },
        ["modular.leftText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.leftTextBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.leftTextCircular"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.leftTextCircularRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.leftTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.leftTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff2862ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#e62358ff"
                }
              }
            }
          }
        },
        ["modular.leftTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff28624c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#e623584c"
                }
              }
            }
          }
        },
        ["modular.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.rightBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#e330bdff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#e330bdff"
                }
              }
            }
          }
        },
        ["modular.rightBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#e330bd4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#e330bd4c"
                }
              }
            }
          }
        },
        ["modular.rightText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.rightTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.rightTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#e0b500ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#e0b500ff"
                }
              }
            }
          }
        },
        ["modular.rightTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#e0b5004c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#e0b5004c"
                }
              }
            }
          }
        },
        ["modular.secondarySpeedText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      orange = {
        ["modular.leftBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#615957ff"
                }
              }
            }
          }
        },
        ["modular.leftBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c4c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.leftTextBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c4c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.leftTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c4c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.rightBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#615957ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c4c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.rightTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c4c"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      red = {
        ["modular.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#f7ad53ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.leftBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.leftBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a7f"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.leftTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.leftTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a7f"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.rightBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a7f"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.rightTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.rightTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a7f"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      rose = {
        ["modular.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#5db2ffff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8d251dff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      starlight = {
        ["modular.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#1fbc34ff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#fb971bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8d251dff"
                }
              },
              lightMode = nil
            }
          }
        }
      },
      yellow = {
        ["modular.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#3ab7cbff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#fb971bff"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.leftBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a993f"
                }
              }
            }
          }
        },
        ["modular.leftTextBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc4c"
                }
              },
              lightMode = nil
            }
          }
        },
        ["modular.leftTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a993f"
                }
              }
            }
          }
        },
        ["modular.rightBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a993f"
                }
              }
            }
          }
        },
        ["modular.rightTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a993f"
                }
              }
            }
          }
        }
      }
    },
    NoStyle = {
      blue = {}
    }
  },
  palettes = {
    blue = {
      accentColor = {
        darkMode = "#63d2ffff",
        lightMode = "#57aaffff"
      },
      colors = {
        ["common.clear"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba8ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d6583ff"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba84c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d65834c"
                }
              }
            }
          }
        },
        ["modular.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["modular.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["modular.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["modular.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["modular.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a3ff9fff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#60d95bff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a3ff9fff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#076d01ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["modular.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.leftBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba8ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d6583ff"
                }
              }
            }
          }
        },
        ["modular.leftBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba84c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d65834c"
                }
              }
            }
          }
        },
        ["modular.leftText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.leftTextBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba84c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d65834c"
                }
              }
            }
          }
        },
        ["modular.leftTextCircular"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.leftTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba8ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d6583ff"
                }
              }
            }
          }
        },
        ["modular.leftTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba84c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d65834c"
                }
              }
            }
          }
        },
        ["modular.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["modular.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["modular.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba84c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff753cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#df620aff"
                }
              }
            }
          }
        },
        ["modular.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff753cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#df620aff"
                }
              }
            }
          }
        },
        ["modular.rightBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba8ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d6583ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba84c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d65834c"
                }
              }
            }
          }
        },
        ["modular.rightText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.rightTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000003f"
                }
              }
            }
          }
        },
        ["modular.rightTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba8ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d6583ff"
                }
              }
            }
          }
        },
        ["modular.rightTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba84c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d65834c"
                }
              }
            }
          }
        },
        ["modular.secondarySpeedText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        },
        ["radial.activeTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["radial.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["radial.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["radial.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["radial.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a3ff9fff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#60d95bff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a3ff9fff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#076d01ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlTrack"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a3ff9fff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#067f00ff"
                }
              }
            }
          }
        },
        ["radial.detailText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000b2"
                }
              }
            }
          }
        },
        ["radial.detailTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#d7e3db26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000002c"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.inactiveTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#63d2ffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d6583ff"
                }
              }
            }
          }
        },
        ["radial.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["radial.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["radial.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["radial.platter"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f24c"
                }
              }
            }
          }
        },
        ["radial.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba8ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d6583ff"
                }
              }
            }
          }
        },
        ["radial.primaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba84c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d65834c"
                }
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#63d2ffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d6583ff"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff8453ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#438ba84c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff753cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#df620aff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff753cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#df620aff"
                }
              }
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#63d2ffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#004a69ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#0000007f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              }
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#63d2ff4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#004a694c"
                }
              }
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#63d2ff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#1d65837f"
                }
              }
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff8453ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.secondaryText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.secondaryTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#63d2ff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000003f"
                }
              }
            }
          }
        },
        ["radial.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        }
      },
      displayName = "Blue",
      id = "blue",
      prominent = false,
      representedColorScheme = {
        dynamicColor = {
          ["_0"] = {
            darkMode = "#438ba8ff",
            lightMode = "#1d6583ff"
          }
        }
      },
      sortIndex = 40
    },
    custom = {
      backgroundOverrideColor = "#000000ff",
      colors = {
        ["common.clear"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#00000000"
              }
            }
          }
        },
        ["partner.cobranded.decorativeRing"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#6d7c7aff"
              }
            }
          }
        },
        ["partner.cobranded.inactiveRedline"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#2d1717ff"
              }
            }
          }
        },
        ["partner.cobranded.innerRingActive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#1dc5a7ff"
              }
            }
          }
        },
        ["partner.cobranded.innerRingInactive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#1dc5a74c"
              }
            }
          }
        },
        ["partner.cobranded.innerTicksActive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#00000033"
              }
            }
          }
        },
        ["partner.cobranded.innerTicksInactive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffff33"
              }
            }
          }
        },
        ["radial.activeTickLabel"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#000000ff"
              }
            }
          }
        },
        ["radial.coldActive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffffff"
              }
            }
          }
        },
        ["radial.coldInactive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffff7f"
              }
            }
          }
        },
        ["radial.criticalActive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ff544bff"
              }
            }
          }
        },
        ["radial.criticalInactive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ff544b7f"
              }
            }
          }
        },
        ["radial.cruiseControlInactive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#626265ff"
              }
            }
          }
        },
        ["radial.cruiseControlLabelActive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#9cffa0ff"
              }
            }
          }
        },
        ["radial.cruiseControlLabelBackground"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#000000ff"
              }
            }
          }
        },
        ["radial.cruiseControlLabelInactive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#626265ff"
              }
            }
          }
        },
        ["radial.cruiseControlTrack"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#9cffa0ff"
              }
            }
          }
        },
        ["radial.detailText"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffffb2"
              }
            }
          }
        },
        ["radial.detailTextRedacted"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#d7e3db26"
              }
            }
          }
        },
        ["radial.forecastSpeedActive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffffff"
              }
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffffff"
              }
            }
          }
        },
        ["radial.inactiveTickLabel"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffffff"
              }
            }
          }
        },
        ["radial.largeText"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffffe5"
              }
            }
          }
        },
        ["radial.largeTextRedacted"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffff26"
              }
            }
          }
        },
        ["radial.lowLevelActive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ff9f0aff"
              }
            }
          }
        },
        ["radial.lowLevelInactive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ff9f0a7f"
              }
            }
          }
        },
        ["radial.primaryActive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffffff"
              }
            }
          }
        },
        ["radial.primaryActiveTicks"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#000000ff"
              }
            }
          }
        },
        ["radial.primaryInactive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffff4c"
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffffff"
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#f81d1dff"
              }
            }
          }
        },
        ["radial.redacted"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffff4c"
              }
            }
          }
        },
        ["radial.redlineProgress"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#9b1010ff"
              }
            }
          }
        },
        ["radial.secondaryActive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffffff"
              }
            }
          }
        },
        ["radial.secondaryActiveTicks"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#0000007f"
              }
            }
          }
        },
        ["radial.secondaryInactive"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffff4c"
              }
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffff7f"
              }
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#f81d1dff"
              }
            }
          }
        },
        ["radial.secondaryText"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffffe5"
              }
            }
          }
        },
        ["radial.secondaryTextRedacted"] = {
          single = {
            value = {
              stops = {
                ["0.0"] = "#ffffff26"
              }
            }
          }
        }
      },
      displayName = "Custom",
      id = "custom",
      prominent = false,
      representedColorScheme = {
        single = {
          color = "#495957ff"
        }
      },
      sortIndex = 9
    },
    green = {
      accentColor = {
        darkMode = "#c0ea67ff",
        lightMode = "#577711ff"
      },
      colors = {
        ["common.clear"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e60ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#57603aff"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e604c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#57603a4c"
                }
              }
            }
          }
        },
        ["modular.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["modular.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["modular.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["modular.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["modular.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#d3ff74ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d3ff74ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#d3ff74ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#537701ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["modular.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.leftBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e60ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#57603aff"
                }
              }
            }
          }
        },
        ["modular.leftBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e604c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#57603a4c"
                }
              }
            }
          }
        },
        ["modular.leftText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#8a5f38ff"
                }
              }
            }
          }
        },
        ["modular.leftTextBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e604c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#57603a4c"
                }
              }
            }
          }
        },
        ["modular.leftTextCircular"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#8a5f38ff"
                }
              }
            }
          }
        },
        ["modular.leftTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e60ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#57603aff"
                }
              }
            }
          }
        },
        ["modular.leftTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e604c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#57603a4c"
                }
              }
            }
          }
        },
        ["modular.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["modular.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["modular.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e604c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff753cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#df490aff"
                }
              }
            }
          }
        },
        ["modular.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff753cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#df620aff"
                }
              }
            }
          }
        },
        ["modular.rightBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e60ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#57603aff"
                }
              }
            }
          }
        },
        ["modular.rightBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e604c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#57603a4c"
                }
              }
            }
          }
        },
        ["modular.rightText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#8a5f38ff"
                }
              }
            }
          }
        },
        ["modular.rightTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#8a5f383f"
                }
              }
            }
          }
        },
        ["modular.rightTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e60ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#57603aff"
                }
              }
            }
          }
        },
        ["modular.rightTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e604c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#57603a4c"
                }
              }
            }
          }
        },
        ["modular.secondarySpeedText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#8a5f38ff"
                }
              }
            }
          }
        },
        ["modular.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        },
        ["radial.activeTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["radial.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["radial.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["radial.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["radial.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#d3ff74ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d3ff74ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#d3ff74ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#537701ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlTrack"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#d3ff74ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#537701ff"
                }
              }
            }
          }
        },
        ["radial.detailText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000b2"
                }
              }
            }
          }
        },
        ["radial.detailTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c5bcb426"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000002c"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.inactiveTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c5bcb4ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["radial.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["radial.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["radial.platter"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f24c"
                }
              }
            }
          }
        },
        ["radial.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e60ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#57603aff"
                }
              }
            }
          }
        },
        ["radial.primaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e604c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#57603a4c"
                }
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c5bcb4ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff8453ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#df490aff"
                }
              }
            }
          }
        },
        ["radial.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#757e604c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff753cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#df490aff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff753cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#df620aff"
                }
              }
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c0ea67ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#8a5f38ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              }
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c0ea674c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#8a5f384c"
                }
              }
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c5bcb47f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000007f"
                }
              }
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff8453ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#df490aff"
                }
              }
            }
          }
        },
        ["radial.secondaryText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#8a5f38ff"
                }
              }
            }
          }
        },
        ["radial.secondaryTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c0ea6726"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#8a5f383f"
                }
              }
            }
          }
        },
        ["radial.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        }
      },
      displayName = "Green",
      id = "green",
      prominent = false,
      representedColorScheme = {
        dynamicColor = {
          ["_0"] = {
            darkMode = "#757e60ff",
            lightMode = "#57603aff"
          }
        }
      },
      sortIndex = 50
    },
    midnight = {
      accentColor = {
        darkMode = "#7c88a2ff",
        lightMode = "#596181ff"
      },
      colors = {
        ["common.clear"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a2ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a24c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b654c"
                }
              }
            }
          }
        },
        ["modular.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["modular.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["modular.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["modular.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["modular.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffdd6fff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ff7c17ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffdd6fff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#a04500ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["modular.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.leftBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a2ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["modular.leftBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a24c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b654c"
                }
              }
            }
          }
        },
        ["modular.leftText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["modular.leftTextBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a24c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b654c"
                }
              }
            }
          }
        },
        ["modular.leftTextCircular"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["modular.leftTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a2ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["modular.leftTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a24c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b654c"
                }
              }
            }
          }
        },
        ["modular.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["modular.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["modular.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a24c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              }
            }
          }
        },
        ["modular.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d72514ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a2ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a24c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b654c"
                }
              }
            }
          }
        },
        ["modular.rightText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["modular.rightTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b653f"
                }
              }
            }
          }
        },
        ["modular.rightTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a2ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["modular.rightTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a24c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b654c"
                }
              }
            }
          }
        },
        ["modular.secondarySpeedText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["modular.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        },
        ["radial.activeTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["radial.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["radial.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["radial.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["radial.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffdd6fff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ff7c17ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffdd6fff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#a04500ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlTrack"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffdd6fff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#a84800ff"
                }
              }
            }
          }
        },
        ["radial.detailText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000b2"
                }
              }
            }
          }
        },
        ["radial.detailTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a226"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000002c"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.inactiveTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a8b6d2ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["radial.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["radial.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["radial.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["radial.platter"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f24c"
                }
              }
            }
          }
        },
        ["radial.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a2ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["radial.primaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a24c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b654c"
                }
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a8b6d2ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              }
            }
          }
        },
        ["radial.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#8188a24c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d72514ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a8b6d2ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#0000007f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              }
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a8b6d24c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b654c"
                }
              }
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a8b6d27f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b657f"
                }
              }
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              }
            }
          }
        },
        ["radial.secondaryText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b65ff"
                }
              }
            }
          }
        },
        ["radial.secondaryTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a8b6d226"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#404b653f"
                }
              }
            }
          }
        },
        ["radial.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        }
      },
      displayName = "Midnight",
      id = "midnight",
      prominent = false,
      representedColorScheme = {
        dynamicColor = {
          ["_0"] = {
            darkMode = "#7c88a2ff",
            lightMode = "#404b65ff"
          }
        }
      },
      sortIndex = 80
    },
    multicolor = {
      backgroundOverrideColor = "#000000ff",
      colors = {
        ["common.clear"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff2862ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d0c959ff"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff28624c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["modular.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#007affff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["modular.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#007aff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["modular.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["modular.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["modular.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a3ff9fff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#002a67ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a3ff9fff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#002a67ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#e330bdff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#4b4b4bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#007affff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["modular.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#007aff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.leftBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff2862ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d0c959ff"
                }
              }
            }
          }
        },
        ["modular.leftBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff28624c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["modular.leftText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["modular.leftTextBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff28624c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["modular.leftTextCircular"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["modular.leftTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff2862ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d0c959ff"
                }
              }
            }
          }
        },
        ["modular.leftTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff28624c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["modular.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["modular.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["modular.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff28624c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#e64b3bff"
                }
              }
            }
          }
        },
        ["modular.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#e330bdff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d72514ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff2862ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d0c959ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff28624c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["modular.rightText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["modular.rightTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.rightTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff2862ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d0c959ff"
                }
              }
            }
          }
        },
        ["modular.rightTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff28624c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["modular.secondarySpeedText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["modular.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        }
      },
      displayName = "Multicolor",
      id = "multicolor",
      prominent = false,
      representedColorScheme = {
        multicolor = {}
      },
      sortIndex = 10
    },
    orange = {
      accentColor = {
        darkMode = "#ec5b36ff",
        lightMode = "#ec5b36ff"
      },
      colors = {
        ["common.clear"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b36ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec5b36ff"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b364c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#6159574c"
                }
              }
            }
          }
        },
        ["modular.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["modular.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["modular.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["modular.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["modular.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b0e9ffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00407bff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#626265ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b0e9ffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00407bff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#626265ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["modular.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.leftBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b36ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec5b36ff"
                }
              }
            }
          }
        },
        ["modular.leftBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b364c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#6159574c"
                }
              }
            }
          }
        },
        ["modular.leftText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#615957ff"
                }
              }
            }
          }
        },
        ["modular.leftTextBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b364c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#6159574c"
                }
              }
            }
          }
        },
        ["modular.leftTextCircular"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#615957ff"
                }
              }
            }
          }
        },
        ["modular.leftTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b36ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec5b36ff"
                }
              }
            }
          }
        },
        ["modular.leftTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b364c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#6159574c"
                }
              }
            }
          }
        },
        ["modular.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["modular.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["modular.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b364c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#af1b07ff"
                }
              }
            }
          }
        },
        ["modular.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d72514ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b36ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec5b36ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b364c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#6159574c"
                }
              }
            }
          }
        },
        ["modular.rightText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#615957ff"
                }
              }
            }
          }
        },
        ["modular.rightTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#6159573f"
                }
              }
            }
          }
        },
        ["modular.rightTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b36ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec5b36ff"
                }
              }
            }
          }
        },
        ["modular.rightTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b364c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#6159574c"
                }
              }
            }
          }
        },
        ["modular.secondarySpeedText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#615957ff"
                }
              }
            }
          }
        },
        ["modular.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        },
        ["radial.activeTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["radial.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["radial.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["radial.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["radial.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b0e9ffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00407bff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#626265ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b0e9ffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00407bff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#626265ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlTrack"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b0e9ffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00407bff"
                }
              }
            }
          }
        },
        ["radial.detailText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000b2"
                }
              }
            }
          }
        },
        ["radial.detailTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#877f7c26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000002c"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.inactiveTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["radial.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["radial.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["radial.platter"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f24c"
                }
              }
            }
          }
        },
        ["radial.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b36ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec5b36ff"
                }
              }
            }
          }
        },
        ["radial.primaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b364c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#6159574c"
                }
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#af1b07ff"
                }
              }
            }
          }
        },
        ["radial.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ec5b364c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#af1b07ff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d72514ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a99f9bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#615957ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#0000007f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              }
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a99f9b4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#6159574c"
                }
              }
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000007f"
                }
              }
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#af1b07ff"
                }
              }
            }
          }
        },
        ["radial.secondaryText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#4d4543ff"
                }
              }
            }
          }
        },
        ["radial.secondaryTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#a99f9b26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#4d45433f"
                }
              }
            }
          }
        },
        ["radial.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        }
      },
      displayName = "Orange",
      id = "orange",
      prominent = false,
      representedColorScheme = {
        linearGradient = {
          ["_0"] = {
            endPoint = {
              x = 1.0,
              y = 1.0
            },
            startPoint = {
              x = 0.0,
              y = 0.0
            },
            stops = {
              {
                color = {
                  darkMode = "#ec5b36ff",
                  lightMode = "#ec5b36ff"
                },
                location = 0.0
              },
              {
                color = {
                  darkMode = "#ec5b36ff",
                  lightMode = "#ec5b36ff"
                },
                location = 0.49999
              },
              {
                color = {
                  darkMode = "#6e6763ff",
                  lightMode = "#d1c9c7ff"
                },
                location = 0.5
              },
              {
                color = {
                  darkMode = "#6e6763ff",
                  lightMode = "#d1c9c7ff"
                },
                location = 1.0
              }
            }
          }
        }
      },
      sortIndex = 30
    },
    red = {
      accentColor = {
        darkMode = "#f0250eff",
        lightMode = "#b01a0aff"
      },
      colors = {
        ["common.clear"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7474744c"
                }
              }
            }
          }
        },
        ["modular.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["modular.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["modular.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["modular.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["modular.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#15bbe0ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#15bbe0ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#717171ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#15bbe0ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00667fff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#717171ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea952dff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea952dff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["modular.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.leftBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["modular.leftBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7474744c"
                }
              }
            }
          }
        },
        ["modular.leftText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.leftTextBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7474744c"
                }
              }
            }
          }
        },
        ["modular.leftTextCircular"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.leftTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["modular.leftTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7474744c"
                }
              }
            }
          }
        },
        ["modular.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["modular.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["modular.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["modular.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f34122ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["modular.rightBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7474744c"
                }
              }
            }
          }
        },
        ["modular.rightText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.rightTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000003f"
                }
              }
            }
          }
        },
        ["modular.rightTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["modular.rightTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7474744c"
                }
              }
            }
          }
        },
        ["modular.secondarySpeedText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        },
        ["radial.activeTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["radial.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["radial.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["radial.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["radial.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#15bbe0ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#15bbe0ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#717171ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#15bbe0ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00667fff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#717171ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlTrack"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#15bbe0ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#007c99ff"
                }
              }
            }
          }
        },
        ["radial.detailText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000b2"
                }
              }
            }
          }
        },
        ["radial.detailTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#e9d6d026"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000002c"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea952dff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea952dff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.inactiveTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#dfd6d0ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["radial.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["radial.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["radial.platter"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f24c"
                }
              }
            }
          }
        },
        ["radial.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["radial.primaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7474744c"
                }
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#dfd6d0ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["radial.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0a4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f34122ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#e9d6d0ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              }
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#e9d6d04c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000004c"
                }
              }
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#dfd6d07f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000007f"
                }
              }
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["radial.secondaryText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.secondaryTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#e9d6d026"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000003f"
                }
              }
            }
          }
        },
        ["radial.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        }
      },
      displayName = "Red",
      id = "red",
      prominent = false,
      representedColorScheme = {
        single = {
          color = "#b01a0aff"
        }
      },
      sortIndex = 20
    },
    rose = {
      accentColor = {
        darkMode = "#ffbdcdff",
        lightMode = "#a43c68ff"
      },
      colors = {
        ["common.clear"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca1ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca14c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e60654c"
                }
              }
            }
          }
        },
        ["modular.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["modular.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["modular.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["modular.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["modular.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#006bc0ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#90c3ffff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#626265ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#006bc0ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#2862a9ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#626265ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["modular.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.leftBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca1ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["modular.leftBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca14c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e60654c"
                }
              }
            }
          }
        },
        ["modular.leftText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["modular.leftTextBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca14c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e60654c"
                }
              }
            }
          }
        },
        ["modular.leftTextCircular"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["modular.leftTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca1ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["modular.leftTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca14c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e60654c"
                }
              }
            }
          }
        },
        ["modular.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["modular.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["modular.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca14c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              }
            }
          }
        },
        ["modular.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d72514ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca1ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca14c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e60654c"
                }
              }
            }
          }
        },
        ["modular.rightText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["modular.rightTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e60653f"
                }
              }
            }
          }
        },
        ["modular.rightTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca1ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["modular.rightTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca14c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e60654c"
                }
              }
            }
          }
        },
        ["modular.secondarySpeedText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["modular.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        },
        ["radial.activeTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["radial.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["radial.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["radial.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["radial.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#006bc0ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#90c3ffff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#626265ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#006bc0ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#2862a9ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#626265ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlTrack"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#006bc0ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#196bcdff"
                }
              }
            }
          }
        },
        ["radial.detailText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000b2"
                }
              }
            }
          }
        },
        ["radial.detailTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca126"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000002c"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.inactiveTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#db9db6ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["radial.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["radial.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["radial.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["radial.platter"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f24c"
                }
              }
            }
          }
        },
        ["radial.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca1ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["radial.primaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca14c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e60654c"
                }
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#db9db6ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              }
            }
          }
        },
        ["radial.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b59ca14c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d72514ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#db9db6ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#0000007f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              }
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#db9db64c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e60654c"
                }
              }
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#db9db67f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e60657f"
                }
              }
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              }
            }
          }
        },
        ["radial.secondaryText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e6065ff"
                }
              }
            }
          }
        },
        ["radial.secondaryTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#db9db626"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#7e60653f"
                }
              }
            }
          }
        },
        ["radial.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        }
      },
      displayName = "Rose",
      id = "rose",
      prominent = false,
      representedColorScheme = {
        dynamicColor = {
          ["_0"] = {
            darkMode = "#bb8995ff",
            lightMode = "#7e6065ff"
          }
        }
      },
      sortIndex = 90
    },
    starlight = {
      accentColor = {
        darkMode = "#cfc5bdff",
        lightMode = "#6d5a4fff"
      },
      colors = {
        ["common.clear"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bdff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d474c"
                }
              }
            }
          }
        },
        ["modular.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["modular.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["modular.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["modular.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["modular.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#17a12cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#3ebb51ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#717171ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#17a12cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#006e0fff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#717171ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cb7003ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cb7003ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["modular.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.leftBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bdff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["modular.leftBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d474c"
                }
              }
            }
          }
        },
        ["modular.leftText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["modular.leftTextBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d474c"
                }
              }
            }
          }
        },
        ["modular.leftTextCircular"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["modular.leftTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bdff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["modular.leftTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d474c"
                }
              }
            }
          }
        },
        ["modular.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["modular.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["modular.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              }
            }
          }
        },
        ["modular.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d72514ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bdff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d474c"
                }
              }
            }
          }
        },
        ["modular.rightText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["modular.rightTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d473f"
                }
              }
            }
          }
        },
        ["modular.rightTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bdff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["modular.rightTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d474c"
                }
              }
            }
          }
        },
        ["modular.secondarySpeedText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["modular.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        },
        ["radial.activeTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["radial.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["radial.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["radial.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["radial.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#17a12cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#3ebb51ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#717171ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#17a12cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#006e0fff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#717171ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlTrack"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#17a12cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#007310ff"
                }
              }
            }
          }
        },
        ["radial.detailText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000b2"
                }
              }
            }
          }
        },
        ["radial.detailTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000002c"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cb7003ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cb7003ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.inactiveTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c5bcb4ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["radial.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["radial.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["radial.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["radial.platter"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f24c"
                }
              }
            }
          }
        },
        ["radial.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bdff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["radial.primaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              }
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d474c"
                }
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c5bcb4ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              }
            }
          }
        },
        ["radial.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#9f1f15ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d72514ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bdff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#0000007f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              }
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d474c"
                }
              }
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c5bcb47f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d477f"
                }
              }
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              }
            }
          }
        },
        ["radial.secondaryText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["radial.secondaryTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#cfc5bd26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d473f"
                }
              }
            }
          }
        },
        ["radial.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        }
      },
      displayName = "Starlight",
      id = "starlight",
      prominent = false,
      representedColorScheme = {
        dynamicColor = {
          ["_0"] = {
            darkMode = "#cfc5bdff",
            lightMode = "#554d47ff"
          }
        }
      },
      sortIndex = 70
    },
    vibrant = {
      colors = {
        ["common.clear"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              }
            }
          }
        },
        ["mapsMedia.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["mapsMedia.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["mapsMedia.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#17a12cff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#3ebb51ff"
                }
              }
            }
          }
        },
        ["mapsMedia.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#999999e5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["mapsMedia.detailText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["mapsMedia.detailTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d473f"
                }
              }
            }
          }
        },
        ["mapsMedia.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["mapsMedia.largeDetailText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["mapsMedia.largeDetailTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d473f"
                }
              }
            }
          }
        },
        ["mapsMedia.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["mapsMedia.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["mapsMedia.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["mapsMedia.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d47ff"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d474c"
                }
              }
            }
          }
        },
        ["mapsMedia.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["mapsMedia.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#c52a1bff"
                }
              }
            }
          }
        },
        ["mapsMedia.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        },
        ["modular.leftTextBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#554d474c"
                }
              }
            }
          }
        }
      },
      displayName = "Vibrant",
      id = "vibrant",
      prominent = false,
      representedColorScheme = {
        linearGradient = {
          ["_0"] = {
            endPoint = {
              x = 0.5,
              y = 1.0
            },
            startPoint = {
              x = 0.5,
              y = 0.0
            },
            stops = {
              {
                color = {
                  darkMode = "#ffffffff",
                  lightMode = "#f3f3f3ff"
                },
                location = 0.0
              },
              {
                color = {
                  darkMode = "#7d7d7dff",
                  lightMode = "#9c9c9cff"
                },
                location = 1.0
              }
            }
          }
        }
      },
      sortIndex = 100
    },
    yellow = {
      accentColor = {
        darkMode = "#eded63ff",
        lightMode = "#266771ff"
      },
      colors = {
        ["common.clear"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000000"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded63ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d0c959ff"
                }
              }
            }
          }
        },
        ["mapsMedia.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded634c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["modular.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["modular.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["modular.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["modular.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["modular.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#008fa5ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00778aff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#626265ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#008fa5ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00667fff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["modular.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#626265ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#bf6800ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#bf6800ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["modular.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.leftBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded63ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d0c959ff"
                }
              }
            }
          }
        },
        ["modular.leftBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded634c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["modular.leftText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.leftTextBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded634c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["modular.leftTextCircular"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.leftTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded63ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d0c959ff"
                }
              }
            }
          }
        },
        ["modular.leftTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded634c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["modular.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["modular.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["modular.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded634c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["modular.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["modular.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d72514ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded63ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d0c959ff"
                }
              }
            }
          }
        },
        ["modular.rightBottomInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded634c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["modular.rightText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.rightTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000003f"
                }
              }
            }
          }
        },
        ["modular.rightTopActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded63ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d0c959ff"
                }
              }
            }
          }
        },
        ["modular.rightTopInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded634c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["modular.secondarySpeedText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["modular.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        },
        ["radial.activeTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.coldActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d2ff"
                }
              }
            }
          }
        },
        ["radial.coldInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0064d27f"
                }
              }
            }
          }
        },
        ["radial.criticalActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544bff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c00ff"
                }
              }
            }
          }
        },
        ["radial.criticalInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff544b7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ee0c007f"
                }
              }
            }
          }
        },
        ["radial.cruiseControlActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#008fa5ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00778aff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#626265ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#008fa5ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00667fff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelBackground"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f2ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlLabelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#626265ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#999999ff"
                }
              }
            }
          }
        },
        ["radial.cruiseControlTrack"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#008fa5ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00778aff"
                }
              }
            }
          }
        },
        ["radial.detailText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffb2"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000b2"
                }
              }
            }
          }
        },
        ["radial.detailTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#968e8026"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000002c"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#bf6800ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.forecastSpeedLabelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#bf6800ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.inactiveTickLabel"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0ccff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a99ff"
                }
              }
            }
          }
        },
        ["radial.largeText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000e5"
                }
              }
            }
          }
        },
        ["radial.largeTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffff26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.lowLevelActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0aff"
                }
              }
            }
          }
        },
        ["radial.lowLevelInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ff9f0a7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ec7d0a7f"
                }
              }
            }
          }
        },
        ["radial.platter"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#f2f2f24c"
                }
              }
            }
          }
        },
        ["radial.primaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded63ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d0c959ff"
                }
              }
            }
          }
        },
        ["radial.primaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.primaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded634c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a9933"
                }
              }
            }
          }
        },
        ["radial.primaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0ccff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a99ff"
                }
              }
            }
          }
        },
        ["radial.primaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["radial.redacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#eded634c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#00000039"
                }
              }
            }
          }
        },
        ["radial.redline"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["radial.redlineCrossed"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.redlineProgress"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#d72514ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0ccff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#336070ff"
                }
              }
            }
          }
        },
        ["radial.secondaryActiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#0000007f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000007f"
                }
              }
            }
          }
        },
        ["radial.secondaryInactive"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc4c"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#3360704c"
                }
              }
            }
          }
        },
        ["radial.secondaryInactiveTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc7f"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#618a997f"
                }
              }
            }
          }
        },
        ["radial.secondaryRedlineTicks"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ea3722ff"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#b01a0aff"
                }
              }
            }
          }
        },
        ["radial.secondaryText"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#ffffffe5"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#000000ff"
                }
              }
            }
          }
        },
        ["radial.secondaryTextRedacted"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#69c0cc26"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#0000003f"
                }
              }
            }
          }
        },
        ["radial.trackBlur"] = {
          dynamic = {
            value = {
              darkMode = {
                stops = {
                  ["0.0"] = "#00000066"
                }
              },
              lightMode = {
                stops = {
                  ["0.0"] = "#ffffff00"
                }
              }
            }
          }
        }
      },
      displayName = "Yellow",
      id = "yellow",
      prominent = false,
      representedColorScheme = {
        linearGradient = {
          ["_0"] = {
            endPoint = {
              x = 1.0,
              y = 1.0
            },
            startPoint = {
              x = 0.0,
              y = 0.0
            },
            stops = {
              {
                color = {
                  darkMode = "#eded63ff",
                  lightMode = "#d0c959ff"
                },
                location = 0.0
              },
              {
                color = {
                  darkMode = "#eded63ff",
                  lightMode = "#d0c959ff"
                },
                location = 0.49999
              },
              {
                color = {
                  darkMode = "#69c0ccff",
                  lightMode = "#96b0b9ff"
                },
                location = 0.5
              },
              {
                color = {
                  darkMode = "#69c0ccff",
                  lightMode = "#96b0b9ff"
                },
                location = 1.0
              }
            }
          }
        }
      },
      sortIndex = 60
    }
  }
}