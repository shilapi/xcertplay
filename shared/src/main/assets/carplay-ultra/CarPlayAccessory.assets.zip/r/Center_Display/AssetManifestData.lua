return {
  ["7d47b9799f6b41fd82b61c7e2d1ce42c0bd6dfbb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/apple_logo_bootup.png"
  },
  ["bec3f97e83d41d3544700a0950813a1322d42292"] = {
    assetType = "image",
    destination = 2,
    path = "Images/partner_logo_bootup.png"
  },
  default = {
    assetType = "font",
    destination = 2,
    path = "Fonts/default"
  }
}