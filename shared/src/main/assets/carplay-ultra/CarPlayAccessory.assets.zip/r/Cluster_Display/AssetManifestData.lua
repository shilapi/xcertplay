return {
  ["000d38b9c33e045e19a16a1383e142facf75bdb5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_fr_FR.png"
  },
  ["00178af75c6adda42f0f9360bc75b4925034b888"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_zh_CN.png"
  },
  ["002513c49d9495797561f824e149e78aab3e9909"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_ja_JP.png"
  },
  ["002556a2881386a54476eb4e8aeda35e43fbb167"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_el_GR.png"
  },
  ["003f1c3da00e5657e25c04f8d65d5fb5393c9be3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_pt_PT.png"
  },
  ["00486ec13afe9864b364c537222e5e014903ec49"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_zh_TW.png"
  },
  ["005af2f8751696008418ec7efd29719ca7336daa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_th_TH.png"
  },
  ["00746cbb01da866d2daa0f79c5edb904875067d5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_th_TH.png"
  },
  ["00785b37ad54a2c0bbec7c0a5d9e20825af24de9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_sk_SK.png"
  },
  ["007f3023e558e18740783ef69e028231beae39a8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_id_ID.png"
  },
  ["00a0816602d4e106257bf2ff19864a1733f49e5a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_de_DE.png"
  },
  ["00edf886c48b6aadfc95cee9e69c96db11161ab5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_zh_TW.png"
  },
  ["00f0ff27a5de51f6a96b2851c7f64689e024f357"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_en_GB.png"
  },
  ["010888740eb8dd6c7ebe0456f44d450fd05f5593"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_hu_HU.png"
  },
  ["0111b355cb2d2cc7f92579a3bbd1876dfe162f18"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_no_NO.png"
  },
  ["0121b79b3efd86957733160cf13c9eef6119b9d0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_sr_RS.png"
  },
  ["01326b92e757b5bd374a54a2c96f2f3466e2fad8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_sr_RS.png"
  },
  ["014f3d01b19e9387810aff80f4bf546c580d6fd8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_id_ID.png"
  },
  ["01794671a853254abfd0763ea8db73b2c553d207"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_th_TH.png"
  },
  ["0184f81e9f664dbd305e061e5c4b586f62b8a207"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_ar_AE.png"
  },
  ["01a464f783fe9f7ef545e9387d3c5249d6748f59"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_sk_SK.png"
  },
  ["01eff5504da4ab1a8e4adead1c89d50232aac166"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_fi_FI.png"
  },
  ["024c7b087fb4c8a952ab8c6cad45d7b25094fb96"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_zh_HK.png"
  },
  ["0258135cc4429d33a62fb7001c98b6647d102da5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_th_TH.png"
  },
  ["026772e641fa356f76279f868d436fa5d46800bb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_fi_FI.png"
  },
  ["026822dd400aa0a0293730f21b18f63bf3026e7c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_tr_TR.png"
  },
  ["027a1dbf1ed8ea95667f7cf5c7d85088f1d74d2d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_hr_HR.png"
  },
  ["027c1ca74746ee407c70d4ad25a3e6c5c28a6225"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_sr_RS.png"
  },
  ["02b069664c9bbd35b1f50d299050dccbe1050cb0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_zh_CN.png"
  },
  ["02bf8a6c707b62172ab1e8bcf56f3c4fe8fef7c9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_zh_TW.png"
  },
  ["02ee12292c047655af55e7a325aefe7fbfeb2c4c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_ja_JP.png"
  },
  ["02f4ec7dcd85c9970759575352a0f6607288c219"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_he_IL.png"
  },
  ["02f8de20fb87d31dd0af21e8f7ce98d53d6d85f2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_ru_RU.png"
  },
  ["02fc1988cdcba570b162f7d24dc85e24411bbf1e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_fr_FR.png"
  },
  ["0307dc91e9ec93680f7a6ac8bbfe5159a20aab0b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_ro_RO.png"
  },
  ["031681f2c78980fb83fff65cd13471730deb9505"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_ms_MY.png"
  },
  ["031cfccd28ad927ab365d95dde5dbe89abc8a96a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_zh_CN.png"
  },
  ["032515fd48e1d1cb7e91d198bd21f0021ff64ee2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_ar_AE.png"
  },
  ["033bc5aef1402ab33da1a83be54cbf6f355249ef"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_zh_CN.png"
  },
  ["033bd438fa97c86fab0335d654222d0529146a3d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_ar_AE.png"
  },
  ["0349c91db26f4bf2c2917ea84b85d6ffeebbb37d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_ar_AE.png"
  },
  ["034bb45f816fb25861597e886e3f99e1bfa5971e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_sk_SK.png"
  },
  ["03b9bbba9db4be4c03542cfc74f3f50cf62b3712"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_th_TH.png"
  },
  ["041e802a4693f5aac7681eb052f6241a8afe7658"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_en_GB.png"
  },
  ["0423e73d2ff48198663178b8a033bef7aab57133"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_hr_HR.png"
  },
  ["0426c9403d58df3fedcfb4a366292858ccb37377"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_sl_SI.png"
  },
  ["043368c627453b7f528a63bdb397d5ca8b9ac60e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_ko_KR.png"
  },
  ["0455c7a0313b2cbd9a481571b9b1227f6ee3565b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_nl_NL.png"
  },
  ["0458c8e7354f61bdace0b70bc782bcb783227b4a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_en_GB.png"
  },
  ["047b64616abc10737d653d97e6ee0806ce126105"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_fr_FR.png"
  },
  ["048e9abcb7209f9a67277427b2a3501af0430050"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_es_ES.png"
  },
  ["04962278117adb29c63d51ff83bbba304a739a73"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_uk_UA.png"
  },
  ["04a87b55938f7e790297b765bf4743ccf85eb590"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_bg_BG.png"
  },
  ["04bbb678f053bfa41b2b4350faac3422c3a35eb1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_ro_RO.png"
  },
  ["04f5caae3b5e628110e6c883ba23558e3b7153f8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_fi_FI.png"
  },
  ["051f3abc2447904bdaca6c8bc61e8ea6720beb13"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_bg_BG.png"
  },
  ["05681ef4bbf90f41a1fd842806499d148e7bc46c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_pl_PL.png"
  },
  ["0573d64587f5a557830279d1ad434ace79a9006a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_bg_BG.png"
  },
  ["057ad9b588fb48fddc88c6202411044a4a21cb05"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_sr_RS.png"
  },
  ["057fdff591d1e9191239b056d1c2178e81852a69"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_fi_FI.png"
  },
  ["058f23d81ea97a6eeba801ae28fff882e231f83b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_ja_JP.png"
  },
  ["05a204cc3296aa17c3f004c4bf99d11875310e59"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_ko_KR.png"
  },
  ["05c3ecb0fd6ef98d4d4779f08ced01bb7ca7d473"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_pl_PL.png"
  },
  ["05cb2f7125c76f83457c3d5ac6483f8ac93fd0b3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_el_GR.png"
  },
  ["05d74adf46af8af328b16c2cb4211d0673d7b27f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_ar_AE.png"
  },
  ["05ef7f8fa57e534b7cf9e13ea6a54a89070c5387"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_pt_PT.png"
  },
  ["060eb3b0fb9e2d91f2bbd09dd74412f8efb353a7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_ja_JP.png"
  },
  ["0611b660fe9205f64728f855ae392482b01826ab"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_sr_RS.png"
  },
  ["063c38e95980d5bb2d2a8c8a3aa6baa938aab221"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_da_DK.png"
  },
  ["0659776e1aaf0aa6ff49c9fb762e9b0f8f02b9d1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_sk_SK.png"
  },
  ["066a628ded180984534ecc90355586804fa972f3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_he_IL.png"
  },
  ["067616234306be6a137244e689a7d3c247b8b579"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_ms_MY.png"
  },
  ["068bc6c16c4f6e6c544fcb5c340b13259b8cac49"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_uk_UA.png"
  },
  ["0691df8351768bb6a137ea1e3c138409d7fa7dcc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_id_ID.png"
  },
  ["06b508bf24bf358ae87f424800b7b94ab2281c8c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_tr_TR.png"
  },
  ["06db921578b00b574817e43d25cbe72f44d62227"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_it_IT.png"
  },
  ["06f83e2b80a9e9092ec00b8cf9220eb8daaa6066"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_uk_UA.png"
  },
  ["07362e1f7e9a831551add91c92178911f21b2011"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_pt_BR.png"
  },
  ["075c35955242b2bdde6095ea33de5ed37acf8ec6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_nl_NL.png"
  },
  ["0793eacaa5bbaefb9ae4c3c3f834edc98518dfe2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_ru_RU.png"
  },
  ["079b8b290f16e7a53ee818160d41337393b52277"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_pt_BR.png"
  },
  ["07ab5a9c1225ea0d1a8c0bce176211d7a581a287"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_bg_BG.png"
  },
  ["07d6ca9298084725c11bbee0c03d7a21f3df81cf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_th_TH.png"
  },
  ["07e1d7fda759368d3343fc49d4a98cc6eb91461d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_cs_CZ.png"
  },
  ["085a41b0d3e407df54de98201a3b14f092dfbc69"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_he_IL.png"
  },
  ["0881b216f1b40131a470add45d318716fbe3c1ba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_zh_CN.png"
  },
  ["08aa4328354b9f0cba3e6b3a6a9a511a803af9cd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/track.png"
  },
  ["08ae4ee91bbc213710f4cc9bb4f2b6a983d6730e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_pt_BR.png"
  },
  ["08b16b7ed102210da4c64bbf2348e124d49ff78e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_hr_HR.png"
  },
  ["08c56750d04166a2f20ce1807744fed95b8b3432"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_fr_FR.png"
  },
  ["08c62585d7aca0ee8598d01c4030b34d03a06613"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_ko_KR.png"
  },
  ["08c9995dac375acdb2034d8dad7027141c9d9a25"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_sv_SE.png"
  },
  ["08d6072cb83d7bcf2e1cfaa0cfaf0b6701e68ae7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_no_NO.png"
  },
  ["08d9fc4ab5a163bf429a03b9a6d156b590ae798e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_th_TH.png"
  },
  ["0938990e2c4064715897bd63eca695d97693db64"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_de_DE.png"
  },
  ["094489eae9330050613a0fa9d6610aec67374833"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_ms_MY.png"
  },
  ["0949f24f821dbe0414e6c354f11c00d85604400e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_hu_HU.png"
  },
  ["094a2da90a0566ac1300d224c1e57b959ecfce0b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_de_DE.png"
  },
  ["09539dc987f134cf9b334749428cca7b56c5e64e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_uk_UA.png"
  },
  ["09755e09680baed1c28c0fd0c2d7dc874c7cd01b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_el_GR.png"
  },
  ["0977199787a7fb762146bf06c88c646a71d7faaa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_el_GR.png"
  },
  ["0990f8ce57b4c80cf2c8768aba0ad63d4c8034e8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_fr_FR.png"
  },
  ["09a3b148acb597ab27f889bf0f09371e46daac1c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_fr_FR.png"
  },
  ["09ae538befa478c327d84fe36842736e748c9d0a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_de_DE.png"
  },
  ["09e7d22b74e38fc71d371857f401053eba3b0ef8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_en_US.png"
  },
  ["0a1bc0142759c9e3f5ef181822abf23c06cb5a6e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_it_IT.png"
  },
  ["0a289297480fc12e4ff2f1f408656a7c44d67c8b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_fi_FI.png"
  },
  ["0a37358247b59f46da13d065668e072571852a7e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_he_IL.png"
  },
  ["0a3820bd500e7565d630c38fb9cde20eedc510d9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_pt_PT.png"
  },
  ["0a49907579812fa3cb967df8d0886b198db2a484"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_el_GR.png"
  },
  ["0a58a548eb2c7c56d6b0138a07e45fdc5bbfba7e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_id_ID.png"
  },
  ["0a62e52cde63a586dd35960f6241edce1750539f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_it_IT.png"
  },
  ["0a8bf08144e2150d9facb76a5ffbef238a9de2e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_pt_BR.png"
  },
  ["0aa8633bcedf34cf970ab1d2adb8d1323fa2d5bf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_en_US.png"
  },
  ["0aa877c436ea840b6cf0d73e391add2a807aba7c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_tr_TR.png"
  },
  ["0abb497ce37c157fa538e44b8bc569161287ddba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_de_DE.png"
  },
  ["0ac116cfd61e9d23a1142029044a2ccb811c55eb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_ja_JP.png"
  },
  ["0ac13c527b06be588507d3e4bfd69e3af8a209c1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_sr_RS.png"
  },
  ["0ac1f93cf16e8bf5311bf3b94336df64aa18730d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_ro_RO.png"
  },
  ["0ada8e791df4c709974223ce2f05128c7a7006c5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_no_NO.png"
  },
  ["0afd1a635b3edc8c0a1d3b516d41646507c0adb6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_zh_CN.png"
  },
  ["0b0a71729a1d68991886a74e1d67413c7d0f7cdf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_th_TH.png"
  },
  ["0b1b1af376ff1f4138ba72c69c174a0d5690dcfa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_ar_AE.png"
  },
  ["0b1d69e72511d79781c353fc253231a051836f59"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_tr_TR.png"
  },
  ["0b2632f6c3d97bb28257ea6e633ed1581f72e341"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_th_TH.png"
  },
  ["0b3628ac205efefaa5777c43a2f451537be73559"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_fr_FR.png"
  },
  ["0b3bad839e02004da54335aabd842b138019ff8d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_cs_CZ.png"
  },
  ["0b4444f7018f17fbd4eaa781ac8a1134f9969ed0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_fi_FI.png"
  },
  ["0b9c2307f9b4f8db16341c40c9b3f367a41a8f3a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_th_TH.png"
  },
  ["0bb9882ac1ea92f1f28049fb6897f04a469206ca"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_zh_HK.png"
  },
  ["0bbb432e988841fba995ac3d85a305b210b05475"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_it_IT.png"
  },
  ["0be6786798c1c6f58299be80ee6168eb555557ee"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_hr_HR.png"
  },
  ["0c00bdb2bcb26c447ef69a9f75d8806d58492081"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_fr_FR.png"
  },
  ["0c0d3e05a5ea020a8ea701a77ae54efe9f4b069f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_es_ES.png"
  },
  ["0c2353ed8b73dab3e152d2c1c6935a9109bbdcae"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_uk_UA.png"
  },
  ["0c3eb1b1952271970253e5a7f6f08f033ea6a963"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_zh_HK.png"
  },
  ["0c42b787c504fd773aee09fd91b2555a63f155c0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_zh_TW.png"
  },
  ["0c62318eca5448c7d848433606b60d6de6c3a74e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_it_IT.png"
  },
  ["0c6e3eaa60a8aa3af1241ee2b0c34eb187dc72c7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_uk_UA.png"
  },
  ["0c79ac06827ec7ad44d5fedd2f6fb7d6e6838294"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_el_GR.png"
  },
  ["0c958bb9c7db3a955cac967d8dd930fc0f1141c1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_ms_MY.png"
  },
  ["0ca5b1d23653238b50455caf40c16f6d70ccc347"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_vi_VN.png"
  },
  ["0cb22607a704d2dd2cd2406f65e05a299fcf8ea9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_id_ID.png"
  },
  ["0cc2f574cfc1e004017cf13c49ab42fcfeebf862"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_es_ES.png"
  },
  ["0cd6af4b887e55e193d820db54195ca7403d7394"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_de_DE.png"
  },
  ["0ce9f9390a27c237be3d4c51683e7631dec1063b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_he_IL.png"
  },
  ["0cf361768a271750531486073fc5ac8cd4476ed6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_ro_RO.png"
  },
  ["0d04c713241b0207a9cc324b70d6bb13672f808c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_da_DK.png"
  },
  ["0d29d03e528b66c7081f18d7fb068400638b44ba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_bg_BG.png"
  },
  ["0d342c5de0cd00ba59273e3117923e9b36f91b26"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_fr_FR.png"
  },
  ["0d5165cb98afecee131d62a87c955a00a2786de2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_tr_TR.png"
  },
  ["0d5c8acdeff8b8aace4b158f6875798462ca16f0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_no_NO.png"
  },
  ["0d8327de019411e3b14773faa18b4e72fe452b7d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_fi_FI.png"
  },
  ["0db73b3882d8da85c88abf11ed2772a6045ff65f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_ko_KR.png"
  },
  ["0dbb5de035ea4397f73f9834e8123860dee8ec2e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_bg_BG.png"
  },
  ["0dc864b150a5ef92d8aadb78508dd62f7e2c3616"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_en_GB.png"
  },
  ["0e253ffe39807ad0b345324a70d62885880c0ad8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_uk_UA.png"
  },
  ["0e29d3c7bbf0a3d598b1a00a39451c5c594a31f7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_zh_HK.png"
  },
  ["0e2d40dc8a2d49497d9f32779ae760704046fff0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_ja_JP.png"
  },
  ["0e3b6f42e8955aecfc6d0510e14545cdf543c6f1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_ar_AE.png"
  },
  ["0e6aeb52b0eb617edb319314b9584b795c70889a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_de_DE.png"
  },
  ["0e745cf09d96fd5a920c2fcf0d1cf142e3d4a341"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_bg_BG.png"
  },
  ["0e779670ae08d6ab4ed1207e73c3311d7c230679"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_zh_HK.png"
  },
  ["0e7cd5518f30dd9de4a1d3d9c7b85cd748893077"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_it_IT.png"
  },
  ["0e8aa333be944b758cb151e3d66c9104d1adc29e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_zh_CN.png"
  },
  ["0ec7563b46b6d0d03c16cf50f472710fd06e731a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_tr_TR.png"
  },
  ["0ed00a1037dd2b9de758f577d490621f9cd8985c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_nl_NL.png"
  },
  ["0edbba29c537888d6d9d4c08853728bed696d58f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_sk_SK.png"
  },
  ["0edcbf79bfb5b32709a9508564d00dd9bc60696a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_pt_PT.png"
  },
  ["0efe3ee094a30578ce9502394799ea3ba8b5f1ed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_sl_SI.png"
  },
  ["0eff7839a13b645f9809b0b543ed24510307b423"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_ms_MY.png"
  },
  ["0f00f2321723f3190951b6973415e09cb728ae22"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_hu_HU.png"
  },
  ["0f12f692f125ec50e19c97132d3d9a76dee0cb89"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_bg_BG.png"
  },
  ["0f23a0f57545d551c777e55902a4d170f83d052b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_it_IT.png"
  },
  ["0f29561a10ba229b61874da8f31b04fa6864a177"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_zh_CN.png"
  },
  ["0f6401f0e88f026a87c3bd429e1f7ff0230ba304"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_fi_FI.png"
  },
  ["0f65814c16e357a40cfb6b6c90c3fc0c1c14014b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_zh_CN.png"
  },
  ["0fb44be2f3c34cbd5fdc662161c26ca8aaab18eb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_pt_PT.png"
  },
  ["0fb646bf4d953a67eba721e5e17b50befc58242d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_en_US.png"
  },
  ["0ffc24c0bdb5c02ffdea655ab0414d507cd80278"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_en_GB.png"
  },
  ["1017ddc44a06ce07b008a461f822887f94237acf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_en_GB.png"
  },
  ["10422ef2bf8bf010e6a4050f2f3920fbf1325348"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_fr_FR.png"
  },
  ["106e1a9d10f182446b4acfdbd1c3bfb45640214b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_ro_RO.png"
  },
  ["108a30c0c7c60fe3b0956290a9f63ad1c870634b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_el_GR.png"
  },
  ["108ac0df5f027b2e65a3e9c86c8e7bdc7eddd136"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_hu_HU.png"
  },
  ["108d925bcf8b5d1f8bd7d7dadbffa4ab86d15e91"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_he_IL.png"
  },
  ["1092a57d245c1df9461f1f2d101d4211e9c1724b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_it_IT.png"
  },
  ["109d9bf7a6d1b3a20a18df6f7d975e4de75f7ca2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_fi_FI.png"
  },
  ["10bdc0d7e06122fec7758218ab48431eb537cf23"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_sr_RS.png"
  },
  ["10c639502acc7d214ba89e36483b8fbb3da0bcc0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_pt_BR.png"
  },
  ["10da285f2efbfdbff9f3b5469654ac1725eec195"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_pt_BR.png"
  },
  ["10e9c663099663e696b839ebd9b63abada687b8c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_ar_AE.png"
  },
  ["10ecb911d5f98ce05ebca1d686d47d098e91cd9d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_ro_RO.png"
  },
  ["10ef2ac5d6f5f32126ee0cf8a2d8bff0d31bfba7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_zh_CN.png"
  },
  ["10f67a922d253bf6807b0c707dd048c257a6d663"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_ja_JP.png"
  },
  ["1101c2eb05de73ae674f5690f2b7a14b712dab9a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_vi_VN.png"
  },
  ["110364315bde870708638f7b3ae3a56d7fb95042"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_zh_TW.png"
  },
  ["110c55d4b97b06e8a1dcfd5588490f079b18eebe"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_nl_NL.png"
  },
  ["111a8725e9c5b1fe1b3176ec381f4519c42202c5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_sl_SI.png"
  },
  ["1127235b4fdd2687b8d6101987c1314714552bf6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_bg_BG.png"
  },
  ["113cc8cbc841ba53e316301382ff52e54d46a169"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_hu_HU.png"
  },
  ["113fbb3b7fdad766e98edc23f081003533326c7a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_sv_SE.png"
  },
  ["115022f0f56b4b680d421fab536953e1b7efaa71"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_cs_CZ.png"
  },
  ["1150fb1915f3478ab13da6bb9a3cffe108b4b564"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_ja_JP.png"
  },
  ["1155f547384bebef00bfd02999f2b6a298ebbaaa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_el_GR.png"
  },
  ["1158b46f303cc19e2be01bd3f240d8b073457952"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_cs_CZ.png"
  },
  ["11777168ecad903080b2e63695d75c1a80f83b9d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_en_GB.png"
  },
  ["11a1f6e73dd7f5a0e56f476e6707cb0725978807"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_sv_SE.png"
  },
  ["11a8c3a854153f5d78f763bc9e0e09444e1a80c6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_ja_JP.png"
  },
  ["11afc9f6aff9322fdd2c181a7d4418b9b979aa29"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_ar_AE.png"
  },
  ["11b046387e44c8412fa839a4d70f1ffd2ad38ca4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_sl_SI.png"
  },
  ["11b9dcbb52116206238ad728af42caed786712d9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_ja_JP.png"
  },
  ["11e6f0a741394646fcfbcd8db35e1f23054e4e07"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_pl_PL.png"
  },
  ["11ec16a1b74ac51f4554721a99a923b9f423bc21"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_sv_SE.png"
  },
  ["12137c0e31d3d3deee43261f02876e8cb4c86a3d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_sk_SK.png"
  },
  ["1222b5dd6866e2a192391e359e1c2c7c08f41e12"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_pt_PT.png"
  },
  ["12253d5bc77a92f6d2ae1898c7d43c0c5c24ce66"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_da_DK.png"
  },
  ["122d8392df8dd0f4aca8abaf21950fa261982f90"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_th_TH.png"
  },
  ["12790a0b5ef3849bca206cbe91b78c95f382de8e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_ko_KR.png"
  },
  ["127cbcd7f0cb7a5e6bd99457344a5c3fa07f7230"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_id_ID.png"
  },
  ["128104029f5773c775666669e6afac3fec97c451"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_ar_AE.png"
  },
  ["128b536d1c3cf0a128932db812a465dc2f15ea74"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_ja_JP.png"
  },
  ["1293dc568053adc9fafebc37c9b23b83f97bff54"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_th_TH.png"
  },
  ["12cc1d8af6810d9a77f8020e9c9b92e1574597fc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_zh_TW.png"
  },
  ["12d2b72a7f35fabe506469cb4758b51ba764531a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_ro_RO.png"
  },
  ["12ddf079c77647121a7b729fe7dd9a7ffca5b60f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_ar_AE.png"
  },
  ["130f0fdb2562cf7614b3831b9e1999a9754b3ce5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_he_IL.png"
  },
  ["1314b4f4a8894594464eadf7deea26566b0a5aa7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_ru_RU.png"
  },
  ["132c6640d72986d970bb1ca91017c745d6016e0f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_ko_KR.png"
  },
  ["133dec7ea38ac00893ba39a883473f8acf49c59b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_fr_FR.png"
  },
  ["138ba0480d591203540135e133cbe5b464707d28"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_ar_AE.png"
  },
  ["13fa395ca3a64a6cc7eb143a28493b7247ad232e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_da_DK.png"
  },
  ["13fedfff7e0551b67a585a9ed96487f36cdf031d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_vi_VN.png"
  },
  ["1413a2083666f721e1c735f2dcf40d2ee4183991"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_da_DK.png"
  },
  ["142db8924f212ce6f941511f7368639c537a7866"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_zh_TW.png"
  },
  ["14310e85d7bb06261bc84cfc77e9e8fa1e39540b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_ja_JP.png"
  },
  ["1432bca2aaa11bd432032afdd9148d2efcf12d18"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_pt_PT.png"
  },
  ["1436a5fc3e7b56ee3054c9ca5d6ebae5fb85d2e5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_ms_MY.png"
  },
  ["143743b3155a088526e33ded9569f4741b66fea6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_de_DE.png"
  },
  ["143d716a22a08485b5f2484ecd9c8130a1d5b7a3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_sl_SI.png"
  },
  ["1440d1693e3246efa40d37a892bc07a40e49d1a1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_hu_HU.png"
  },
  ["1446197e3fe9cbe70fe3840c032d7a6547fe8b82"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_vi_VN.png"
  },
  ["14662c02fb2ca250ec93322af416d93749edc7f0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_es_ES.png"
  },
  ["1466e96c56c00b822a7c1689be2a5b6337f636e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_ru_RU.png"
  },
  ["1471bdb492b34dcf2bf446eae53d6487f625b075"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_ms_MY.png"
  },
  ["147913a6c210648be6871322d10718ecb9e6d005"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_ar_AE.png"
  },
  ["147db15375f948cc30214b7f5dd6f54cacad3a02"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_ro_RO.png"
  },
  ["1498e6acf7c6b16ce0b874dfd2fd4672406503e8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_bg_BG.png"
  },
  ["14c37497374fef0520ef463fed8c575d8f1960f9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_zh_TW.png"
  },
  ["14c40a59494e59a67f67ce447194976e60f03ba9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_he_IL.png"
  },
  ["14e988e875ecdfe0d84d0ecff77bccdddd9f21a2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_zh_TW.png"
  },
  ["15128dae67a61eee1a69f6af50a125de625a0285"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_tr_TR.png"
  },
  ["15311011dc8cbccdd82f3380308f3fb9d708d986"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_uk_UA.png"
  },
  ["15344f9f578b30cbf14c1dd12b9893cae0415e6a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_nl_NL.png"
  },
  ["153b319e414763cac3011a95da18f3bce7744c7f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_el_GR.png"
  },
  ["153fbc03d6758cad2ddb57ebf61036b9dfef9591"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_no_NO.png"
  },
  ["1546b63775fc87dbc9a9b9c40a18f14ce88a578b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_en_GB.png"
  },
  ["154f15ccc185e863578815602b13c10f4cb5d602"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_en_US.png"
  },
  ["1574309ac7a975bcd9853593be898a64ce3a9342"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_es_ES.png"
  },
  ["15e20c33715b5383bf4e8582a24783064ad33179"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_pt_BR.png"
  },
  ["15e72646c282ef11e265e65b6436ca44ea1efebb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_ko_KR.png"
  },
  ["1607439b34acee4a04df74f6bb695c0d6661735d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_tr_TR.png"
  },
  ["160c21b533ac4eb53dced7d848a64121cfe25ac0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_hr_HR.png"
  },
  ["160cdf4c82c3a389f2a2f26870088b41534f648b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_ru_RU.png"
  },
  ["16233dab90f975e564008167eabd2bb7b4175044"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_ru_RU.png"
  },
  ["1637e267100326982125fa4d6cd552175d8d4289"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_sl_SI.png"
  },
  ["163b67f5004a347b890fb0c3597dd4baad1bcee2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_fi_FI.png"
  },
  ["164b118dc82ce8e1ed49bb6a4f93ba7df1f321b8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_pt_PT.png"
  },
  ["16672c63e955749a34f71b8b212a368a3e9cab03"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_sk_SK.png"
  },
  ["166897f5214c49a133c67254e734a745727cea31"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_hu_HU.png"
  },
  ["1678455ec714634fe349b326393c17e8dc8bd8b8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_fi_FI.png"
  },
  ["1686e5037a265efc6e391273d42f8857477daa16"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_da_DK.png"
  },
  ["169ca50ca492dd3d45a7cd996e89d25285049d38"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_th_TH.png"
  },
  ["16ab2f9358e75acfbfff7211ec2d67129c2ae40e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_it_IT.png"
  },
  ["16adc6d78a2270c5826a5644865c19488a6cf2b9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_ro_RO.png"
  },
  ["16bdef2e6219ff2b13298bf737b3935a721eee97"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_pt_PT.png"
  },
  ["16e964a78d4e06f365aad6b240d8dcd78538acaf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_id_ID.png"
  },
  ["16fe2fd89191bbd083b47577c80e8466ed6d7f5f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_sr_RS.png"
  },
  ["1703b46d1de8813af6963e351669ddc05b9da66a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_hr_HR.png"
  },
  ["170fb0753654a0cb9055fb262304d19ec6a67b81"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_pl_PL.png"
  },
  ["1714f7f3c4d39c60a49e968402445fd32cc56b3c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_ko_KR.png"
  },
  ["174170edb7f2c286d96582ad3644a8f8fd1f0531"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_vi_VN.png"
  },
  ["174a9747de76eab93e152cd703c7ab79d4b641f7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_ar_AE.png"
  },
  ["1756d61ee524b434a28293cda2d69a804e83cd29"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_es_ES.png"
  },
  ["1766eba899980935e339c5d47197643da7c177a0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_sv_SE.png"
  },
  ["17767e5c6220804ff19e144a650ac4b63f0e8030"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_zh_CN.png"
  },
  ["178d2e55ea219b4e480df00a410c4e6ffe26249c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_nl_NL.png"
  },
  ["178d76f31f894df5e6cd46ac5608eb5ee10aa07e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_en_GB.png"
  },
  ["17e78c3c3caa2ded3ffa2b5f610882704adf95f2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_sr_RS.png"
  },
  ["17f6c11c671c78f5aa37cff90e477b8bb754870e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_uk_UA.png"
  },
  ["1814618e7f3d71ce25825e6c39d50929a7457eee"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_zh_CN.png"
  },
  ["18152552e46a53773c73a39178e3b86604c6a6ee"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_sr_RS.png"
  },
  ["18173418919e9b5afedb8b078b41244e007b8368"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_cs_CZ.png"
  },
  ["182eef67401cde241bee5cbec677d0d14d0e85d5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/partner_logo.png"
  },
  ["184fc3d54dfa552cc70357c701a705f59bb82b46"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_en_US.png"
  },
  ["187282ac7dca146952ff66b8c9c96c1319008e35"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_hu_HU.png"
  },
  ["188335f3c1117dc26edc85d6cb76e2896d0eef3b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_ms_MY.png"
  },
  ["18876b38b72d81ff8d8016725e047b42f366c55d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_ru_RU.png"
  },
  ["18884ab364cb75c446671874ddb4d10442b930bb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_sk_SK.png"
  },
  ["18a0abc9e5eb047a6c66cf0c1a6e5334d82d98c7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_sk_SK.png"
  },
  ["18c15502e57ab6de72909c387e1fb91643e0935b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_de_DE.png"
  },
  ["18ec0423bf0139cc1b2cf49d19c14c9448fa64a8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_tr_TR.png"
  },
  ["18f09cce669ce24acf732a51fd5482f518513c01"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_ko_KR.png"
  },
  ["18f9666aa59e046501fcd75ac336368eb9209db4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_ar_AE.png"
  },
  ["18ff325d9aa42da00bc255dc06c1d2da5804327b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_fr_FR.png"
  },
  ["190a996fac404223e7601d485afad8e3c614140f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_sv_SE.png"
  },
  ["1921bab84e32f063fc25f95ace04f61c9ffe872d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_sl_SI.png"
  },
  ["192e9812bce48979ae20993eec61f5aa703517a2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_hu_HU.png"
  },
  ["19626db384e1c0cb50444c528aa675397057e96d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_sk_SK.png"
  },
  ["1984658cc5c20f8574c8104459550b5f428cc8d3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_tr_TR.png"
  },
  ["199e8e69b9b85b105e6055317458dccc20f8ee9e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_it_IT.png"
  },
  ["19a094cb551e1259ad1a4195dbfed6b0d7402dbe"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_he_IL.png"
  },
  ["19a73b349db59f7cbc911d0894e0b54ea535de28"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_en_GB.png"
  },
  ["19a90248ca716ce4f136b2f2b712e8bf0df18658"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_hr_HR.png"
  },
  ["19ba96f347e205c58157c3f7c657d23e0eac9279"] = {
    assetType = "image",
    destination = 2,
    path = "Images/speedometerOrnamentalKMH.png"
  },
  ["19c59b19c8299d2efaf31c91db3cd60351e01f50"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_it_IT.png"
  },
  ["19f2501f9c483f4e11f30e90f9b7c67642259828"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_cs_CZ.png"
  },
  ["1a1255cc7cdd4baaae6e6fc8486f9661e5493eac"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_pl_PL.png"
  },
  ["1a449acf8adcb7f5c195a6cd79a30e6c1c3581bf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_sv_SE.png"
  },
  ["1a4fc39aadc15fa8de2369a03495300fa1f2080e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_nl_NL.png"
  },
  ["1a8e97af74b93fc90b76e41cf86c5a5db6910ac4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_sl_SI.png"
  },
  ["1aa484280eadc226fd29eab7f98f7cc0f82f405a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_zh_HK.png"
  },
  ["1aa5c05476711979c38cb4b4f34edd39fbc727c7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_es_ES.png"
  },
  ["1ab82e1319c34fcb5d8bfc4ce749b5472c379f31"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_bg_BG.png"
  },
  ["1ac647d7f2daaa5b63b6a93924606f342970aaa1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_de_DE.png"
  },
  ["1ad3ede2ccb7c45e8370f271e7503343ab48ec67"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_cs_CZ.png"
  },
  ["1b4b341bfeb0a12a8f6509974ce3610568bc5c09"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_cs_CZ.png"
  },
  ["1b515df56093f645da68fbaab73f7d7068f7af59"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_id_ID.png"
  },
  ["1b5570c52753538d724ed0b89c17b9b4fd07f4e6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_en_US.png"
  },
  ["1b67c644494683f560ef0c9a56f002db6079d73f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_he_IL.png"
  },
  ["1b92eaad5fa0da87f5e873a5a467c8d57bae11a9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_da_DK.png"
  },
  ["1b957af0d7125973ca80bd8a854845bef8a775a5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_ro_RO.png"
  },
  ["1b9e7015f1bcd0ef0630f78da92360597b2f1d6f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_he_IL.png"
  },
  ["1bb51053bba3b37a1074e3f1b2a9e3f5c97f5968"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_no_NO.png"
  },
  ["1bbd25fca62a2a61f2b17920c8664f1122509c48"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_ms_MY.png"
  },
  ["1bfdffbc58c89430115af6209603d0623027b9ab"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_ro_RO.png"
  },
  ["1c1f60ae1bed994587157d7ae9d245edea6512e7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_en_US.png"
  },
  ["1c21bde75e34d5d3abc8813038c9baf0374bc32b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_tr_TR.png"
  },
  ["1c255bafa2c4c2d51e20a7c581f98bcd61e4494c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_ru_RU.png"
  },
  ["1c387e2cc9f69007100b324d79942b3b9d0dc623"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_ro_RO.png"
  },
  ["1c4a166874bc5f84bb6b89a3ac980762cf2f9154"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_pt_PT.png"
  },
  ["1c5db57720153661080ab9f3e4bb7676a419aff5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_sl_SI.png"
  },
  ["1c63ef2f527522c6d819c98639b3bb6dcd01cd06"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_he_IL.png"
  },
  ["1c7bb15ee3da306a90acf96b516ec844152598b9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_fr_FR.png"
  },
  ["1c9d4e20a046cd3a4e6b4519e2dd5e92ff0a4104"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_bg_BG.png"
  },
  ["1ca33ab99ad016c7cee2240986ee98ca559e228a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_ja_JP.png"
  },
  ["1cb619d3138079a43d52e4421dabf306ebf7d166"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_en_GB.png"
  },
  ["1cbad440119ad26c4ce94d9527d8a12585c66301"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_id_ID.png"
  },
  ["1cbc6832d4cfd50491ed5c581bcf9db83e42fe3b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_en_GB.png"
  },
  ["1cddbac38baa319a8540c0088a39529421946832"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_zh_TW.png"
  },
  ["1ce5cb90e24dceadf63621d3e268ff3b112d5197"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_ar_AE.png"
  },
  ["1cec214aabf51dde4cefa225f6b0294aabc3f27b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_ko_KR.png"
  },
  ["1cec24519d828ae96ce08db8aae9222a27219f15"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_hr_HR.png"
  },
  ["1cf4401e6a4704393863eb76ce3cddb4d83bfe8d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_de_DE.png"
  },
  ["1d15eca604ffdd960a249e207a32d86424139a43"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_es_ES.png"
  },
  ["1d2dbb39dadb9ca900cf236fa41d3393f5c666b9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_pt_PT.png"
  },
  ["1d3c33fe1c26c3487c0f03f6fb7f1cb3a4b3821b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_id_ID.png"
  },
  ["1d495374be0befc8e5286ef8b653409c14ec1e0d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_en_GB.png"
  },
  ["1d6aa00fd344455fdaaed412723cc8f239430d71"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_it_IT.png"
  },
  ["1d6b9309481b4de59dc01ab8a29c658a08e6d4f0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_ja_JP.png"
  },
  ["1d6d24831a25ee6a600c909ba5ae97077363fc98"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_zh_HK.png"
  },
  ["1d7353f92da15c132f320d1d5b3a4aa5d5e334be"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_de_DE.png"
  },
  ["1d799880f44a3c6491caaad02eb8b2cdcebe25d0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_pt_PT.png"
  },
  ["1d7c2425d946e4a55841db1b24a5c6f54e1b2446"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_fr_FR.png"
  },
  ["1d97d19bf9188cd9d42711b38269ba85682573da"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_pt_PT.png"
  },
  ["1da009d245eea1a61e3c7cb2e6c7fca9a1d426b2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_ru_RU.png"
  },
  ["1ddc8d1e69ed011f25f902b7bd56a471ea036eee"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_sr_RS.png"
  },
  ["1ddcbe997182b4040709162b7f021ead40cb1c34"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_ja_JP.png"
  },
  ["1ddd111a07c6808b41de211e2bf2db9ffc5e65b2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_sl_SI.png"
  },
  ["1de34a8d13d55c1a62a8a1076afe508c0a9765e0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_de_DE.png"
  },
  ["1de7bac39ca71a6754b1a0ecaee00f0bd6cdbfd2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_nl_NL.png"
  },
  ["1de98109390c32f714cdc4a0e02e1cde5243391e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_zh_CN.png"
  },
  ["1e04d83be5518804349805734a2bfaac65431ee2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_zh_TW.png"
  },
  ["1e0c86950272e92c64630d625fdee2e5bc973520"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_he_IL.png"
  },
  ["1e11ae3b63feae6af5f3480a2a43eb79e481ec3d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_sv_SE.png"
  },
  ["1e2bc337fbbd9ae61a4d5e53ac93c38083c8e8b7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_bg_BG.png"
  },
  ["1e411fa6da1c46dbbec55f22862b586897f027b2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_zh_TW.png"
  },
  ["1e4af5e7a1bb5d02c8f892536f1dc009c75ac693"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_zh_HK.png"
  },
  ["1e804fe6b894bb89a9e3477086496833d11469ed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_bg_BG.png"
  },
  ["1e9a3aeb0cb3de7563e1520f03efc249e6303097"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_en_GB.png"
  },
  ["1ea1937db19b7a3f3dff0770bf6c3f363937503c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_no_NO.png"
  },
  ["1eb2271b9e6fd6a4ea5ef7a8f026e41a8a48bb31"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_de_DE.png"
  },
  ["1ebd17613191eb407145448632423dfd547fca4f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_sr_RS.png"
  },
  ["1f0ca4832fc7f6dcd7d6c21e7b13a4c9e6cf85b9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_it_IT.png"
  },
  ["1f3617fadff6c837791ac56d086956ad4163b46f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_cs_CZ.png"
  },
  ["1f84edf5dcbe8a1d152650771c988f8ddb6cd8c1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_zh_CN.png"
  },
  ["1fb5ad0d3f8880aaeb8a3ee7b5b834d34eff355b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_hr_HR.png"
  },
  ["1fbf1762c9792e99a9365f9df26e186288896d1c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_ko_KR.png"
  },
  ["1fc2e6962bd3da835320b5ab62315f1f18cd4d04"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_sv_SE.png"
  },
  ["1fc2e721eb9236622e688419f1b89f3e75ba8e03"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_zh_CN.png"
  },
  ["1fc69009215f4d267e736cf0bd70ebaf046280f6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_fr_FR.png"
  },
  ["1fd62b1b7df7b9cdfe463f9f752875e6456dd895"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_bg_BG.png"
  },
  ["1fd8afea3d4e348b3c88bc9e422300e2809d8c98"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_pl_PL.png"
  },
  ["1fdb5bb3193360a52aabf0b7bd57d2f39aeea12c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_ar_AE.png"
  },
  ["1feeae76474b03d9a02e843c6e9913c16790924f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_he_IL.png"
  },
  ["200483360537717e7a2338880291f7379d849fe6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_da_DK.png"
  },
  ["201b169fa6dda2498b0e622bec53028d24f0fcb8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_zh_HK.png"
  },
  ["203a703895b0ef46327bd5e89ff15d3bb69b416b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_en_US.png"
  },
  ["204855431d94fafcc7b9c703d26c3a3a582e76c8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_en_GB.png"
  },
  ["2072818eaa54134c231b8a9b48dc806b186acd32"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_es_ES.png"
  },
  ["208488d48e05a229603de1405d3105ecc53bf8c0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_it_IT.png"
  },
  ["20922e781e322c4eed71ea6f2b75255c62c8b714"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_ms_MY.png"
  },
  ["2092affb5aad3ffefbce5a000f63932a311d0e31"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_ro_RO.png"
  },
  ["2093e9bd207bedb5b998cc7ea9c9f60d5cdeb59d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_zh_CN.png"
  },
  ["209719ad2650853a38aaa1856945260114fdd2e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_zh_TW.png"
  },
  ["20b0fdad7ff0dd2c85007cdaa37d3b607a912a7b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_de_DE.png"
  },
  ["20e940e366ee8785e0629b9f2e7831a9421b7188"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_ro_RO.png"
  },
  ["20eefc159f0bfc4bda65e43d8ba83551be7d9bd5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_ar_AE.png"
  },
  ["20f1b4d4eb76532cecd318c464336e180e95fb1a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_es_ES.png"
  },
  ["20f3a33f4488be489e8b28f35c72b7b6a70191fd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_sl_SI.png"
  },
  ["210418fc8f0e8f3fa5c3af342ba1399439a844c5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_tr_TR.png"
  },
  ["211ca74e1c8ae46a627ceea51395629a4b14c707"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_no_NO.png"
  },
  ["2171c07415107041475ca8aa700898e5aa61e31a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_fr_FR.png"
  },
  ["21a26c3778cbad4c48bc5d1118edd6dc53f4e860"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_da_DK.png"
  },
  ["21a37f5ed71cfd3ca086f3a25b50eee927d1215b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_zh_TW.png"
  },
  ["21b8ae84266e1124e34e7999785b73483f5ba5d3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_he_IL.png"
  },
  ["21eb18dd19aa77cd67365d9d55940c2b8a3930d5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_ru_RU.png"
  },
  ["21ed326c49c54ec422355be8cd7c9d0daca76291"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_fi_FI.png"
  },
  ["21fad45654f4aa1868ce0c4d910ac4236f6775fc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_sr_RS.png"
  },
  ["221cecce0297260c7d0884c70474156b315bb6a0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_sv_SE.png"
  },
  ["222d887471ddb07fc4518ec0f966a6950632feac"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_ja_JP.png"
  },
  ["2238a172ec24d372c9b4178b455a3a618c54ef7f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_bg_BG.png"
  },
  ["223f370657e461670c7cf5bee634edc65ca5d0bf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_ko_KR.png"
  },
  ["227d4bb647fb179f3445cac6b8bfc906dcfc0e40"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_sr_RS.png"
  },
  ["227e3311d7fcf3f74a3fb3122ca820e15f2978ee"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_ms_MY.png"
  },
  ["228769ba0e99e7eb5b2f4a84bf47c10b9d4d8e53"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_zh_CN.png"
  },
  ["228f61c1901c3bfbbac93c15f4af1b2bd5fdc22f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_he_IL.png"
  },
  ["22ce161f852878150036d0f1410c2857f3842ae8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_vi_VN.png"
  },
  ["22df30ade460369723ea194f7b10023577ef7d8e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_zh_HK.png"
  },
  ["22f340e6b5aa2a934547287787eaf0185ace5e53"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_vi_VN.png"
  },
  ["230114cd2709ff0cc04aef20597eb2614da5c0d4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_id_ID.png"
  },
  ["2311edc2e5edfd2818b96426fe05a83dc0544456"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_ro_RO.png"
  },
  ["2316566fa17dfb3666b2fb0a01452160209b4c58"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_ar_AE.png"
  },
  ["232f210d7694e47e7cfe5c2b341292a3304acbfc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/Shadow_Top_Right_Corner.png"
  },
  ["233f691292d0a65e405b88915cf46041c1c4f7c0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_es_ES.png"
  },
  ["237979e20dc5ca0aaa597d2dd653580d7512627b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_zh_CN.png"
  },
  ["237c1ca47ad642e11874c3d8902abb398622969a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_ro_RO.png"
  },
  ["23b4f6210ca1891faba1610d948948729a5f43bc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_ja_JP.png"
  },
  ["23c59c62675ed137b4ec22806760ee9712a162b4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_ar_AE.png"
  },
  ["23db0d025a9fdcff35777bacafbd6036c0981e0d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_ko_KR.png"
  },
  ["2438ea1e2b53f5bfba7b3fe7d3c5bf12f3478211"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_bg_BG.png"
  },
  ["243a9f88b42542fbaad90b7791318d5f5b66a0c1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_ko_KR.png"
  },
  ["245aab2fcefef90641fee2f6b29004ef23f40d2b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_vi_VN.png"
  },
  ["2479c1664323371c17d7996809bd6393a006ee8d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_vi_VN.png"
  },
  ["2485a1c65a6bf753893f32a26406c4a2c54787da"] = {
    assetType = "image",
    destination = 2,
    path = "Images/GT.png"
  },
  ["2490e817f19f53eee62526b37b8ded04e174d0b4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_ru_RU.png"
  },
  ["24aaf3b9238a9ab65b31dc9d9650dcd3ce15db46"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_el_GR.png"
  },
  ["24b82d3bd97c38966539f5bc8fa4370e6bff74ae"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_bg_BG.png"
  },
  ["24b98406c409c4f3ce462c3ebfb841b7b83cbb56"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_en_GB.png"
  },
  ["250e8af20d1074a8ca6e41b6f8ac09c45f56a727"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_fi_FI.png"
  },
  ["252138bd3801301594423ccab8d796517a458b1c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_sl_SI.png"
  },
  ["2522f7a5e3426840af07b524a628fef289093250"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_ru_RU.png"
  },
  ["256525b62a4f9c22b53c5f00f46c2412fac75c5f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_ko_KR.png"
  },
  ["256a203f22b8f9b614dab699a366e163ae8d30a2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_ja_JP.png"
  },
  ["257191f061cf46000ce4a6e4e6b9f6fd99387a7a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_pt_PT.png"
  },
  ["2590494c004c39164c0722745144bd6491eb556c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_zh_TW.png"
  },
  ["259ff34b9a74af7292143ec74eb12a04bedd85f2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_vi_VN.png"
  },
  ["25c36be001ec514156d251e759e78a5686a7fbcf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_en_GB.png"
  },
  ["25ebf5adad0d27b666d663a6f884928f1d84b631"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_bg_BG.png"
  },
  ["2629e90140398646670a6affe15bf6133ee127b4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_sk_SK.png"
  },
  ["263bcce7a38c4c7503e52681c58fc6385fd79df2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_pt_PT.png"
  },
  ["2645492e2e49fb4b43ce8e3cf8c885f258d77e45"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_pt_PT.png"
  },
  ["2646a64ddece94a166395559b2880306e9107c8b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_zh_TW.png"
  },
  ["26489de64798dd07b7cb0be97d845a66c06d37ba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_sr_RS.png"
  },
  ["264a25f47dfb6076416122134707862a65e2736c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_id_ID.png"
  },
  ["267883d301a2bc41a4f729fcbf3d8af53eafa92f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_vi_VN.png"
  },
  ["268ac06b38effee927197005795968693d36c7df"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_de_DE.png"
  },
  ["26a48b43dc17bd3d574d0c6c5bd76bafe09b16e0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_fr_FR.png"
  },
  ["26a4e55b27085448107f7ca4c98eb553da5c88f2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_it_IT.png"
  },
  ["26b53ad204aff06b00fa4988a956fd108a83687c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/decorative_speedometer_kmh.png"
  },
  ["26efb881ce0f1450189852ce8d8532b5d4809e2f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_da_DK.png"
  },
  ["2704983c6616feaba48f08783b9af374305e8f24"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_pt_BR.png"
  },
  ["27178717059ddd5af39ce7d4032e6e35e1446d6b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_sr_RS.png"
  },
  ["2728f3bae4b246e467eeebad787a79845218c398"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_en_US.png"
  },
  ["274aaab70b1520d0fcdae2b630ef70452358f797"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_sk_SK.png"
  },
  ["274c6868cfd60017fedeae508937127087488f23"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_fi_FI.png"
  },
  ["2755b9968e77d26678cbb6a550c4b12464d9446c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_no_NO.png"
  },
  ["27687f58b4dc1d5d74c2d160ef5ccb9a2abdc17e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_en_US.png"
  },
  ["2774bdd6bcca66052d3f5f72897fe985dd70113b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_es_ES.png"
  },
  ["2779ad92d585b5afc1495b85a6e681c51332012f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_vi_VN.png"
  },
  ["27849038563c009c5f50d40bfba391871b56c2bb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_zh_HK.png"
  },
  ["27a0708b03b71eabb20d4df3cfcd685dc0fe604e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_en_US.png"
  },
  ["27a4c827f468af78b32860267cf94c99330bca7c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_el_GR.png"
  },
  ["27ac5e727c232a1022c7f368208fb6a39acf3343"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_uk_UA.png"
  },
  ["27dedb4684d18487147e17d2fe49d05ca0655485"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_he_IL.png"
  },
  ["28627072afce6ad2263ff8d61c9a0586837bd24c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_hu_HU.png"
  },
  ["28749fdac606aa7fe71e9ad7747d83d915be7443"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_it_IT.png"
  },
  ["2889bc599a4a29e9e457162abdbe0fd9034a7073"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_id_ID.png"
  },
  ["28944676c91fa72b3d5690b53eaf5a0e168be1df"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_ja_JP.png"
  },
  ["2899d52be6323652b525aac41ff36c9d0d583110"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_uk_UA.png"
  },
  ["28a27a2cf5cbf12a16eb8465c8bfc287caf0ac0c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_en_GB.png"
  },
  ["28b94bd9c135221fabce88725de7ebbe1ef13058"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_pl_PL.png"
  },
  ["28cb7f76e9605ffc909fa14e64262c59de2a69c9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_ro_RO.png"
  },
  ["28d1a103ad3cc349abdf96da9cc1644c6e320f77"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_sr_RS.png"
  },
  ["28d7cb75bbb39971d51fd5c14f12b762457bee8d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_fr_FR.png"
  },
  ["28f6203b8a5e9cc7dfa45b80d31a597f2cf0dc70"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_el_GR.png"
  },
  ["28fd81e01920c7f6044957951fcc4ebeb03d4504"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_zh_HK.png"
  },
  ["29021f5d7440ba352de074619f7df6396861474b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_vi_VN.png"
  },
  ["2905877f23e9d59aaf4b86087ed7a6718d461c9d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_nl_NL.png"
  },
  ["292e1d4384b61256344defa81e8a3cbbbc87eb74"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_en_US.png"
  },
  ["293ba2df1d9daa76440e09ae4251871cd9d21fa6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_da_DK.png"
  },
  ["29415d7ae8a5044bd737f13f08e43f24352683b4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_pt_BR.png"
  },
  ["2966232da0ecc3ad6742b0f277532f4461e1fb06"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_sl_SI.png"
  },
  ["29747ae8b01d4b9f8d82e7130b0349e1404df0ac"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_sk_SK.png"
  },
  ["29775e984f111d0ab99dc29efe54c6d845873c4d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_pt_BR.png"
  },
  ["29814f9a9f0cbcfb25e1690fe1bb55ec6be1bcd4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_sl_SI.png"
  },
  ["29950a73a4fa2cf211fe533f3c187925cc0136f5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_uk_UA.png"
  },
  ["29e3333d888e1cecf29af7ac9f4b162dee96ff5b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_nl_NL.png"
  },
  ["29e6242b52969c67167b339b62b7ab02b7eca676"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_hr_HR.png"
  },
  ["29fb2e2b74ad07baf0ec94cc824257eea447b01b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_ru_RU.png"
  },
  ["29fefc268c316e687c78fa4eafffea221abd1725"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_da_DK.png"
  },
  ["2a075bc36e9d8ffcd1c6500bbda1dfd8cffeb94b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_ms_MY.png"
  },
  ["2a2029326725b56b13ea63e4281f08bd3cc4e66f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_no_NO.png"
  },
  ["2a230e92114e17fa5ef71e9185a0dd89a13835ac"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_zh_TW.png"
  },
  ["2a23153ca465be74bc12ad80bc9f96dcd6871046"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_ms_MY.png"
  },
  ["2a9742162f9eec03a1ad3d90143668e7b7711c10"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_no_NO.png"
  },
  ["2a9826fbc14e009a56d29bd3a029696a75c3d8c3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_hu_HU.png"
  },
  ["2ab6aac6405cd20422fb1921c8ab0efb1a3eb253"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_no_NO.png"
  },
  ["2ad0fea2d8e6e3f7fede7d77b6beb563a472987c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_de_DE.png"
  },
  ["2adb7e356cea4852602fe517526762090ec4f018"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_no_NO.png"
  },
  ["2ae0594f95ec30adc50efbf0eb3d3620dee97b39"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_es_ES.png"
  },
  ["2ae987dd50631ebc2ed757ac145611f9b82e8c51"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_pt_BR.png"
  },
  ["2b23a7db897ccbef898d66931af68bd722323f2e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_es_ES.png"
  },
  ["2b456bbe06e4e53f7b20334797ff1df3aa5f0f5d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_th_TH.png"
  },
  ["2b522d0617ef88cf9be0b90615bdd4002d013909"] = {
    assetType = "image",
    destination = 2,
    path = "Images/fuelpump.arrowtriangle.left.fill_body.small.png"
  },
  ["2b5399dbbd4126aefa1d775bc4799f7e3dede73f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_zh_TW.png"
  },
  ["2b847025b689b93956011c51e596052d0466d32f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_sl_SI.png"
  },
  ["2b9271e062a7cde2c0de4588021b7450d091d9b4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_hr_HR.png"
  },
  ["2b9480a51c858796ceb6fb3d7db1f634c43e07b1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_fr_FR.png"
  },
  ["2bd3aaf9ce418a4eb61be0945e1bd9779cf4b2e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_uk_UA.png"
  },
  ["2be584269774d891808e2a4a59a96cecf0d10e4a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_ro_RO.png"
  },
  ["2bff19a98a877cf8c1c20619babc0b0d7f121ed9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_zh_HK.png"
  },
  ["2c32d14bf97f8343581d4fea9ad3fc558f019c29"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_nl_NL.png"
  },
  ["2c359fb044fb8b9fc053f01200fe648b42dfa925"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_tr_TR.png"
  },
  ["2c3b0a846d3b01eeee58d24c7229e273b3123e90"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_cs_CZ.png"
  },
  ["2c3fbc172061fc6425090612d0a548c7a12f059d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_bg_BG.png"
  },
  ["2c69b5851e9f9f9f0bae2c139735c3bc54faeb44"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_pt_PT.png"
  },
  ["2c81d161c9d3a1fe4361e9cd07ad6256864dc3a8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_sv_SE.png"
  },
  ["2c9f25eda9d5c944f591f2996223dbcc3621172e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_da_DK.png"
  },
  ["2cbb6bd2591125abcb7dd9012513caca587e093f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_sv_SE.png"
  },
  ["2cc6b305e53ce4df82fb0f1775c5676b79c8df5c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_ko_KR.png"
  },
  ["2ce200078d9114366b4f69dc5d3f66a1c1db1205"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_da_DK.png"
  },
  ["2ceee1594ef9d3fe349d1882e115fc40c8297763"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_sv_SE.png"
  },
  ["2d0347caca030b78b5d5d20fdeb5cc2646495a7f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_id_ID.png"
  },
  ["2d2d01d4c0c29b673de9430bcbb94073a6770262"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_pt_PT.png"
  },
  ["2d314573a73fd81526f787d44647f2ff4f6e27b0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_ja_JP.png"
  },
  ["2d955636a094c1a266e137486ca827d32eb6081e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_el_GR.png"
  },
  ["2da44e00b9271b752a842d086b2f7d67d017c86c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_el_GR.png"
  },
  ["2daeec131e1eb486f1780585c4d95411cf5a83d8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_pl_PL.png"
  },
  ["2db6bd37301c0be5670de1c98b15aef82e992d04"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_en_GB.png"
  },
  ["2dd9c0f082a942b0ff18637b1a36327c704ff493"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_ar_AE.png"
  },
  ["2ddd5c0e17612c11ef704800cdb6fb8203230d97"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_da_DK.png"
  },
  ["2ded3a47d9939f15087b504b7360dc593fb37c33"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_sl_SI.png"
  },
  ["2dee0bd64d916caa7f6c0e592bbb959113112eb6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_ar_AE.png"
  },
  ["2df0e6aadd76477baa5e6e58d88e4c753a4d0aa4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_fr_FR.png"
  },
  ["2df6eea7ea0483f137bb6fc6982b046c0bdfc50b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_he_IL.png"
  },
  ["2dfc4775e0a1aab993ec0ce3039edd3b7a712f24"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_uk_UA.png"
  },
  ["2e024f256bcbd652d34fad82e56b39de71fb5c6f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_sk_SK.png"
  },
  ["2e13a049f90103325488d5dd9a82d72d9ddb27f5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_fr_FR.png"
  },
  ["2e261cd4eefd3fabe9606287f8bcc616bcfe60c4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_ar_AE.png"
  },
  ["2e2781abffa8212a83f2202f01de7a959e25830f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_no_NO.png"
  },
  ["2e64bdd7c9d570c4063caa3cf593e68243fe2637"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_pl_PL.png"
  },
  ["2e6636b521c49dcada89a7b4af00e39733debd90"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_bg_BG.png"
  },
  ["2e73d1e627ba68d7ff4fd0d76820a9fbd3ac90df"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_vi_VN.png"
  },
  ["2e82560600a4f71456d8188953826a89bb4d2f73"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_cs_CZ.png"
  },
  ["2e90545b3d309c78db484f8932b2530cd4d6ccbf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_ru_RU.png"
  },
  ["2ecff766083d2732b92a4ce29760fff8571eba57"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_ja_JP.png"
  },
  ["2ee8b88b82d31a2e9bca87a80c9e8399724df808"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_el_GR.png"
  },
  ["2f0133607cc479e777b0abd738b72cad27ca5e61"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_nl_NL.png"
  },
  ["2f243cebd7ec6064a6f0a89f1c06e43e9f16f085"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_hu_HU.png"
  },
  ["2f27be2aab811adbaf3b14e70edc4de9e5b016a4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_de_DE.png"
  },
  ["2f38f16f36bcc1287d230559ea96538681f2a8d0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_it_IT.png"
  },
  ["2f3f62b5587aeccf1877a2caa61f3db6772514d6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_uk_UA.png"
  },
  ["2f90602d09be494b85c2d8846503081d98c3f449"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_id_ID.png"
  },
  ["2f9734329444a3a7eae8f2bce0b4e26bdc04a016"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_sv_SE.png"
  },
  ["2fc8d5f4d07ba3012d27d7ffdde378a3e18e3315"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_ko_KR.png"
  },
  ["2fdfe383521bbdfa7c9b2526ea04034c9e23c4c8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_zh_HK.png"
  },
  ["2fe8332f113ada493735da23769a080696b11ccb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_ja_JP.png"
  },
  ["30139fb1012a5569ecaf0e76ea9cbb627ecd7eb7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_ko_KR.png"
  },
  ["30173ca23a1431b9b4b3b1fc0f44656e6d93c8e8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_ko_KR.png"
  },
  ["3022767e1d1f3c559ffafe8eed1eca5f58324bc9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_ko_KR.png"
  },
  ["302f3b3ac3209c9749ed0bf76fadcccff2a94758"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_hr_HR.png"
  },
  ["3031cecf0534cf1581460d9d37449b9d7429c7d2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_sk_SK.png"
  },
  ["30743e2b54f733f5da16cad1e1549f43f33afbbe"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_hr_HR.png"
  },
  ["307bb4764b5b76250dc1360ab890fb5b213773c1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_tr_TR.png"
  },
  ["30b63412dc098e30db55d208ef4d6d14fcf884eb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_sk_SK.png"
  },
  ["30b8f2b94272d2bd43e39ece97eb50eea8585edf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_sv_SE.png"
  },
  ["30c15df4c6fcd117a89cebd961ab527095b259a6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_zh_CN.png"
  },
  ["30d76d7b257b2cd8d9902bfde1ef8d82e328e801"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_tr_TR.png"
  },
  ["30e4968ae94552435800750e9b51af9e81a0844b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_el_GR.png"
  },
  ["3105eaaaabc6bd85c2e2831365e508c7871d389d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_zh_HK.png"
  },
  ["311503311737fcf30c9b8e629d14ecf167aa9e2f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_sr_RS.png"
  },
  ["311764f2600117bf8b624b7d06d2a5a13991597e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_hu_HU.png"
  },
  ["311a8e4c6160e4972c940d088f4f8028784ec6e1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_it_IT.png"
  },
  ["31210a6e70da35b9ad54df82e71c4c40f8224829"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_ko_KR.png"
  },
  ["3173c125fa469c4c19b70ae6a3061b6538274cd7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_pt_BR.png"
  },
  ["31a1faed21f9c7b981780c9f3c4fb756cde1b33d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_pl_PL.png"
  },
  ["31cefa81ceecbcbaeffd669d03b78c285001164d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_ru_RU.png"
  },
  ["31f68ebc21e7ad990f3caf1b76cfed800c328944"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_pl_PL.png"
  },
  ["31faf5fea9f4d43f6595b119b81e999388c712f9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_nl_NL.png"
  },
  ["321245e3ae3094dfbddcc82ea308d73286bdc740"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_vi_VN.png"
  },
  ["322b48c0a041fa9e4476739f91bccae1725a47bb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_hr_HR.png"
  },
  ["32383386f8033135c35cb57874e1fd60023b9a26"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_zh_TW.png"
  },
  ["3243d7cad7a33f8988cc4d90f2a5c4bbde2f302c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_ru_RU.png"
  },
  ["325239f4c1ca1450d8bb8e6c961b81f3a4c48ced"] = {
    assetType = "image",
    destination = 2,
    path = "Images/fuelpump.arrowtriangle.right.fill_body.small.png"
  },
  ["325b22b16b86bf42518553b15b67e4fcd02da04f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_ar_AE.png"
  },
  ["326bc4900bf3d1f9c4f5bf8e1d1ba1f9b5773917"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_fr_FR.png"
  },
  ["32902214d13638bf3335e51dbc41a0081adcd177"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_ru_RU.png"
  },
  ["329b85237c96cbf671b40416e71f64d6ffacb712"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_zh_TW.png"
  },
  ["32ab4d58b1b8f8ad5f6cd2e8b917619085d78db0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_tr_TR.png"
  },
  ["32b125a785e5578e071f47523ae9ae55ed071134"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_pt_PT.png"
  },
  ["32c7ea735e56d45b0e8094232064bbba02968296"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_cs_CZ.png"
  },
  ["32ca9a3d5728db705c7a2ddc2ce8a2e28ba00829"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_ja_JP.png"
  },
  ["32e2ed3cb47b64c63221b04421dc61df59761ac3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_ms_MY.png"
  },
  ["330a60d7a6c5a38e5c8384b7da5a0eb3ca51dcb1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_tr_TR.png"
  },
  ["333f4daab3cd585f831f5982c2c8ac7f41026467"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_cs_CZ.png"
  },
  ["335bd7988aefc00e95f69bf261c016e251f5bf16"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_cs_CZ.png"
  },
  ["33861a891287608bc3ebb5b1d2f8d7cfafbb8507"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_de_DE.png"
  },
  ["338897baf1daba0c310ee1ba2d201ad828ee6a02"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_ms_MY.png"
  },
  ["33a1eff2386e63a734b142781d8b9640d8274f63"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_th_TH.png"
  },
  ["33d4db76de82f03e28c8e08299be37d560acad5f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_en_US.png"
  },
  ["33e10b9b7dd95c4ef43cebce8f18902434e1af60"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_pt_BR.png"
  },
  ["33ea9189276c139063c851cd66783ab0b220f437"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_th_TH.png"
  },
  ["33edafd7e03c70bbe328f4084b38d05ae77c068e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_en_GB.png"
  },
  ["33f215a8cdff9e4b679844793e1f8c2888d4ab37"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_it_IT.png"
  },
  ["33f6af1a04eba1d99f34849dda0e3675844e7108"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_el_GR.png"
  },
  ["341c2298d01a3c76519ba696bb137df1c3668031"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_fi_FI.png"
  },
  ["34305d0383d9d36be2c8f4f7f3acf7ec7f3cca3e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_es_ES.png"
  },
  ["34471f0c00ad7bf631c1d2d3f3bd54cafc3f8163"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_de_DE.png"
  },
  ["3447979df0c32353c9f9e80e3687fbfa3a28d211"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_zh_CN.png"
  },
  ["345aeb3870581edba2cfbe2143e5ea29b6be5653"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_ar_AE.png"
  },
  ["34608f05c7c526e86b3762988e41c5792adcb58d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_sl_SI.png"
  },
  ["3473fc911590524f754bd85663feccc5aedc4ae9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_pl_PL.png"
  },
  ["348873549514bff0a503d5b17769e8170126e70d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_sl_SI.png"
  },
  ["34a9e88723431fc6abbf6babbd8d49ae67bbce44"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_sv_SE.png"
  },
  ["34b6d1c6ba4baac7195ff734d857d935b661461a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_ru_RU.png"
  },
  ["34e2ff2ec62a516650b5a7a2c44e50a1839c5626"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_cs_CZ.png"
  },
  ["34e95c694b763fc2442f52910f268e4f628b4b9e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/thermometer.and.liquid.waves.cold_body.medium.png"
  },
  ["34f2d44a74fe04a8e0391661e53841c2632fc019"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_nl_NL.png"
  },
  ["34fc520be0b03e7e966d6e8881f1e747e7434e9b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_pt_BR.png"
  },
  ["3525d65bf6b3cc416d882a2281af524f882cf2e2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_ko_KR.png"
  },
  ["353842f99f803f9c251eadd4732b798e64c0129e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_tr_TR.png"
  },
  ["353a8ec565320055536b676c5488eb7bc0366b5c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_en_GB.png"
  },
  ["355389b38f9de86d4a7972215873e3f01fb96879"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_cs_CZ.png"
  },
  ["355398773219f758332d7577f412f65ea586046f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_ar_AE.png"
  },
  ["3561e4ac72deb441164182f534962dee32b4d383"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_ro_RO.png"
  },
  ["358715b842f370ca14d677c2b7c6c8e4e0d1415e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_es_ES.png"
  },
  ["35915231f06243619c8cae64e5f73d64ab3a8284"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_ar_AE.png"
  },
  ["35d91a69b3c42949c0d98a17aff5b07a6e841cb7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_sk_SK.png"
  },
  ["364fc42a51266fd05b35f671963a4fef30243d58"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_en_US.png"
  },
  ["365f4e45b94568561667a57650cdcf9aab0435fb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_ms_MY.png"
  },
  ["3670daf3df8ccde09ee431f2cb7792bc20b4a032"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_bg_BG.png"
  },
  ["36846fd2fbd499825f36eace47fd1c57910ddad5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_pt_BR.png"
  },
  ["3689c8e240c9fca97194359c3949c2361b430e64"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_ja_JP.png"
  },
  ["368d61dfbc5766a49d0f8239af3fb87aa2189dad"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_bg_BG.png"
  },
  ["36b6692c0ba123e2dec6fb297bf7a812b5426b2f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_vi_VN.png"
  },
  ["36bd240d5d53966a7ff8e5e3cdba0adae1bc8f88"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_ro_RO.png"
  },
  ["36beb104d05331f6829f2cf39e1d9ebbf3367ae9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_hr_HR.png"
  },
  ["36d5ef41cbb65f96ae94da541cf8c699ce1ef53a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_da_DK.png"
  },
  ["36e3fb68a9eb6f4b5d0d87339abb38c40551980c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_pl_PL.png"
  },
  ["36eb5f32c42ef5fe5149f2536ea2ba7c0825078a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_nl_NL.png"
  },
  ["36ebf56d7b88b7270d30ec9e6ec9818eead3815e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_ro_RO.png"
  },
  ["370b474320cd81f910433f52d99cbd5ed05406c0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_ja_JP.png"
  },
  ["372796a0f75eb938ba1f02556e6b076a2ba4257f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_el_GR.png"
  },
  ["3742a10b5ac9a2851716e59927efdc49a97236fa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_no_NO.png"
  },
  ["375b6e6b995ec566fab92bfce9b9fb31d391288f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_sk_SK.png"
  },
  ["375d96d612817f7213a6026fcd785283d4cf9fc3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_ru_RU.png"
  },
  ["378ff32d893da0e5ca5a1b7b267cfe664c76acfa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_de_DE.png"
  },
  ["379f40048d6ac87fb29fbb349c5ba0ad7cf17568"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_ja_JP.png"
  },
  ["37a4f5f8ff697714e28ed3cb13548694dccf2ab7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_fr_FR.png"
  },
  ["37cc6fdb5f14521c1d086f1a5adb6ae10ac47e29"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_pt_BR.png"
  },
  ["37cce75046ca8e634cbf61c6b4ef40edba1d6031"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_de_DE.png"
  },
  ["37d88d42f585c5e2b81f2fd262721bec8aa0053b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_sr_RS.png"
  },
  ["382a0c2937772cd42f2fcaa0e02abbc945fc708c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_sl_SI.png"
  },
  ["383f65e1591072ff7c6d07fdc38bdf5feb0420c0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_he_IL.png"
  },
  ["384728a6180243fcdcc70cca78bf98f5ef1ddff6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_el_GR.png"
  },
  ["3858d1f3008827813773fe6a23b03d786fca368d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_fi_FI.png"
  },
  ["3860f0df37fc6d9ebd0c4033154e24dc3e8c9b37"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_no_NO.png"
  },
  ["38837f649b77bad873a7f083a07f15b59a6b3751"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_en_US.png"
  },
  ["3883a6b2e93ac0d0997e48de655cbd54dd088489"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_he_IL.png"
  },
  ["388cb78ae5d8b796e2f652e866dab0fed4452c4e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_zh_HK.png"
  },
  ["38a9b802876f303e6ee6244cbaa162e1ea239f2e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_ro_RO.png"
  },
  ["38b2059d414c095fdbaf9fbaaf5d37e6ff7fd484"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_ko_KR.png"
  },
  ["38c917c4632c7695145c89cd53a916ac48659fbd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_pt_BR.png"
  },
  ["38cc6a7583cd7c879db22fdb1104eaff6cdfe2f9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_no_NO.png"
  },
  ["38f8b12e7be670469e7f6574761e9473085b9294"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_en_GB.png"
  },
  ["390a020892f3b1ade9abf93dd53bd1b0bd6e3399"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_ro_RO.png"
  },
  ["390f4166cb4a37ce2637e04c4a056100ceb5f0a7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_en_US.png"
  },
  ["3947c79792d2d526e1bfee762d51189f23e2d86f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_ms_MY.png"
  },
  ["39689a01f098bda009bbb04bd313e9dbf7d78c1c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_sl_SI.png"
  },
  ["396ba9362e66e24db84f902356e71f4480933913"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_pt_BR.png"
  },
  ["39c585df27628d8c427f0561b0c1a364ed749817"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_pt_BR.png"
  },
  ["39dc35ed466bfdefa6b1e5feab8782ee3048ba06"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_pl_PL.png"
  },
  ["3a054a6fa06973b6842b8abee3015b4dec736bbd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_en_US.png"
  },
  ["3a0837c35071b1de16ae3d9fe32b365fe23b8ee1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_ro_RO.png"
  },
  ["3a08b6dcd97a9a848fdef9f59b92ccfcf206a80a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/fuelpump.fill_body.small.png"
  },
  ["3a376f9b9e0f9e0f4d847cf53cbe7eb3a9cc2467"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_cs_CZ.png"
  },
  ["3a5af1ea0589f36f9a29cf63227ecd495385f4b6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_zh_CN.png"
  },
  ["3a61a6ed11d54543d427896543d10b4c7402cadf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_id_ID.png"
  },
  ["3a781a2d61616d5d33aa6e706c99b0e1bcedb7fd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_sv_SE.png"
  },
  ["3a85fd960577707cf9d1a082cc7a6ae808ed3096"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_pl_PL.png"
  },
  ["3a885a298ee2aa9ab2fe0905b8ab52521933a17c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_id_ID.png"
  },
  ["3a93b6644c691f6ffabdde191861fb63930f2879"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_no_NO.png"
  },
  ["3af0c2f7941d2635fbd61599ca5a286af915fb9c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_ko_KR.png"
  },
  ["3b1ad28d256c6ffdf8ef4c60e4d44b570fda7bf5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_es_ES.png"
  },
  ["3b45bb70971c6e3dfaf7dd0d3ce73bd09b608e10"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_ms_MY.png"
  },
  ["3b6c9d7368aedbade66eb4d2de27be1013ede182"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_it_IT.png"
  },
  ["3b735ee48711cb162d003362fa37565ca92d0693"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_tr_TR.png"
  },
  ["3ba59e1320c9a6cc3000529c64c5a6c3a500675c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_fr_FR.png"
  },
  ["3ba981069b33530d392d6df118795e42af583b74"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_sk_SK.png"
  },
  ["3bab072caedfae9e0a2c815b081de38303df6dfb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_ar_AE.png"
  },
  ["3bc55edd8002458138609b85b430b16c1d214df4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_he_IL.png"
  },
  ["3be55cd17c3b2f93fa91203fcb395375a721a0f7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_hr_HR.png"
  },
  ["3c190a86115476246c77cf481ff169db983ae44c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_no_NO.png"
  },
  ["3c2aa929dcab6f8bbbcd5979b7672b862f82ed34"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_ro_RO.png"
  },
  ["3c30af33d52ee0ed5ca03e6de8ed6cb3168bea4e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_ms_MY.png"
  },
  ["3c3d2b56e4543d35e009a7a559f090dbfe1fe401"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_id_ID.png"
  },
  ["3c3d726e3c9ac5b44b8d6da36adbccf40802f4af"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_sv_SE.png"
  },
  ["3c3fcb0c88238585fc72e8e56910412b66d926ba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_sv_SE.png"
  },
  ["3c807e0b367b05cb9283f9cdd85e22ee37cca8b3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_ja_JP.png"
  },
  ["3c84185aa0e0b7b1b90fa51883d7316568efdf0e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_sr_RS.png"
  },
  ["3c8ef1957f4133a7c9eabc256c7731b13e8f5dec"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_sv_SE.png"
  },
  ["3ca6018e480ccbbe7a8b4dd35108943aa2f6c270"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_tr_TR.png"
  },
  ["3cc4635e123de4d43cf39f287df1ab7099666deb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_el_GR.png"
  },
  ["3cc9013650f6e5862ddcd67904836fb8b6ac4cb8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_uk_UA.png"
  },
  ["3cdee577855a011e6142c5856d40b1557073560c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_hr_HR.png"
  },
  ["3d12b16c0630fe8b390b12b8d45d5f4ceb3ec7a7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_da_DK.png"
  },
  ["3d3baef4ef74d1edf33c0a6497048bb549d137cb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_vi_VN.png"
  },
  ["3d44f364d94cb7cca893db14735d29e738f8d3e6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_tr_TR.png"
  },
  ["3d45cba5f6f3bb05c5c3415b27c685e640469efb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_ko_KR.png"
  },
  ["3d4707c964e75485d13e950ebe87c7a832d177b8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_fi_FI.png"
  },
  ["3d473ead97279e87cb119a4a3b1eea54f8d4c6fb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_en_GB.png"
  },
  ["3d48e3a5be976609b27fa77dcf33561923ac83e4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_pt_PT.png"
  },
  ["3d4c83d627f645e27c19fc401c908ac271df309d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_zh_CN.png"
  },
  ["3d6286d9cb7133464d9e1ecf1891e818737ee435"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_fi_FI.png"
  },
  ["3e7784646530f997d7c933ae74b6484148eafbc6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_sr_RS.png"
  },
  ["3e8507958c6ae8b8c564e4a12b478a5a35496dc3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_sl_SI.png"
  },
  ["3e9e459ce68b8cd9487ece6fe33bcc86b1f0d2d2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_fi_FI.png"
  },
  ["3ec3f63cbf3b6e06d7797172ccd69f026c5defdf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/decorative_tachometer.png"
  },
  ["3ece3656edc68731f38884554bcd117e7ad35039"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_el_GR.png"
  },
  ["3ee398a711d0b1bd62431acd62729a46c78ef56e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_sl_SI.png"
  },
  ["3f0e82163f0f2e9152321350bd93632041ff7d2b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_th_TH.png"
  },
  ["3f2178c8deed2f7eb36edeff494c08c9ad5c7510"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_sl_SI.png"
  },
  ["3f29d5dd1ced914d3dcff8b6cf8a879a2c8caa15"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_el_GR.png"
  },
  ["3f3cce31d360fd70897a3c35d22dae9201907fcf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_it_IT.png"
  },
  ["3f4df9e7959984080f87d5b18a765d100991479f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_sv_SE.png"
  },
  ["3f54e4c9296690776687de5a43426b204401919b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_sk_SK.png"
  },
  ["3f5971ecf34e9d71b27254a99c824e9956515a4c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_fr_FR.png"
  },
  ["3f5c93480cb0851138b40aa662127271c3ca2151"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_th_TH.png"
  },
  ["3f86741afeed2e2d110ac432d4ac8713327ac717"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_cs_CZ.png"
  },
  ["3f8778f7330d052d6f95d957d0553ef6fcb233ac"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_el_GR.png"
  },
  ["3fb22194299c4f69dbd2c1ecfacad55347b32bde"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_pl_PL.png"
  },
  ["3fc26b2479d223479688a24332e0e2e9b49f88f1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_ro_RO.png"
  },
  ["3febf39eeb38db613e52a58b0c7977a65a46ebac"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_he_IL.png"
  },
  ["3ff4e27d367a1ae3b0834d53b7f5194c932ab1a2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_th_TH.png"
  },
  ["3ff7b48c434c13166f7b6e6bc7a5112a38abd9d1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_nl_NL.png"
  },
  ["402c6dd62106d6f95c8db2411154b47241b5875e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_ja_JP.png"
  },
  ["403defe44cb47df8b3ef4a43096f676cdb9a5dc9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_id_ID.png"
  },
  ["4098d2f57aec9de1d0d83aa4a377ba339b1394a5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_tr_TR.png"
  },
  ["40c45fcbc9b3c804097fe1f55c8dd0d3a5ca2d19"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_he_IL.png"
  },
  ["40c61c83a04bbb9ba6ef6ada5e81944c1e26695e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_hu_HU.png"
  },
  ["40c6cf504332eff839e656009995b0b2fd975929"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_zh_CN.png"
  },
  ["40f741a4d0560c008a3cf5defe0ed5dd5ca3a053"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_sk_SK.png"
  },
  ["411fc205f5364bf9be8623c32ca66555cca5cf92"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_hr_HR.png"
  },
  ["415c042501e67ba2f86aea1e3eaad1e44330f6c5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_ja_JP.png"
  },
  ["4169f8ee53332464269a27fba5505b8db734450e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_pl_PL.png"
  },
  ["417f1940a2a4b127e20e15c185bc8d62e21a4ba7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_zh_HK.png"
  },
  ["418f5bc564093c2e13aace0c6f82ff994e3ba1dc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_he_IL.png"
  },
  ["41c96bf0a10e20cb8e90933f47619bcb8bb39e72"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_he_IL.png"
  },
  ["41d05b9d83d3a7fae39270240eff05b454342d1e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_pt_BR.png"
  },
  ["42328deb6b62fc12204a68be9f7a43da5a7c0ca5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_ms_MY.png"
  },
  ["4248da8f614d307c07e2c56869eec9f8f046ac59"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_fi_FI.png"
  },
  ["42751ca573d0a55182e35052c2321af8c48ae56c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_el_GR.png"
  },
  ["427f4f4958a4f7ffea57232fb1bdcc87b097b6c2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_sk_SK.png"
  },
  ["428fe4ed13fd04375466d8b835c6cb37b191bc36"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_sk_SK.png"
  },
  ["429119e416c76d0093c524c4ac5a73266071b7de"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_hu_HU.png"
  },
  ["42ba69a774e52ad1c00a280d3799726ea57e8071"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_es_ES.png"
  },
  ["42c2849f89c12fdd7b88de04037168ca1321fa97"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_zh_TW.png"
  },
  ["42df8f4aaf99f558935200cb32eada932f015e27"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_vi_VN.png"
  },
  ["43292b7e1feaf79e7bca9e1db32b5389d6be3e2f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_hr_HR.png"
  },
  ["433f499b60f013b74e575f6ae234f697b8991617"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_fi_FI.png"
  },
  ["437d8df3650f60fe759df618bcc4cd9644094df0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_id_ID.png"
  },
  ["437f61c5d0bb1d8d7560832a9f04f5208da87c46"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_ru_RU.png"
  },
  ["43af755ed2f3193177f2418152aade6c1f7639fc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_uk_UA.png"
  },
  ["43b6a29b49dd741961f83b795415768a1639ac69"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_sl_SI.png"
  },
  ["43b92c00d7986bae6fcfc24a7f04181cc434d310"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_sr_RS.png"
  },
  ["43c258cd6a585627f527c0d616b4831e69bccf91"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_en_US.png"
  },
  ["43e9651ed9fcc3a9a68c222eea74eeddbcbe8c2d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_fr_FR.png"
  },
  ["43eba2a397a0dc8c414b49ef7914ff8ecef5aa31"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_fr_FR.png"
  },
  ["441f21542098aa238331847a3467be2cca8490ab"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_it_IT.png"
  },
  ["446d050360ec5ac47c8ccdb0a1cb44b4f5277226"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_pt_BR.png"
  },
  ["4489c1888e16f797243d3aa23a991ace7da81770"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_es_ES.png"
  },
  ["44bcdb9358fe7a6b00dc8b80ce4c6d8a7d2e7fca"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_hr_HR.png"
  },
  ["44bf2184a6d3c11570ea968c6367587cf0bc528e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_pl_PL.png"
  },
  ["44d1ffb9d3a9d60a0962d10d009a2faf13883812"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_it_IT.png"
  },
  ["44dc9b3b4f7a553b2a34b9f909f870960ece6687"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_th_TH.png"
  },
  ["44e8c9ded1811a4be5ae39da67de635c28651490"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_ar_AE.png"
  },
  ["44ec396e72250e5a3abda518feed1cf62683e218"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_vi_VN.png"
  },
  ["44eddf071a728d93110ff20ff4b0d7af73b30fa1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_ms_MY.png"
  },
  ["44ee295f035147f81b8e4ab06449b08ab16e9345"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_fi_FI.png"
  },
  ["450dd03bba0b4560615f817f602276a2c1f768d2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_fi_FI.png"
  },
  ["45104e9584152eef70f6fbd04a4dc79e14b981a7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_it_IT.png"
  },
  ["451319f2daf793abc53c81fd1b505e02f839037d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_el_GR.png"
  },
  ["451813ecb8c630b4d98b9968da7b12296c82a1e5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_de_DE.png"
  },
  ["4525fa8c05fd9647412ca64dcef7d56571bf036e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_ms_MY.png"
  },
  ["454c07161357f719295222999d202779935c1dae"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_pt_PT.png"
  },
  ["4552ca3730f3bbc2feee1968602f83949144c5e6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_ru_RU.png"
  },
  ["45945d84fc0a55f3ff35e8c2ab5085b57e039255"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_hu_HU.png"
  },
  ["4597f8cafc20dbb506b5ec8ee9fbceb6829bcfe6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_pt_PT.png"
  },
  ["45b3eb77a8e2a50cde99b6d7c55e30ccec2cf19e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_en_US.png"
  },
  ["45c305a8116db055fa0056952d7cd8c3ad39f7e8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_pt_PT.png"
  },
  ["46106127453db9574f343c0746d4320eef50c53e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_he_IL.png"
  },
  ["461d6fdd1626e348280e34f6c65377f93a087a79"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_es_ES.png"
  },
  ["46488deabbae05bb841cdf9e73a814a6d3c865e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_tr_TR.png"
  },
  ["4671b9acde4dc10c8d665dfc5f654557ffae119a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_nl_NL.png"
  },
  ["46ad27085b8e16aa7ed73486caf50eea3d0a250a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_ru_RU.png"
  },
  ["46b0f490cc4804b7dfebd0762d65848cda545a75"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_th_TH.png"
  },
  ["46b79c83861070254cecf28a5bb997940d9340d6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_ko_KR.png"
  },
  ["46c612e29a1899b110cdf041e11f1d6a58d165e0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_ja_JP.png"
  },
  ["46e7aad7cef4fa2ac013520535963ea0580290de"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_hr_HR.png"
  },
  ["46f9ffd38c8d3f03c80e9948e8e4b178a6f36123"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_zh_TW.png"
  },
  ["4707dc1438b310c1f7d06576593884cba1d3c703"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_ja_JP.png"
  },
  ["471265f54087fd7c538f6a46f2ec33ace5191298"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_id_ID.png"
  },
  ["4734282e769dd45a1ae363b11f8b2135cc89f435"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_sr_RS.png"
  },
  ["4760257c1ee7a49b75358710fefb61de6789f8e4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_vi_VN.png"
  },
  ["47608a3df23338aff6e855c56ac44c587b03afc7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_cs_CZ.png"
  },
  ["4768bd509e7b247b0316a8b335a7a275419b28e7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_pt_BR.png"
  },
  ["478688a7dcf5f406ce549759921e12e83d8d6ca0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_sv_SE.png"
  },
  ["47a72b71f3982e7b96bfec3a632d75a53d7406cd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_fi_FI.png"
  },
  ["47d77a654494e9facc16ec75ef232c99bce2d290"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_ms_MY.png"
  },
  ["47f2effa8a2233c5995c86d58fe7706a033ce3fb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_cs_CZ.png"
  },
  ["485af492ba99b0a5fea1c3fd7c30b0042bcc0bc5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_ms_MY.png"
  },
  ["4883d445829a79bbef55e5070fed0f714a628cfa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_zh_HK.png"
  },
  ["48af0b8e1df4614562e4d4df789f32f64d109ea3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_hu_HU.png"
  },
  ["48bc48bf4d7d0b5214461f098223a4a868974fa2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_fi_FI.png"
  },
  ["48cc5b8c75da629fc6f776ced1de9e6c9bd89386"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_en_GB.png"
  },
  ["48cd46ca3dfa2828e9f19a71b53cd37bd4833b16"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_ro_RO.png"
  },
  ["48dce12cd01e21c2b5447674d810ef52a2813ba8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_da_DK.png"
  },
  ["4902a006813fb2f4a072aa8fc982d5ebc0b4d686"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_no_NO.png"
  },
  ["490c6a8e0e624a3a3b7f69d097538ed318834917"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_uk_UA.png"
  },
  ["49161c6dbc62745d8c76d0f0b233d88a8cdef79b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_pl_PL.png"
  },
  ["492397ecbfde244e5cd8b7bddfabf3fa8edab233"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_fr_FR.png"
  },
  ["494521ae5f4cc3418a35dfcc6559f7f877b7ddd6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_zh_TW.png"
  },
  ["498a418d62cb68c1dc1a196066bd20ce8ad29473"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_fi_FI.png"
  },
  ["49aac6b47cc23fdd3b493cf802ab549ba1fcf9fa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_he_IL.png"
  },
  ["49bc9d29f1ed56f8b1dd8860d1c1dd7e41a67740"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_ro_RO.png"
  },
  ["49d4123cf1c4dda5cc9a671f2dbc792038e0817b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_he_IL.png"
  },
  ["49da09388f654265b186593d45844c39c1cc09f5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_he_IL.png"
  },
  ["49e9971b499e3fe9f558e3e6977d66625000ce08"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_zh_CN.png"
  },
  ["49fe0d85a40121d252fbbe338153f0183bd8d96a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_ro_RO.png"
  },
  ["49ff64436e0b21b0d57a3cf4e53642eabe299b54"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_ms_MY.png"
  },
  ["4a1034855a19efc0f20a809c5ae29d5512ec7915"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_it_IT.png"
  },
  ["4a6555fba69eec120f3300852bc5ab12c2adc4dd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_en_US.png"
  },
  ["4a93be40f34f10dec6cf6b0a978a6355942b40e0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_el_GR.png"
  },
  ["4aa486a4d3b561d675eaa1225555185b707160d4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_ar_AE.png"
  },
  ["4aa754a7837d74f10adae34065594019ab0e7b04"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_el_GR.png"
  },
  ["4ab11f1f77fef10066702837aeeafe78c263717d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_en_US.png"
  },
  ["4abd45b51d3834102e5449530afd374c7199f1e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_ms_MY.png"
  },
  ["4ac8d0ac6adbc54dd891532ccf199d29015db580"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_sv_SE.png"
  },
  ["4acc795039b8b10fdd5c06aaf0e1165f2f8e5bda"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_tr_TR.png"
  },
  ["4b01b003695fd6be377077d38d4f910afe05ca5e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_ro_RO.png"
  },
  ["4b0a736b7061255a523ec1b0c1d6b3282b271931"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_ro_RO.png"
  },
  ["4b0de4068cde7269b7b4a62ee587ff4a9bf666ff"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_en_GB.png"
  },
  ["4b31e13d5fbdf2ad70553184b0b15527649db3be"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_ko_KR.png"
  },
  ["4b6108cc238ba1a5c447da1702b065a1fed724b7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_de_DE.png"
  },
  ["4b743553ba10c52413fa789982262c588db7c117"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_fi_FI.png"
  },
  ["4b85233358b055349f2113f5fb5acfc01c930ef2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_uk_UA.png"
  },
  ["4b8b14c132337ef03d528cda4a3f95d8ab9148e4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_en_GB.png"
  },
  ["4baa263bb6a0234ee5750a82d0de62e021438e29"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_en_US.png"
  },
  ["4bb93c035c13133282fd0a4df083f308d15f5b4d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_nl_NL.png"
  },
  ["4bc277b9aa52261b31c608a547faff46889b2e04"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_tr_TR.png"
  },
  ["4bd7a98b5547d7c810851f9d8b2e8a8747f6a1d3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_pl_PL.png"
  },
  ["4bdccfa1b049a3cff1c241640f42c20b43e9f35c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_zh_CN.png"
  },
  ["4bec6309c81c2a168d2244271ce5931da80f7156"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_de_DE.png"
  },
  ["4c0dec1067fd5d1e092aebe69dc4adf3b985ab5c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_no_NO.png"
  },
  ["4c32ce6eabc415c3beffa6f41b4d8e8b190a51b7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_ko_KR.png"
  },
  ["4c3472227c84ad523d23b8359cf0ce0a7165485f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_zh_CN.png"
  },
  ["4c388ff1cea57e096b45c704d901dd880591da83"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_hr_HR.png"
  },
  ["4c44a33d2a19fa36aa7217983c341be73c5494ab"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_it_IT.png"
  },
  ["4c4619830ffb7b9ec28553101f9b90b7c6bbfed1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_pt_PT.png"
  },
  ["4c49556aee70e45d98da3fcc1f419907ba04c18c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_th_TH.png"
  },
  ["4c4f27c4a84cacae63f123a0cadbddefb56b7f28"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_id_ID.png"
  },
  ["4c544ff58c78f2f10c8579aef048327a4496346c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_zh_TW.png"
  },
  ["4ca7487193146373536442dd5950bedd22fccae6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_de_DE.png"
  },
  ["4cad62b64b4b7d95838673701d4c3804ce788b44"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_no_NO.png"
  },
  ["4cbac4494997cefdd598f998c70a10b499cd5f81"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_ro_RO.png"
  },
  ["4ccb8945ec05402fcfbdccfb29f77009f9389006"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_de_DE.png"
  },
  ["4ccf38aba6767e0dc312cf577f9088ff7c3c6175"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_sl_SI.png"
  },
  ["4d1911c06c91390f96c86a9a56ec6c102d1565cc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_en_GB.png"
  },
  ["4d4654eacc889ff6050d7eef0bef4aad7f2fe788"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_cs_CZ.png"
  },
  ["4d69cd2b743c357917dd280fe125c533f31a682b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_id_ID.png"
  },
  ["4d6f45912c418d03a98506800d5abb4ff8ea44c3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_he_IL.png"
  },
  ["4d812a58e3dd508996211f31dd503608d5bede07"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_ja_JP.png"
  },
  ["4dc90152b5895bb445ec4e2a8ef52a95d5be25f0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_zh_CN.png"
  },
  ["4dcc3fd60157adba115d952fc3ce6150c07fcaf2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_zh_CN.png"
  },
  ["4dd43832c03aa385882c5e99f8450f11ac67cb5b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_el_GR.png"
  },
  ["4dd5d2b17135277874f42a4df33c3bcc1f1a41f1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_sv_SE.png"
  },
  ["4de2dc9c7b02a0d97f9946f3f6b23e5a472a29da"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_ru_RU.png"
  },
  ["4de409f3bc398abb514ad51c3b87775d5fee237b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_id_ID.png"
  },
  ["4e1190263228688de0b43807adf5798a258fae36"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_fi_FI.png"
  },
  ["4e18a91b74d98ae482d554652e2bd488daa60977"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_sk_SK.png"
  },
  ["4e30c0162f52b1195688f84757ee0f2ae1b624ed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_ro_RO.png"
  },
  ["4e421a0298befcc10c850deb96ce3d67995e8a8f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_fi_FI.png"
  },
  ["4e5a20faf8c49939a1aa67c13ddedd26818744ad"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_bg_BG.png"
  },
  ["4e68b788563e053948a77b48786ddd9f3beb52bf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_uk_UA.png"
  },
  ["4e77608f5a51230bfb3c8862248eb89609a49e41"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_pt_BR.png"
  },
  ["4e928c04d053683a08aa47a6633ddd56a426d038"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_de_DE.png"
  },
  ["4e9751f3517c27b051ee1f31197031a3e38452c7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_nl_NL.png"
  },
  ["4eeef7964aa5e7095a1bdf204df89a59a8781803"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_it_IT.png"
  },
  ["4f2abeb87e15982420c3669beac91ed572f2adc8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_no_NO.png"
  },
  ["4f329cd293a6f52ee7c48f3faf49a9d2bb790233"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_pt_PT.png"
  },
  ["4f53b2fefdabadeb4f3cf5e961031fab5b473ffb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_tr_TR.png"
  },
  ["4f8f70dfbc877a23f0a13de323518e43701bd771"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_hr_HR.png"
  },
  ["4f91baa562c8301999836544ec745c529596887a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_it_IT.png"
  },
  ["4fa60cf080910eaba1cd6ac6a5478be79959c9fc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_ar_AE.png"
  },
  ["4fbfda4481ee5ceeada7dbe4c953d9f2dfa27a35"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_da_DK.png"
  },
  ["4fe982262f27f91b5d8771b6c9df13ad82c037b4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_de_DE.png"
  },
  ["4fe9a37e0f80eaedf225a8fe36c41961e3fbd850"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_ar_AE.png"
  },
  ["4fed72cf8660c86183218b684b7bdb9f19b7edcb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_ja_JP.png"
  },
  ["4ffc62e02933f4598236e72a298736e7e280bea6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_sk_SK.png"
  },
  ["50136552fb96818f02a06d022741776f62ca808d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_th_TH.png"
  },
  ["50320516cf58aefa7e56c4f2a0ce78a167b401c1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_ja_JP.png"
  },
  ["507202e3be898179eedc190654d9198736b0340c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_pl_PL.png"
  },
  ["507f98630c6ac8ed748465db4a5fd6d901bd3f05"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_es_ES.png"
  },
  ["50a42890672058583e8c3bda1adbccc88100392a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_ko_KR.png"
  },
  ["50ab2999b601786e846591e9eac6f298b3fc5784"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_sl_SI.png"
  },
  ["50b4d555bcb1bc3ee0741ea6e3eba07bc31d5fd3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_ru_RU.png"
  },
  ["50daf3c398148e25bd0c36edb14e08148c9c5f99"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_th_TH.png"
  },
  ["50f9740b908046018eb79556db8ac7075661bb75"] = {
    assetType = "image",
    destination = 2,
    path = "Images/gearshiftup.png"
  },
  ["50faaf72b0880ee77eaecaacc67d04cde5f89cb9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_ko_KR.png"
  },
  ["510088eedff13c7c483b113824c19c612f62b7e4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_fi_FI.png"
  },
  ["511a8b1659e01eb12d84a85c05e9aa926280cc98"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_ko_KR.png"
  },
  ["5147877cc18dd25dad82de00a09eec9754e7bd9c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_th_TH.png"
  },
  ["514a48c32cd5e2a58082dc6d722ae383638af93b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_ja_JP.png"
  },
  ["51b2c8b657813e83c64fccf54ea2d4227a7d90a9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_pt_BR.png"
  },
  ["51b9acd51ade858a71b30efa87b6ede09f51b11b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_tr_TR.png"
  },
  ["51e8d4f13126a117f85496a091ba88197d3f5871"] = {
    assetType = "image",
    destination = 2,
    path = "Images/Shadow_Top_Left_Corner.png"
  },
  ["51f29b2048ffc3c3cc0bbd00816d8935470abe48"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_ar_AE.png"
  },
  ["51f68e8257decbd3a8628882f7e1f51c62188487"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_pt_PT.png"
  },
  ["520bd3d5798b78e2af5856edb3659f7e1a186de1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_cs_CZ.png"
  },
  ["520f0ad5493999fa122ee8a8497aabb382a949fd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_ja_JP.png"
  },
  ["52176cf42498cc5fc9232fcd5da54cd2f01721e1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_sl_SI.png"
  },
  ["52297e6c25159f35d886aba81e6892f8f504f700"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_sk_SK.png"
  },
  ["524649a55645406ae9aeb6d2896a70894e692503"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_fr_FR.png"
  },
  ["524fa63a849474addbacf7d2fb8be0e0e66ba176"] = {
    assetType = "image",
    destination = 2,
    path = "Images/invalidDriveMode.png"
  },
  ["5263e717a291a27260227ab61687db4c5fdf801e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_pt_PT.png"
  },
  ["52ad324e5c1276c479a0f04de7646b9f2c73f2dd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_zh_TW.png"
  },
  ["52bc2432f51b3fad3f54b518e84e46a3ed76eb66"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_vi_VN.png"
  },
  ["52ce35dfe4b6ff8420f35797eb6d7b351579d312"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_nl_NL.png"
  },
  ["52fc23bf870b49fa16799d5ec2e4005df08f445f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_ar_AE.png"
  },
  ["52ff527bc53eec1d72d0aebe922099ad9cd75764"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_zh_CN.png"
  },
  ["531c1e92689305c32527c85bff3bb2f278d7fc37"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_pt_BR.png"
  },
  ["5347a2c96339c05808d0793a68292ef5df58c0f7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_nl_NL.png"
  },
  ["535ae8522134381d52db32efb5623fbcea797493"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_pl_PL.png"
  },
  ["5367cfaf3896b411a775e04e6a9bd3af0b750862"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_ro_RO.png"
  },
  ["537566d995679bd04f2ba37cbba3ef67fd2f8863"] = {
    assetType = "image",
    destination = 2,
    path = "Images/sport+.png"
  },
  ["537f3509e217ade35702d2838011987c5fd6d9ac"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_ja_JP.png"
  },
  ["538ee9569fe00ba33cea51e83f290280ff023503"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_no_NO.png"
  },
  ["53aadfe037d197d62b973058e80a26a8bb04a081"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_ar_AE.png"
  },
  ["53b2f4ddac596f934b5af8dd02de55462317c01b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_fi_FI.png"
  },
  ["53c1d5a2f5f4dce1cd64133e386fb593b52a0ce4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_bg_BG.png"
  },
  ["53d833d7b41e4d0bccb732fdfc19bfd3687c0164"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_tr_TR.png"
  },
  ["53d95698fa615908a57319e2f8eaf2c379294a27"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_uk_UA.png"
  },
  ["53dc34464749b078a2b53bc05885dba055fc7bfd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_no_NO.png"
  },
  ["53f5a93a58d613475e9f95bdd20baa6d40880f68"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_ro_RO.png"
  },
  ["5420a5c8bdb7f9184f00ba0ea8c68083555d138e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_ms_MY.png"
  },
  ["5423be000ae4512e3226bbe67090cc8db995b024"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_ru_RU.png"
  },
  ["54249a9a35987763a43612c9cf3bb4230b1de5fd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_ru_RU.png"
  },
  ["544e8fffd03db91b64269eca4fe9c1bcfd573493"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_en_US.png"
  },
  ["5479b2219dc8b4a3c496c55d11321be0cb594660"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_id_ID.png"
  },
  ["5496d85669553f55e47dcd5405e4d945da855146"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_fi_FI.png"
  },
  ["549f4cfae993e687d8d18eccaa297607fd61db58"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_ru_RU.png"
  },
  ["54c34572516908d3ea5f41a9fffa04203c3d91e1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_uk_UA.png"
  },
  ["54cf873346781100af2654978dc054fda1a6c443"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_el_GR.png"
  },
  ["54ef1ff491b00a872bbcbcecf6bb4ed461aec7cd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_sl_SI.png"
  },
  ["555c5fe5061aecfdf9fb6c08ccc78ae32a814274"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_cs_CZ.png"
  },
  ["557c631f793275cbcb03f89b3fa32aa9e3be5846"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_cs_CZ.png"
  },
  ["557f292a5b8f5013b86cdfdfcae6591b5708e1ab"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_no_NO.png"
  },
  ["5586a628581f5397543adcf0d2b74efbcb8b0dcf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_id_ID.png"
  },
  ["55974a68d1e9a17c25275915ecb742521309fb2e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_uk_UA.png"
  },
  ["55cf3566b4a27e19812c60a7eb781518d051c8c4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_da_DK.png"
  },
  ["56121bc95f4e63aa394843512f4ab97b1c35e9e5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_it_IT.png"
  },
  ["5615428f973e539b385c7cf33782634312c2f3f4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_sk_SK.png"
  },
  ["561eee459b38710cc389773ef1867df45f76d56b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_da_DK.png"
  },
  ["562e519f7d0fd98aa319c19a8e014e30148650e6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_ru_RU.png"
  },
  ["56361b7b617392254f6a813e97f7d65346d53d09"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_pt_BR.png"
  },
  ["5641cef6d0b796132cdcaaa5f93f801bbc757433"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_sl_SI.png"
  },
  ["5662fc9cf856935f0284476ccb66b71249f9045e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_hr_HR.png"
  },
  ["566a257d08062cde787e9a6d812196eec0c3d1c0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_zh_HK.png"
  },
  ["56819b74af8293a8d3cee3a07ed066f699155cf6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_id_ID.png"
  },
  ["5682f51a737a044343ff2a247a1f17c8bf42bb4d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_uk_UA.png"
  },
  ["569961660e7220427d10976826a36fab8916f896"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_ms_MY.png"
  },
  ["56afe42ec41aadbb9cf610f260f7476f0ec26cdb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_ko_KR.png"
  },
  ["56e41a7eb7bef4efd98d3e164a8f00a1f3c74093"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_th_TH.png"
  },
  ["56e7577f5e4c94f1b4872caaf3c16c0687e13fb5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_sk_SK.png"
  },
  ["56ff371c7716d0eaabf367e73fa4e6df4d2a2c0c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_ko_KR.png"
  },
  ["574286f83659521596989ea0d6c11932697fffd3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_cs_CZ.png"
  },
  ["5782196dbd1de0b111389f941c51d81a96f930e8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_ja_JP.png"
  },
  ["579bd57c9b83ca93f8545ef29215a7a157da6592"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_pl_PL.png"
  },
  ["57a6f2c325bd2ecadce8143a12964f7c92ca7eee"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_he_IL.png"
  },
  ["57a8d04cdafdba4cc3d482bab6ae97836063c53a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_no_NO.png"
  },
  ["57ae6ebe8a428c5ad00f31c06ca35319ee40c4fd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_hr_HR.png"
  },
  ["57b908f187a61744061154c0e030961835b481cb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/decorative_speedometer_mph.png"
  },
  ["57bc0e2fb76d12aae8b1225e95faae470a7fd11b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_uk_UA.png"
  },
  ["57bdc1d340ce1cb724a0293cc529935232310238"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_ko_KR.png"
  },
  ["57c173a10ddc3d15eb45c12af7f74d9c0d452fe5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_cs_CZ.png"
  },
  ["57c635de0fcf8e5803320e289d802cad0b1fe08e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_sl_SI.png"
  },
  ["57f8ab848c46ed3413153a49ac40fa5215205162"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_ru_RU.png"
  },
  ["580fba82d3b467b4c1372e6206e1536830850fbf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_ko_KR.png"
  },
  ["581aa187cfe649876deed32b1143aed3bbfce7d5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_es_ES.png"
  },
  ["582184cd0dec31b489604be5cff88ea87902cdc6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_pl_PL.png"
  },
  ["582762b760d88052ef15e6dee53a667ee4bf6987"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_sk_SK.png"
  },
  ["583601d8f9f6fe396c7bce9588ef2f8c927f593f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_pl_PL.png"
  },
  ["585a7d5cf88335ed46e638866454e7a7cead0969"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_he_IL.png"
  },
  ["585b5eb913e1229614d70d8e94c78c0a59f3f9e5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_hu_HU.png"
  },
  ["5866e22606889b7d4f67b97b812a11ec352b11eb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_fr_FR.png"
  },
  ["58833f07516b5788b29f44af66655e545e1aafe8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_ja_JP.png"
  },
  ["589a0bdce9ab155164bbbf3371f1e68938739007"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_nl_NL.png"
  },
  ["589ec6fa83891265c3d4716bf61c34f97f5dfc7c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_fi_FI.png"
  },
  ["58a602f1c1cb936d46e9e4227df84a08e9fad0ed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_fi_FI.png"
  },
  ["58bdd768267416b9b87d3d8d2a0c2a25ee477ff6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_hr_HR.png"
  },
  ["58c6312c3f16d99620ab15453f1324de24bc1b13"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_it_IT.png"
  },
  ["58cf92dbf9ba93ae82fdad22583625fd591d067e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_el_GR.png"
  },
  ["58e1e52a8f214c790b5e1b87df461f36975c85c7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_hu_HU.png"
  },
  ["58e3ccf5dd8c71ade5ca6b6560db8669652bde38"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_zh_CN.png"
  },
  ["590efcc8228e700e7f6dad9e148cc283f21519de"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_en_GB.png"
  },
  ["5922ae8cdf5f787dd0b2ce443da93befdcb13cef"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_nl_NL.png"
  },
  ["592b36fb36225bae14102817eb1964aa7d69b694"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_en_GB.png"
  },
  ["593165fae94eb507174439f015cdbb798752e268"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_sv_SE.png"
  },
  ["59336f78eb1584b92e2a6c85034884b57d17a06b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_ms_MY.png"
  },
  ["5943c2527e2ca38f53799ff4824854203ab2d462"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_ja_JP.png"
  },
  ["59453768c9b0fb16732010e83503c72288f25909"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_es_ES.png"
  },
  ["596305bab654d86cd206764f250049009eb32039"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_hu_HU.png"
  },
  ["59766002a5326d2fb246a062a1237d99c5643f27"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_vi_VN.png"
  },
  ["59807c9082e2a7e08e6dd90953f6eefc22621400"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_ja_JP.png"
  },
  ["5998fe689ab4012f06812ebe4c4134087be48338"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_nl_NL.png"
  },
  ["59af7ef1e5d39af53706761baff09ddd8234b2b8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_id_ID.png"
  },
  ["59e5387bc04f007f8a64a718aa3079b5b73373e8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_de_DE.png"
  },
  ["59ea31d39603bfefe5491e80b2b0764c76c344e5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_tr_TR.png"
  },
  ["59fa22faf653515393836c2994acf655468764d0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_sl_SI.png"
  },
  ["59ffdb59f0cc875cd8e687eb8f3b8f99af1c96ae"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_fi_FI.png"
  },
  ["5a12c850272a07f2243dbdcff3224ace00940243"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_ko_KR.png"
  },
  ["5a334a9a913b600dbd0e8e8f26a3f022b1a5c33d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_ar_AE.png"
  },
  ["5a35a987a9cc17cc4996003c8cab1a27aeebe979"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_zh_HK.png"
  },
  ["5a44eb290e86684e4b541b0f12c98895896065ce"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_zh_HK.png"
  },
  ["5a5686596ca63aa14c1fe20975e693f005605129"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_no_NO.png"
  },
  ["5a64a78304699966d4479fa4e9b0a86b91a40f3f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_pt_BR.png"
  },
  ["5a7661f3541a9431148dec9396303af7aeabee80"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_id_ID.png"
  },
  ["5a96065650728c5e41bf5242a14e5e3b12345165"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_hr_HR.png"
  },
  ["5ab020e4715755d4efc38d374098241c277efbec"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_sl_SI.png"
  },
  ["5aca23f399ba5e9e843c7c04d948729e982ae0c2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_de_DE.png"
  },
  ["5adb10ca1d9f21927f0ce79a01394a8bfe0385e8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_sl_SI.png"
  },
  ["5adb1fa00a5de2333fea9feafbf86923929a7027"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_el_GR.png"
  },
  ["5aeaf6e0ac5cdf37014b96888529be7b4291bfc5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_ms_MY.png"
  },
  ["5b0a0416c18e1b41fa60fe161a8bef71633795e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_hr_HR.png"
  },
  ["5b2110413fae17e6d18e5c7423013a032b44fa7e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_ro_RO.png"
  },
  ["5b63a987d24a6c4881150a49d78386ce36ef0c8b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_fi_FI.png"
  },
  ["5b87c92954848858cd30ab8db5127acb3ebdb297"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_fr_FR.png"
  },
  ["5ba084dc4ffcd472bd8bd5c094acc5e3647b7d64"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_ro_RO.png"
  },
  ["5bb636c990de554c1f4934627ebc39e3158c95a5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_en_US.png"
  },
  ["5bc203df9532f720597ad9ea7ee9bdad1730713d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_zh_TW.png"
  },
  ["5bd5a67a8c4b28dc7272d3adc7409075095524b7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_id_ID.png"
  },
  ["5bd8a78a4c6d81c3ad1c7feb1ee3765ec5dd4c10"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_es_ES.png"
  },
  ["5bda1065f5032dc1b52be47705eb785c7c76ee52"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_el_GR.png"
  },
  ["5beae99c85fae16fb4c93def4c2be6fd78ec6def"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_tr_TR.png"
  },
  ["5bf3cd92e5746bbb7c3a6ada54c49720f1cf0fc4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_zh_TW.png"
  },
  ["5bf7e35427e7d8bc8f086ffdb11b4f6011d4bf36"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_bg_BG.png"
  },
  ["5bf94fed1c71c561bdc3ca0d4ae5c1a8ad971563"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_th_TH.png"
  },
  ["5bfb31f143035a71448f6bab285172a37b692275"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_ar_AE.png"
  },
  ["5bfba94f2c60194898e71932eaa263fd10822569"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_en_GB.png"
  },
  ["5c1ddd45ce0b210538f1025fa34f07f68bfaf3d8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_he_IL.png"
  },
  ["5c50c70ae45bd2c7d3b59cfa09e6d84b3ceaa9e9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_en_US.png"
  },
  ["5c5b7142ac2dd5eb5ae4140b62bff13dc5ec3327"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_hu_HU.png"
  },
  ["5c6697f66f9fec339e93ddb712caa1c0f69543c3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_sr_RS.png"
  },
  ["5c74a84d4ec3d5567c665ac80f7c3ca6e439ef7d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_sv_SE.png"
  },
  ["5c9bbc873464610e035de5bf0a66e6e8c166a210"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_en_GB.png"
  },
  ["5ca95f664d251ab7a570c696397831c93c55c21e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_ru_RU.png"
  },
  ["5caf02052d46989b1110950ef394dbcdf31cd572"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_th_TH.png"
  },
  ["5cd2e79ed86c9153639bb2636b36cd75ff2dc1fa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_sl_SI.png"
  },
  ["5cefb8945f082f85454c43de3fe5abf49d97a72b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_sv_SE.png"
  },
  ["5d2118e85a29039307a69a887a9f9aae9dd7face"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_sk_SK.png"
  },
  ["5d2677256d45603c68d06be365f33ece9562a127"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_en_GB.png"
  },
  ["5d80a459aff1fae807ee233176d22cb07985368a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_sr_RS.png"
  },
  ["5d90ec2facabc7a19d72ac0126945171193a4a75"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_sv_SE.png"
  },
  ["5dc1da32818017ae6c75fcc16152a7d3d1a793f3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_ms_MY.png"
  },
  ["5dd1202144d7126c260ad4d3927fba3d0406c9a5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_no_NO.png"
  },
  ["5de820f3730e590197f0d30fa28c9460debf1954"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_el_GR.png"
  },
  ["5df161cb53a80ac64c45629bccff214c6cdd580a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_sr_RS.png"
  },
  ["5e0b58bfe10d611e80e71eb1868534da6118a72c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_zh_TW.png"
  },
  ["5e0c125bbaf7f383f88e1a279c5c71362c11e9f3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_sr_RS.png"
  },
  ["5e0f4419aac3ace5ad724f6feada917284444f5d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_hu_HU.png"
  },
  ["5e10594dc7291e51bc48cae2729b54833c799b90"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_el_GR.png"
  },
  ["5e1d2e0c1a4b2e06c191d480e0e0d96a506ba191"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_uk_UA.png"
  },
  ["5e443f4ff5107cd928efe73ded199a8e0e314909"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_hr_HR.png"
  },
  ["5e462b6580c5da91a4219ec3071e4d705a8c636c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_fr_FR.png"
  },
  ["5e8ccbd8a45ef138b2da0f8fcaf62302e43fe475"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_id_ID.png"
  },
  ["5e9bd3ad9a78afbbc5085c3c9c0b985c639e118e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_uk_UA.png"
  },
  ["5eb9fbc43cd2101c1f6e5571f06c14c71771705e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_nl_NL.png"
  },
  ["5ec5c5b5052c52bc674522e789367ad943669b36"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_pt_PT.png"
  },
  ["5ee36dc5f83cefddc167b3bd32fdcd4937933665"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_uk_UA.png"
  },
  ["5ee94f1e09e990abc53ff477b4e55113731359b8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_en_US.png"
  },
  ["5eee5cc470f6856f8affca3ccf4687decbe76c1c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_nl_NL.png"
  },
  ["5ef330d8b1c62748c3b11d07b8e67f30f6daeb40"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_es_ES.png"
  },
  ["5f07ef447ddfe93be44b5f0c9ab84ebb09f290b3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_sl_SI.png"
  },
  ["5f2ae5f08cc1213cb3fde122b3c52dd25d18fde9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_sk_SK.png"
  },
  ["5f2d68abc67b421aabad77de45ebb490a4424f12"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_sl_SI.png"
  },
  ["5f3c51c049e9c2dbd6b3dfc7469a4d3df4fd60c9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_tr_TR.png"
  },
  ["5f4433d09dd4e1928fd6798a646afdfdf9f09491"] = {
    assetType = "image",
    destination = 2,
    path = "Images/CloseButtonDark.png"
  },
  ["5f5d7cf27fc45438977ef09d67800e376e85d031"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_es_ES.png"
  },
  ["5f5f1c9ed51cb2b48d3cc54d6a242d11c4b130e1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_pt_PT.png"
  },
  ["5f630d4a5df7ed274634b91fb739a56662e5fef1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_cs_CZ.png"
  },
  ["5fa434d1a9d4fb1d26c04b26636461bfef637bdf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_vi_VN.png"
  },
  ["5fdb4a8c7fa1c3e997b30c7169a4d530c47ad003"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_no_NO.png"
  },
  ["5ffcdde025c6a7a1e9a048f99ff2b5cabfb17163"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_el_GR.png"
  },
  ["600da592c5df3426fc615d71cfed26abd69d0fff"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_cs_CZ.png"
  },
  ["60189145bb7bb0132eaab33dc3941f433243822b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_hu_HU.png"
  },
  ["60191665312f8603cffd194052e5ab31ebaaa909"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_ru_RU.png"
  },
  ["60772d66d197aa9aa7ffc6e3226efb087920c516"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_fi_FI.png"
  },
  ["60890565572481bf7c215fad3804187a027c9dd7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_no_NO.png"
  },
  ["60b44a54ae6a3f6ccf7867e283bc5ba07bc0aec5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_hu_HU.png"
  },
  ["60c1d7d4e2b95dd0b08d4117bdca41cd52aae5e7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_sv_SE.png"
  },
  ["6115d66095cc5435adbbaa7dce5f02e4fd2cac2e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_fi_FI.png"
  },
  ["6125745724f93736be288964b89af7d56bd9127a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_tr_TR.png"
  },
  ["61332d92d21c91c4801a5597b7fd48b4cae2fe61"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_hr_HR.png"
  },
  ["615d5c117bba1b412f54677b09c2a61d3f7ccd26"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_it_IT.png"
  },
  ["6173bd4eed90fc65fcdc874b03fbde078785b6c2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_it_IT.png"
  },
  ["6198745d88c5e5d9cc498309b075f14bdeba8255"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_he_IL.png"
  },
  ["619a7f5fa632305dd41d063c9bf84bcd9ae8a458"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_id_ID.png"
  },
  ["61a54fe3b798ae7963add6b5762ed075ee64c8c8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_de_DE.png"
  },
  ["61d9b0db1f6682f480a1b84ca8c872b97e658ff4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_ms_MY.png"
  },
  ["6201ff3bce8024c194e667a50481955f88f89a9d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_ar_AE.png"
  },
  ["620539eb24893aed435c721994fe9ad416401c41"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_th_TH.png"
  },
  ["622053ff125749d9beced3b101613892e3575c78"] = {
    assetType = "image",
    destination = 2,
    path = "Images/gearshiftdown.compact.png"
  },
  ["6251b3a5c8c9d37b0e2c21c46d7a57887f26c334"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_da_DK.png"
  },
  ["625f8371152a339bc50d524aeee143e9575795d8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_he_IL.png"
  },
  ["628006c6f2f8b3f9b738bf795a3565a7abb97365"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_zh_CN.png"
  },
  ["62c0250900a15187e3b66443a0f5870bb6f8ab2a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_uk_UA.png"
  },
  ["62cb9e3526705a6f008b86b5c7ca58b274ded441"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_hr_HR.png"
  },
  ["62f632708d2f9f8526a36add240513ff645b8f6b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_zh_HK.png"
  },
  ["6318740da945d47e9d2886e67ad7c395045e71fe"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_pl_PL.png"
  },
  ["631c1c9ba8a0225f3d09cc5b2ef6fb7c9913080d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_fr_FR.png"
  },
  ["6321536365230b6534228321fdc18cac9f3bea12"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_es_ES.png"
  },
  ["636b6aefb071d5b8737beb83b9e447a1f6d11452"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_id_ID.png"
  },
  ["637004a2dd61764cab8b19588c6f03df83e8b861"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_zh_TW.png"
  },
  ["638a2fc7a9122f357b630171738df936a580e0d1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_cs_CZ.png"
  },
  ["639e4c8c78ac1829f518f50d72682da8c5990f8c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_sl_SI.png"
  },
  ["63ba5bd6a28a0c293ef1f3897b9877b8636bf6fe"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_zh_CN.png"
  },
  ["63da7f8c2101c25f5b9cd9864f390170753f2ef7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_ko_KR.png"
  },
  ["63dbb112d574aa7b84d4859b64605cd803864710"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_no_NO.png"
  },
  ["63f5b18f99fbd5d930cbc89a113baaecf7e80767"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_cs_CZ.png"
  },
  ["63fb9cb748dab6b85bf8a16b238c90abf21e7615"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_de_DE.png"
  },
  ["63ff76f37f626dbbdac6dd71c3e8a046879679d0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_en_US.png"
  },
  ["641fef635feb3ad24c0ecf048e0a81a2e7908e5f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_fi_FI.png"
  },
  ["64300134a70343df484e69d0008b821e9eed2212"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_it_IT.png"
  },
  ["64539318091adcebeeaa048c8f5eef2e418c4eec"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_th_TH.png"
  },
  ["64668ff96ba5b43b18e982e2731ba558cf653a2d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_zh_TW.png"
  },
  ["646bb8bd338a3f97f7a8563d40371452544eb870"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_el_GR.png"
  },
  ["647b207b5e784ae1739fd23a890edc5dc7ac74ab"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_tr_TR.png"
  },
  ["647fb0c65978d71e6dc35548a8517332a4e7892a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_pt_PT.png"
  },
  ["649a7908a93a7f6eecf8221f2de94c31924b5be9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_ro_RO.png"
  },
  ["64c968b30a4f3d814d7cd42aa6368b806c2b3324"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_sv_SE.png"
  },
  ["64d57ce3def04ee69c552f55fee4afa9e14951e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_nl_NL.png"
  },
  ["650b5ad6c305960e86261338862492650efe6d28"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_zh_CN.png"
  },
  ["6517f240a9d86c638481e07ba1675fe05f9e86c8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_hr_HR.png"
  },
  ["652897440e5598936fc3c15415bcd54106a6220c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_hr_HR.png"
  },
  ["656e18fc60164666d99932de04cd5c8fb11371fd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_it_IT.png"
  },
  ["659447b26af4f039c3db22680631b7ee3a30e540"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_es_ES.png"
  },
  ["65a6cd152ee51c50615ab926d6ad9480633268c2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_ms_MY.png"
  },
  ["65aa84ebef98728ad964e9342988c87ec2e98b50"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_he_IL.png"
  },
  ["65b9fb4bb2e32ad82c8bb39d7069c054bd486dcb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_fi_FI.png"
  },
  ["65bb07ea073a647fd06a58a9fcb2303607ea0bfe"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_vi_VN.png"
  },
  ["65c5ec278ea9bb8cf856b2a2a31c798ae744e9f6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_es_ES.png"
  },
  ["65eabbad3ece78cf666efd8fd7d2d9a96c8ccf4f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_vi_VN.png"
  },
  ["6620ac2fdee0ec5e2636d108379f2143744b33ad"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_zh_TW.png"
  },
  ["66271011334bc5dfae55a1acad2caf03d2475da9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_pl_PL.png"
  },
  ["663582eea8dffbe8ca12d5d1147feb228eef3847"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_zh_TW.png"
  },
  ["6638ea77aee6748f39aa1955349a8a0640bafb8b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_ms_MY.png"
  },
  ["6668ae0a205c1054a6cb9eabc6edfe9bf0de41a9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_pl_PL.png"
  },
  ["669ddc665e1359c81b2d44f0d28a389985363f29"] = {
    assetType = "image",
    destination = 2,
    path = "Images/fuelpump.arrowtriangle.right.fill_body.medium.png"
  },
  ["66b005bd0b0ca4a7088b0626e924028147a0e367"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_ko_KR.png"
  },
  ["66c7375dde87ca30400c9b6430cb938da6552dc9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_cs_CZ.png"
  },
  ["6718ef4e6396f6d12b6763b019034e16ac0c0fd4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_zh_TW.png"
  },
  ["6729f6f84f767d2e667b6ca20c1e412ad7633032"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_pl_PL.png"
  },
  ["67572e570ba4ed30d42801fc3edf9eead50b4183"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_vi_VN.png"
  },
  ["67579476617d78a78df723e8e3668c9103ac2086"] = {
    assetType = "image",
    destination = 2,
    path = "Images/FocusedCloseButtonDark.png"
  },
  ["6785b567e0e45416d375d68df825a8c267327727"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_pt_PT.png"
  },
  ["67913b0625caa5817dc255080f8b9fe335e3a8de"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_no_NO.png"
  },
  ["67a79c2763d83d61be1274189632e9b01389b41a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_sv_SE.png"
  },
  ["67c9e9bdc73f3297175e623c85243e71b1dbe368"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_pl_PL.png"
  },
  ["67e28fb4b2881a38c05368d0e720a078f66432bd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_bg_BG.png"
  },
  ["67e7a251eccc78cd28be1c063ea37678e8db84e0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_ja_JP.png"
  },
  ["67ec836df2b65ec6b878988a068735df98448f8e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_pt_PT.png"
  },
  ["67f0657a0681b638c1a9205027af36e7b8dc536f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_pl_PL.png"
  },
  ["6837147ab0a61961d86144b5d3859659cb3e96bd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_fi_FI.png"
  },
  ["68547a714ce901ef3742308bee8617c7a4c17148"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_en_GB.png"
  },
  ["685a731bec6269891c0122380e30e025b75a52c3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_ar_AE.png"
  },
  ["68c8f6a35af8120da13c8b3a7e239a8cd282a418"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_uk_UA.png"
  },
  ["68e446a6f992f64721f62d99489ee157cdc8e7e8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_zh_TW.png"
  },
  ["68e8d6f50427380d33c05f611306931960962c51"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_uk_UA.png"
  },
  ["68eea2903646b112c29fe60ba1fff8709002edbb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_nl_NL.png"
  },
  ["68f535266a989d1d86d7094cde090ad30c5c5163"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_sr_RS.png"
  },
  ["68fecd43ce2573d1e1bfa772fab831ad1a75a887"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_sk_SK.png"
  },
  ["692308e03f9a5837469a7cb5ac481e1c85abd5cd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_fi_FI.png"
  },
  ["692323f993bbbe83c43133bbd381bf543310a83a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_ko_KR.png"
  },
  ["693b631b7ec333060fb7e2806edd31068626e01a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_no_NO.png"
  },
  ["6947fd0afe90174fcd9e5e3ebfa397b41f9095f6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_ms_MY.png"
  },
  ["696e0bdc474ca81a8a85ea1f2ee9397f810c1611"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_bg_BG.png"
  },
  ["698d076c163a9cd43f3cd80d69067d78ac9f0639"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_sk_SK.png"
  },
  ["6996e7161a0ca9e21dbde292f5a0a4214a76b0f2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_el_GR.png"
  },
  ["699c3be699d0fd0116dedfad67ed20b51ba209de"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_da_DK.png"
  },
  ["69c99571454d69129a7ac524cac33e5d7c0e44f7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_zh_HK.png"
  },
  ["69cfd82fd5bf88507f483f5b5851264f168d7209"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_no_NO.png"
  },
  ["69ecb36802273df8a60c910b339fb2dd58521406"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_uk_UA.png"
  },
  ["6a3d301468fdc6cf7e4e2f9b75f4ae37c6095391"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_id_ID.png"
  },
  ["6a542c01795176d6745f2798ba9fcd7c49395560"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_pt_BR.png"
  },
  ["6a9cb948fe5659471638d2e2967eca9d335eda9f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_ar_AE.png"
  },
  ["6aa17d2f75affd713d7b295352b0d350f1652d4f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_uk_UA.png"
  },
  ["6ab2c27fa16bf9230de450deb7f9b181bf450d5c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_sv_SE.png"
  },
  ["6ac0118598d7145cd61be57186493a425475901a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_uk_UA.png"
  },
  ["6ade84fc64762a36e8f33cd17a4a36aa89235c59"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_bg_BG.png"
  },
  ["6ae69950592e551c745618062fa3aa3686697137"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_he_IL.png"
  },
  ["6ae742f6ade45864ba0e04078aea2bc06dd907e2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_hu_HU.png"
  },
  ["6aef26a9a8cf09dd2da64e0a3994d872ee60d6bc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_en_US.png"
  },
  ["6b071bb72b206ef4ecd5e1a58cb9ce111b8454d6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_en_GB.png"
  },
  ["6b0d9611ba17249eff49c63b403d24f87d441635"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_sv_SE.png"
  },
  ["6b107d31080e0a26cb3efc9ccc03cfe215274798"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_he_IL.png"
  },
  ["6b18ef12be778d8a247dff936a2aa509ccd33bdf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_da_DK.png"
  },
  ["6b24b7db3c459bac197587f8993445b39e59282d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_ms_MY.png"
  },
  ["6b4f1b77deb7614da74666a15fdfbf04db994c6f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_id_ID.png"
  },
  ["6b9df911a22b4ceb4c1bdc4b3adfcd41f065f407"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_hu_HU.png"
  },
  ["6ba81384fc2321fe4e91a236fdb47b364e6c2d4a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_vi_VN.png"
  },
  ["6bb975af7e70a2699b8b51ce3fbe2f5263ebf467"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_el_GR.png"
  },
  ["6bfb743d5b495e357b7950ff0390755900edc571"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_pl_PL.png"
  },
  ["6c149aae9b6898f9ab90442279b05a041714a7fb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_sv_SE.png"
  },
  ["6c1604d6099088294dfc958f8524fa8fcc90964b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_da_DK.png"
  },
  ["6c315ca9271a1e32755cba6a47dab1eef2212140"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_es_ES.png"
  },
  ["6c46ce6dd94704348cdbfa0f124096f992a025d9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_de_DE.png"
  },
  ["6c7bbee303dbc55044a1c8aaee8cc9c0e47725a9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_hr_HR.png"
  },
  ["6c7cd34fa3d49de36735b5913a29f27b3862100b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_cs_CZ.png"
  },
  ["6c9417283e8a9b3e38803a3ec1b7dd27f35c2040"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_fr_FR.png"
  },
  ["6ca3db07f6f53bf554472800f99a543886d60dac"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_hu_HU.png"
  },
  ["6ca5b966998b4d93613f08759be9f6de57ddb700"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_hr_HR.png"
  },
  ["6cb9abeb142d714489f5a6ee8cac357665b2b293"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_he_IL.png"
  },
  ["6cbac4452783dc22c2cd2838dea310d035ed1269"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_pt_PT.png"
  },
  ["6cc98260190d3f30e5af03db8e0664fa5e8bc78e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_sk_SK.png"
  },
  ["6ce1cbe5c549a98f30d108c977bf1e2da879d30e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_zh_CN.png"
  },
  ["6ce96e019bb52ca09219d4f46f34c79540180ecd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_he_IL.png"
  },
  ["6cee28e4dc7120d3b47324040939d41944434ca9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_de_DE.png"
  },
  ["6d30a4cbe57c52a21488f46ead2d5194b1ff195d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_da_DK.png"
  },
  ["6d4f704b34f53f9aac70d7fb2e43898c651e5aaa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_bg_BG.png"
  },
  ["6d5a72ccf666d1e11a4f5f957ee1644a5ba9ea80"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_ar_AE.png"
  },
  ["6d63a67cb51893713f57c68ef1cc08e84b92dd57"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_cs_CZ.png"
  },
  ["6d8481a876e741ceab7b4d9931d6ac5f3e1afada"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_hu_HU.png"
  },
  ["6d8c099d9299f396d837e390f1097cbd13b38f21"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_pt_PT.png"
  },
  ["6d95226382ecf206bd289401326d05dc1d140826"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_th_TH.png"
  },
  ["6dcc899d0bc56b09a7f99fabf5f88d4f53851611"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_pt_PT.png"
  },
  ["6de1f9d09cd787522a38ff89352b3a60927f1648"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_cs_CZ.png"
  },
  ["6dfb7f78eee8c59e256d8ed3e6652ab1bbb019d5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_bg_BG.png"
  },
  ["6e052fbddacba90b7a14519fe01b6d66598e07dd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_pl_PL.png"
  },
  ["6e16060782eccf9de08d2e7f770df1104a48a795"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_sl_SI.png"
  },
  ["6e25a2b4499c19e418b6a62126f6c4a43970b2cb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_uk_UA.png"
  },
  ["6e2eb0f4e87292290132598f8c00abb5c084f30e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_zh_HK.png"
  },
  ["6e314076310bcf0a9983075d95598f14f086b160"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_nl_NL.png"
  },
  ["6e447765594b996554043bffd58aa40f4157f8cb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_sk_SK.png"
  },
  ["6e57de16bc5ec474e37f5dee99c28ced39ea6cf1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_sv_SE.png"
  },
  ["6e588b0eccae1f135a405da0196d4ccecbb9cfd8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_ja_JP.png"
  },
  ["6e5fc82b213ebfe29b72f5b552bcf92a081fc3dc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_sk_SK.png"
  },
  ["6e60f60e9fa2892ad3c2168e3e1d9e4cd1090169"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_uk_UA.png"
  },
  ["6e74bcdda73b85df90d8d44566c8a3e60713cb56"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_id_ID.png"
  },
  ["6e9d76c1be4894cd7a6eac5d4633b21ac0136e6f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_sl_SI.png"
  },
  ["6ee0ecf8feb0ba96688d938fd81212d627687e15"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_vi_VN.png"
  },
  ["6f04fe6ee85232ee0ebde0947f7b8d8a8d7d8037"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_it_IT.png"
  },
  ["6f0d106a1b50942484ddd5474d6af34bd76c34d6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_sr_RS.png"
  },
  ["6f14b9e9d8b6ae62c9060f06167dec454743fc9b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_de_DE.png"
  },
  ["6f24cd1e8d02b2a3209d0fe2d0ab054f6b521ef6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_de_DE.png"
  },
  ["6f294097978c48cfd77ccb5f912e98f52dcad3d5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_sr_RS.png"
  },
  ["6f3604fd170038d8f5e7f5849800e915f5e3e2b3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_zh_CN.png"
  },
  ["6f7ef5486a2cf26291ed490fd55b4bb7170d1e7e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_hu_HU.png"
  },
  ["6fe06d255b5f9bdc8022bb099d54675a06eff3d8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_ja_JP.png"
  },
  ["6ffcb4be1cadf36ab7aa4836c5219f8bd127d93b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_ro_RO.png"
  },
  ["700e226ba0900e996c90f629abfd45dda0a6aa21"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_da_DK.png"
  },
  ["7019a69726a29814612fc1a80c6dc4c6a6875c44"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_zh_TW.png"
  },
  ["701de0a967151cba0d589b486e4683d749a03a64"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_id_ID.png"
  },
  ["704ec387ce26e8011ab9cf009d5554b2ccb201fa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_fi_FI.png"
  },
  ["7065857e1aaddeb8d00e0a18731543e8d123d47c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_no_NO.png"
  },
  ["7087dc74cbc32507ef7c2a09f278e0984c55427b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/thermometer.and.liquid.waves.hot_body.medium.png"
  },
  ["70af15969e0a4ef2fa9e2c21df15e424173dbbc3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_pt_PT.png"
  },
  ["70b6789688c9c80cf2535f648a9572eb8a0704b8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_uk_UA.png"
  },
  ["70c96a4a06aca0d3165f2a0b21a2c13b143f932e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_id_ID.png"
  },
  ["70e2a0b2e08f12faaf6cb98c6def0444b51e398d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_sl_SI.png"
  },
  ["70f658392345c09436feb6b03049338b71a2a5de"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_pt_BR.png"
  },
  ["71231c705398e1819120ca3f58bb099c535801de"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_it_IT.png"
  },
  ["712e4e53a28010552c48c798327f9a41e8dc7769"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_tr_TR.png"
  },
  ["714f8637c1b39521f67c97fcd462e4282fc5bf99"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_nl_NL.png"
  },
  ["715828f019fab7c67e8d110ea799c929f59733dd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_hu_HU.png"
  },
  ["718946354d68d468fb7a3c43b30a34368c924e9e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_zh_TW.png"
  },
  ["718984993824e6c0fc3aa2de08d09842db52cb94"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_de_DE.png"
  },
  ["7191fc78a9e496287c777c44a5980741a50a504a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_pt_BR.png"
  },
  ["71a32e26b699b3dc6980be037dc1a4bbad6623cd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_ko_KR.png"
  },
  ["71af167d5a1085ad0b2b7cc7930e174f8ec7d314"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_no_NO.png"
  },
  ["71b7412534544d21100e37be4e64590d47e9b282"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_vi_VN.png"
  },
  ["71c92472c1817351b416d1c2ecc3ad4296cac4db"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_ko_KR.png"
  },
  ["71cb7cddce293b26c81a720ffd88c382ef1dbc1c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_ru_RU.png"
  },
  ["71f5f7eaa381bb2dd1bb767e5db2e77e6896d5c9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_pt_BR.png"
  },
  ["72069562d9e1f30fc4f2719254ff83ec251604ce"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_ru_RU.png"
  },
  ["720ee6f8cc3c98952178b9c43a361fcf67df3242"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_fi_FI.png"
  },
  ["72184a7d9873dc7f307cadb72f80bd996f4a7be4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_pt_BR.png"
  },
  ["722a7adb90670b7733931e608daae666295c7905"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_uk_UA.png"
  },
  ["72545d4cd943be7c8c172d6fa7b00311153ef4ad"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_zh_TW.png"
  },
  ["726409ec93f5213bc8fd2da34ca57770bb257a00"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_sv_SE.png"
  },
  ["727dbf5193485459d5124c1faa0e498e837f000e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_pl_PL.png"
  },
  ["727ebdbb9531f454cb844864b364245a3d39c611"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_cs_CZ.png"
  },
  ["72946cd04feed46bd9438ec8223c982b71f3f4bd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_sl_SI.png"
  },
  ["72f014d74912d5bc4aadd2f3afc6f932544ae1f6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_hu_HU.png"
  },
  ["72f0c6ea47dcae43043dda25c74c8e63b5a82a50"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_hr_HR.png"
  },
  ["7311ad3bb489cd7ddb78bfd9a2eaa671fad1eed4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_fi_FI.png"
  },
  ["73175c88100c26d739ac354699c148bbc3a5974e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_fi_FI.png"
  },
  ["732791a18a55d3c8c4e221b22bbb3fa4489a660d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_bg_BG.png"
  },
  ["732a4bcec1c38f1e7faa020fa2fa93bab0cb7127"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_pt_BR.png"
  },
  ["7365d855182ad03a6f860f4c6f2685db76db455a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_pt_PT.png"
  },
  ["737eccc005877ba33a722d3fff5738703716f62a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_sl_SI.png"
  },
  ["739f0331a75e726d61d7df774f0e1e3b8d8c11fc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_ru_RU.png"
  },
  ["73a696750c64844aa99544c39cf07f59cb9c534a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_cs_CZ.png"
  },
  ["73bcb16260a7fbf9174ff60cb6bec5fd5b67b428"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_nl_NL.png"
  },
  ["73c4d43ae977c48d95ee54a972fea960ea13b665"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_el_GR.png"
  },
  ["73c91df57ef062abd4788c2611f72568ff244c73"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_uk_UA.png"
  },
  ["73e623ba4fbf1ab07c9f3383084475a7345e32e8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_pl_PL.png"
  },
  ["73ec5d0266eb14ba2800412bbdd4db1e73d233b9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_ar_AE.png"
  },
  ["73f6426bb21829aead1243d562b55f7d20ca2988"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_fi_FI.png"
  },
  ["73f6ca80cae4183d46c359d47a2e2bd940d93632"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_ko_KR.png"
  },
  ["7421d7c7e042b5de08a9944364b6c6f25ae353b7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_de_DE.png"
  },
  ["744cc39c8271d29a4498fe5e273dd51cedd90485"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_ro_RO.png"
  },
  ["744e9360930cb82aae3bb268297fc22f115542fe"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_zh_TW.png"
  },
  ["7453a0a6c53d167c7dfcfc0b832ca901cbc7cb16"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_uk_UA.png"
  },
  ["74628e1f0e6448d7225224579c069d739385a455"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_bg_BG.png"
  },
  ["7467a7502fece24d339c0a6b598add36740b08cf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_no_NO.png"
  },
  ["747b418104b6d523de6f2276a187ab890ccd8366"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_en_GB.png"
  },
  ["7491cd1cdc5552ba57c59ca8379df8b87678105c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_tr_TR.png"
  },
  ["74b86ac3b4639f37e5c0a160abe13683e58f7cc2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_ko_KR.png"
  },
  ["74c60f9d6c467b2333a22e23622bdc686a5c0afa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_pl_PL.png"
  },
  ["74cb945270fc03ae878c8769153caea85ed4e15e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_pt_BR.png"
  },
  ["74d446d071607945512e084612797e40a41a8fb1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_sr_RS.png"
  },
  ["74ed0e20c9202908feb8c0b64d78ed507c491f4a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_it_IT.png"
  },
  ["74ed98ded67d8c4bdf371adc77ef6dda8f144afd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_en_US.png"
  },
  ["7506ccff3861fb1c317af48a9b6d61f11a4880a8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_zh_HK.png"
  },
  ["750baa0231a022ef8bc9fd9b9f30d6e41aed6c34"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_es_ES.png"
  },
  ["7524143c684199afee4dbaef4327375f2d58322c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_zh_HK.png"
  },
  ["75869c9d266fa82e6cf5e38c0ee718b65daf6d74"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_bg_BG.png"
  },
  ["759881309084bb1ba356b8ef38953524ff652dac"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_pt_BR.png"
  },
  ["75beb7f79213ca987bf94f7c4eff62527168a741"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_nl_NL.png"
  },
  ["75e8257f21864fe6f7d0230cb3b54643cec38299"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_ja_JP.png"
  },
  ["75ed5462da62f0700641ba10e9613816bbe5586a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_uk_UA.png"
  },
  ["75f82fd66a2f9ee2673b19666e6028fd46e2fd9f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_fr_FR.png"
  },
  ["75fffb030470cc8f01739b1a0bd4e0ab70f9d28b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_el_GR.png"
  },
  ["760cdb3c76770dab923b52309fd2a3d81ac1010c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_zh_HK.png"
  },
  ["7636931a1c06f8eea4617042255ac7836789fca6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_zh_CN.png"
  },
  ["76379892b4c195b5833eca5c296b37571f018536"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_he_IL.png"
  },
  ["76c4937913d665a0c5b2281832e23e1843c336a5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_ms_MY.png"
  },
  ["76c6cf198191baf37b086ae29a259ecfc336a17e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_es_ES.png"
  },
  ["76cc7a15ab1ecb2e2f20fda17edf14b6376b5e2c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_tr_TR.png"
  },
  ["76f56ccc1e424ad57574e5439f242754869409b3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_vi_VN.png"
  },
  ["770018187ccae91911e8af35957d1ec5bad81956"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_nl_NL.png"
  },
  ["77092c046c63d8cffee2a3334d36cb38ba929fa8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_nl_NL.png"
  },
  ["77104d2a07e5874f997e021dde7d5b55b37de828"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_ro_RO.png"
  },
  ["771d668ea8161a81b1b9c74f18239000214d1425"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_en_GB.png"
  },
  ["772cb55171883c50bcb245f446b5efe5a6aedfaf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_de_DE.png"
  },
  ["777576ce753e1c5cff97b5a65081d9dea876dd09"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_pt_BR.png"
  },
  ["7776f96d3bbcdadb18db2a94d31d4c983884056b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_vi_VN.png"
  },
  ["77784652a4ddfacad8564aa48dbbc34c8bd88113"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_ko_KR.png"
  },
  ["77cbbc5acf463d1eb8e5c60706acd9fbadb2841e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_en_US.png"
  },
  ["77e5dc71d8a6ad919218e48572634634f722ab40"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_ko_KR.png"
  },
  ["77e774dff9eb9c75c89f7371267018b69063d547"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_pt_BR.png"
  },
  ["780e90ab8af34dbb3d147eec514d06c36fc179db"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_vi_VN.png"
  },
  ["781021007d5999bf2ea67e25b24c83d7e0d192a1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_pt_BR.png"
  },
  ["7814a5327156f75ac67be68befd2d27a4cbfc141"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_sr_RS.png"
  },
  ["781f520ff8555cec4972e9fc78e45ab9a0dd3cbc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_es_ES.png"
  },
  ["782adbce8f6c3ea046bf0a67bbf16ef712e3a7ab"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_sl_SI.png"
  },
  ["783086216ef167f4d7f7e11762b5e2346665a1ef"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_bg_BG.png"
  },
  ["7834ddc3cab64157210649f8e7f5b907efe13989"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_sr_RS.png"
  },
  ["78447aceaa6dc13449a6de3e3d06d38270e8c523"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_pt_BR.png"
  },
  ["7868a8fc57982a2cc0636943e64e6345faf1277c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_he_IL.png"
  },
  ["78884f499d8c3644e368f304c6689c0f35acb541"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_th_TH.png"
  },
  ["789b22cd1700ff4ac15c8f67409a7b47eab75ba9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_th_TH.png"
  },
  ["78b2f0cb8ae41064a3fde119b96464c27451e504"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_no_NO.png"
  },
  ["78bbeab2ea160407caa7de1d3e213a699aaff449"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_id_ID.png"
  },
  ["78cb342d20d5d049c856e17fc335a77cd6711bbf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_bg_BG.png"
  },
  ["78f75d68fec6842eeac24778032de2218b0413f1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_sv_SE.png"
  },
  ["7902b14f3e66aa09634b711b6d80b4fe4be27508"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_pt_BR.png"
  },
  ["790353bc4bcc24f779051e8b167d4d26305c569a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/fuelpump.arrowtriangle.left.fill_body.medium.png"
  },
  ["7909575b1ccd0b88e3ca39ce9e1510a8c1a2b27b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_it_IT.png"
  },
  ["790c2467dad75328b46959001db4872d5f83936c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_hu_HU.png"
  },
  ["79226ba99d35332dc891ee727fbfac4c50d4b427"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_uk_UA.png"
  },
  ["79945313f794c2b71e21d65a1eac34036aa8cb29"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_es_ES.png"
  },
  ["799a1329f0e9a35bc8a40daee08ad39f58cb95fa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_tr_TR.png"
  },
  ["79abf6d4048b25ed31923553429fe554dddaf426"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_ru_RU.png"
  },
  ["79d29c3be05e4642b969230c80e9de5f4497fd50"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_tr_TR.png"
  },
  ["79d632ecec96abfef5ccb05c1654969ecafa633c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_hr_HR.png"
  },
  ["7a03151eba1cbd3ffd1644c7ce7b0902c4a9eb5f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_hr_HR.png"
  },
  ["7a17aa3278816f6f4a68c45c9ae4df37b57097d3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_zh_TW.png"
  },
  ["7a1ebe66bfd949068cce3c677ed99b7d7aeb55e6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_fi_FI.png"
  },
  ["7a2e87ae57678a9ef12050f8948ea09b6262c523"] = {
    assetType = "image",
    destination = 2,
    path = "Images/Shadow_Bottom_Edge.png"
  },
  ["7a383f16608ff112953cd14ccd7a2014bca34b47"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_tr_TR.png"
  },
  ["7a42569c8e91d76f5625cf14155f5ffca317ef1f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_pt_BR.png"
  },
  ["7a45345c788cf47967e2a4e71d37a6671bc9cdf9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_th_TH.png"
  },
  ["7a56d70dcb097dac6b966603ba854625fab25b7b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/gearshiftup.compact.png"
  },
  ["7a5ac1be5dea3945ae00d02e22ad80bd25ccb8f5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_ar_AE.png"
  },
  ["7a7346b786d646b3ac1fffadd266b636253664d4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_fr_FR.png"
  },
  ["7a95960451a593883ea918d5e17a6aa4579f4450"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_id_ID.png"
  },
  ["7aa98b61e1d4eaeac1e9fdc8a1aa8b81831612ff"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_hu_HU.png"
  },
  ["7aaba78f60784bfcf3db121bef097454c474e07a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_vi_VN.png"
  },
  ["7ab0a9f9812239886929307e9044825007324c82"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_hr_HR.png"
  },
  ["7ab301182ec3c808a91b736881cf0614afb75c4c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_sl_SI.png"
  },
  ["7aba7afa72cf9d767e1839fb2431dde1be270c82"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_nl_NL.png"
  },
  ["7afa29dcfc91e3166042886af830c5ce97aa679b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_vi_VN.png"
  },
  ["7b011c1de105705fd944ce539be559ffa20984d4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_zh_TW.png"
  },
  ["7b0d16b782f52b6ec19233d182a27f1510a4d735"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_ro_RO.png"
  },
  ["7b1810fc6347086852ec55e1c96496562a064dbd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_ar_AE.png"
  },
  ["7b47048e7bddfb9c614ec8eb92969a89b20ff218"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_bg_BG.png"
  },
  ["7b47dde2c1af4e70821d685e231d4408d74f954a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_es_ES.png"
  },
  ["7b4fa0ad3b46d70c5c4a6cef934639128bf619ca"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_ms_MY.png"
  },
  ["7b7ab95abda614a1b8cb9c06a1b5dd61d39694da"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_cs_CZ.png"
  },
  ["7ba9179a3d3757a6d688561165cd02c9298efc92"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_hu_HU.png"
  },
  ["7bbca9dbd4fe5f444286a011bcf24380bd0ab16d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/decorative_rpm.png"
  },
  ["7bbdb2d1127edf8b3bd96befb54b5f643feb0a82"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_zh_HK.png"
  },
  ["7bc1689e6d291f3a821356151bccf6a0b29ac70b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_ms_MY.png"
  },
  ["7bc3e5c5c6e886eb11eff42311aafb09e25936cf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_ar_AE.png"
  },
  ["7bc8fa6019c03570b3d7dc4e3811afe78748d411"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_ja_JP.png"
  },
  ["7bcbb12d23e8fe5edb58cef9f6418946fd7ea956"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_fi_FI.png"
  },
  ["7beed8cf8ca02b421ba1c2e3915bc10b3b6e12de"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_fr_FR.png"
  },
  ["7bf54fea24c415037f341d418aa268d6d301a326"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_ar_AE.png"
  },
  ["7c3ceff0705379476b1f9f8396faf84b6b23e4c9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_ja_JP.png"
  },
  ["7c682b14be5ccbc4f69f8fe5b3b7b0883dcee331"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_sv_SE.png"
  },
  ["7c814c243f54d7032041b2e5999d6da2bff90df1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_bg_BG.png"
  },
  ["7c85c1b7175b9e5d129bb4f2ae175f9929987103"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_da_DK.png"
  },
  ["7ca911a259446b30f89de9c86927e464519b6180"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_sr_RS.png"
  },
  ["7cd4289f85a38452a969e7ab67a3f5f10b36c542"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_no_NO.png"
  },
  ["7cd4ebce7509a264106f3fbd9e427dc128b713ba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_pl_PL.png"
  },
  ["7cdd06385fa327fdab73d362a9610f3d403f7e72"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_ro_RO.png"
  },
  ["7d040c18cb1c041127b6a5446bbe887010ece54b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_pt_PT.png"
  },
  ["7d090df8dd76b9b169714692fd3fba37500a07bc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_hu_HU.png"
  },
  ["7d0923e8445f67ac70ac76b663129b783fe47509"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_ko_KR.png"
  },
  ["7d3258e4dbf6fe9ab8ee6d1a08a28d31129ba58a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_sv_SE.png"
  },
  ["7d41181ace0f8b840823f526ce1c46901c3a7869"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_tr_TR.png"
  },
  ["7d47b9799f6b41fd82b61c7e2d1ce42c0bd6dfbb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/apple_logo_bootup.png"
  },
  ["7d62c932c10dd4b85d96d50ca693327e509fc73c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_es_ES.png"
  },
  ["7d73f13c1f7e8d4cd0fd76532f7c2ea409b194da"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_da_DK.png"
  },
  ["7d78b2f781d964d9a06a58f8b682bc4d4e6b5d3f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_sk_SK.png"
  },
  ["7d7d0d642773f482864a85526036fa6e9648d961"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_da_DK.png"
  },
  ["7db14e505a907592c911efab6592ad62c5c00213"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_es_ES.png"
  },
  ["7deed9b899c23acfa0f3de61b6637ac12efc79ba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_zh_CN.png"
  },
  ["7e35b17b16dcde70f6801c9c0417f2504116a1e5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_zh_HK.png"
  },
  ["7e3891f77510049643aefbf5d60fa760d8a55f59"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_zh_CN.png"
  },
  ["7e4598ea2f80f1b291f2bbe2122ae05dd60b5668"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_vi_VN.png"
  },
  ["7e680500246f077fa8371bb9f25e73768a3da9ad"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_hr_HR.png"
  },
  ["7e6e59a34b14d3e36f25521b5b7623a2cea83a93"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_no_NO.png"
  },
  ["7e74d74347e4c8b785721218c8179b7d1da46a75"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_hr_HR.png"
  },
  ["7e750e4a578fbb118984089fdb5a47f60bca178b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_sv_SE.png"
  },
  ["7e802e8bc825b37d46611515df72f3cdb3419a6f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_el_GR.png"
  },
  ["7eaa122b39ae849fc621215eecb688a301c27d82"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_sr_RS.png"
  },
  ["7ec22e209a424afcafea82f02c5474344800acc6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_en_US.png"
  },
  ["7ec89a753913897d19a87ef6db371b7074e97535"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_el_GR.png"
  },
  ["7ed443e6001de46b40ee340264eb42c7ece6a715"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_ms_MY.png"
  },
  ["7ed8f8f8ecb3d608c7527c4abbfbb65caa83c5af"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_hu_HU.png"
  },
  ["7f01c8baaf582b7e78a49b349f28269974158623"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_sl_SI.png"
  },
  ["7f1c4abfbdd36cc4551f6b859f06f6cd2840c9fc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_en_US.png"
  },
  ["7f3247df9ceeb69e060560a6c4e051de1b2886ba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_it_IT.png"
  },
  ["7f8fdf89ee787a6a10a312429497227e14970887"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_en_US.png"
  },
  ["7f909a0d319cc05381d28ad3db725478deb58668"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_pl_PL.png"
  },
  ["7f909f7878203ac7bd5bc5406426c907eeac8ac3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_ar_AE.png"
  },
  ["7fb58a2921f73320f89bfcb0dc6353074fd4a3b8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_sr_RS.png"
  },
  ["7fc1c90039bfe4bbd7645bb05a702ae4729d9fc9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_id_ID.png"
  },
  ["7fd851f057ff4a85a710fcb7f944ba88c3299978"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_ar_AE.png"
  },
  ["7fe52ab2478eb30a33b244d8598d7dc8b73e1ae1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_cs_CZ.png"
  },
  ["7fef0c489aef2c76a9eb5c436ecb16201654664d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_sk_SK.png"
  },
  ["801721ddbc0c13a079096ab93fda271fcf57326d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_uk_UA.png"
  },
  ["8020c30a671144e85c573cd3b56d07fb83b701fc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_pl_PL.png"
  },
  ["809e73842eab0ed811147cc1025b90a05321b3fd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_th_TH.png"
  },
  ["80fabe8da16964964055b927fa72cb6f40677d49"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_sk_SK.png"
  },
  ["80fe2ae26cb1bb48db70b3c1945e266819222d84"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_fr_FR.png"
  },
  ["8105538787a098e73e9688a823ae3b488ed13df3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_fr_FR.png"
  },
  ["8144706558cda8d230af403fa434cd6ad73c51dc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_bg_BG.png"
  },
  ["814dea655aa99f1f62e9224499e707e8a31bc4b1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_fr_FR.png"
  },
  ["816919570ce3fd87d5dfc34cdc57106842c632b2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_sr_RS.png"
  },
  ["818d533a556a3b425ad7fc95f2fa9d605a63032e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_th_TH.png"
  },
  ["81a122dc0c0205c6ac7abde6a340166cdc699827"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_hr_HR.png"
  },
  ["81b88c37e7e47fe72ed9b9ee46395f3333809d78"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_uk_UA.png"
  },
  ["81d2c36e0c99574e74f733a57e2f095ea0aa3a80"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_it_IT.png"
  },
  ["81f4636d0dcf35f490db4ed9f4d0c3ff9216a16d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_bg_BG.png"
  },
  ["81f970841834581d95b98337f9b18b96de2cfce2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_fr_FR.png"
  },
  ["81fa21bc19f652d2f030e88f1fb107173e7b71ca"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_no_NO.png"
  },
  ["820174a3def7a11bdf6a793df722fb5fc7357730"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_sv_SE.png"
  },
  ["822b9ceb44a562df9b6f35c5c4fa4072c88b954b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_el_GR.png"
  },
  ["824847f298fc10a8b5b3a49eb85632b39f504ef3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_ja_JP.png"
  },
  ["82598e863a2caac4f5b6035c2252c9d53c481ef7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_it_IT.png"
  },
  ["8271f7da8a393762c65a501a2183f31c7c88e285"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_nl_NL.png"
  },
  ["828827a8c9dc580146075b6d247d70cdfb124f6d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_it_IT.png"
  },
  ["828da7a08ad3c709834ebe7a47afff41469a7744"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_ko_KR.png"
  },
  ["82a13ab4d1ba571c74e8c6885d3f363dad872ec0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_id_ID.png"
  },
  ["82bc319285c65fb95d774b79d66ec20bc8f3451f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_zh_TW.png"
  },
  ["82ee47538bd371a3f8849ad5551816725856b3d2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_fi_FI.png"
  },
  ["82f779ddea092ef61415a0c9a755ef5083ac7999"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_zh_HK.png"
  },
  ["82ffd951253c9e4a8530da72dcdc40f247fca2ba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_de_DE.png"
  },
  ["8324feb5078434a28b35230a0af6f71be56cdaea"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_pl_PL.png"
  },
  ["8345977a7cfe0c8c372e6720f97e76fae630b728"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_th_TH.png"
  },
  ["83672e276d3a4eb93cf39ce646c18d860683d050"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_zh_TW.png"
  },
  ["8390f7a71e04b07e56fdde66afb4560cae03f986"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_no_NO.png"
  },
  ["8395b557f35209139f77a8d59c4352288fc872e0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_id_ID.png"
  },
  ["8395d352f9b13d9f97f21983edb58b95e2e595bc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_ru_RU.png"
  },
  ["839a3a7b94dcdc95d8398a870f0f3cb420c49c3d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_it_IT.png"
  },
  ["83a40fd001ac01077e61fb56b24cc02b1c51a378"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_fi_FI.png"
  },
  ["83d11a71a5e5e794dd3016f3f11a2353e4c573ec"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_ru_RU.png"
  },
  ["83e093ffd6d2b21c0f59e5839dae363757d29a0d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_vi_VN.png"
  },
  ["83f78b82c348fd0a26048a4dc30e14235cb3218d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_el_GR.png"
  },
  ["841171c00f0bbe3ffff1c6f4de31196750e645e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_nl_NL.png"
  },
  ["8422fbeb1c7d461af3f4d1fc7fbcbfaa55e47526"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_ro_RO.png"
  },
  ["842ac0138aaf254a02294936128b41c9f56d5a6b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_fr_FR.png"
  },
  ["842cf9c25e28e1dc49aa8ade556dbb8166f2bfc3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_ar_AE.png"
  },
  ["844c8d3433a617f468b8630727d3fdec2e9977f0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_bg_BG.png"
  },
  ["846b5c239c1e8bdd68e02573e04da47a137a7a85"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_ms_MY.png"
  },
  ["846c32390b7be321caebc67e9b1efc1b33e0c726"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_sr_RS.png"
  },
  ["847ef325489030d3ba6fa172e092eb3cb3ca03bd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_pt_BR.png"
  },
  ["84ac91e443985d7ac2782eaf3f56be53a8e17045"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_en_GB.png"
  },
  ["85087cd8d694f039ca60bbd24dce773ad3b27497"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_he_IL.png"
  },
  ["85227de1a391ce953d6ebc069cfb3648721bf7de"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_sk_SK.png"
  },
  ["852cb4833720f3385199a34b19b498cf08b762ac"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_sk_SK.png"
  },
  ["8536d18e69c1625dedcbf49ee94577014eb966cf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_sl_SI.png"
  },
  ["854014d60d0b1e08a07a7a6ae036384b1fe989e9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_en_GB.png"
  },
  ["8542795d9fa01006ed96bac462038c2858817c00"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_nl_NL.png"
  },
  ["85452f402b630616899c69ad72d88af526fe0d5d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_en_GB.png"
  },
  ["855f4c1075b1cb5ac70d77fe8a34f2f13ea9be0e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_pt_BR.png"
  },
  ["85786c57c7bee8772790a6d16d64ea8e0b046f4b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_no_NO.png"
  },
  ["85c55852994129d9204b50c757a5bf152442acfc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_nl_NL.png"
  },
  ["85c8312738bc70994106c53146a7313624cdfaac"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_hr_HR.png"
  },
  ["85f563c4e80068cf7396d881b4add32962fc251d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_sr_RS.png"
  },
  ["862cd04e2f46bdf3fb80a240a1c185318d4e7c82"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_ja_JP.png"
  },
  ["862d589fc0cb9df2a0a4f0b400da3c86dd7f35ed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_pt_BR.png"
  },
  ["863839d139f673521d2d11955597415284f10542"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_zh_CN.png"
  },
  ["8661aad6bde3733ee34484d3cc5a7f9455adbda5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_pt_BR.png"
  },
  ["866ea341b8e3fc977dee2a859c03153945b34ca7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_pl_PL.png"
  },
  ["869b860be06e7f903b847636457c170248a016c3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_tr_TR.png"
  },
  ["86bcf76aad14c8d45044d3553a84fefb1a43f4c0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_hu_HU.png"
  },
  ["86d7990c071e7ef96daccacb04e03608c975edab"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_bg_BG.png"
  },
  ["86e251a984a5aafe15b923801617a04cfa4260b6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_pt_BR.png"
  },
  ["86ea358ae9a5c2c88528410f7e9470cc7406ceb3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_el_GR.png"
  },
  ["86fbca276da0719f87e35034dfde99c2385f29c6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_zh_CN.png"
  },
  ["87526b4309e42aab2ded3b5ba4e7636f4a421f5f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_fr_FR.png"
  },
  ["876f06257a295fdde6672d394c01efb9f08fb458"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_hu_HU.png"
  },
  ["877f4270212c15216a54d163d15948a442f97bb8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_it_IT.png"
  },
  ["8792edabb1d6de9cbbf76e254bcd860502203c8d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_tr_TR.png"
  },
  ["87a10126e1dd804484d299b9591a9279796e2068"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_it_IT.png"
  },
  ["87a2c2d4fe1157c98e175d5a2ffde5163ef6c62b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_de_DE.png"
  },
  ["8803e72087440a39a6234700ff8dca11a221a8d6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_hu_HU.png"
  },
  ["880ab059124eac9b5ac21b8bd7c4b1ed1241d949"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_es_ES.png"
  },
  ["8810627cbef1720feb8b033e85314022047ef945"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_tr_TR.png"
  },
  ["88326b21657a7e58fa78d942ff428fd601a843f7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_cs_CZ.png"
  },
  ["883bf9642c3e59308f2b5b1a947ee87b17a25849"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_hr_HR.png"
  },
  ["88a67107a5a1d8e3d132ebda722f046dd3719e65"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_ar_AE.png"
  },
  ["88db06ce4a9ca55358303d9668aab875e2913c53"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_fr_FR.png"
  },
  ["88ecef4031c503e583f0b86d65d7db280118c8b9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_en_GB.png"
  },
  ["88ee4bd29ff0caefd63eb90d188fe556a2a22593"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_ko_KR.png"
  },
  ["88fba49570c4c34757086868f01cf441a3dd2093"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_fr_FR.png"
  },
  ["891174fccf37034e7018df9423267e96ff8684eb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_th_TH.png"
  },
  ["8912a67303cdf0538dea7114df3514ac3350287f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_pt_BR.png"
  },
  ["8919f18f53ddc3fac628e2dbe13bed797557153e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_ms_MY.png"
  },
  ["891b0837608ef62bff7525e9dd0609abd5ad5bce"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_vi_VN.png"
  },
  ["8929069c1b8fda447a969cd5f8859770a61524fc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_pt_PT.png"
  },
  ["894d9c28d1b3b61df6f8d63969a72c6fa848d516"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_en_US.png"
  },
  ["8952ae48104d147f15e1cb6b65471f394f2b9c2f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_nl_NL.png"
  },
  ["895bebe185bb862f798b5108169ab322017ee0b6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_zh_TW.png"
  },
  ["896017fd39e8e2bf14aa33b0d3ec7d542efbfc4d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_it_IT.png"
  },
  ["8967e4cb9b6b4d4aa76a7d7b1250f512f05d5007"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_zh_TW.png"
  },
  ["8971bf0e9c1ed5ff6ff4c5082223623dd3f298dd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_bg_BG.png"
  },
  ["8973a4cdbc04fc29e1ff1f680ba212668801dfcd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_cs_CZ.png"
  },
  ["89940c13ba5cace8014e015c878e8fe733550565"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_zh_HK.png"
  },
  ["89aece743cf8739e06d0eff2721dabdb8598762b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_hu_HU.png"
  },
  ["89b7d3b2bda92982e8b22d62d3e1eb51ab7e3f0b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_ja_JP.png"
  },
  ["89bdbba290aeeac9e0b3af657ae9047bf98994bb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_sk_SK.png"
  },
  ["89da50f67c2c2b2c5de501684725a3c8ddf1d3ca"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_ro_RO.png"
  },
  ["8a0a37f98f2c32420816d7dde9b6bd73dd35efcd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_id_ID.png"
  },
  ["8a36f3ef03b35896a5c73d332f6f7cc82da5aa7f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_no_NO.png"
  },
  ["8a39d1018b8777b1988ae9857a975f8e0f35e7b0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_fr_FR.png"
  },
  ["8a3e83076bc64d7a982cd0cf5891fbf2e77d067c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/Shadow_Left_Edge.png"
  },
  ["8a79c2c78a97d03c658db09d70667931b405cdfe"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_vi_VN.png"
  },
  ["8a7f3ba20096a2db24601c0178016539d5efcc9d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_es_ES.png"
  },
  ["8a87613ffc92776ad684c2098b950120d554aad8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_sr_RS.png"
  },
  ["8a93a15b2bca2ceba410e81a48398d41bf4e5913"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_ru_RU.png"
  },
  ["8a963819c3691620d19d79a28f18b4e5707e1caf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_hu_HU.png"
  },
  ["8af89067254662a6290a110e7416bb6c49499667"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_bg_BG.png"
  },
  ["8b0322f334c882681ff20328993371077719144f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_sv_SE.png"
  },
  ["8b10f819bae54773ad59ee3de4dafe1bf3a8a497"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_nl_NL.png"
  },
  ["8b15cd4e7e8f469d3c214bc2cb301cdfaaf12bed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_uk_UA.png"
  },
  ["8b205d48aa3f765b80f586098cc8e2666a236cf4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_bg_BG.png"
  },
  ["8b4032438a2be171a2f27183dfe0ac38fd95756c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_en_GB.png"
  },
  ["8b4293b239b6a84614666a26b59237a28389fe70"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_fr_FR.png"
  },
  ["8b4b848355868483cf7400d1d71d54cf3e31c6c5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_no_NO.png"
  },
  ["8b55de7fd0831122d0baa022f5bb0d8fbf232e0b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_pt_PT.png"
  },
  ["8b6d0404b7f4acbe967221de07cf812cb8de6838"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_uk_UA.png"
  },
  ["8b7bd10d3e71c9e4c2679450d05a76bdb7becf10"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_th_TH.png"
  },
  ["8b84973c326fef46ee104d184d1ddfbbdc6721a4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_zh_CN.png"
  },
  ["8bb4ab1b1d78b31bfe8a030b6ec2ce0304663362"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_ar_AE.png"
  },
  ["8bcbb1e389f095e1aa76aa9fffcf4018d266df28"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_uk_UA.png"
  },
  ["8bd565d85bd3d8e8bd85832c52c6e7543c1b80c4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_en_US.png"
  },
  ["8be9b88726c32ceb833a9cbde8337adbda1c1de3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_da_DK.png"
  },
  ["8bf5245444b3fe04035e40c785650f875a8fed0d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_fi_FI.png"
  },
  ["8c277f49e0d99fe8cf0b9de27ce7986f7ce26cb4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_zh_TW.png"
  },
  ["8c37a277ea3c68af06736e66602ed74cf283ee6c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_no_NO.png"
  },
  ["8c416f595b910c0c34f916d66ea3505ee173b211"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_ru_RU.png"
  },
  ["8c4c16603412e3610aff0b29681e3cb4f2111bd5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_en_US.png"
  },
  ["8c4ce6eb16782152a4d554fd5b227454ec737cb7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_tr_TR.png"
  },
  ["8c57ccbea95aaa67998db1814a46894d88da8c40"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_da_DK.png"
  },
  ["8c6f0dee8a2a4ade8fdeb7d809284001deecd6f6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_sv_SE.png"
  },
  ["8c79389bc90e7c1079fac7aea78bf2f934bd73f6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_cs_CZ.png"
  },
  ["8cc257fd2f27479cee17d80755a08e58d291011d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_sr_RS.png"
  },
  ["8cf58b94013ce874490af8849918eba65f01c1c8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_el_GR.png"
  },
  ["8d17d83db41aa15e2ae35731c794e41ab162f3e5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_it_IT.png"
  },
  ["8d29b0ff4f01b9dd41c08bcaf30ef496e08ee2f5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_de_DE.png"
  },
  ["8d49de7c8477a77ae7ffbbec2a5fdc57e39ab424"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_nl_NL.png"
  },
  ["8d566c838e9bed949aea9c370baf6eb7480cdca5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_pt_PT.png"
  },
  ["8d6c82f1902d93d063630bda23f41259a23491da"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_sv_SE.png"
  },
  ["8d7b9904e72e7063570e3712130b8804b738b603"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_pt_PT.png"
  },
  ["8d867ad3e3e8ee969ffeed533afb4e18952fad11"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_pt_BR.png"
  },
  ["8d8a0aa673a00a037a9f6f4fa7e6d8171c1312c9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_es_ES.png"
  },
  ["8dfaba2e486c1af1e2841cde02f4fbb10f679b44"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_en_US.png"
  },
  ["8e29d073d3f0dbb9cb7824f4024b6c3c8d69100e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_pl_PL.png"
  },
  ["8e629c4aa67c0904b4d229605b51b3fd32f684d2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_hr_HR.png"
  },
  ["8e66e9b6ec8b7b7d64726e860f84cd34b55c798c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_bg_BG.png"
  },
  ["8e67bc89eeedf800c65295ae6d1c1b282ba41487"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_fr_FR.png"
  },
  ["8e848e65a62acb527ebec66da0f6231f675a7240"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_sk_SK.png"
  },
  ["8e9de93b37481af446e5e3ad9dc3222241fb4f27"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_de_DE.png"
  },
  ["8e9ea86577f3f21020a2092b5fe3b3683a092ab9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_ru_RU.png"
  },
  ["8eaefa1494c6f0f12c18ececb25f066243fcd3ce"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_ar_AE.png"
  },
  ["8ec3af220eac336f7117063a6381e2df82db328b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_bg_BG.png"
  },
  ["8ee3c988fdbdd3b153ea7af879e654bc66e09744"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_fr_FR.png"
  },
  ["8f05297afc5bf2d970431d04abc5dcadd9aa6922"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_uk_UA.png"
  },
  ["8f23e97f9d803c5989a89a9d24e8a880fbc23d04"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_pt_PT.png"
  },
  ["8f3010b04093d4504dda8cf10183b2f8bcf4cb35"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_sr_RS.png"
  },
  ["8f31abd4cdd5a5ed458a5f90ed669164ba143c49"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_da_DK.png"
  },
  ["8f4d599fe5bf47941661660e2c527fec39680890"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_en_US.png"
  },
  ["8f63291bbfd06a0a5a0bb524e770f55b3826405a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_en_GB.png"
  },
  ["8f728c9d8cb46f851357255d550563beeafb8e4c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_es_ES.png"
  },
  ["8f82f67cce1e2eeea991c2b38440ee2ecdf7af48"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_ko_KR.png"
  },
  ["8f9cfb008dc0ee1c98fac03b37f3fdb06e884fdc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_sr_RS.png"
  },
  ["8f9e95ad7d19009ad7b4415e184a2a8b6293b091"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_ar_AE.png"
  },
  ["8fd9df592c1ba5106d1ca57a9bf02d877c5f63d8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_bg_BG.png"
  },
  ["8fdcab8a45e2a12bde5c427012726f01e2ec34b4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_vi_VN.png"
  },
  ["8fed3b41f0adb2c1b64bb44a52e4f9049d17e056"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_th_TH.png"
  },
  ["9014c6cf0e849c3bd6b3f3cc661b4faa35330fea"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_es_ES.png"
  },
  ["902a2d757489e7aca37e221b4d40f13159a07b44"] = {
    assetType = "image",
    destination = 2,
    path = "Images/Shadow_Right_Edge.png"
  },
  ["9031b53e4b428d91b7831e426d482da688662345"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_ko_KR.png"
  },
  ["9033a4a6f8377e501965e8988ed5e8de788356d1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_zh_HK.png"
  },
  ["905cac4eae397df0207fb39ffb0f0b851956a810"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_ar_AE.png"
  },
  ["90623070b4645ac3817f262ceb4d9b2a0e07a6e5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_hr_HR.png"
  },
  ["906c2127f00fb00cb2f45d26928f1929ed063e7a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_zh_HK.png"
  },
  ["907f52ffbe106744618a4d6bccd0bc25a653f177"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_it_IT.png"
  },
  ["90c84a25b40d7d6cd346fb67936813107675ec36"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_sv_SE.png"
  },
  ["90d4ab8d51f503326ac24546d350ff131164bb79"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_zh_CN.png"
  },
  ["90eb2b1a956997a12c4a77e6ba77e6bfe360ea05"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_da_DK.png"
  },
  ["90eb3426dd688f152634a4adeea6593298fd1c29"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_th_TH.png"
  },
  ["90f64f32ad59b34442104c3d6415084694835903"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_zh_HK.png"
  },
  ["90fe1c34c0d8fe6251fc91b4bfa32451eeeb61fe"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_pt_BR.png"
  },
  ["910ae89f87c07af5d95fe904dbec3ec813239772"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_pt_PT.png"
  },
  ["912b89ac4dd90b79ceddb2b7ccf8e2ce9f924f09"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_ar_AE.png"
  },
  ["9138f87145abfb79249d6621292bbbe60cbc69d4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_fr_FR.png"
  },
  ["913df9d4c4c4b8fa18f63d41a0f92cb7ceaf5a9d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_hu_HU.png"
  },
  ["913f01322f43838a82ca8ec648ad30d5e1594df0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_he_IL.png"
  },
  ["91476613afef0b5d2c4889d65537d79c01955116"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_es_ES.png"
  },
  ["9155a89ed55760aa808d24a4330bb6d7b1fc48f4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_ko_KR.png"
  },
  ["916834e33ea39ed9562f0898e1554ccd71ee708f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_it_IT.png"
  },
  ["917e192acea2685e7e7563fd93e5b2b736ce124e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_zh_HK.png"
  },
  ["917fd48d35add0d822851beb4c931111c58e6922"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_fi_FI.png"
  },
  ["9195b6771cc0ff59a1ecaf69932f810c1482e926"] = {
    assetType = "image",
    destination = 2,
    path = "Images/thermometer.and.liquid.waves_body.medium.png"
  },
  ["91d4eafbf13b4827e7371ade495e1a0ff9fe0606"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_cs_CZ.png"
  },
  ["91f11adff89f6537133739c89c0f4d555008ba72"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_he_IL.png"
  },
  ["920372d83dca62b32a000dadeed17ce7a2047a28"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_no_NO.png"
  },
  ["9212ab6dd6f78aa34e66f3f005d904224ff61e87"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_el_GR.png"
  },
  ["921caab8256f93e336fc8e70b8dc39d8c91b72f9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_da_DK.png"
  },
  ["9237af2d76dcc5fce1878b08437bba8818ff30e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_en_US.png"
  },
  ["9250bea21c0670ef4ccbdeeb798f452ae10c2587"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_pt_BR.png"
  },
  ["9251b0123b607033e0c82fe272743a009901a44d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_de_DE.png"
  },
  ["92585cb8a2f55d515d3fbe9da12e560f35aa5bc7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_bg_BG.png"
  },
  ["92605b3b15d29546d387c070420d59cdfd16d6cd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_no_NO.png"
  },
  ["92647f5087598fea6f23d96dd5c7366a82e7a20d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_zh_HK.png"
  },
  ["926a3e1f9c93b44c2d9d2314bb247a6e3d7bfa9c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_sk_SK.png"
  },
  ["92b65b1ccf6736c2a2feaa7441605ccd914ab803"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_no_NO.png"
  },
  ["92b91b90c10facb23207ad9793ead8799c52e196"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_en_GB.png"
  },
  ["92cc5729b9c61a38b1927b5d95d87b22bb671a6a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_zh_CN.png"
  },
  ["931cefaf0414cf120165da06356b2ff5e7f8fc05"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_da_DK.png"
  },
  ["9333b1c8d7840478abe101e633c1ec8e94063f03"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_hu_HU.png"
  },
  ["93405fcc2ef0dc86307ce645e3ebe9649e2a1ddc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_sr_RS.png"
  },
  ["93662f0af01cece7b39735f107b3c88927d30b9e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_cs_CZ.png"
  },
  ["93965f2b382184e5f521679903f4dd443d522eb0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_da_DK.png"
  },
  ["939fe39716ab9f6014b34b43f1975dcac2224ea4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_fr_FR.png"
  },
  ["93bab6193f487694f094d9982bd29edfbe95463c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_hr_HR.png"
  },
  ["93cefb31b0ebd84846fba15d662f6b5e89c5eefa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_en_GB.png"
  },
  ["93f63234894204485a46befcc607f9a1aeb0abf9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_nl_NL.png"
  },
  ["94126cc7f0adbe6290177364f602957a73db2d6d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_el_GR.png"
  },
  ["9421f84c20ddcc3a85cf419bb4a4aff2092508b6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_en_GB.png"
  },
  ["9432602bcc367a3e9fa266f0623f7022d12b77bf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_ru_RU.png"
  },
  ["943e947efddb5f4ca75ea81a41efa9c52fdc1be7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_ko_KR.png"
  },
  ["94584ac18f359a74b92ce971548a2d472c796255"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_zh_HK.png"
  },
  ["945d539ad03a89fad05dd477c2fdb2df1a082a27"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_tr_TR.png"
  },
  ["946276499d3bed952ffc9162f52665179c9226ae"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_fr_FR.png"
  },
  ["946bebdfdb4573f0805e672e1c7460c31e60e09a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_vi_VN.png"
  },
  ["9483533485c8a82a93418dabad5dc36b09453d03"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_sk_SK.png"
  },
  ["94a84e064cfdad561a83c58307bf39975b6fbd1e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_fi_FI.png"
  },
  ["94b5384bee35897c09f8f900d59c04b7d926202a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_en_US.png"
  },
  ["94b80b39c939ace5b0c4dfa3761999c2fa80834d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_ro_RO.png"
  },
  ["94ca3eb38c4e65de74af935549350cc228cb6222"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_sv_SE.png"
  },
  ["94ce819b6c7911199de682312260150ca1a4ddd8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_da_DK.png"
  },
  ["94d642f875790b91889bac397813c34d349b7418"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_ja_JP.png"
  },
  ["94d71defe77e48f8b4899878064042c55efdad37"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_id_ID.png"
  },
  ["94f30dd766329cb163ebc6d64cea12bfd2f6ca9e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_ms_MY.png"
  },
  ["950fd279c67b349e7f8b74ea3a5691e261d8038c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_id_ID.png"
  },
  ["9538148191b3b6fc321d6709a311e75073c05b67"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_ms_MY.png"
  },
  ["953ab5136e149ac6e3acd84e25f1f1fb7e5caf9d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_de_DE.png"
  },
  ["9557945607fd056ee2e1a0bcb4378b144ae98c09"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_en_GB.png"
  },
  ["957be70390c42170d690cb4b7db37df1fa53a563"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_ro_RO.png"
  },
  ["95944c345993af1eae86293ae9ee16663a9e4a5f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_cs_CZ.png"
  },
  ["95ba7413cf02f10f1a2462c11d2e7d684f951e53"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_zh_TW.png"
  },
  ["95eab84c2bd1313f15df3740648e32d8c419704f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_es_ES.png"
  },
  ["96074cda8e8632d4c57231d389d4760729fad4e5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_zh_HK.png"
  },
  ["9621051f2c3d118c355c40bc9e80925cb0c48ccc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_ar_AE.png"
  },
  ["9643234f9effedeec0cc38df21cf7cc92a1c443d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_zh_TW.png"
  },
  ["9643560529ec33da0543b803739ade18fa5d25f5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_ko_KR.png"
  },
  ["964ff1c03c153f07e7146591140d2106e4fadf5c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_ko_KR.png"
  },
  ["9670831b5e59afd4713ae295f023426e16804db2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_ro_RO.png"
  },
  ["9673d0c745aae85e45b22cc74e3511732da0fbf8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_no_NO.png"
  },
  ["9675ae09c830fbc6f3f3839bea036fdcfca74e2a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_uk_UA.png"
  },
  ["9678899426671c15d59652478ca838fd53673326"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_vi_VN.png"
  },
  ["9679ae1029f8a0f220881a0277d250753138dbf1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_it_IT.png"
  },
  ["96944bb61adb5d30da61fad1d6d89ec5d88d41f5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_sr_RS.png"
  },
  ["96ad34279335cbf2984dc87f3ef9631a662e763a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_nl_NL.png"
  },
  ["96bc44f9371e3f85463e4766c23d22dfacb292a6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_ms_MY.png"
  },
  ["96cc5942bd93d8f81d46a32f5a186ce319ed856f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_ms_MY.png"
  },
  ["96cdd2b147d5dc59248c078e7996a9713ec520e6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_uk_UA.png"
  },
  ["96e8f49cc5a5b4d96dcfe35cc2d3e665de61290c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_sr_RS.png"
  },
  ["9710b3f882320abcb29f076b6e5d8146c31da53f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_vi_VN.png"
  },
  ["975984dcff928318ddefdb900b2da9afc7a0d016"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_ja_JP.png"
  },
  ["9784205d0d135d849c078e850e8fc61447c72c87"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_hr_HR.png"
  },
  ["97ac5972e1686bf7ebee5f38311a259c495a1b13"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_pl_PL.png"
  },
  ["97b99976fd60d3813d265470044e5fe85eb7b586"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_ro_RO.png"
  },
  ["97e611b8ddb38f4d43a073cdd5fb0a5192cd6eb7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_vi_VN.png"
  },
  ["98049ec794f7268b0d1915aaa1e734c4d580598d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_ja_JP.png"
  },
  ["98075e61a02e45373e67781b45aef7756ea105d7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_ro_RO.png"
  },
  ["980795db6ed733126e867df9537339e5177525f8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_he_IL.png"
  },
  ["9869bd4537cfebfcc0ffeb25c960c1d677b46871"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_th_TH.png"
  },
  ["98a5ad96d18a545801f3c52d2459517ce44fdc2b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_pt_PT.png"
  },
  ["98be736c870358917a3d6a1ebd114adbe0924191"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_zh_TW.png"
  },
  ["98c512e316af27653075b99385d70395c5f786a2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_vi_VN.png"
  },
  ["98cfd28f18b46e60fa518d950d26abe5d255f10e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_ko_KR.png"
  },
  ["98e21f7cea48be55f22199e213df6e5110ff6699"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_uk_UA.png"
  },
  ["98e3f49ee4b89ca7472a5d6d7b20af9605304156"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_hu_HU.png"
  },
  ["98f47b5dd86be9c3e52ead3b9d3b911b63268a33"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_zh_CN.png"
  },
  ["990660bc1b67816550d6adf091227185f4eafc9b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_zh_CN.png"
  },
  ["99135ff39a82af10b601028d39e68e4ab94ce193"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_bg_BG.png"
  },
  ["992554fed68b25efe80035cc2536f7785322cead"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_de_DE.png"
  },
  ["993a243643ac9874e980a74e13656c0082845cbf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_vi_VN.png"
  },
  ["9977f4e986d8eb5c92ab3e06e398605659d841ee"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_sk_SK.png"
  },
  ["997b9cbf78ec035dd3c0c1c842c33c0291da1433"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_it_IT.png"
  },
  ["9983ce56b9dc7e6b304b6214ef30996d449ce0a2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_vi_VN.png"
  },
  ["99b5e4125a19b32994ba4eda3cbe9dbae197ed56"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_ko_KR.png"
  },
  ["99d2e42dbdf918eb999d6d936879b174e7b98d39"] = {
    assetType = "image",
    destination = 2,
    path = "Images/Shadow_Bottom_Left_Corner.png"
  },
  ["99d88c9fe9d1acb86aaa6744dae897c519fb2bb1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_de_DE.png"
  },
  ["99fc6b3a3db341f0bda64a0c2b5cfff86de86185"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_en_US.png"
  },
  ["9a122fbf7dcc4646de5acafd6e5da2d234c77541"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_ru_RU.png"
  },
  ["9a1ed9b4bd0e3d88e974905017ce10ebfa3bb917"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_zh_CN.png"
  },
  ["9a255487fb78c352e0daf762eccdeafaafb0e2b8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_zh_HK.png"
  },
  ["9a670a21122a47971fa6fc811dd6d91be41eb372"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_zh_HK.png"
  },
  ["9a69e02e820d76c649ba296707f381653c76cd83"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_zh_HK.png"
  },
  ["9ab0139db8bf15df956bc87295dc886c07369f1a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_pl_PL.png"
  },
  ["9ace1c9b76a8b4baf2c632ab0eafffb62f8157d3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_it_IT.png"
  },
  ["9ad2846b2c0d650a01dd5ec9c36a226767cbf2a3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_pt_BR.png"
  },
  ["9ad3a45d5fbe4214332d81cae58b9ab6898e92e2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_ar_AE.png"
  },
  ["9ae346dd68c672a5466fa1f88e7b895634887768"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_el_GR.png"
  },
  ["9aecb9f708bbbab589b58f1193ca41ea0ebf22f9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_sk_SK.png"
  },
  ["9aef383a8d42a5e3afedb9e07db3f00357829605"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_ru_RU.png"
  },
  ["9b0c3dc902ab9bbd10ffb813df852adc0aec5898"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_ja_JP.png"
  },
  ["9b0e5fbff54377606f902876668ceeba15b2f7b9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_es_ES.png"
  },
  ["9b1ede0a97bfac36bae1748d570e389fc3040807"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_ro_RO.png"
  },
  ["9b2878a9d0da774ce5d460f95e55ebcac49a1f3e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_ja_JP.png"
  },
  ["9b4266b4abab9eba951886392bd6bf3939a28d83"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_th_TH.png"
  },
  ["9b47794f7de9d0444df6823d8e6a2d44d6e3e938"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_pt_PT.png"
  },
  ["9b60d18eeaf2ea9d10d61fff36186fc6b5330a8f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_vi_VN.png"
  },
  ["9b691aa3d65fb055d7aaa8dbc798a58da16d23f0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_id_ID.png"
  },
  ["9bb533e432efa41d16f5ed0986e3b5d93395e137"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_tr_TR.png"
  },
  ["9bbb0b1552eb93c87c101ce03ccc3e2ed5fc9237"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_hu_HU.png"
  },
  ["9bbc2990e577a7801beecc67cad96b00a378da22"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_no_NO.png"
  },
  ["9be5cdeea0530e34339664cf267f58499f3cdf8c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_he_IL.png"
  },
  ["9c1ae5d768cc9622ab3f450086b43891839c5513"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_hr_HR.png"
  },
  ["9c520c2722b0265807f7b26825aab35c605cc61f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_tr_TR.png"
  },
  ["9c95e8d366000912e45de30e3d532b680e4239b2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_da_DK.png"
  },
  ["9ca1376bc07f6f6f77452f6a5f042bd78eda6fa7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_pl_PL.png"
  },
  ["9cab714a047cc29b62533280e18747c2d8a7314b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_el_GR.png"
  },
  ["9cc106a4872ab9ee16c7bd06e863c078c2947c21"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_zh_TW.png"
  },
  ["9ce34beaf566cb87324d100c002c703446d7b800"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_vi_VN.png"
  },
  ["9ceb1fc55235b6a2e28ae3da696b448a1fa450bb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_sl_SI.png"
  },
  ["9cee29d56df8b730f8c298248d397875a33e3e75"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_he_IL.png"
  },
  ["9d13733c02e070988aa76d658e3ce91c400dd7d5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_fi_FI.png"
  },
  ["9d38792aade1cb8b8c820a3dea07b1e0e9fec7ce"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_fr_FR.png"
  },
  ["9d38bccd2a6b2ea5fec9a558d0b562a1c207c895"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_sv_SE.png"
  },
  ["9d62b401ad6829dfb4b39dc29ea77373351db2e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_ro_RO.png"
  },
  ["9d78c10a00813bdb512e21626e206fce3cbaa883"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_no_NO.png"
  },
  ["9d83b9ef1e8efb1719de73f9abebeec102ae3451"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_fr_FR.png"
  },
  ["9d88f7ed02e47d3edbfa674ad38551e69d4ae9a7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_uk_UA.png"
  },
  ["9d9e0467f6f4b88769f7abdc66d984469be45433"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_en_GB.png"
  },
  ["9dab59de2058369cacb4ca350d879328fbef5f0c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_he_IL.png"
  },
  ["9dabbfbd217f2c7403a66d6d4cb639c0b69ead00"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_el_GR.png"
  },
  ["9dbd9c73cfbe2b2915b47054577858c0d248c7a3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_ko_KR.png"
  },
  ["9dc1cb5ff32fe84eede9976856e46e08df7d7bce"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_de_DE.png"
  },
  ["9dd2d2dc913ce6961cee595a03535a5c638e6a9c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_es_ES.png"
  },
  ["9df14734b1fadb4b24afe93d10793ec32781849f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_vi_VN.png"
  },
  ["9e138c373ecbf596f560463fc3ee55b8d4d2095b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_tr_TR.png"
  },
  ["9e16003023fe4c4d6ce668d7d328b526f78c255a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_pl_PL.png"
  },
  ["9e26ffd22265b0f1002b9dd9ae3ab07002c81a3c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_cs_CZ.png"
  },
  ["9e2cca374ccd89425ba61f5dd74449bcd07793d6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_tr_TR.png"
  },
  ["9e362b63eec72d23c780547390d54b7720434d60"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_ms_MY.png"
  },
  ["9e3db97fecb051f3d813707d39bcc07bcbd48d7d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_fi_FI.png"
  },
  ["9e3ee3c8cb2147775e07c84780c995ce0e1462f9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_da_DK.png"
  },
  ["9e4a5c7fea2796f6835592ed2698e0128a86f73a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_da_DK.png"
  },
  ["9e6c92022a6d943867fbb4d6737f2409fccd9f30"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_uk_UA.png"
  },
  ["9ec0a87420c511bdf49cca80575769b42dc591ea"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_zh_CN.png"
  },
  ["9ef6d5813be73ff5ddb86bead257be45e7bd569a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_th_TH.png"
  },
  ["9efa86b0e751e7419c187beabcd38f7b48d98b8b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_da_DK.png"
  },
  ["9f17472259271f3ec9c72e07a57e37819aeea312"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_th_TH.png"
  },
  ["9f32085df0df58e09dc491ca4ba5efe6aa8b6136"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_da_DK.png"
  },
  ["9f5c552f8454f07d00ad3620fd9bc9501e72ebd7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_hu_HU.png"
  },
  ["9f70d986c24d3912b2fc11e6cb3a5ffbb9cba24e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_uk_UA.png"
  },
  ["9f7f8ad5ae26570297196904ccf63de476ce52ae"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_sr_RS.png"
  },
  ["9fd12e98080c944523d0747b8649f1b165b7ccb2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_pt_BR.png"
  },
  ["9fdda9fdac34b118da8fc646e17827595a7c8a10"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_hu_HU.png"
  },
  ["9fecd5c818c5e83c8f08156e19134d3cf9f24ac0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_he_IL.png"
  },
  ["Stable-SoftNumeric-Medium-150"] = {
    assetType = "font",
    destination = 2,
    path = "Fonts/Stable-SoftNumeric-Medium-150"
  },
  ["Stable-SoftNumeric-Medium-170"] = {
    assetType = "font",
    destination = 2,
    path = "Fonts/Stable-SoftNumeric-Medium-170"
  },
  ["Stable-SoftNumeric-Medium-200"] = {
    assetType = "font",
    destination = 2,
    path = "Fonts/Stable-SoftNumeric-Medium-200"
  },
  ["Stable-System-Medium-30"] = {
    assetType = "font",
    destination = 2,
    path = "Fonts/Stable-System-Medium-30"
  },
  ["Stable-System-Medium-36"] = {
    assetType = "font",
    destination = 2,
    path = "Fonts/Stable-System-Medium-36"
  },
  ["Stable-System-Medium-90"] = {
    assetType = "font",
    destination = 2,
    path = "Fonts/Stable-System-Medium-90"
  },
  ["System-30"] = {
    assetType = "font",
    destination = 2,
    path = "Fonts/System-30"
  },
  ["System-Medium-30"] = {
    assetType = "font",
    destination = 2,
    path = "Fonts/System-Medium-30"
  },
  ["System-Medium-32"] = {
    assetType = "font",
    destination = 2,
    path = "Fonts/System-Medium-32"
  },
  ["System-Medium-36"] = {
    assetType = "font",
    destination = 2,
    path = "Fonts/System-Medium-36"
  },
  ["System-Medium-46"] = {
    assetType = "font",
    destination = 2,
    path = "Fonts/System-Medium-46"
  },
  ["a03e8cf641bd0ac17c37c4829124abaa64224f5f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_de_DE.png"
  },
  ["a042238a3ce9b9b3be886adb8288fe92b42ed22b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_it_IT.png"
  },
  ["a0433ff6371ccf483d2a3bbbced6d9002fef44e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_th_TH.png"
  },
  ["a0469e201d63844cb9aaa3fcc51af739b8955e85"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_sk_SK.png"
  },
  ["a04b75b73a5f2617a7dcd905a4fed8d2eade3d21"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_sk_SK.png"
  },
  ["a054ca44a614bb214f277bc599c9bbb91a9426c8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_it_IT.png"
  },
  ["a0729cdd887e6fd36e527044479b1e7f450fea72"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_uk_UA.png"
  },
  ["a077ae541e8887a7a28e81b1f8af4062549bf5c1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_pt_PT.png"
  },
  ["a078de44605186ad6f1e33a94e2446d95db7338f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_id_ID.png"
  },
  ["a0a5695dfaa0f64bbdd62a43c87f8c1a52859807"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_es_ES.png"
  },
  ["a0ea256454cb4399e812cb0e6836e22293480196"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_ru_RU.png"
  },
  ["a0f2ea2e245a5dab4dd148560aba2064291f1281"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_cs_CZ.png"
  },
  ["a0fe659c97d5a0fe7101c3f56e244f7e38e4e82e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_uk_UA.png"
  },
  ["a12d938242497dfa556ba000894fe45e255a55d3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_pt_PT.png"
  },
  ["a13cc6e595af381a23b873b28fc7bf11aeff104d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_vi_VN.png"
  },
  ["a14ac47a6c76495d42248c8182f39b609608db46"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_el_GR.png"
  },
  ["a14d0e692501d052ca636ad5fb0f05db4b77bc6f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_sk_SK.png"
  },
  ["a157d1f9a441e2742b28da49e81a4f1b2f0fd16c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_ru_RU.png"
  },
  ["a184e2a0aed9995c9ea21233d10ba7b1e0c40bc5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_sr_RS.png"
  },
  ["a191d748885f8652841101454cba63fab826f23c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_pl_PL.png"
  },
  ["a197bde4a6bef99637acd8bd2b7a93a5bb9f72b0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_el_GR.png"
  },
  ["a1a7c9c30fb3ba1844204e98d7d827a477a78f53"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_fr_FR.png"
  },
  ["a1c7aa08324907dd9fd004f60e3d121d9768d122"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_sl_SI.png"
  },
  ["a1cb8b8b87bfcfe796881059dd689349d9796000"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_sr_RS.png"
  },
  ["a1d605598da721a4473a8b2862235dd5dbdb2780"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_fr_FR.png"
  },
  ["a1da492fc6214600299fcaaaff84e6e45d411a4f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_id_ID.png"
  },
  ["a1f84b02d2ccf640c3cb7c77eb926c9176516f2c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_th_TH.png"
  },
  ["a2040e5874c1591596289deb0cb428b45699e2ef"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_ms_MY.png"
  },
  ["a21207fad177ea72adb99e8805339e64c3ccd679"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_pt_PT.png"
  },
  ["a22cd069aec32a0fe88e40c513a4d942347b143c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_pt_PT.png"
  },
  ["a238ce991f852b73e6153175be7c10c4dece8f28"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_bg_BG.png"
  },
  ["a23ea2f089fdbd40d296fa44615bb08f66558f43"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_th_TH.png"
  },
  ["a27b13ee904f53439296b970f8e8f1935f7aaa8d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_ms_MY.png"
  },
  ["a28703331c60dacdb99bfdc123e96c291eb25a98"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_ms_MY.png"
  },
  ["a2872938cfec3edecf51f8ba82e3715e44f0f8d4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_tr_TR.png"
  },
  ["a290f113edb2d9a09ef300ce0ab6695a89985238"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_fi_FI.png"
  },
  ["a29826f71173a7800bb335292feab4f106b217e7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_cs_CZ.png"
  },
  ["a2aca387b03cf74d2405deda82320ff03dd4ee73"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_zh_HK.png"
  },
  ["a2bba6354c4c1e833ee5b5ee8e59061e4aa2ec36"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_id_ID.png"
  },
  ["a2bbed5b14b475301bda5c6384ac2832f5114075"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_ja_JP.png"
  },
  ["a2e1f9622caf650e2a8b5c7376d2e175b97d215b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_ro_RO.png"
  },
  ["a2eb3065f6366ddfb641d4f432df663c663907af"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_sr_RS.png"
  },
  ["a31b80340ea32f71fdcdfc71f9c31ae3affa34ea"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_nl_NL.png"
  },
  ["a31d37e2374a7e9ca8ec3a15b69027cfa1d17b36"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_hr_HR.png"
  },
  ["a334fa140145f7c57736b1ed7dbf91f90188da6d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_sv_SE.png"
  },
  ["a3401c47cb40291343e1e95163f19890e8f3fbd5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_it_IT.png"
  },
  ["a373c02751258e6a7001f8f5fca32cee431997b4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_es_ES.png"
  },
  ["a39c53dac77d8f79bc754d379072f87d9d616b5e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_no_NO.png"
  },
  ["a3af91597287ec5e9db291630184e3d5524837a1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_zh_CN.png"
  },
  ["a3d14a39326b6a5b51d6b204e4298ec2a1bca66d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_pl_PL.png"
  },
  ["a3fa40be6e3f0047371a75b176efe10a1956c600"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_ja_JP.png"
  },
  ["a408152e27897c64f9b2bef3fe041defb61ef342"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_hr_HR.png"
  },
  ["a432e181b9bb744ebcfaa893782104655fe878e5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_zh_CN.png"
  },
  ["a45d1a3c82618fc8f2d48a3bfeeb6e85e1c9c322"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_ms_MY.png"
  },
  ["a461407eed8a67f416011e23a3ccffeedc7d9d7a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_sk_SK.png"
  },
  ["a46a4a75eb6b69ffb172e302f10b1425a3e46ab3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_el_GR.png"
  },
  ["a46fe8a7317fcc98af66d98dae1edc82832f8853"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_sr_RS.png"
  },
  ["a471ab146d12ef18169b0fd9256a310344d94f30"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_en_US.png"
  },
  ["a479b127225d197f0bb24ea912ed24b9f82d6f49"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_ja_JP.png"
  },
  ["a481deac97548aa4fbc3b33a268d1698f9caf6c4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_fr_FR.png"
  },
  ["a487831df3d51f6e192f5708f53dc0be0c53c30c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_ro_RO.png"
  },
  ["a49585f57d8c24d546d9361891d860a62a4bea3f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_sr_RS.png"
  },
  ["a496403bc0ce746aff69ec8ecafc18224ad52280"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_sr_RS.png"
  },
  ["a4965297d74f83ab7a6ca9d7c3b3b2e8e7255644"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_zh_CN.png"
  },
  ["a49ec7717066cc27d5a13b70c44512a9aecceff6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_tr_TR.png"
  },
  ["a4a121434874210370e16979c962017b2b67c801"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_zh_CN.png"
  },
  ["a4a4be96160f19fc6318ac310b32058515d9dbed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_en_GB.png"
  },
  ["a4b6affb09368cb25b83173a474b8134483b19a6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_da_DK.png"
  },
  ["a4c950c5d4e003d22d3f614499734a9ef915f36a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_en_US.png"
  },
  ["a4fd41aeeba4cb468d5100b3a16ed089efd58916"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_no_NO.png"
  },
  ["a50e5d43df9f721c66946ed11015025999551fad"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_fr_FR.png"
  },
  ["a5154fe426703fc2dc57ac2a4b657967f6ad6a0b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_ro_RO.png"
  },
  ["a52ae31fee18d0ae82058f0a822646ac4f77bbb9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_it_IT.png"
  },
  ["a53ffaa45c4f7c8820490c249797db6a357dd92a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_nl_NL.png"
  },
  ["a54b0e4d0a4db40b3abda66c90cf57f8e67dc958"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_de_DE.png"
  },
  ["a54b87ec2ac30765a2902813f4e7b09644f5e4f1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_en_US.png"
  },
  ["a58c76c6625231eef5356668fd1905535ef50a35"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_zh_CN.png"
  },
  ["a59aa4aa903903c4c8bdc3596b862fff21b7beae"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_da_DK.png"
  },
  ["a5c6377138747caa13f645deb4f1c552bcc2aa58"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_id_ID.png"
  },
  ["a5d23f931b94aae5017e3794b6590078a9a9d69c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_zh_CN.png"
  },
  ["a60e19cf923ddfaac353c494f5ba2cf3da9f9909"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_ro_RO.png"
  },
  ["a61aee07ba9fb4250ce13dc5df1a020445b0b7f0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_pt_PT.png"
  },
  ["a629f8289994564d295f71c7aee1591cee8135d5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_en_US.png"
  },
  ["a653a51cb22ba264dcc32758072f83074d4a202c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_bg_BG.png"
  },
  ["a65d930c0d7b4960efb8f8678788bbca0563dc32"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_id_ID.png"
  },
  ["a66c1d58a9a2bb5f7a8ab5a6884bfcdc9c5afa9d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_pt_BR.png"
  },
  ["a66ef42ed58ca5835c2c7c8d510f1f8183a1e4ea"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_fr_FR.png"
  },
  ["a6737d388d3769605d05a39e4277fdd167ad3ac6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_en_US.png"
  },
  ["a69aab6e78b60621cbc73bf18e3099d0407219a1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_en_GB.png"
  },
  ["a6bfbf69b784ca5ae9a4a561ec6fa1161059b330"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_en_US.png"
  },
  ["a6e6e1a1aa8f0279585fa9ee975768afbb101ecf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_he_IL.png"
  },
  ["a6e74bb9d17b5ea6d331ce78f7b9efe26cb04ad6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_fi_FI.png"
  },
  ["a6e9859da5e81c5a5cf0ae2c0c653302056e7cf5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_sv_SE.png"
  },
  ["a700af9171b9aa73432d838da88b7b7e8b3dac51"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_vi_VN.png"
  },
  ["a717b84d783803b5ac6e31e7fa29ead697ba1133"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_ro_RO.png"
  },
  ["a74dbec5dc552bf293476241e3cb68ee7836136e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_sv_SE.png"
  },
  ["a774240ea42873f6a813adf6d1c06915b2cc1778"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_zh_TW.png"
  },
  ["a7764e3d45e40e6b993646fa1378d41dd893392b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_en_US.png"
  },
  ["a7873dd7af19cc626f9c0c9e2e11009ed30505bd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_ko_KR.png"
  },
  ["a78825673a91b5d69c08749cf39233ec0cdbe59a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_cs_CZ.png"
  },
  ["a796119d712b8511f6afae858af16c0ca666f27e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_vi_VN.png"
  },
  ["a7a3abec170473c4ec2ac6a226684b85b3d5c542"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_el_GR.png"
  },
  ["a7adbe0f33aa0df7a30b9047e020f5b3db562083"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_ar_AE.png"
  },
  ["a7b2b5d49fec9fa855742e34d0a6d29790979f72"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_ms_MY.png"
  },
  ["a7c76cb680e57d07e715aeaa1e9abd31bda2d65f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_cs_CZ.png"
  },
  ["a7c804468827cc8d47e26e396c89b4999a1cbe45"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_fr_FR.png"
  },
  ["a7e964b7f84395cb4e65db4cf7af1eee320f6b73"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_da_DK.png"
  },
  ["a8015c876741db3e0ab40217757bfc18005ce3b7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_ms_MY.png"
  },
  ["a81a18346f79f72d52f1a9a3a36c5453e55c2f2c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_ro_RO.png"
  },
  ["a83f25b5fa0b468d1fe55d14cb177d9ed129e20d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_tr_TR.png"
  },
  ["a83fa9793d499202d51c3a1d5c546fa9aae248d7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_zh_HK.png"
  },
  ["a842ddd2702d5adf3fd431f4c2b52a0bc09a98fd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_ro_RO.png"
  },
  ["a86d5628390a8ae745664043debcb3c8ea41d00a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/thermometer.and.liquid.waves.cold_body.small.png"
  },
  ["a86efbdbb1fb9d63177e55f6d89fa02d31b6fc5f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_ar_AE.png"
  },
  ["a878c36410130a9a1d29b5e79205eca175852879"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_da_DK.png"
  },
  ["a88f20a9a223ba3eb71c94d7313299ee148ee0b1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_ar_AE.png"
  },
  ["a89d985bc395e551ea67486f3591076d81f6f598"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_vi_VN.png"
  },
  ["a8b68ce25c176627e0fc3e526c09b0a5bd49cb2e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_vi_VN.png"
  },
  ["a8ccb872d380bbac043559631f3988c23ae4e1df"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_es_ES.png"
  },
  ["a943bdb38788fe11ef8e18c4a37e6afbc8fa92cf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_el_GR.png"
  },
  ["a94b0317001cbdc7285456608c4f67c6f2b3b6bd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_th_TH.png"
  },
  ["a95071b4f165125d208a7231846df064b36e261f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_tr_TR.png"
  },
  ["a9648df9752d371b091b84f28444552daece818b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_pl_PL.png"
  },
  ["a976c611723a18e0b77c267b53c07d632a412f93"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_pl_PL.png"
  },
  ["a9946995d4a9ab721854b3049605f8f17258e481"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_zh_HK.png"
  },
  ["a9c41e3152178223d1f4ab411fff862462afe22a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_tr_TR.png"
  },
  ["a9fb37ada42e90a1154025b69eef07bb9d711947"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_th_TH.png"
  },
  ["aa1d0f91e85be1cb46073de70f390db3ebf7e5f3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_zh_TW.png"
  },
  ["aa1eee355d5063f95b45f9756ff62c22900797bc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_bg_BG.png"
  },
  ["aa2d9fd5f840b3af42d1e12b36d0fb44aedae759"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_th_TH.png"
  },
  ["aa343325b2add0b27ebed1b869d2c74fe731af2a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_zh_HK.png"
  },
  ["aa4e51d1834062b7117cabe1684551efa9e2a3af"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_bg_BG.png"
  },
  ["aa5e08767e5f9460e18bdd6d2dd019b6e6ea43e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_he_IL.png"
  },
  ["aa6555d7f607b7bd749db991dea4bac9ac802134"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_zh_TW.png"
  },
  ["aa7797cb529f1054f3664fb64a4eac611bba5304"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_hr_HR.png"
  },
  ["aa9949919189d472506d2c22d33eaa6728d6281f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_ja_JP.png"
  },
  ["aae8b29a7e3054b78339242ca7bfe55c80b7c956"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_sk_SK.png"
  },
  ["aaf512b5be9a59af7a8442c1436f94d92c3f050a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_vi_VN.png"
  },
  ["ab0ad5f0fc5f843266d491f5407b8878669997ca"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_he_IL.png"
  },
  ["ab181b7852bc968a5efa218431965cf8ac38e77d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_sk_SK.png"
  },
  ["ab32d300941e2b98adcb861d3809854a68e76161"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_pt_PT.png"
  },
  ["ab631c358932fbe893c96a42ab7b8c5e652a72ed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_pt_BR.png"
  },
  ["ab7c0ebc0e1bdc2722086ffadc897ec740ffe1ac"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_en_US.png"
  },
  ["ab824422edf2a587841fb8fd6943297f5a5e716f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_uk_UA.png"
  },
  ["ab83e3d3d1aa243f9b3aa6a9eb7d3bc43a9f2e82"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_zh_HK.png"
  },
  ["abc5a889c209e41dba5af9f974f0ad11eddba394"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_sv_SE.png"
  },
  ["abd212907130671ed288ae13eb72cec9ff06deb5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_he_IL.png"
  },
  ["abf330283a4a7f2ca8bde234a6297fe502b80efc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_bg_BG.png"
  },
  ["ac178a113470ec78c904da45ad495b326edf03b2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_nl_NL.png"
  },
  ["ac7a2c7a372cf98c657d0fbd7b5aa9c1d599eeff"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_da_DK.png"
  },
  ["ac87afec024c4a5f8bd31c6d8c301a93fefa559c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_en_US.png"
  },
  ["acba893db4ea7251bf16324c8c99939c0c450e29"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_hu_HU.png"
  },
  ["acbaf5f4beb396ac5842d22f52a85035175a958c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_th_TH.png"
  },
  ["acce63c84c2586e43803f43311fa77f0bae12cc8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_ko_KR.png"
  },
  ["aceb5f93265932d4468e9cfaf499a57a39bb1f6a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_sk_SK.png"
  },
  ["ad038f0119c51e943c6ac448fc5dc1d9747f68c5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_ms_MY.png"
  },
  ["ad2e40fd518fcf1ce36a1d0d617cb097dd99fb09"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_ru_RU.png"
  },
  ["ad30c18e4bbf3df89975305c19d0d6c3f6a120c6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_el_GR.png"
  },
  ["ad409a5d71977dfd19bbd929bea64668459b1dce"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_uk_UA.png"
  },
  ["ad44f16bec99c1d3c6bd455112a4113da6c6cf17"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_sv_SE.png"
  },
  ["ad5853d5c4b161b19d0f97d093625f91766a027a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_ko_KR.png"
  },
  ["ad944e2a20410af2adf1b255e91e46bbd69c266d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_id_ID.png"
  },
  ["adaf594736458c57ad4105f501ca6e5f8dc0c5af"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_he_IL.png"
  },
  ["adbb3ea29a70dca028c0a6bbbf091f9cdbb299fc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_fr_FR.png"
  },
  ["adf9ee7bd4585f248005c88752994052bf106e02"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_da_DK.png"
  },
  ["adfe7bb0fbd7be78390838e0f7ec9fb15d608431"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_ro_RO.png"
  },
  ["ae1f50cfe856a98907ad6225aefa2cae13af325f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_pt_PT.png"
  },
  ["ae3417279a9e73c1b5357da26e946b77b6f3e0e9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_fr_FR.png"
  },
  ["ae3c5ffeb3792d6b1f5c0f7a0e924e2bcc8f26ee"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_he_IL.png"
  },
  ["ae3fb45f0265af68aab66e50b305b29673578941"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_pt_BR.png"
  },
  ["ae509ca141bd13e2eb097049c6d9c91d2416d22c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_nl_NL.png"
  },
  ["ae7caf3c390fa8fa06c92ef2aa43ebacebde1ce3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_sv_SE.png"
  },
  ["ae8a2ef42c90a17ea70338f0ffcb0a51c268029e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_fr_FR.png"
  },
  ["ae9ebf3be1420328541fbd4e94c7d752f25ce408"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_es_ES.png"
  },
  ["aebf8fc74aad9c68065b2e64060dc72a0938f0cc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_ru_RU.png"
  },
  ["aee4936d6ec82b0d76e39a242198e663c0a0b620"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_sl_SI.png"
  },
  ["aee5bdcb1a94cbdee08da4dd272340324f3341c2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_zh_CN.png"
  },
  ["aef5a7519624e1c2c3590f6f7b9677145df16c5a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_zh_TW.png"
  },
  ["af2a91e7e3d2585d33bf90db8bc743a2cd98b202"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_zh_TW.png"
  },
  ["af34e10d5581cb0e09dbe20b9dfc46a327e9b430"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_tr_TR.png"
  },
  ["af4136910f1fb396ef73ee060c18ebb811be0ece"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_nl_NL.png"
  },
  ["af5f7d78654d3908223735ea366c26518ef4e0de"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_el_GR.png"
  },
  ["af93c9360c19205a775772591e5e8367307ba0c5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_nl_NL.png"
  },
  ["aff6546df043bce3c988b3eb7f05c83a2ba33f0d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_ms_MY.png"
  },
  ["b013e7aa45f0f9c189c0bbe9f484297916656268"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_fi_FI.png"
  },
  ["b03ae2fa80ba15f0cd6aae246670780f5c4b4c84"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_pl_PL.png"
  },
  ["b0481d1f8ba875ad89ee68d3d39af2d5b3d06406"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_es_ES.png"
  },
  ["b04f51236c84dc29cfa117ee04981bbdf847cdd6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_el_GR.png"
  },
  ["b05e42c160fec8f0c91026157d1977c30f86e3ba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_it_IT.png"
  },
  ["b0a971e8022406f3f17f3793e33720e47b4a7c64"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_fi_FI.png"
  },
  ["b0c4bd161b4a27825d65c85f8bc341c59ca1d793"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_th_TH.png"
  },
  ["b0d89c1535f81dbf4867ae18b3e82d7478ceb46b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_el_GR.png"
  },
  ["b106ef60e83be30b14e53f773d460be2413c4d04"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_el_GR.png"
  },
  ["b12cbbb3ead264979a1807f90b1ef91b0e2fe627"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_nl_NL.png"
  },
  ["b1326b6136ebb87c84bed311e6b018e1398cd3b0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_en_GB.png"
  },
  ["b14fa275110066a74e062e1365637baa9613461d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_th_TH.png"
  },
  ["b15199799f12fc4a9d3833bc7cf556e39cc77763"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_fr_FR.png"
  },
  ["b19ea15044bafec6ee5faec63b096e31a08d3817"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_vi_VN.png"
  },
  ["b19f8d9d473b57bca4cbc8d19ff305d61d50e471"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_hu_HU.png"
  },
  ["b1a0271b549468a4fcb3bdaa7371f820fa0c6948"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_sl_SI.png"
  },
  ["b1b0bb65dade56a8ca23e6c6ef8c0a65cc4ab61c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_pl_PL.png"
  },
  ["b1db40bf7834e79b63260d1a54e73283475ee092"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_en_US.png"
  },
  ["b1df0f04a095a3528cb97789d460a06f5eade2e6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_tr_TR.png"
  },
  ["b20c51e867a817822cbb9cf6bb697facbf1c9b13"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_pt_PT.png"
  },
  ["b21e37d4526253c59455b7fb7a7377284f0ce29a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_zh_CN.png"
  },
  ["b23afde1955fbebb067c513a128b1a6e1e199308"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_zh_TW.png"
  },
  ["b262c7396b0ec04c227bb719d527d9c37863e1cc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_zh_CN.png"
  },
  ["b2979c0c6a96d4bd91165e06cf520999d1f72bd1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_zh_CN.png"
  },
  ["b31e62fca58eaaab84b977850532d32e151c12ce"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_ru_RU.png"
  },
  ["b33dfd74cb59efd71a574e1a955b6b674152bd54"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_pl_PL.png"
  },
  ["b36ecbc5c775fdfdc2fdb9fe5252f4bf3d7fc0ad"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_hr_HR.png"
  },
  ["b377e57ecda4793c9dd929412ced793bc7c180fa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_it_IT.png"
  },
  ["b37be46d645f4d70648c2aa1e476497a61d12183"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_pt_PT.png"
  },
  ["b387836504f6203d9065e246cb85c1007d801b42"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_uk_UA.png"
  },
  ["b389647eb5c74608588b346e03a52777e65de3ca"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_he_IL.png"
  },
  ["b3a2aa44dcec98c4f795e26e8833f28a979aeb35"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_bg_BG.png"
  },
  ["b3a9186a5bd4c44d97d9b3b21f67dca7fe1b3b29"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_fi_FI.png"
  },
  ["b3adae908211a59e1c0adfecde73a9df6a06c389"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_id_ID.png"
  },
  ["b3b63ffa8bc94dea144edbabfedfc772903c79c8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_zh_CN.png"
  },
  ["b3bb22dada0d555794e4d1c4b12b1d140b65c7da"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_fr_FR.png"
  },
  ["b3c420c8f393cd7113213c711faa7ef2fe4a357a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_es_ES.png"
  },
  ["b3fb9f817c96426b4d97a3cfddab99c6f95e1bd4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_pt_PT.png"
  },
  ["b4032101f13bdeac5c394a783b97a4bc721970a6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_pl_PL.png"
  },
  ["b4046428c4bc24e7a188855894ab1a46e6855808"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_tr_TR.png"
  },
  ["b40639e2e96e9b5aa615938367c3b3853bde032f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_sv_SE.png"
  },
  ["b40662f3e01954e25198b4df3d39b862f084f6bc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_hu_HU.png"
  },
  ["b419070bafc94ccfd5a7e62d407f4b86c30b2be1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_vi_VN.png"
  },
  ["b44081da95ebfc76bf7097bc3948939738b03965"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_nl_NL.png"
  },
  ["b446e86c0af6196794713febca5b0550d5bc8449"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_ja_JP.png"
  },
  ["b45f616620a3d6c8e3d8ca052225ca6c12d0a504"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_ms_MY.png"
  },
  ["b4644cc23b9e5660bda116641ac6604075d897eb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_da_DK.png"
  },
  ["b4649bb078af1be88730551998ed9dad2709d6e8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_ko_KR.png"
  },
  ["b46c7d5df4364e4a05bf8198647ad6f6a0df4424"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_da_DK.png"
  },
  ["b4834c28d06f6005a3dd07ad1d8e8f1f6cccd7bc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_en_GB.png"
  },
  ["b4ae6b41cb2c5c6d3b63d9126d43626ea7c901bf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_pt_BR.png"
  },
  ["b4b8fa8faf6863f19938e3f9745bc1ed8b0e6752"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_fi_FI.png"
  },
  ["b50bd390b25201fc4ad52c55ccf9c404223920b1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_it_IT.png"
  },
  ["b512c87772bd0106a870151bf9967065d4ced6b6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_sl_SI.png"
  },
  ["b52325a82a83f0178e6a32b1a7045a77d0bfc698"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_hu_HU.png"
  },
  ["b52376c2a2fb316bed3e9070e7bc457cb80967ed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_id_ID.png"
  },
  ["b52ed12ed02dcdb8370fe06148484e3cb3c205be"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_ms_MY.png"
  },
  ["b54afc093f456fc31dfcaaf45e5f0176043ec286"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_fi_FI.png"
  },
  ["b556de34bd82475685652f825019cab1cdb6f01a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_pt_PT.png"
  },
  ["b56b301d1fe5a34d6e467f75e18a9e1360564d1e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_ru_RU.png"
  },
  ["b5919c89804ae0e582c39404fb403d219e347978"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_id_ID.png"
  },
  ["b5a415a2d287089dbd5244f39369408b320d628a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_ru_RU.png"
  },
  ["b5dcf0c921ea69c6f85cf3f1af262c5b6b34a8eb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_zh_HK.png"
  },
  ["b6147656a08f3300882a71a414312d8b37fbfbb9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_zh_HK.png"
  },
  ["b623224ab37a2cc9a6ea03d5bc1861ad5959d9b2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_sl_SI.png"
  },
  ["b63b45cec84afa98be9da3dd60ecc438b0a6358a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_ru_RU.png"
  },
  ["b66863120e3fb8b6fb7ef7165d1382843e0a7407"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_da_DK.png"
  },
  ["b6847edf5d41bd9743406a6746d575444c0f2531"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_pt_BR.png"
  },
  ["b71190f2e83e8dd3708d9eee7490cf675089db05"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_pl_PL.png"
  },
  ["b731407e5558ecdca2c679bd78b6a5ef912cab42"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_pl_PL.png"
  },
  ["b7360bd80403e8b4c3e5880d2a6effe9e7b1296f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_ja_JP.png"
  },
  ["b73e8d6aa475a51e1fbd6f8b23f7b7b259d93a51"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_zh_HK.png"
  },
  ["b7567fe32b7dd558f42f41c700ca869b1abc6705"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_uk_UA.png"
  },
  ["b7592abdb11db9fbb550a894082e012d20b3742f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_da_DK.png"
  },
  ["b75b3e867e0b331f7c824340bdd26a8ed0441e4f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_vi_VN.png"
  },
  ["b7920d6849dd91dc711d7fe1a018088e79a800b5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_en_GB.png"
  },
  ["b792239fdb1873332319ef385f4961f3dd8fc85e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_hr_HR.png"
  },
  ["b7a96f950ef6c8e82bf62e92dce9c973176f3407"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_hr_HR.png"
  },
  ["b807c9687d28f7340808944d106fca96474bdbd5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_hu_HU.png"
  },
  ["b80805d24e60a4d555e85aa155d97611d039c94d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_he_IL.png"
  },
  ["b80f410bf17a7a49f0a9403f6457e5763d24f3cb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_vi_VN.png"
  },
  ["b820ef16aa52719fdd88fa98e1276139b568297f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_cs_CZ.png"
  },
  ["b82bb644a7353d6aea658bb04872e9b4158c2f35"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_de_DE.png"
  },
  ["b8416dc68cb0470da424c1ac706f57b6c9b8b16f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_de_DE.png"
  },
  ["b857c61440bd23ea8c2fb03ea51c943e6251bc97"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_zh_HK.png"
  },
  ["b85ccad76f899470bb008f01436970e02aa27095"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_hr_HR.png"
  },
  ["b860d05ad2992df2f2f1c4cdbcd3e8648b5be42b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_zh_TW.png"
  },
  ["b87f66edf453445c922669f254f605f9d57b1193"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_pt_PT.png"
  },
  ["b88b1417f2bc701db884a81e8fa7cd86dd3f376c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_sk_SK.png"
  },
  ["b8d1882024c91b860e5252ff14f893879332df01"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_hu_HU.png"
  },
  ["b8e640b9c59ca6946582d8a5421b93aef58afe7e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_it_IT.png"
  },
  ["b8ecfffa3febefc839d0c1fa7d150776e623b32f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_vi_VN.png"
  },
  ["b8fb1c7f83e684cc580ca1d27fec852973a2fa09"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_no_NO.png"
  },
  ["b90b5fa92fb177d4d1541c482a0c353fd7279d88"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_zh_HK.png"
  },
  ["b94f5b0c5c4a6d5d44957ef0eb4d0dea066df19c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_pl_PL.png"
  },
  ["b95022598647d2b1436ab43e1f9dd989529bde48"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_bg_BG.png"
  },
  ["b95d75acb0993b8c059a1dbfbbd45f36ea59943c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_en_US.png"
  },
  ["b96b8e6e149379a27fd29d9e2be865a2549a042d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_sl_SI.png"
  },
  ["b9743e65cf91a32653689fa1ad5f9b2960f97fb0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_ro_RO.png"
  },
  ["b977202b44b1dfafbe803da17bdc78ccb9b0be16"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_sr_RS.png"
  },
  ["b983e948b344d2fdc1e8572e2857a672e8dfafab"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_vi_VN.png"
  },
  ["b9b60dd7d42ce5300f5d95cd46692a2c9cd277ba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_fr_FR.png"
  },
  ["b9d5b729b264aa0818f6cff15b7302b63c0bffcc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_it_IT.png"
  },
  ["b9ea18f548993e44d55871210b2816f3d53cd56d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_de_DE.png"
  },
  ["ba0c511afc09eff00770dbe185196d222f07938c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_en_GB.png"
  },
  ["ba12318f9be0e0fcdb6d0b4edec88e897dda4a7a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_ru_RU.png"
  },
  ["ba1c13641c3795dec334499b5d3b321bc8249cb6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_sv_SE.png"
  },
  ["ba1d097aba5cc43ee7944f2ea07167f5c2bc22c9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_zh_HK.png"
  },
  ["ba26145962b511d85edea616cb5835dca0a2084f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_es_ES.png"
  },
  ["ba39e46c6b8310c713b4ae0b3e2ed651dbd878bf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_zh_CN.png"
  },
  ["ba49274da639fdc5677b4bd47a58638cf13107e1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_fi_FI.png"
  },
  ["ba8a587e9cf20b6cce1e89e57886d21de3570c89"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_cs_CZ.png"
  },
  ["ba9123f393d2ce46214a1e54212484262b7f77fc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_fr_FR.png"
  },
  ["baa31ca8477c84acc87975a222ce8b1642103203"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_ru_RU.png"
  },
  ["baae26bca56561c3073f862454340568100a6536"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_it_IT.png"
  },
  ["bae3e7be97dd59f258d672575c6b040d84a1f15e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_id_ID.png"
  },
  ["bae4a6febadce52dd097fa12ba7b9baf5dda99f4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_ru_RU.png"
  },
  ["bb187b7581633c109fbe6dd02bcc48f9c8682e65"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_tr_TR.png"
  },
  ["bb2f5811631bb510f56b52c5aadcfa1963301018"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_ru_RU.png"
  },
  ["bb5e48885551136025167a70bb25b8004efc1e32"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_sr_RS.png"
  },
  ["bb8dcec9725a09bd520dd2f74faf23b4a040cbc7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_ja_JP.png"
  },
  ["bbab0f3b09f825cacd0d0c808549a5b034ff21de"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_hr_HR.png"
  },
  ["bbb672dc66abc89a67a751aee35cdd3a0e99e787"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_th_TH.png"
  },
  ["bbb73a4f4623918b4469589edfec16db3c615289"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_no_NO.png"
  },
  ["bbd058dfb39d852aee3d6be80a53014306d6235c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_sk_SK.png"
  },
  ["bbe2b6126a87ff9360578083c6e2095a1dd65d48"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_zh_CN.png"
  },
  ["bbedf31830f38ccb6c2af862177bd2984598a155"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_zh_TW.png"
  },
  ["bc12a61921f6d122a9d979ca94f918e9152668dc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_en_GB.png"
  },
  ["bc2e354ad6a7eae936bcf3122bb86b72b1406441"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_pl_PL.png"
  },
  ["bc4075ccfe0e1e90308d3d0fc3afa1ea49f53348"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_sl_SI.png"
  },
  ["bc48c0c2ceef5c4f6c4a80b08a2186675734500c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_ar_AE.png"
  },
  ["bc5b9a00b44b6949ea4c245eb025fdfc96b39cfe"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_th_TH.png"
  },
  ["bc7f912802caf4afe7fb8bd1d21cf890dded67d1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_en_US.png"
  },
  ["bc99c4ba8c1c4f0c0bc9906672610c33355bb3ad"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_he_IL.png"
  },
  ["bca5e7c61e6bcb1ea619cca838644cc971d43c34"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_sr_RS.png"
  },
  ["bccc4bcc558323f859fde62ec64b635699539980"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_sk_SK.png"
  },
  ["bcd575a7096265fa78d2d411a3f35e6a7080ecb3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_it_IT.png"
  },
  ["bcde52b3dda35db393831fafabc4fa6ba49c7af7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_zh_HK.png"
  },
  ["bce399ef210ba3e8d33139b3ae2e766acd4249b4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_sl_SI.png"
  },
  ["bd13744fb569546ea3efefbf137e99962656d2b6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_ms_MY.png"
  },
  ["bd43740d236544a5c8087bdcdd624063331b4f0a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_zh_CN.png"
  },
  ["bd76390e6cb2301179a2fb5c0e32b9322b5637d1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_uk_UA.png"
  },
  ["bd92c2cc537c5fa080db5cc5d844125fae1221a5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_fi_FI.png"
  },
  ["bdc40b331e4253f8a62f233f72f7840d658fd6b4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_id_ID.png"
  },
  ["bddda147daadb46ce64c75abbff2aea009023a9f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_hu_HU.png"
  },
  ["bdde747b0b4eeba7aff385c9e630e2c1194c464a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_ru_RU.png"
  },
  ["bde2183e5dac39c3abd364be552517f1badbb1dd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_el_GR.png"
  },
  ["bdf7da974e3dfa9b57a42870edc534646f0b8906"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_hu_HU.png"
  },
  ["bdfa74288e5f8967b527797a0336ac8e5fe0ed9b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_sk_SK.png"
  },
  ["be0863ace836b2bb854a5c504438e9b206e30458"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_tr_TR.png"
  },
  ["be4be8a28c635378ba03947d9d207e52223c7f00"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_ms_MY.png"
  },
  ["be8a33e2d8a5aa8918390fe23b2b8657ca1cd5df"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_el_GR.png"
  },
  ["be9527d3ccb717dd4fc27ac0457c9b99525fce1f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_no_NO.png"
  },
  ["be994bacab65480fc1bd200afef4d38e96d51d27"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_no_NO.png"
  },
  ["bea0a1c3cd2d5b865b3216fdb84e3173825c876c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_el_GR.png"
  },
  ["bea349a0cc4afa7c866ee5ad29a26c42832b9030"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_he_IL.png"
  },
  ["beb2bef2b597f9b8e8c81d344b7e32ce0b96e78b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_sr_RS.png"
  },
  ["bec3f97e83d41d3544700a0950813a1322d42292"] = {
    assetType = "image",
    destination = 2,
    path = "Images/partner_logo_bootup.png"
  },
  ["bec974914ea92c42f4431d4d3f127ea149c2244a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_no_NO.png"
  },
  ["becac7a2f0378b6024c4e5904a35cc29171243c6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_hu_HU.png"
  },
  ["bed93a27a3d01fec44402b3539fc689bcf015ffd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_de_DE.png"
  },
  ["bef04c2ecd14715359af8bdf3fc8df5e343873a2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_pt_BR.png"
  },
  ["bf0b65d3599a696dd3adca35946d452f5f9e28f5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_zh_CN.png"
  },
  ["bf1374b95c4d86f451c398996e6d0a03da6c741e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_cs_CZ.png"
  },
  ["bf97a9ecf87444af8c09f3201064683d9e80d4cf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_hu_HU.png"
  },
  ["bfb3b190b89c46e81fdc63507c861fd24f7aa09d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_th_TH.png"
  },
  ["bfc28e816d0f1e2f8bfc6ad46280806c89e0c804"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_no_NO.png"
  },
  ["bfc75489dbd4a8268b8f1504d18df2a808e27c4d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_zh_HK.png"
  },
  ["c03b5141c1f630bd6a5f6c640e7398740e0176ae"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_pt_PT.png"
  },
  ["c06fb18b91da86bfc90fa7a97a976ece0eb4a160"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_it_IT.png"
  },
  ["c0776bcc400a9236c12eaaba0409ecee86f8edc7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_no_NO.png"
  },
  ["c0af64194f83af8f8c58935060d06e507cb882d5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_tr_TR.png"
  },
  ["c0b9a72ea34f2854c1243007073ecbee8078697c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_zh_TW.png"
  },
  ["c0c0734db41bce42952c5c1c1fc8c04330d30a67"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_sv_SE.png"
  },
  ["c0dbb2bf9d265368672f7b5531fc41c3f1678254"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_tr_TR.png"
  },
  ["c0f4d0258ed954d1cd43a14087cc8e750202255f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_nl_NL.png"
  },
  ["c11e7f9441dc613c0f9cd3e87b05f26bfd4fb2c4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_nl_NL.png"
  },
  ["c15a13537e9bac4551c5beae27f94fb3ac01a8b5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_it_IT.png"
  },
  ["c18b595490a46b2805036d3b9059b1938c8dbc4c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/Shadow_Top_Edge.png"
  },
  ["c1a985ec5d69c4016fdf883934672973ba6b7fca"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_it_IT.png"
  },
  ["c1b7a31546dcb6582be4d4a07a84c482b7d1240a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_nl_NL.png"
  },
  ["c1d86d3e2a01c35652336c655d5968247e825d0d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_uk_UA.png"
  },
  ["c1efce8a69aa0e5f9bdfa89387002a090af3251c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_pl_PL.png"
  },
  ["c1f5943c198223ba7793c5cfc26662fb02db373c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_vi_VN.png"
  },
  ["c216b2b6c9dcf9ad2b54b3b6c503e4698b9d5736"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_tr_TR.png"
  },
  ["c2321057697479029c8a0ff84ddb8126c2306732"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_it_IT.png"
  },
  ["c24189cc49f15b0252f4f96b948ac898d0620577"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_de_DE.png"
  },
  ["c29393533b8d560c427ee73c37c5e978451fbcfe"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_ru_RU.png"
  },
  ["c2e7f7581df1a62a41af26e7d951f200d71c87e8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_hr_HR.png"
  },
  ["c315d1c6b6d317c4e7d774edae5955dce45575f5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_sr_RS.png"
  },
  ["c3334459b2a288e331ce6a9ba44ae3fc66d7fd41"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_pt_BR.png"
  },
  ["c33424b5d0d709342e71825062f41e74b8e8dd54"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_ko_KR.png"
  },
  ["c340edb7f8f6e0328e65822e90d6a53425f89bfd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_sr_RS.png"
  },
  ["c37c730c0a0acf646d417a06925a22f8de93a916"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_sr_RS.png"
  },
  ["c38a7ad6a8563a61a1ec2466210b50eeea9dcce4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_en_US.png"
  },
  ["c3942eff5efb1b7215e908607239f76f823dd0f4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_el_GR.png"
  },
  ["c3968c1ed98f0f479cb5cdf11dab06d597853a6d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_ro_RO.png"
  },
  ["c3b60e43f73aafd05a10898142ab574959496d68"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_bg_BG.png"
  },
  ["c3f777460d927c75e0e3b3b0e9b27b591029b4b1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_ru_RU.png"
  },
  ["c405fefac6d1d9cc68f78f96f33a9bc3e7b881fd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_zh_HK.png"
  },
  ["c409728cec2d8f083e4749b3d6bd80c9c26559bd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_fi_FI.png"
  },
  ["c41b0e6c985187288401741c82b941838b24a138"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_cs_CZ.png"
  },
  ["c4409107e4c0e5c2faf44aa6c2919f6424d66146"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_id_ID.png"
  },
  ["c461accc1efb334b7dbc768b66b14c7164bb30c3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_hu_HU.png"
  },
  ["c463172a95ad101a9030c0ba8cb9683700ef7c6c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_de_DE.png"
  },
  ["c46317c49c4b3b71c1da9ebf6b1c861096769c57"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_id_ID.png"
  },
  ["c470e65db16f0839aa75b90c6ae2992650da2436"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_de_DE.png"
  },
  ["c49758a6ba4bc92e44f0ddc31c3b98e848417d76"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_ru_RU.png"
  },
  ["c4b120f541ec0b17806f431a5906b4875941ea1f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_es_ES.png"
  },
  ["c4e9ab930c08338311659de26e63c8116d7a0055"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_ar_AE.png"
  },
  ["c4f05a547e48431824a27ec8b047c12c967996ea"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_fr_FR.png"
  },
  ["c52095b83297d6b87975d614de9e5cc4cc9a1831"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_no_NO.png"
  },
  ["c5303acd1a713805e580d5a2421117d73c617b8a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_th_TH.png"
  },
  ["c5596af81e75ed86c8b4e8ac1fd4ae4ea253b378"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_id_ID.png"
  },
  ["c55bb0598fb4943caa6e9b96afa1f0d3290aa1af"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_id_ID.png"
  },
  ["c5685530d3a0ee98044a029d6530b5ebb0d313ce"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_ru_RU.png"
  },
  ["c57176facd649d4e4c33caa2d9d9a4526b0353e8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_en_US.png"
  },
  ["c582b91b49529ddc76b1e2d4bda1b0598067d64d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_pl_PL.png"
  },
  ["c58635d6b0cdbbfb7963247c86617a65daea0b4e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_bg_BG.png"
  },
  ["c5be6d237acdd548a7825e89a2bca4e64babf49c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_en_GB.png"
  },
  ["c5c24fc79439184027f241c640cbc98460ec23fd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_en_GB.png"
  },
  ["c5ef56eda8070888a6860ad8bec75a4cc641b03a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_ms_MY.png"
  },
  ["c5f7554919ff3a8df9ba76409c9fdf74b7365413"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_zh_TW.png"
  },
  ["c5f8ff97a2afe21c101feccb592a8e33418f2bc5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_ms_MY.png"
  },
  ["c5f9a17086e342e4839c3a43745d224443f4e6dc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_tr_TR.png"
  },
  ["c62a082501a243b2508e2a3890e074e83264ef46"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_fr_FR.png"
  },
  ["c62f51151906785c282014232ea1e2fe748c2e70"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_pt_PT.png"
  },
  ["c64b8d82351a96ddf73cd6cf28292f99b5a22d84"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_ko_KR.png"
  },
  ["c6541f2419f6babc0811eb8a62265e3bc3c9c280"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_de_DE.png"
  },
  ["c6644a7dd70061c5407e8ed633062889c6fdd033"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_ar_AE.png"
  },
  ["c66b52afae5873355ce2d7af349ec7e7f80486ff"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_ms_MY.png"
  },
  ["c6b2fe34fbc5e09adb8f2ea4ccce66680f64b634"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_sv_SE.png"
  },
  ["c6d23c1b3b02411286d21578051e98d6ac3933f9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_sv_SE.png"
  },
  ["c6ed9b9a40edf18faf58561d0cba4ca696a52909"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_el_GR.png"
  },
  ["c705feed0fac4cc54b17d097cf8fc5c832ec9bb1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_sl_SI.png"
  },
  ["c714e3997afed105d93fc5b14ecadad6c5d8a5a0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_ms_MY.png"
  },
  ["c71a9e07981c854377248ff41bfaf68c95b68f11"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_cs_CZ.png"
  },
  ["c73fdfb076cf1d991da7c4cd74a2fbb16543fee2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_en_GB.png"
  },
  ["c75e841846e1dcf56e47703188d5bfd1484965d7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_vi_VN.png"
  },
  ["c7739a6b2eec2a27673a9661755773b934038232"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_pt_PT.png"
  },
  ["c77e9c8799939138d80d7654c6e7d738319d0b4d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_en_US.png"
  },
  ["c7860e259e61e522d91f4ef0e17201a7b369fe37"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_ko_KR.png"
  },
  ["c788858d703fdf6b9a0162a11238d1f7b3744791"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_nl_NL.png"
  },
  ["c7bc920226707f9cfb0177add732193d26ec0767"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_th_TH.png"
  },
  ["c7e10ee1dd8ecb6f1f6546b99be52f95c66ebc31"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_cs_CZ.png"
  },
  ["c7fab4eb0f5d7b0f9caaa4da12aa961ea4aae7f8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_no_NO.png"
  },
  ["c800bbc7d9a628e29ef4d67f10c568da21e13eca"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_en_GB.png"
  },
  ["c879b4136f35ac437ee9da9a42354f559796af6b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_en_US.png"
  },
  ["c8b8d98207d2ea2b391e7b46eb9270069ea6d8ae"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_nl_NL.png"
  },
  ["c8d79155c9c29ee18a449720003b9c6995ed6069"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_ms_MY.png"
  },
  ["c8e90995e2d5ddefaf578c73101301e540d20ab1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_sk_SK.png"
  },
  ["c8edf2de6f62d29a4810615ddf233a980ce7132f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_en_GB.png"
  },
  ["c920d73c9216664790ac75cee092e3d165fce8e1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_en_US.png"
  },
  ["c937f62189716287fcdbfedfa304eb2780ac7bd7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_sk_SK.png"
  },
  ["c93f36b124a97e5f4e55ec092808c3a7126b5992"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_he_IL.png"
  },
  ["c94c74d5d05bf2324c7922f91c9634ce5a14e3d8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_hu_HU.png"
  },
  ["c94d43d7e84c4bf2c71826e2dcb55c1f93e9a156"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_sl_SI.png"
  },
  ["c956db4416a604981b752fe754e37bf9f9322015"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_zh_HK.png"
  },
  ["c9bff81b61590ad978c44d4676262af411bc0550"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_bg_BG.png"
  },
  ["c9cb696b617ded3ac6b3e80e7ee3fadf4d31e4ee"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_ja_JP.png"
  },
  ["ca46babeb92fd7e864e2c5a31ddf7f2f0e83b530"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_zh_CN.png"
  },
  ["ca48d8011dde68b0b86725227e6a11ed046fa844"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_sv_SE.png"
  },
  ["ca582f4cc6c036c2110fddf625df0ba69f743dba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_tr_TR.png"
  },
  ["ca58f76fe8202dd25a3add0d6b8064e49002ebeb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_uk_UA.png"
  },
  ["ca5e7cdfd1cc42272c91f9bc35bd6de3d0f38e51"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_ru_RU.png"
  },
  ["ca618045c2634ac82a294a14ba5263dda7b959c7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_th_TH.png"
  },
  ["ca82406616303fa314f95f6bea81417a7d719289"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_zh_HK.png"
  },
  ["ca863d1a6555c88144004fb84e99d51475ad12e7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_tr_TR.png"
  },
  ["ca8930fe665d7ffaf82e5c0becd6212fbe6327ed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_uk_UA.png"
  },
  ["ca98bec579967c85388038e50c3c0fc612d01ecd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_zh_CN.png"
  },
  ["ca9c3407f763bba2e1397590ac95881cf5bd9eec"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_nl_NL.png"
  },
  ["caa78f4c8b6d3fe4470e19d3ebedb8cb5a87c2aa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_ru_RU.png"
  },
  ["cac067ce71db0bb0b523ed2906a714245e305eab"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_sv_SE.png"
  },
  ["cacc51a90968f99886c0535a5b3c476823b1c7a4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_hu_HU.png"
  },
  ["cadb5f378504af7b8e0386a2620b5045ad3143bd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_zh_TW.png"
  },
  ["caf7cad320e73a44a85fca8e88982cf3a3ad1684"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_el_GR.png"
  },
  ["cb0100b01a46a696e1192c60e4172a18c9a9caa0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_zh_TW.png"
  },
  ["cb47059330b3514914ac619a44608e81f913ac6e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_hr_HR.png"
  },
  ["cb4c5f8fa04dfe58988e27d682678fda2aec1847"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_sv_SE.png"
  },
  ["cb6a76bbd2339f78988b03924302082fb731bbda"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_cs_CZ.png"
  },
  ["cb718b4d0215b0bbe15732333b0ba7c3a0cfb765"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_zh_CN.png"
  },
  ["cbb26618e120defaac7cb89f9f40d5dffe80afb2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_en_GB.png"
  },
  ["cbc7cbc43028599c3ab8440a0a1e195f21be846b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_de_DE.png"
  },
  ["cbe670ba9119364b3604b76a63629bb91610ec29"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_ko_KR.png"
  },
  ["cc0612f4b5f5652a40838d9df533f2ee1b158cec"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_zh_HK.png"
  },
  ["cc0804f11135e66a3a200cda034363c208d03642"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_nl_NL.png"
  },
  ["cc9fc7c6ae9f14a58a3ed005462ce890c4bf0641"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_it_IT.png"
  },
  ["ccc4ce438d76d03ef246ee2ecb9221de0a9aa39c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_fi_FI.png"
  },
  ["ccce7cf649c1d36787ce5a10504772ff025b47eb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_sk_SK.png"
  },
  ["ccf3b56514163bbf0e9f58845b4970a7282aeddc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_hu_HU.png"
  },
  ["ccfc3e0afd87177150ee8305700feb1c6da19118"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_ru_RU.png"
  },
  ["cd3d0c848e3296d8e0df46350dc804a3e0fd6ceb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_en_GB.png"
  },
  ["cd5d7ee9f8bd0b2ba7a1fa8da4b17c6a90a09bf5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_en_US.png"
  },
  ["cd5dfa584af19b0a21b31ceb4e0a4d15662841d7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_cs_CZ.png"
  },
  ["cd9940420a68f9f881a423daa781ed3d7e44c603"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_zh_TW.png"
  },
  ["cd9dc2abd31e30ece3ebceb8b201510b8897ef34"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_ko_KR.png"
  },
  ["cda3cd63a838faaffc0e7f82c588e4f15da251bf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_bg_BG.png"
  },
  ["cdade8b8610ed19f4b47a1bdbad93cbee2f9088e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_it_IT.png"
  },
  ["cdce8dc3d558c2fd7601bbd2aa784fe3ced8240e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_id_ID.png"
  },
  ["cdef1a58b5d8d31240b09140f36ab4a52adb944d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_th_TH.png"
  },
  ["cdfb54694b014c2a897c0b7e079d5b2c16485975"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_ru_RU.png"
  },
  ["ce06a327bf3614323f6097e4cc9497e2d6c91946"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_vi_VN.png"
  },
  ["ce58e1041374c7a82b15e9e0f3166f455a09bf1f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_hu_HU.png"
  },
  ["ce6eabfef4d043b09d2a13fe03c2c6e2b86c57bf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_vi_VN.png"
  },
  ["ce9715acc1d5b81b460083e32b03e4b3af5c091c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_sv_SE.png"
  },
  ["ce9bca5888c4382b9c1e07e78c798e1e0356a6f8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_da_DK.png"
  },
  ["ced0734e304b37aa6facf5a72a0a456d7a325633"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_nl_NL.png"
  },
  ["ceea284053ac60fe4322fb542c4de4ed58dc2096"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_bg_BG.png"
  },
  ["cef33b6f07d1a8bf88934a7ca6d07d80b6ba2ce4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_sv_SE.png"
  },
  ["cf1851c31a29ba20e2e168cca5cdaea4377af71b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_pt_PT.png"
  },
  ["cf2b6c069bcb838dff2b7cb3e81a94c64aba7cc8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_fi_FI.png"
  },
  ["cf400c300697558196bb7eda16b8336e3d09d155"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_da_DK.png"
  },
  ["cf65a9b2954e6170c131acf189fbc7d9c0673131"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_sk_SK.png"
  },
  ["cf7e0f465508fc4e9b680625ffb8157546fe156b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_de_DE.png"
  },
  ["cfa240e24feceb18481241caafd649b2c5561c92"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_it_IT.png"
  },
  ["cfbea9811d5824d4283827d6446a6d362d081b81"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_uk_UA.png"
  },
  ["cfe78003b7d633bb0de4c923b1f812c463e4eb3a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_ar_AE.png"
  },
  ["cff4e31866c013e1cef4087c2a39ad3075c3bbdb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_hr_HR.png"
  },
  ["d011175eecfdc3fed8027136d7c2d1bad975a799"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_sr_RS.png"
  },
  ["d0458198499b386f64d5f02138c769598bec1ebc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_th_TH.png"
  },
  ["d04efd4e3a8afebedf2d8b8baea04809ea071d62"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_es_ES.png"
  },
  ["d05e41b9509f737291641f86189982266df78936"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_ru_RU.png"
  },
  ["d08640a7a535d6876d07e65a0abd36cdb2f60835"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_de_DE.png"
  },
  ["d08d6e77d297da741567fb88c84dd3b900b7ba3b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_de_DE.png"
  },
  ["d0955dce4d98a322251c8b912a0f3b7981a5f204"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_pt_BR.png"
  },
  ["d0b451ed95deafa2e0d008ad1fe3c997213fc370"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_es_ES.png"
  },
  ["d0cd509a31f0bff27e68ae674099df6616d3fb4f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_he_IL.png"
  },
  ["d0d2fae7466f2f4b586d97db4521917111ed7079"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_fi_FI.png"
  },
  ["d0d79611013b21fc4735b907611ec8411123f7ef"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_el_GR.png"
  },
  ["d10299d54af633c2f6cad13968e935dfab94977a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_ja_JP.png"
  },
  ["d110623474b4dc7bc1611ddcb89dc9acd355d5bc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_ru_RU.png"
  },
  ["d113f5063dd266b304e9960b51a56cd717b0f4b6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_ja_JP.png"
  },
  ["d131ef471bd4408c06c3ca8a415f2a9eddf15224"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_es_ES.png"
  },
  ["d13501a3cebf4832c43dc94009d6807c5dc5194c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/sport.png"
  },
  ["d16633032d39c68721e4fa930dbbba8e0916b28b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_vi_VN.png"
  },
  ["d197230831e3258f3f9e3f7ce0ca79eb6efef180"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_ru_RU.png"
  },
  ["d1b19ba54455dff9a395d2c9b30f38ee10828345"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_pt_BR.png"
  },
  ["d1b52860b393ed965281b8ad793b9b85a7cd6171"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_sk_SK.png"
  },
  ["d1c313a252396f8daf19ff77587210e487cb4e3f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_th_TH.png"
  },
  ["d1d191e4eeaf6a575c7e7e86df2d5e5b0aeba5b6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_id_ID.png"
  },
  ["d1d3de95e20cb181da86822da2c1be6ff7c8f422"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_vi_VN.png"
  },
  ["d1e0b8ba2cecb0e160c86f651ef7ac0897ab4c85"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_ms_MY.png"
  },
  ["d1e0b9ca0c6f85fcc0b27f82e74241af2baab661"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_ko_KR.png"
  },
  ["d1ef573787bbbb5c5c210e8f50b8dba0cdfc74bf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_he_IL.png"
  },
  ["d22f4229b2c1e450103c874782d3ad6109b9ff8a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_es_ES.png"
  },
  ["d22fffa32e7bce5df65c9a56d00319779b942e7c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_ja_JP.png"
  },
  ["d2520913a05c40014f90dae047872b19104e1f8b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_th_TH.png"
  },
  ["d255e9f0a4f492254cfed907e6f39be010a101fa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_de_DE.png"
  },
  ["d25e7820fd23f1d4ed70d51c912dfb8a0e4e75cc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_en_US.png"
  },
  ["d26fba3d8e27e201c84dfd6111d54b7843a2ede8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_de_DE.png"
  },
  ["d2838f3fbd73b2dac05e806ba4d72c5c03c68166"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_ro_RO.png"
  },
  ["d286a3585c8eee9f4a637f70e6236adf042ac9b6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_sl_SI.png"
  },
  ["d29e352a1df695fe80977caf7ecbc862ec2f0b9f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_pl_PL.png"
  },
  ["d2dac87b77870aa75cf6228b368e96669fdbabbc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_sl_SI.png"
  },
  ["d30973ea6a718fa4b6d272f81a57e9bca22ce8fc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_nl_NL.png"
  },
  ["d3139a683ffc36ded68642231a7da8415b94ec17"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_sl_SI.png"
  },
  ["d34fe5db945b752ea6086833757e8ba3d348993d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_en_US.png"
  },
  ["d355942aa82228302e023db2cd1190f0659d3419"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_el_GR.png"
  },
  ["d3692f0acbcc50858754618141b9284d9905d063"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_cs_CZ.png"
  },
  ["d37c90795dffe6a9380fdaeef06097beaedc0fb9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_pt_BR.png"
  },
  ["d388ea1d05e8b2ffb69c064b578d297f669c8449"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_cs_CZ.png"
  },
  ["d3ac8a6f96b5b903db3ee9f5cb7dec4f5b4bded0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_ms_MY.png"
  },
  ["d3b8bfd00839bf83aa6a06849cbac5c0c1e0edca"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_zh_TW.png"
  },
  ["d42a7ae14b16c4df3141fcc5ad6af061205ea91b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_da_DK.png"
  },
  ["d42f42ba838c88c4a05affbfcde8e6b15d097463"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_nl_NL.png"
  },
  ["d43587d49e914876a0cd88349a75cba2fb48cd2a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_uk_UA.png"
  },
  ["d446cff87395280741f950b6cabb271117a46abc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_ja_JP.png"
  },
  ["d44fda313739b942127b6e6d5c45717d1285680e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_sr_RS.png"
  },
  ["d457b64a66679a48a4d1f6902667317ac0f54217"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_id_ID.png"
  },
  ["d462f09a198afca146e7cb749e2d9e4f4afd0050"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_ru_RU.png"
  },
  ["d46b42d5e2e7f4ec4b157951f8c157903c242a89"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_uk_UA.png"
  },
  ["d46f152cac81b3d36dbfc3da07b715e8436e6e18"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_ru_RU.png"
  },
  ["d4936c606b576855075b1601c2bf385cf55e086a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_sk_SK.png"
  },
  ["d495d1cec189432e1d57a13f5ed636db467b1c2d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_id_ID.png"
  },
  ["d4b31b1028c53d4dbacc40982ff4f61fae707318"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_ro_RO.png"
  },
  ["d4c811376b81fc99dfce64940cf25004df930b1c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_zh_HK.png"
  },
  ["d4c961beb55f0239a2a2acf4557c6b5b7d37db7a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_pt_BR.png"
  },
  ["d4dae7538c5c4d1b98794d9949279f2d552e27b2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_da_DK.png"
  },
  ["d4efa034b72e8cd6ddf6bbe5c48b84ad22a0eedf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_he_IL.png"
  },
  ["d4f389782e335209b46372754447afb2a92ba131"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_ar_AE.png"
  },
  ["d50dc1d443bc3b78a5549e1c793e5b9b643dabc0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_da_DK.png"
  },
  ["d51168eb79c26cfed91b477a18671e7bf1483628"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_pl_PL.png"
  },
  ["d512a26710758cb81e5a94935e133773f02e122a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_sr_RS.png"
  },
  ["d56198593fe8681506f9bea0318beb1655513436"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_bg_BG.png"
  },
  ["d590351eb9d0e743c7b5df66bd54cb23e57524b7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_es_ES.png"
  },
  ["d59a4d6cb2afc0933e36471ba6f3460bd5dc5323"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_en_US.png"
  },
  ["d59b3fed476d54dbe73eabae63e415f12e0b9eb4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_sr_RS.png"
  },
  ["d5aacdadfd4fef6ab6c88ffca4e1dd5a19c44427"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_cs_CZ.png"
  },
  ["d5cf75ebeb4ea24d36ed959739683a8a349f5210"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_cs_CZ.png"
  },
  ["d5e86e929aa7deaaa89532e5210e052271230b3c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_no_NO.png"
  },
  ["d5e887c9cfff894095ee3f05decfe4682f428109"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_ms_MY.png"
  },
  ["d5f367f03b3dcdb3cb7a0f977f2f4cb53236d935"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_es_ES.png"
  },
  ["d60c0bbaa78c95ed2325abdac9a58ecdbb3ba6d0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_vi_VN.png"
  },
  ["d60d85124b519d318887c16b0d7ed984842c0ccc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_es_ES.png"
  },
  ["d6132a10c18d7a9013937dda571d58976bd4c2c1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_ru_RU.png"
  },
  ["d62be2c19b9113d785f8e959e569aec7090e45e2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_es_ES.png"
  },
  ["d6344e3a3a3af6f0602a9bb5b64d264a0b0d4638"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_hr_HR.png"
  },
  ["d63c050037eb2520d0b7f761a7570c7e328d3e10"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_pl_PL.png"
  },
  ["d6420b10c81909719962f6b0b71321827606e696"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_hu_HU.png"
  },
  ["d6a71bb4f92d0f8153a68c4d963dbbbada89f04c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_en_US.png"
  },
  ["d6cd1fff3a75d98878c9a6d4e8cc14561a15d4e2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_sl_SI.png"
  },
  ["d6e05d4585777da72759f8b4c5e9923d478c6d5d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_ms_MY.png"
  },
  ["d70116a0df707b9940857ea61926ebee20b96dbc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_fr_FR.png"
  },
  ["d706b3ff3ee2ca960c1430b8af3a746635105701"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_bg_BG.png"
  },
  ["d72cf18ddc24aae1c7ce05d33f7a0674421832a1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_uk_UA.png"
  },
  ["d74f11d17d2ec4d163a3fa7c94adab96d612b3d5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_pt_BR.png"
  },
  ["d762a653cb15be655764b73a517513dabacff58a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_pt_PT.png"
  },
  ["d76d30d2dacb105dadd2dbe68166c0b42916a933"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_no_NO.png"
  },
  ["d76fa1a5f835d18208107b41b008b70999c443f3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_pt_BR.png"
  },
  ["d7a2a09e5f680312c55817e4a54514c029a93554"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_es_ES.png"
  },
  ["d7b4f35f62695dfe9f355c7206e594040a8daf21"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_he_IL.png"
  },
  ["d7c36f7ef8742b6130887b208c3f5b0a4f8257ce"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_fi_FI.png"
  },
  ["d7c4222de92e17ca3888c6fd9e5b49266eb403a5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_hu_HU.png"
  },
  ["d82ab9f6da86dbc723dcec7176405ed24495d7d5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_sl_SI.png"
  },
  ["d82b3980f0b9bba021dd00bd18f5094f967736b0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_tr_TR.png"
  },
  ["d82e010bf996c292047402e7fc8d301852babbc6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_ro_RO.png"
  },
  ["d833f126780ddaf005a11bc7f956745d4f8cde49"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_nl_NL.png"
  },
  ["d8499fa27ede2435672d6bc2a239ad5df1a68629"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_id_ID.png"
  },
  ["d84b2b55f107d9a4dbea43224c6651f092d3ce99"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_ja_JP.png"
  },
  ["d84e5903bb95d84337b10edd11db4c886240c215"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_es_ES.png"
  },
  ["d85d98a44c3e7cec82ee74c081aa0a0221994949"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_tr_TR.png"
  },
  ["d8c80c0089875846263ac1a9747f450aebff8d93"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_sr_RS.png"
  },
  ["d8e75b9d07dc4823989dcb88a22c546c05c14233"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_sr_RS.png"
  },
  ["d9174afb0a2afd2e7f461c31d6ed24d4a1a09380"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_hu_HU.png"
  },
  ["d9223865f3031209763f4820cfd167459f3e32c3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_fr_FR.png"
  },
  ["d94001f109efa524fb268a87977f4aff0d257c6a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_ko_KR.png"
  },
  ["d948fabf20766eab2251f1104fb313b5509c554a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_sr_RS.png"
  },
  ["d95bf81e7f9c4f599f846d3e4e6628b578d8f674"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_en_US.png"
  },
  ["d9a0625b1254510ee3c2ebcb4df714093e428f16"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_nl_NL.png"
  },
  ["d9b926e266013e4bbbec2b95e4a435e9e830c57d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_he_IL.png"
  },
  ["d9bcf41799a694408eedf12b52ee4f94294e4e5c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_zh_TW.png"
  },
  ["d9c8e733e64a24991dce16cfb8d5946d1a5f41e4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_sl_SI.png"
  },
  ["d9ca0a93da1a939fd1919c5ef85d9d97ede29a6b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_ms_MY.png"
  },
  ["d9cd5376fa1ba3563890e68994dc1266122853f9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_sv_SE.png"
  },
  ["d9ea63718292bc896f2ae44c50d0a6cb45316904"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_en_GB.png"
  },
  ["d9edee815a4fd739bb4ef635ba94701841c97dbf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_ko_KR.png"
  },
  ["d9ffb4c82bd9cb7b42b3aec79eade2d5b9cf322e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/track+.png"
  },
  ["da04e51aa2d31152e6d64818da5532a89c18bc27"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_fr_FR.png"
  },
  ["da17c1d8e500b59e3721b7ea4ced46d8f8f33618"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_fi_FI.png"
  },
  ["da1b20ab41c89874e0bfd8f514107cb6f95cb385"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_zh_HK.png"
  },
  ["da52ed01fd9d54786361fe6f7e9b32684de615d3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_sk_SK.png"
  },
  ["da77878c3e0cddcf07e7ecec5e5c56f1b3a43c4a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_tr_TR.png"
  },
  ["da9c82986b6566fe7c31668cb6654d138aec407a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_cs_CZ.png"
  },
  ["dac088915d64bb8059f4df20f59e72a8bd907815"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_ms_MY.png"
  },
  ["dac61c9174b232d1feb2e3ed7a63d3d5a6dd2939"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_zh_TW.png"
  },
  ["db33e6eb0864a69d9c8c08a97190fe2667474c47"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_sv_SE.png"
  },
  ["db6040c29c2beb6729532fbe6a4cd1f5c1685b3d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_pt_PT.png"
  },
  ["db86438600f5402ed286c108d69787d05947ba01"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_zh_HK.png"
  },
  ["db9dc5f93c71c27ebb330b2a8baee27eda35ae99"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_da_DK.png"
  },
  ["dba8813493d11b25af71bdccabf71105e82dbec8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_pl_PL.png"
  },
  ["dbaa06293ebd1f872399c8403b46d93d400ec786"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_vi_VN.png"
  },
  ["dbb89b5671bc96dd470890c94fb9cf3cd3a627e0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_fi_FI.png"
  },
  ["dbb99f1c31ede6ce090732515d8f1b427ea15c68"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_sr_RS.png"
  },
  ["dbcd604e273013838f4a62158a6fbde971102c98"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_hu_HU.png"
  },
  ["dbe16e3cb01c47ffa2c696353357551074104898"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_th_TH.png"
  },
  ["dbea41804313ce1975d653b3bca363433b0a2bcb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/wet.png"
  },
  ["dbf304f167c1d89d0558a5a1c918a66c6f1e71fb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_da_DK.png"
  },
  ["dbfa4555dd3178be50e9bf24b57c6e4e7efe6e27"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_no_NO.png"
  },
  ["dc08d1f959949a3da26bd2e072386802466936ae"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_no_NO.png"
  },
  ["dc1ee584e83b56ac9a40da2171a3c16d9995ac04"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_ar_AE.png"
  },
  ["dc2597764f47e8bd9c0dbd6773d8eab14174d522"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_hu_HU.png"
  },
  ["dc6679b836494a057e6eee1eec4d70355eb3a533"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_nl_NL.png"
  },
  ["dc8aaf983012ec8fba8f7ad9ccf04fbff18fd15b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_hr_HR.png"
  },
  ["dca3f39953ed18bc779a24b404b87b13eed78c15"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_he_IL.png"
  },
  ["dca7022cfbcd5a90c779ecf1954a09ed296b9871"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_ms_MY.png"
  },
  ["dca8fedfe71e574897655f95b653af93c5ac5aa9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_pl_PL.png"
  },
  ["dccf01bd8b311f33721bc4671419cda7bafd968f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_en_US.png"
  },
  ["dcd2faf1117731b42fe29aeb84669f8e4bef2d01"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_da_DK.png"
  },
  ["dd1e029665b042cdc8244048ad2f267685c72d57"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_fr_FR.png"
  },
  ["dd1efb15614695ed2d5f78874d6a8fe3969cb757"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_hr_HR.png"
  },
  ["dd24b9a69eb6ad622830d0aa713cb61d986626ff"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_sl_SI.png"
  },
  ["dd3522c6154832cbf3856afc7f24e76041a40fd5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_sl_SI.png"
  },
  ["dd3945f4a9e5dfeccd9c5e78fd8bda155ae9baa3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_ko_KR.png"
  },
  ["dd63580aa84f777419b0fece145e293c960cb063"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_sk_SK.png"
  },
  ["dd8d6b2dcf4d1db6fa82a24abbe2a1f15fcd2188"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_de_DE.png"
  },
  ["ddaed9e95cfcd18129719d2dea3574edd44c5854"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_nl_NL.png"
  },
  ["ddb9dc8fd38991c8a36faeb9136bb8044744d95a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_en_US.png"
  },
  ["ddd179ac69f011a0ff903de9cc7341b691f31fa8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_cs_CZ.png"
  },
  ["de06f395d93e930e461e6a6deef5747eec3db411"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_el_GR.png"
  },
  ["de23d2c047705abbb3c424cf945597b2110a3997"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_cs_CZ.png"
  },
  ["de5ceab5903edfee72715848da8f5cebdae61b25"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_no_NO.png"
  },
  ["de6bb8bf71364e48c113feee93500caf89b3b419"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_sv_SE.png"
  },
  ["de6fd7842940d6e7016584d3fa79a8971c97a683"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_ko_KR.png"
  },
  ["de7027529a4d883bc25c129879e099e514362917"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_tr_TR.png"
  },
  ["de80197e51a796a84216b7fa7828c256a6682cca"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_zh_TW.png"
  },
  ["debd4aaaee438112e6b88867502e332fc9758aba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_cs_CZ.png"
  },
  ["ded24cbc0ddc0fb1f12952500eefbcd2253860bd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_da_DK.png"
  },
  ["dedbaa799a702fb38c8d7ed257f261781ebf4186"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_zh_CN.png"
  },
  ["dede20ecece88a7777a7e9bce20f3142a30923a1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_sk_SK.png"
  },
  default = {
    assetType = "font",
    destination = 2,
    path = "Fonts/default"
  },
  ["df0ce7a5ec971f4f8108fc880ea18a4484a15b31"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_ru_RU.png"
  },
  ["df1da24ef0962a440700deb695fc3a9075bbf03e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_th_TH.png"
  },
  ["df30b9f69059da7c581eca6a37beea237aed79ce"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_es_ES.png"
  },
  ["df3563fbe88c392e49f6c987ba6ab10b0b5df7c2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_he_IL.png"
  },
  ["df63615c35eb196bfb7363c9213816e0c7e7b154"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_zh_CN.png"
  },
  ["df643591f91e560d4d99aaf48b64f098cbc238c9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_ja_JP.png"
  },
  ["dfcec1c8be3c97fbc3e2b33db2241e943a95b851"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_pt_BR.png"
  },
  ["dfdf2ead19e4a5055b7ad839903be8da422ea857"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_da_DK.png"
  },
  ["dff335541ee3f988e7dd77ea29cd27f2648b09dd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_pt_PT.png"
  },
  ["e012eaa007c8e0acae503b4cef992b92702bea67"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_ro_RO.png"
  },
  ["e013b44c03f6cb7756d87459da0286daa0d90941"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_bg_BG.png"
  },
  ["e02e0578e7326048c81317b14fe27368214ed946"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_ar_AE.png"
  },
  ["e038498f740514024057b3723a2852d18c019a42"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_sk_SK.png"
  },
  ["e03b9f9a1b8170bfeb095b76381862669b2f7e4b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_cs_CZ.png"
  },
  ["e0414422a96409a6a8eab34beac4d2eaafbd3da9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_pl_PL.png"
  },
  ["e0467dc45d47f4e153cae56511f48bd406b3503d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_fi_FI.png"
  },
  ["e04da8d6e8cd0004fc79c588e21c6f83d622248b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_zh_TW.png"
  },
  ["e0560e4055dfaf0ab99a89e21d8544ced51b9bf2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_it_IT.png"
  },
  ["e05c8bae0616b218373dee93fa38678b206e9504"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_nl_NL.png"
  },
  ["e070d2ba8ba8f3a0664694af5e10e3b6f1be4ebc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_da_DK.png"
  },
  ["e099edde3f8582c152ae4ae0855948dd9ab20989"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200751_tr_TR.png"
  },
  ["e0a08d34b18b7d9866391bf8ebccf6072b3459b0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_sr_RS.png"
  },
  ["e0a1a37b2a9b1d668e3120e9fc8e0b5fcdca7fbb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_ar_AE.png"
  },
  ["e0b94a23a0ecb2914fab28914e39f21b1ca088e5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_vi_VN.png"
  },
  ["e0e2d655ba13ac06e3e13fba71784739f373a101"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_en_GB.png"
  },
  ["e10cfb08b59cabe743eda1adccd5977204f3e8ff"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_no_NO.png"
  },
  ["e10e71612d9167cf44ad46a8722a0b3a6def1785"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_zh_TW.png"
  },
  ["e12fb43bf743e2374c91b430b9a309de2f7bc768"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_nl_NL.png"
  },
  ["e1435c4d6979e8243b3247b155a239a6b5602f87"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_sv_SE.png"
  },
  ["e14c2b7582af014d7438b72c2dcff00ea052d1e3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_it_IT.png"
  },
  ["e14d70f27ad273313f71994e26cd89cd00ae77ad"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_es_ES.png"
  },
  ["e14e03ae671212f02760d4612da6071c8f62a60d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_no_NO.png"
  },
  ["e15d48646a05982174dcda358ba7136bd0c2d8d5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_bg_BG.png"
  },
  ["e1712deb9fa0a27dbf5d308a87f81de66898bbe6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_nl_NL.png"
  },
  ["e18afbba6147ad880c3ca9d412434b97b8ed1c42"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_pl_PL.png"
  },
  ["e1bad45139d0aed0a742c8aa3c2572f73131bbfa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/thermometer.and.liquid.waves.hot_body.small.png"
  },
  ["e1d80d43f83da42e7aa2ef13ecc5554d9cdd103a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_ar_AE.png"
  },
  ["e1e4bd56447651b7c91872d70518e8a2127736be"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_nl_NL.png"
  },
  ["e1f59ab13d0c117d3fe7670bad8f7756574de3a6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_ms_MY.png"
  },
  ["e2132874a2e839e2f5d9f2b157148511d38975e8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_no_NO.png"
  },
  ["e2146d66612a96acc87864340572c2fcea28de34"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_it_IT.png"
  },
  ["e218fe058167c032f52b25548e1c9d99f8c3bccc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_sr_RS.png"
  },
  ["e2418d8c7f2e239e1e3e4c8428a954d6134d5719"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_ms_MY.png"
  },
  ["e25cdc6cedcd8b6df986f64898a13a39c49dcd10"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_es_ES.png"
  },
  ["e2808779f745254e7fbd8b9f24fe6c537fa76595"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_zh_HK.png"
  },
  ["e2875b93a3eb46731e38b35e67ab059d1add3625"] = {
    assetType = "image",
    destination = 2,
    path = "Images/set.png"
  },
  ["e28c0cb51a12bd658e119b6f9a0541a7fcfebfdc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_en_GB.png"
  },
  ["e2983e9be925c3eaa5e894d8e8c1e8caaf4e5b90"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_zh_HK.png"
  },
  ["e29d4f2d86e288c0ddaf282eb9a8e626f68315a0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_hu_HU.png"
  },
  ["e2cd351042292f81813a14bb34f2348276d75b26"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_cs_CZ.png"
  },
  ["e2e1ae591769a5a9a46864973e96206e6c111b01"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_ko_KR.png"
  },
  ["e2e9b6b1fe00dac9408f9a1d63fd8b90dbcde86e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AB_hu_HU.png"
  },
  ["e2f1ed838ae47e7e8c5e6ad8ad182a9e7a9a23a4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_sr_RS.png"
  },
  ["e3073e1514183f91ceef3a8ec9ad4c631dccb253"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_pl_PL.png"
  },
  ["e31ad9c94b5433bf345094bf4f9db1885fdda3a0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_sr_RS.png"
  },
  ["e33245edc027906a48158f52e4739efdae46af41"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_pl_PL.png"
  },
  ["e34002d0c7d1ddef84800de8ff13f4519419c85f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_hr_HR.png"
  },
  ["e392f04164e94d0e196b6e3439aaf58cc6c0068e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_da_DK.png"
  },
  ["e3a22554197028051ef91a201ee6b5af103bf71f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_nl_NL.png"
  },
  ["e3ac5765a4270d8b4ef137c8c029f93ec10d37f4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_ro_RO.png"
  },
  ["e3b113ee205e8dc5b933797b81e10421066e4192"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_zh_TW.png"
  },
  ["e3ba16933d10513de1668bf71434020b88a9515d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_uk_UA.png"
  },
  ["e3c73059ec755525d0b2929087795f2c5828d3bb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_zh_TW.png"
  },
  ["e3dea567b863f1c858c43b4d2295b27bdf8a7719"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_el_GR.png"
  },
  ["e3e105360c95961eeca72b5eef40160ed8a1b9b0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_cs_CZ.png"
  },
  ["e3f8901ef29c4edc2a1971d8c66af418622900ed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_zh_HK.png"
  },
  ["e42297a984278cc92e88c3cfb9f9b624895ac3c5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_de_DE.png"
  },
  ["e45a461e8f6e975540135d67f783a5f1744da1a7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_nl_NL.png"
  },
  ["e47053c3c5fcf60f3d0019201eb4abf1c652e216"] = {
    assetType = "image",
    destination = 2,
    path = "Images/Shadow_Bottom_Right_Corner.png"
  },
  ["e472eaaaefd610b3015c0d32465f513fbd7586b4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_tr_TR.png"
  },
  ["e478c1b42487e95be0f05afbdffb8154ba2e4695"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_pt_PT.png"
  },
  ["e4868ffb6cf74b237dfcb2e450d9b27ca3021778"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_en_GB.png"
  },
  ["e4a06117251576d0c9abc33abf41e1f50b59a079"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_sr_RS.png"
  },
  ["e4ecefadf33682d42e71558f7473496b483a6f23"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_sl_SI.png"
  },
  ["e4ff048bcf94bbb6ace3df963805b2c7145b34ed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/fuelpump.fill_body.medium.png"
  },
  ["e4ffdb4067a7902bc4aed2023305ec55d20e15d9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_bg_BG.png"
  },
  ["e55d8325ab6a67ece3919ff7abefdd0e3356fdeb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_id_ID.png"
  },
  ["e55d87eea47e3e00003df273631d6ce7f50ef487"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_sr_RS.png"
  },
  ["e572a587f045ca9d5c88ae714853b7f153e1c02d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_es_ES.png"
  },
  ["e578d23143f9f1b2d590bb2519c3f980083b89b2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_en_GB.png"
  },
  ["e5a4be55be9b44ec8a14d7ca2cf1c1fba12c7d2d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_id_ID.png"
  },
  ["e5e3ed0d8593b08e363a49276691cc5b45303593"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_th_TH.png"
  },
  ["e5f3091ef781d0d282a423ca63eaff98f3a94686"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_id_ID.png"
  },
  ["e62d67ee90fcf4d420ae8e53968220de77bc6929"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_hr_HR.png"
  },
  ["e6324019ae2f60f779ed2f93728c6baf660191f4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_pt_PT.png"
  },
  ["e63bf1130f3a3e0c8b74c5bc222e83f603821540"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_el_GR.png"
  },
  ["e6493abcd6fe9836c12c1bb10a4b407c95158783"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_ja_JP.png"
  },
  ["e64f6a1c7904cc622cfcc052ead3589bacde9f02"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_zh_CN.png"
  },
  ["e66a6f7a21bd820da247ad02f34663d40a794f8e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/tachometer.png"
  },
  ["e66abf0b95a7cc8e362c7905f6a0224584c10aba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_pl_PL.png"
  },
  ["e66eaaf8be8ce1d42ea701664ae17db29f154992"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_zh_HK.png"
  },
  ["e6a76f76a9555f89e178fa27b0d60746e3750304"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_hr_HR.png"
  },
  ["e6a7e7fb14e8caa688b1dc8e4b3644f8a9c3d520"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_ja_JP.png"
  },
  ["e6c15caa035c7e24ba6a7e5d1c23e718fd5802d9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_pt_PT.png"
  },
  ["e6c65a0d9ae1275675c3ce80f41e28c77fac1bab"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_hu_HU.png"
  },
  ["e6ef210a8ba5b8ac0db9ff803669bed7a0f589d1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003CA_uk_UA.png"
  },
  ["e6f1c5bde00b687d7f662f1f9d9429e7a6d409ba"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_zh_TW.png"
  },
  ["e6f9c11439f98ae83663d593ddb49ae27fe85497"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_pt_BR.png"
  },
  ["e704cf036b8db63b2062e40175be90d04cd432a9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_ms_MY.png"
  },
  ["e706101485b5af3b16fc6fede2ea0d4bbbba29e6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_es_ES.png"
  },
  ["e73ecaa35be190dcc340271c2442e8ae2a919349"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_pt_PT.png"
  },
  ["e7501e397811d94d9ae3e765bf1263b96299c6dc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_es_ES.png"
  },
  ["e76ee3f01a11f438992778497d0088cb132d5e7a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_it_IT.png"
  },
  ["e7730acb1b04bf72a0d2987538c415fec0da1b30"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_ja_JP.png"
  },
  ["e773f8fc1f207f7704aaf8a887f2ee50e07d630d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_sv_SE.png"
  },
  ["e7999f5b7d056c781ef379594f84f861ba89d462"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_zh_CN.png"
  },
  ["e79a5aabb551e5613259aaa6ac85e7636efb6931"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_bg_BG.png"
  },
  ["e7c3e74f6b6b674d47adc6e81fdf4902255e3212"] = {
    assetType = "image",
    destination = 2,
    path = "Images/terrain+.png"
  },
  ["e7d5b7af6340b7331627a3fd2ee5f569444aa624"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_zh_CN.png"
  },
  ["e7dda820f52e2ce644f3f786b659c4257201a65f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_da_DK.png"
  },
  ["e7deb4392dd468c69f34f9e5e9d4385f996625a4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_sk_SK.png"
  },
  ["e80332d4d3463d3f9ff4c6cfc314d2ffcb01bd04"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_id_ID.png"
  },
  ["e85010c84abcb24d2bc85216106ae7fafc6d50ec"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_th_TH.png"
  },
  ["e87d2a27d6af7ae79285af8aae4577d47daf4470"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_zh_CN.png"
  },
  ["e882c0e657d7cc077e39a5086255e223b5a585ec"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047D_el_GR.png"
  },
  ["e88c52a921994c37601950e7c50956ff5d610b7c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_de_DE.png"
  },
  ["e8a6927af373cbb34cef7ee6de94a6804ccb608e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_it_IT.png"
  },
  ["e8bce9a0afaeb2c1d99b090f7a153468a7576ed9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_pl_PL.png"
  },
  ["e8c7a70ba9618f6cd244bda9ea04cbf8f758d2d4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_en_GB.png"
  },
  ["e8d721dc803ed3924158ffabc6f72c3c554e0868"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_sl_SI.png"
  },
  ["e8da9048c517abb4a8495460045e519f2b93c148"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_en_US.png"
  },
  ["e8f1fd133b7134d6cf5a2063975e3d366bfd290a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_sk_SK.png"
  },
  ["e8f250690a42d651889b2171bc053bec4f2b5746"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_it_IT.png"
  },
  ["e9215b96cff0a3728033cb2ec7779c33329d8b87"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_ja_JP.png"
  },
  ["e94917023200a51b937ec7dbeaba39218d50a92e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_en_GB.png"
  },
  ["e974bbad1dae635b3a01fcdbd792a54aebd0d3ed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2000C1_vi_VN.png"
  },
  ["e97b0416898a74534f973c7773bdc038d9cb3105"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_id_ID.png"
  },
  ["e9a8167696ce2dd56df1e38410c78750ddaa21bf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_he_IL.png"
  },
  ["e9d7c7ebae8811eb4afd3eb06960e4444a1b5e33"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_pt_BR.png"
  },
  ["e9f3b81d0ee1d9e202b796240ffac66baecf92b1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_zh_CN.png"
  },
  ["e9f4f169f385dd512e1188180d27e774c709a0e0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_zh_CN.png"
  },
  ["e9f6e3bd53d5c0ab3ffae7db9662f7f4d4dbf6ea"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_es_ES.png"
  },
  ["e9fea55ea35d073f7189e4a30677c064449f912f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_fi_FI.png"
  },
  ["ea1fd94e9254ea3342e6d3671e978701b0f39f1f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_id_ID.png"
  },
  ["ea2178834402b06f6733a354b0a9fcb80302781b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_zh_TW.png"
  },
  ["ea24fd491ca25737ea439a7799322bf879857a3c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_de_DE.png"
  },
  ["ea4440921dfd6fa46a9738c7c576f8ee27ea493f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_sv_SE.png"
  },
  ["ea50381d135ce9f46577f34aa5be3d5944607ab0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_fi_FI.png"
  },
  ["ea550788d91319c378b60d696576248b0dd96e4e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_bg_BG.png"
  },
  ["ea5c1fd42e462f6b0bc3217e063009f27255766b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_vi_VN.png"
  },
  ["ea733cc5baf98fa26fddf88661dcc8253ddcd3d4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_cs_CZ.png"
  },
  ["ea750a6dcfca73c665a67eb6c5a29e54af93d365"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_nl_NL.png"
  },
  ["ea8e4e1f2e8275db2dd29625112fa46ecc8430bc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_pt_PT.png"
  },
  ["eaa9bc7d1f5a4c08624fd198a632ec1d74f59c40"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_id_ID.png"
  },
  ["eabec075f05468a01db2224ee6f7ad4f2123bcca"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_ar_AE.png"
  },
  ["ead4e65277f3a868be9f6d0cb733cdea43adc8d8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_bg_BG.png"
  },
  ["ead8ff2fd4e909d8e8c77af67e48f9bfeaa2541d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_pt_PT.png"
  },
  ["eb10303e4424d10f1bf0627d48b548f8c8bea3b6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_hu_HU.png"
  },
  ["eb17d60c35f22158543d00ebe311721d43f1890e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_sl_SI.png"
  },
  ["eb1c69db32af7879c5fd82d3485036a9be3da204"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_th_TH.png"
  },
  ["eb73e54813adf61e5cb6d4aec6d133e1fa767152"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_sl_SI.png"
  },
  ["eb8a465ac34908b9f2b3d0d2f34a65042688e9c5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_es_ES.png"
  },
  ["eb8a84ff45cc8ace490dd828ccf6a11ffce86c86"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_sv_SE.png"
  },
  ["eb98c415f888c8c76136c1875bc15343b60f203f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_el_GR.png"
  },
  ["eb9a7b22b4a62f4dc83aef78b8291fbafe136d0d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_pt_PT.png"
  },
  ["ebbfd2fe85271874e6facc92019023847912ef7a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_zh_HK.png"
  },
  ["ebcee531c9d97f442f382901f7fc93026a958acb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_pl_PL.png"
  },
  ["ebdb40a62ada2fecd8f92dde97d8fc31243fd1ed"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_no_NO.png"
  },
  ["ebf490effd03487589e2addc62a09d077383e288"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_ro_RO.png"
  },
  ["ec11659b0d54cd56480fa08673a2acf6d656429b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_de_DE.png"
  },
  ["ec1fc22efec6e30259d48859912d22338be515a9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_en_GB.png"
  },
  ["ec329342977286d097b98e4363596a613e33cf5c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_sl_SI.png"
  },
  ["ec52ab6b5f41485bd4c6742ebc9cf278655f2eeb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_de_DE.png"
  },
  ["ec5bb449f5e03f20889e15f0012bf2f0ac301f51"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_ru_RU.png"
  },
  ["ec6637b277cd52e5da3d0f1189d1ba01518b0d11"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_hr_HR.png"
  },
  ["ec748c72ac44b17d149b65a625792ee681c7948b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_sk_SK.png"
  },
  ["ec860be094becee3b7a3b1338258c7e15c2e70a7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_fr_FR.png"
  },
  ["ec8ca68c822807382c6d6bf1d2b53a8abf7b8adf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_en_US.png"
  },
  ["ec936fd7372914e469ecbeb806f89533042de43d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_he_IL.png"
  },
  ["ec989310fefefc0974e0c50778c1b56ba3d4a3da"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B5_es_ES.png"
  },
  ["ec9f75ede16f2392d453f2621344290cf86eaf0b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_no_NO.png"
  },
  ["ecb030e3158c1f3e00d20a707f9ed4d7803c972b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_vi_VN.png"
  },
  ["eccaa53e558b372ccae26f55c923756c24d2e62b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_da_DK.png"
  },
  ["ecfec5037a4a3e7ff6ec204e9ea485116a2cc2e2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_el_GR.png"
  },
  ["ed03a7265b5f3d4f056888d4c47e1180bef6408b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_uk_UA.png"
  },
  ["ed075a3c9f527c8d6239220031680ece9faf95f9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_nl_NL.png"
  },
  ["ed07c0a17a27d160179f1051d166c9a3dd9d1960"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_en_US.png"
  },
  ["ed1c584d7307ae9b3265a0e46c1d8d13d2f201e5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_ru_RU.png"
  },
  ["ed26df5d2052c9e797a14b2a4c54be2490b2eb4b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_hu_HU.png"
  },
  ["ed336b27d42d429892fb18fe0b39b99622af27a3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_da_DK.png"
  },
  ["ed3c51135ae4860a31d85ca31afb6459fb1de8b9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20052B_pl_PL.png"
  },
  ["ed46774c85767363570c23ce61bd6f55289aea85"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_de_DE.png"
  },
  ["ed5f627bd5ad5e8c99986dca10b481a4235df01e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_pt_PT.png"
  },
  ["ed6452f5a07fc475c603b1a2162288883989c206"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200065_sv_SE.png"
  },
  ["ed883f57e8583efa38aa93d58b029bacf810bd64"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_th_TH.png"
  },
  ["ed96a0641d3e8b730d3a9e4fd62835f36e662db0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C8_hr_HR.png"
  },
  ["edb06a15bc538a4b5aadf6d45caac9d78a6f88da"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_sk_SK.png"
  },
  ["edc312fa5f1b8e7dae501e7a16f8b7b16460d2f2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_zh_TW.png"
  },
  ["edde872c9a97239007878342cd01623e21e99ec9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200132_vi_VN.png"
  },
  ["edf69f79d270d9b762c80c324f8caa070f3cc117"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_sk_SK.png"
  },
  ["ee00913fad3a4fd7a5ed37901e5c5d0e12a34f2f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_ro_RO.png"
  },
  ["ee078ba132297fdc278a863b18509d8229c490ef"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_cs_CZ.png"
  },
  ["ee1667a54ed939fbafc9d2a7b313a1772bb49d78"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_uk_UA.png"
  },
  ["ee26605b8adb628a74443edc4e83380488d77822"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_sl_SI.png"
  },
  ["ee4f1ac464fd2b1487c90ed36808f333e867dab2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_he_IL.png"
  },
  ["ee4f43accbd1b816a14f039a3fd8c067cd06364f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_he_IL.png"
  },
  ["ee5f9df1b9b266ffe8147ca7614a7ae6a2bb48d0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_zh_HK.png"
  },
  ["ee6303e2f55ed12e5990b64d4f753c77495636ee"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_sk_SK.png"
  },
  ["ee758f51890e06f2a06a5cb606fa9b772ba2fe30"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_en_GB.png"
  },
  ["ee7851e71436b7404ae7e90a144167601a9fa7ae"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20059C_he_IL.png"
  },
  ["ee81fb153284ed27bb96f0d4b427b345b6097786"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200068_pt_PT.png"
  },
  ["eed77abf5155184ad7965f4d3a36b0e3ef1227fb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_de_DE.png"
  },
  ["ef256d46a0dffede83cd1701876e6bd083224866"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_pt_BR.png"
  },
  ["ef2864b0fa97ab492d2cbda4e8241d86a8289a3f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_pt_BR.png"
  },
  ["ef722835b094c1038d285899db1c1be0afb9c5f2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_no_NO.png"
  },
  ["ef85c5b594c87c35ef75cf2316db59566f100d37"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_hu_HU.png"
  },
  ["efb8c6375c9e437ee25bde409d14ffa7643f4193"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_sl_SI.png"
  },
  ["efd5051200bafe84e7dd24bd212415b5068a6cbb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_ro_RO.png"
  },
  ["f000c2a7ba4512bac28f9a092556a78e70f50376"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_he_IL.png"
  },
  ["f018c2c65fc994c917b515431ece24d8861e82af"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_ar_AE.png"
  },
  ["f0255a91f1c9748f21284c764f46c733c2b73536"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_da_DK.png"
  },
  ["f0436ee743ebe355fbfc0c71630ad844a4c40c4f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_sv_SE.png"
  },
  ["f064282de0181e192447f915bfb5da4c5c807db5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_ko_KR.png"
  },
  ["f06cf51f8c418dfaf97e0abc105f65ee243af5a4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_id_ID.png"
  },
  ["f073a7d351acce10c37b27923936da68186b504f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_pt_BR.png"
  },
  ["f0840a5a4b908367cd8c0a69ac6e0001272ca351"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20057D_sl_SI.png"
  },
  ["f0b2fe4f3612b3a1103e24b63b9fba7fe1c174a3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_en_GB.png"
  },
  ["f0d899cae5a63059a40c969200abd28b4e6cf6c1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_ro_RO.png"
  },
  ["f12298103600c9ad9c3e55022453504e6ce0acf5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_en_GB.png"
  },
  ["f150775706df9b804d503ced106ca3108bd81e25"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_ro_RO.png"
  },
  ["f15234ade0d6b8dec7717adb7f563ba880fdb913"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_tr_TR.png"
  },
  ["f177056b0f6882f0ae50695e348074c6fa83f5b7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_uk_UA.png"
  },
  ["f17808f6b9a8cc62f4a57c097f0eba5af9ff0cfa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_ms_MY.png"
  },
  ["f18e7a91dee59722b91d4c5ef80a0dac05f02c99"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_hr_HR.png"
  },
  ["f1a0882204746822a31faba5b0c80cc77aee4652"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_no_NO.png"
  },
  ["f1b776b97ba94458723340db7fa430aa329b4f94"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_tr_TR.png"
  },
  ["f1b892abb563e3b642b3e504aadf97f332a91a18"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_hr_HR.png"
  },
  ["f1c663f9cf39eb89e4a208846689dcdc55ae4a9a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_fr_FR.png"
  },
  ["f1e124fe45a280d6672cbf2c92f0dfa4d15dc879"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_cs_CZ.png"
  },
  ["f1ed24ba0cb768d18566b7a3e5844c52f77ec3e7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_da_DK.png"
  },
  ["f231708ebbac4b1b068df664b8af0bb3066f1312"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_de_DE.png"
  },
  ["f258bcfddbc34ada39ae27d6a1cc9b4d5981a10d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200122_sv_SE.png"
  },
  ["f259ded1894a6529ec9964dc03f07fcae22bb4b6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_zh_HK.png"
  },
  ["f26d301086361a2622b1dcbf94b856999f4dd913"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_en_GB.png"
  },
  ["f26e85a3fa4b9a11cf8b3eb8270cbaa63ed43c3e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200728_zh_HK.png"
  },
  ["f27cf3cf3a156c3adf0864ac9410ae47c4944e6c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_en_US.png"
  },
  ["f28d119b34e24842d1572e6e07919621314a85f7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_pl_PL.png"
  },
  ["f29105c29bc0ea5dd82285674944b2941e5cc3ef"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_bg_BG.png"
  },
  ["f2b86b2793f044750bf2e45b11a0ec7407de267d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_ja_JP.png"
  },
  ["f2bb9155548df60fb09022f377b8f4f1e127a45a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_en_US.png"
  },
  ["f2e9edaee17233ac90cd62efd556d3a2cfa8576d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/speedometerOrnamentalMPH.png"
  },
  ["f2f076f801e16989a23072ed498144174bc07bfb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_zh_HK.png"
  },
  ["f2f8e0f140f3a2ec4476745cb0b2fa5036be567e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_tr_TR.png"
  },
  ["f3080c8983d09153b7aa0bcd19bb4415a0457690"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_cs_CZ.png"
  },
  ["f3290d6e1c9ceb919025bdcff11a3c03d6b317d3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_sr_RS.png"
  },
  ["f3495e8ffcf71d19ab03f49ad4ea8bff8666465d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_ar_AE.png"
  },
  ["f3896cba86736cc1cdf5593c8b2472b48eb375fd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200790_bg_BG.png"
  },
  ["f3a15d3d234bf627d22cb4eb06c5c56ad2286947"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_ja_JP.png"
  },
  ["f3af8d795971d6cfeb94103861761813db2b59c0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_en_GB.png"
  },
  ["f3c68552b01e0c94299c43a1760c74b41c7c5444"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_da_DK.png"
  },
  ["f3cce20921602cf7d961bc55fec5cce4b61e0eff"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_en_GB.png"
  },
  ["f404aea30222cb8239505a73295b33ce8a85ac2a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_th_TH.png"
  },
  ["f40564276b0a898d99d60cbf1828f59ced3bc5d7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003C5_sk_SK.png"
  },
  ["f406fd7016afebbd4c479a594a5601ca9f79636d"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200113_uk_UA.png"
  },
  ["f40d50336549c9e573cea535b9317fad73f99d2e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_fr_FR.png"
  },
  ["f4250385ef202dbfed9aa2ee3982b4c3df2f8cf7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_zh_HK.png"
  },
  ["f444247d5ef836537df22013922c3a4cfe2fb399"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_hr_HR.png"
  },
  ["f45a966a4d9c9f3fdecd2d12e5b2230feb9c0985"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BB_pl_PL.png"
  },
  ["f495dfda730a7c2a29af4ef7af459fe0c7552fda"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_pt_PT.png"
  },
  ["f4bd96af91bdd5643f15167216b6632ad8d00c7c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200791_pt_BR.png"
  },
  ["f51b91c7eed38e389e1c2969779c51dbe9c0a65f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200674_sr_RS.png"
  },
  ["f566fb7e75d8d1e6013b93bd4b2c71f183331e13"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_hr_HR.png"
  },
  ["f56bcca7b9ce9de6fd3647140f3054e180a644cf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_zh_HK.png"
  },
  ["f57020f40125f1860aa0cb50345d494abad8dd28"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_pt_BR.png"
  },
  ["f589d3f4388f5552b30c1cc0f37a1bc9bd267fa9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AC_ar_AE.png"
  },
  ["f5ff7a7a466939de3a0a9c4066f9d7eb24720125"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_uk_UA.png"
  },
  ["f62f9371b70453c2447e142627ac9cb8ec5e32db"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_cs_CZ.png"
  },
  ["f6357e3e67cc6fe5331f74e973ded70cdeed89e7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_th_TH.png"
  },
  ["f6692fd1df4c12315ee3ebf9fce4cb3689c60de5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20049F_zh_HK.png"
  },
  ["f67de5bc4e59a0beadc7b785c9922f1844964777"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_bg_BG.png"
  },
  ["f699956658b1146766770be81f2b797292455676"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_es_ES.png"
  },
  ["f69ea12327d465332f3a361744a6403ed9643b4f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_zh_CN.png"
  },
  ["f6ab22133cbdfefd31633969a04b3eb96f3bbed2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_cs_CZ.png"
  },
  ["f6d775c9f74b2e0c0c7db71831da14421636274c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_tr_TR.png"
  },
  ["f6fbb4a7b809c3e0db6c83a5a37b030b3d64a782"] = {
    assetType = "image",
    destination = 2,
    path = "Images/individual.png"
  },
  ["f70c786a85d0f6d1f33e9c58339824ba4b350815"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_bg_BG.png"
  },
  ["f7448afbc107093bc03057ada80da8ba4c163d5f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_zh_TW.png"
  },
  ["f75113679df535eb36e170ecfd16060153d06e23"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_pl_PL.png"
  },
  ["f7bfe85c48ca300a1d399cb00be8dbca6996c65e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200227_nl_NL.png"
  },
  ["f805bfdcf1b331a38dd944eb6a09ca88aa552b6a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200155_he_IL.png"
  },
  ["f80ddbf5cb05bed50219febd4afcd3b5c330ed92"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_ko_KR.png"
  },
  ["f8264be493306eb524c3c9237cd25bc6c9318d7f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_fi_FI.png"
  },
  ["f84b45dda077392eef6185351c0954d37a70378c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_el_GR.png"
  },
  ["f8958d28c930bd52c5362e9cc6b04b640a8232a0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_hu_HU.png"
  },
  ["f8b680db8b85af45474b58b84c31c3779c0c13d1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058B_cs_CZ.png"
  },
  ["f9956283b46a9c038935b5e1a8d076cb56f004aa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_th_TH.png"
  },
  ["f9e187fa0d5b979e035f6b3f96414913b3cc05b9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_sv_SE.png"
  },
  ["f9ee0930f1bb3142445cdfd11e3752f650e629ce"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20070A_ro_RO.png"
  },
  ["f9f184ae3c288a1b408d4a8a8433f2ecb03773e0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043C_en_US.png"
  },
  ["f9f2f87c44827a69b8f7651bec44d5e1064dcf83"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_zh_HK.png"
  },
  ["f9fec9987812eefb671c7173ec651e68cd01a484"] = {
    assetType = "image",
    destination = 2,
    path = "Images/gearshiftdown.png"
  },
  ["fa067324ab831e6507a1bf5e688d12086c9fe7b1"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004F0_th_TH.png"
  },
  ["fa0ba3da48648099c7305c43e6936d04fb0446fe"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_de_DE.png"
  },
  ["fa2fb4bf19f6e0768826988d65aae1753df50965"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200334_th_TH.png"
  },
  ["fa3fdc343fe29e1fe239801e059e9f2f5e9c406c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BA_es_ES.png"
  },
  ["fa816f69db3923262499cc948322b98cb3fb7785"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200545_pt_BR.png"
  },
  ["fa92264606c49a9c85eb98979bf6ca7d61ae63b7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_uk_UA.png"
  },
  ["fadcaab38b92703173c262189a0e036d53c2ba35"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_hr_HR.png"
  },
  ["fb0d0eb3809eda77a9a402c0c41a7d80e69fe35e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/terrain.png"
  },
  ["fb4168ca69242b7cf99cb1810a435a5abe080eb9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20060D_en_US.png"
  },
  ["fb45fa8299f330b400f91f23c609dca409cd0114"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200523_da_DK.png"
  },
  ["fb517e749abc39058d3c20ed8cf75396076e08fd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200782_ro_RO.png"
  },
  ["fb5ca75f6f674da5ac3d40e17f5af4c005c7c8f3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_id_ID.png"
  },
  ["fb613052bd26da4be5ac0b1888512f89e4d6d297"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_ms_MY.png"
  },
  ["fb97c82e9d6cb2bd2726cf4c29a367e5b5b6e323"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003E5_tr_TR.png"
  },
  ["fbd0a8ea43bf997fa05d566988c0feeb6e0d0cc6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20043D_pt_BR.png"
  },
  ["fbd54bc988b12e5074346b80cc74bdc0618bcd56"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002D_ko_KR.png"
  },
  ["fbfdfc00fcc4c0f64e392a5b898576d8a98f06b2"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004D3_en_GB.png"
  },
  ["fc26981d4e62d0a36b8e3a847f211be6933c12a5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_nl_NL.png"
  },
  ["fc4c60fcad3c3bf26be8816c67828ca8dedb5737"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200578_sv_SE.png"
  },
  ["fc6882155d8f085e66a341469f620601573240d4"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20039C_da_DK.png"
  },
  ["fcca6592a8eee7fa53df94d6babfcbfd8afaaadb"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2003B4_en_US.png"
  },
  ["fcddde36f99a1c204fd493d2eb888e188e1688ab"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_ro_RO.png"
  },
  ["fce4c6eb70eb5e985bda158e31cefe4350aecfc5"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002B_zh_TW.png"
  },
  ["fcf3d1e10d62b93a9477018220134a1021dcc154"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_ar_AE.png"
  },
  ["fd1da19d8e476e090a709b911ac35f6b583c1efc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200481_en_US.png"
  },
  ["fd23d73d62a0295e31055d3b99ac90755231aa8f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200619_hr_HR.png"
  },
  ["fd4bcf14d766257a0d8bca35d39926522e206188"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_cs_CZ.png"
  },
  ["fd66d35a5aee3a2182c027b296790ba576e217ff"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20045C_hu_HU.png"
  },
  ["fd723acda26a5d39f04bb38315c3d3bfa0ed20f6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004CF_sv_SE.png"
  },
  ["fd7a685c347b5e5fb9dd8ab5f90063eff445cc27"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200455_sk_SK.png"
  },
  ["fdaee4f3f8a20f87bb3405daa42e8ea47d728b83"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200114_ru_RU.png"
  },
  ["fdf51e30f15a441741c9e8565fbec4dbd715d7f8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_zh_CN.png"
  },
  ["fdfbe6148041040b5f0f29bbed5f59033a31e45a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200326_ru_RU.png"
  },
  ["fe07b16a7f6eda00fb74ab1e184bae2b62aa977f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20007C_zh_HK.png"
  },
  ["fe0a8d85a40023bf4f6cd8c13d7f63e2d2a5fa30"] = {
    assetType = "image",
    destination = 2,
    path = "Images/thermometer.and.liquid.waves_body.small.png"
  },
  ["fe3905655b11578543abed342dcb4fcd07080004"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20002A_sl_SI.png"
  },
  ["fe58e140f91fca716558edd66d6393615071bbcf"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004DE_ar_AE.png"
  },
  ["fe645b0bd6e70d63960bae5b560d43f9015ccc3f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200480_zh_HK.png"
  },
  ["fe6f4b4fe86a4b188ba9139a28d5706dfb46cd6f"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_th_TH.png"
  },
  ["fe7304681376667d93c7e1b07e7f08135918b479"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_hu_HU.png"
  },
  ["fe75f85f3f4fb8edcdb59ffb68f32b0afd7de7d8"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200399_ar_AE.png"
  },
  ["fe7b97a78da8eb8ce027f940cc75677ea3bc6245"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_en_US.png"
  },
  ["fe7f6766c84e2e0d94abc9e9026ab3575473b29e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001B6_hr_HR.png"
  },
  ["fe8de2de74b3e954996a36d6eb4c3cfe6a6e4557"] = {
    assetType = "image",
    destination = 2,
    path = "Images/decorative_speedometer.png"
  },
  ["fe93e1b700941066bd6ad40ab7176986c7c517cd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200474_ko_KR.png"
  },
  ["fea046f74fd7a254f96b714be4c27840660618b7"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200531_sl_SI.png"
  },
  ["febf3beb08812190036636a70e0ab0b34865a3aa"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200750_hr_HR.png"
  },
  ["fec737efd6d3c634cec3622255ef748738c7198c"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20019A_da_DK.png"
  },
  ["fed1aafc513ccaeffeaf12ea23d425170d11c4f9"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058C_vi_VN.png"
  },
  ["fed5cb78dac18d9a9c734907adcd1c4792e51c99"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200662_pt_PT.png"
  },
  ["fedb65934b6047563831625bc3e6ab1004a338be"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200112_zh_CN.png"
  },
  ["feeb29249d5efe6f9e95f05cd1fb1d6d735608ec"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200557_vi_VN.png"
  },
  ["ff0867695962867c1a72a5efeec4dc6c3a822bdd"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201003_da_DK.png"
  },
  ["ff0a17aa37bca839c8546b6e2ccb67cac792bd31"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004C0_es_ES.png"
  },
  ["ff1756f2552dd234a127a1f11af7ec4b0c4c087a"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20047A_pt_BR.png"
  },
  ["ff1f19e90342f8c455583b50b123fcfdd6820ce6"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200520_he_IL.png"
  },
  ["ff4159fc606ae6d6a6c84aa243661d3e600bffa3"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20065B_bg_BG.png"
  },
  ["ff509abf9ba4d54b484c2d6d9b232568cdcaeac0"] = {
    assetType = "image",
    destination = 2,
    path = "Images/20058A_ru_RU.png"
  },
  ["ff75318eb236f3bbb3a31135d564f7f4edba86ef"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200618_da_DK.png"
  },
  ["ff89535a2ef52fbe2e5b74206e75d1b75ed3f625"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2001AF_ja_JP.png"
  },
  ["ff90bf625fdf859999336866a83c6efa821f5549"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_zh_TW.png"
  },
  ["ff9850c03da47a6843f749c0a6277d8cf0d2cfbc"] = {
    assetType = "image",
    destination = 2,
    path = "Images/2004BC_ro_RO.png"
  },
  ["ffa272dcdb44571d7eeb931c2f16c05610979363"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200614_de_DE.png"
  },
  ["ffbc9a475c3c9aa7a102d2446ab1e16af3d4109e"] = {
    assetType = "image",
    destination = 2,
    path = "Images/201083_sl_SI.png"
  },
  ["ffd204541795d10675bd0e37d1f8465135717a3b"] = {
    assetType = "image",
    destination = 2,
    path = "Images/200472_bg_BG.png"
  }
}