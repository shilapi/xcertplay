-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Constants = require "Constants"
local DigiBarCommonLayoutUtils = require "DigiBarCommonLayoutUtils"
local DigiBarMarkerConfiguration = require "DigiBarMarkerConfiguration"
local DriverAssistanceUtils = require "DriverAssistanceUtils"
local Enums = require "Enums"
local GaugeColor = require "GaugeColor"
local Ticks = require "Ticks"

local DigiBarMarkerGauge = APL.LuaUtils.makeObject({ _type = "DigiBarMarkerGauge" })











function DigiBarMarkerGauge.newDigiBarDotMarker(configuration, progressController, stateController, appearanceController, name)







    local dotConfiguration = configuration.type
    local barStyle = configuration.style
    local size = dotConfiguration.radius * 2
    local path = APL.Path.new()
        :ellipseIn(APL.Rect.new(0, 0, size, size))
    local layer = APL.ShapeLayer.new()
        :setPath(path)
        :setFrame(APL.Rect.new(0, 0, size, size))
    layer:setName(name)

    local self = APL.LuaUtils.newObject(DigiBarMarkerGauge, {
        _controllers = { progressController, stateController },
        _rootLayer = layer,
        _slotFrame = APL.LuaUtils.NIL
    })

    progressController:setUpdateHandler(function(value)

        value = math.max(0, math.min(value, 1))

        layer:setFrame(DigiBarMarkerGauge._dotMarkerFrame(configuration, value, self._slotFrame))
    end)

    local setState = function(state, appearanceState)
        if state then
            local blendMode, color = DigiBarMarkerGauge._dotMarkerState(configuration, state, appearanceState)
            layer
                :setBlendMode(blendMode)
                :setFillColor(color)
        end
    end

    local lastState
    local lastAppearanceState = appearanceController:getState()
    stateController:setUpdateHandler(function(state)
        lastState = state
        setState(lastState, lastAppearanceState)
    end)

    appearanceController:setUpdateHandler(function(state)
        lastAppearanceState = state
        setState(lastState, lastAppearanceState)
    end)

    return self
end










function DigiBarMarkerGauge.newDigiBarTickMarker(configuration, progressController, appearanceController, name)






    local tickConfiguration = configuration.type
    local barStyle = configuration.style
    local layout = DigiBarCommonLayoutUtils.getDigiBarLayout(barStyle)
    local lineCap = layout.getLineCapLength(barStyle)
    local width = tickConfiguration.width
    local length = tickConfiguration.length

    local path = APL.Path.new()
        :moveTo(0, -length / 2)
        :lineTo(0, length / 2)
    local layer = APL.ShapeLayer.new()
        :setPath(path)
        :setLineWidth(width)
        :setLineCap(tickConfiguration.lineCap)
        :setAntialiased(false)

    local self = APL.LuaUtils.newObject(DigiBarMarkerGauge, {
        _controllers = { progressController },
        _rootLayer = layer,
        _slotFrame = APL.LuaUtils.NIL
    })

    progressController:setUpdateHandler(function(progress)
        local frame = self._slotFrame
        if frame then
            local rotation = layout.getRotationAngle(barStyle, frame, progress, lineCap * 2, lineCap * 2)
            local transform = APL.Transform.newWithRotation(rotation + math.pi / 2)
            local x, y = layout.getProgressCoordinates(barStyle, frame, progress)
            layer
                :setTransform(transform)
                :setFrame(x, y, 0, 0) -- Skip calculating the size, ShapeLayer's path draws correctly without it.
        end
    end)

    appearanceController:setUpdateHandler(function(state)
        local blendMode, color = DigiBarMarkerGauge._dotMarkerState(configuration, 0, state)
        layer
            :setBlendMode(blendMode)
            :setStrokeColor(color)
    end)

    return self
end













function DigiBarMarkerGauge.newLabelMarker(markerConfiguration, progressController, stateController, labelController, speedLimitedStateController, appearanceController, name)









    local configuration = markerConfiguration.type
    local barStyle = markerConfiguration.style
    local layout = DigiBarCommonLayoutUtils.getDigiBarLayout(barStyle)
    local font = APL.RasterFont.new(configuration.font)
    local boundingBox = Ticks.getMaxLabelBoundingBox(font)
    local label = APL.NumberLayer.new(font, "SpeedLimiterLabel")
        :setFrame(boundingBox)
        :setAlignment(APL.AttributedString.ALIGNMENT.CENTER)
        :setBackgroundColor(GaugeColor.clear)
    local layer = APL.ShapeLayer.new()
        :addSublayer(label)

    local self = APL.LuaUtils.newObject(DigiBarMarkerGauge, {
        _controllers = { progressController, stateController, labelController, speedLimitedStateController },
        _rootLayer = layer,
        _slotFrame = APL.LuaUtils.NIL
    })

    local lastProgress
    local lastDisplayValue
    local function updateLabel()
        local progress = lastProgress
        local displayValue = lastDisplayValue
        local frame = self._slotFrame
        if frame and progress and displayValue then
            local charsCount = string.len(tostring(displayValue))
            local width = configuration.desiredLabelWidths[math.max(1, math.min(#configuration.desiredLabelWidths, charsCount))] or 0
            local height = configuration.desiredLabelHeight
            local bounds = APL.Rect.new(0, 0, width, height)
            local x, y = layout.getProgressCoordinates(barStyle, frame, progress)
            local layerFrame = bounds:centeredAt(x, y)
            local pillPath = APL.Path.new()
                :roundedRectangleIn(bounds, configuration.cornerRadius)

            label
                :setFrame(bounds)
                :setNumber(displayValue)

            layer
                :setFrame(layerFrame)
                :setPath(pillPath)
        end
    end

    progressController:setUpdateHandler(function(progress)
        lastProgress = progress
        updateLabel()
    end)
    labelController:setUpdateHandler(function(displayValue)
        lastDisplayValue = displayValue
        updateLabel()
    end)

    local lastState
    local lastSpeedLimited
    local lastAppearance = appearanceController:getState()
    local function setState()
        if lastState ~= nil and lastSpeedLimited ~= nil then
            local state = DriverAssistanceUtils.getState(lastState, lastSpeedLimited)
            local backgroundColorIDs = configuration.backgroundColorIDs
            local backgroundColorID = backgroundColorIDs and (state and backgroundColorIDs[state] or backgroundColorIDs[0])
            local defaultBackgroundColor = lastAppearance.appearance == Enums.AppearanceMode.LIGHT and GaugeColor.white or GaugeColor.black
            local backgroundColor = backgroundColorID and lastAppearance:getSolidColor(backgroundColorID) or defaultBackgroundColor
            local textColorIDs = configuration.colorIDs
            local textColorID = textColorIDs and (state and textColorIDs[state] or textColorIDs[0])
            local defaultTextColor = lastAppearance.appearance == Enums.AppearanceMode.LIGHT and GaugeColor.black or GaugeColor.white
            local textColor = textColorID and lastAppearance:getSolidColor(textColorID) or defaultTextColor


            if layer:getVisible() and layer:getOpacity() > 0.1 and Constants.STATEFUL_COLOR_CHANGE_DURATION > 0 then
                label:animForegroundColor(textColor, Constants.STATEFUL_COLOR_CHANGE_DURATION)
            else
                label:setForegroundColor(textColor)
            end
            layer:setFillColor(backgroundColor)
        end
    end
    stateController:setUpdateHandler(function(state)
        lastState = state
        setState()
    end)
    appearanceController:setUpdateHandler(function(state)
        lastAppearance = state
        setState()
    end)
    speedLimitedStateController:setUpdateHandler(function(speedLimited)
        lastSpeedLimited = speedLimited
        setState()
    end)

    return self
end






function DigiBarMarkerGauge:destroy()


    self._rootLayer:destroy()
end







function DigiBarMarkerGauge:setFrame(frame)



    self._slotFrame = frame

    return self
end






function DigiBarMarkerGauge:getRootLayer()


    return self._rootLayer
end






function DigiBarMarkerGauge:description()


    return "DigiBarMarkerGauge " .. self:getRootLayer()._nativeLayer.name
end









function DigiBarMarkerGauge._dotMarkerFrame(configuration, value, slotFrame)





    local barStyle = configuration.style
    local layout = DigiBarCommonLayoutUtils.getDigiBarLayout(barStyle)
    local x, y = layout.getProgressCoordinates(barStyle, slotFrame, value)
    local radius = configuration.type.radius
    local frame = APL.Rect.new(0, 0, radius * 2, radius * 2)
        :centeredAt(x, y)

    return frame
end









function DigiBarMarkerGauge._dotMarkerState(configuration, state, appearanceState)




    local styles = configuration.type.styles

    local style = styles[state] or styles[0]
    local color
    local blendMode
    if style.type == DigiBarMarkerConfiguration.Dot.Style.TYPE.PUNCH_HOLE then
        color = GaugeColor.white
        blendMode = APL.Layer.BLEND_MODE.DESTOUT
    elseif style.type == DigiBarMarkerConfiguration.Dot.Style.TYPE.COLOR then
        color = appearanceState:getSolidColor(style.colorID)
        blendMode = APL.Layer.BLEND_MODE.NORMAL
    else

    end

    return blendMode, color
end

return APL.LuaUtils.readOnly(DigiBarMarkerGauge)
