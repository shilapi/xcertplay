-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Constants = require "Constants"
local TransmissionState = require "TransmissionState"
local VehicleDataSubscriber = require "VehicleDataSubscriber"
local VehicleDataUpdater = require "VehicleDataUpdater"
local VisibilityConfiguration = require "VisibilityConfiguration"
local VisibilityRule = require "VisibilityRule"
local VisibilityRulesCatalog = require "VisibilityRulesCatalog"

local VisibilityController = APL.LuaUtils.makeObject({ _type = "VisibilityController" })








function VisibilityController.new(dataIdentifiers, rules)



    local self = APL.LuaUtils.newObject(VisibilityController, {
        _dataIdentifiers = dataIdentifiers,
        _rules = rules,
        _timer = APL.LuaUtils.NIL,
        _vehicleDataSubscriber = VehicleDataSubscriber.new(),
        _lastResolvedVisibility = APL.LuaUtils.NIL
    })

    return self
end










function VisibilityController.newWithConfiguration(configuration)


    local dataIdentifiers = {}
    local rules = {}
    for _, rule in pairs(configuration.rules) do
        local identifiers, handler = VisibilityController._getVisibilityRuleHandler(rule)
        dataIdentifiers = APL.LuaUtils.merge(dataIdentifiers, identifiers)
        rules[#rules+1] = VisibilityRule.new(nil, handler)
    end

    return VisibilityController.new(dataIdentifiers, rules)
end







function VisibilityController._getVisibilityRuleHandler(rule)


    local wrap = function(f, ...)
        local args = { ... }
        return function(parameters)
            return f(parameters, rule.showAnimation, rule.hideAnimation, table.unpack(args))
        end
    end

    if rule.transmissionMode then
        return
            { rule.transmissionMode.dataIdentifier },
            wrap(VisibilityRulesCatalog.transmissionVisible, rule.transmissionMode)
    elseif rule.remainingRange then
        return
            { rule.remainingRange.dataIdentifier },
            wrap(VisibilityRulesCatalog.remainingRangeVisible, rule.remainingRange)
    elseif rule.tickmarksSpeedUnit then
        local ruleConfig = rule.tickmarksSpeedUnit
        return
            { ruleConfig.showSecondarySpeedIdentifier, ruleConfig.vehicleSpeedUnitIdentifier },
            wrap(VisibilityRulesCatalog.tickmarksUnitVisible, ruleConfig)
    elseif rule.speedLimiter then
        local ruleConfig = rule.speedLimiter
        return
            { ruleConfig.speedLimitedIdentifier, ruleConfig.cruiseControlStateIdentifier },
            wrap(VisibilityRulesCatalog.speedLimiterVisible, ruleConfig)
    elseif rule.layoutMode then
        return
            {},
            wrap(VisibilityRulesCatalog.layoutModeVisible, rule.layoutMode)
    elseif rule.invalidData then
        return
            { rule.invalidData.dataIdentifier },
            wrap(VisibilityRulesCatalog.invalidDataVisible, rule.invalidData)
    elseif rule.secondarySpeed then
        return
            { rule.secondarySpeed.dataIdentifier },
            wrap(VisibilityRulesCatalog.secondarySpeedVisible, rule.secondarySpeed)
    elseif rule.temperatureLabel then
        return
            { rule.temperatureLabel.dataIdentifier, rule.temperatureLabel.minDataIdentifier, rule.temperatureLabel.maxDataIdentifier },
            wrap(VisibilityRulesCatalog.temperatureLabelVisible, rule.temperatureLabel)
    elseif rule.activityState then
        return
            { rule.activityState.dataIdentifier },
            wrap(VisibilityRulesCatalog.activityStateVisible, rule.activityState)
    elseif rule.powerConsumption then
        return
            { rule.powerConsumption.dataIdentifier },
            wrap(VisibilityRulesCatalog.powerConsumptionVisible, rule.powerConsumption)
    elseif rule.emphasizedEngineGauge then
        return
            { rule.emphasizedEngineGauge.emphasizedEngineGaugeDataIdentifier, rule.emphasizedEngineGauge.secondaryEngineGaugeHiddenDataIdentifier },
            wrap(VisibilityRulesCatalog.emphasizedEngineGaugeVisible, rule.emphasizedEngineGauge)
    elseif rule.sideIndicator then
        return
            { rule.sideIndicator.leftDataIdentifier, rule.sideIndicator.rightDataIdentifier },
            wrap(VisibilityRulesCatalog.sideIndicatorVisible, rule.sideIndicator)
    elseif rule.driveMode then
        return
        { rule.driveMode.dataIdentifier },
        wrap(VisibilityRulesCatalog.driveModeVisible, rule.driveMode )
    else
        return
            {},
            function() return nil end
    end
end















function VisibilityController:setVisibilityUpdateHandler(vehicleDataUpdater, layoutMode, animationInitialDelay, handler)





    if vehicleDataUpdater == nil then

        self._vehicleDataSubscriber:removeSubscription()
        return self
    end

    local animationDelay = animationInitialDelay
    local updateHandler = function(update, previous)
        local visibility = VisibilityController._resolveVisibility(self._rules, layoutMode, update, previous)
        if visibility then
            local compare = function(last, new)
                return last == nil or last.opacity ~= new.opacity or not VisibilityConfiguration.Animation.equals(last.autoHideAnimation, new.autoHideAnimation)
            end

            if compare(self._lastResolvedVisibility, visibility) then
                self:_stopTimer()

                handler(visibility, animationDelay)

                self._lastResolvedVisibility = visibility


                if visibility.opacity > 0 and visibility.autoHideAnimation then
                    local newAnimation = VisibilityConfiguration.Animation.copy(visibility.autoHideAnimation)




                    newAnimation.delay = 0
                    local result = VisibilityRule.Result.new(0, newAnimation)
                    self:_startTimer(visibility.autoHideAnimation.delay + animationDelay, function(visibility)
                        handler(visibility, 0)
                        self._lastResolvedVisibility = visibility
                    end, result)
                end


                animationDelay = 0
            end
        end
    end

    if #self._dataIdentifiers > 0 then

        local identifiers = self._dataIdentifiers
        local validIdentifiers, subscriber = vehicleDataUpdater:subscribe(identifiers, updateHandler)
        self._vehicleDataSubscriber:updateSubscription(vehicleDataUpdater, subscriber)

        if #identifiers ~= #validIdentifiers then


            updateHandler({}, {})
        end
    else


        updateHandler({}, {})
    end

    return self
end












function VisibilityController._resolveVisibility(rules, layoutMode, update, previous)





    local opacity
    local showAnimation
    local hideAnimation
    local minChangedShowAnimation
    local minChangedHideAnimation
    local autoHideAnimation
    APL.LuaUtils.forEach(rules, function(rule)
        local result = rule.handler(VisibilityRule.Parameters.new(update, previous, layoutMode))
        if result == nil then
            result = rule.lastResult
        end

        if result ~= nil then
            local ruleChanged = not VisibilityRule.Result.equals(rule.lastResult, result)


            opacity = opacity or 1
            opacity = opacity * result.opacity



            if result.opacity == 0 then
                hideAnimation = (hideAnimation == nil or result.animation.duration < hideAnimation.duration)
                    and result.animation
                    or hideAnimation
                if ruleChanged then
                    minChangedHideAnimation = (minChangedHideAnimation == nil or result.animation.duration < minChangedHideAnimation.duration)
                        and result.animation
                        or minChangedHideAnimation
                end
            else
                showAnimation = (showAnimation == nil or result.animation.duration < showAnimation.duration)
                    and result.animation
                    or showAnimation
                if ruleChanged then
                    minChangedShowAnimation = (minChangedShowAnimation == nil or result.animation.duration < minChangedShowAnimation.duration)
                        and result.animation
                        or minChangedShowAnimation
                end


                if result.autoHideAnimation then
                    autoHideAnimation = (autoHideAnimation == nil or result.autoHideAnimation.duration < autoHideAnimation.duration)
                        and result.autoHideAnimation
                        or autoHideAnimation
                end
            end

            rule.lastResult = result
        end
    end)

    if opacity == nil then
        return nil
    end


    if opacity == 0 then
        return VisibilityRule.Result.new(
            opacity,
            minChangedHideAnimation and VisibilityConfiguration.Animation.copy(minChangedHideAnimation) or VisibilityConfiguration.Animation.copy(hideAnimation)
        )
    else
        return VisibilityRule.Result.new(
            opacity,
            minChangedShowAnimation and VisibilityConfiguration.Animation.copy(minChangedShowAnimation) or VisibilityConfiguration.Animation.copy(showAnimation),
            autoHideAnimation and VisibilityConfiguration.Animation.copy(autoHideAnimation)
        )
    end
end






function VisibilityController:unsubscribe()


    self._vehicleDataSubscriber:removeSubscription()

    return self
end







function VisibilityController:_startTimer(duration, callback, ...)




    self:_stopTimer()
    local args = { ... }

    self._timer = APL.Timer.new(duration, 1, function()
        callback(table.unpack(args))
    end)

    return self
end






function VisibilityController:_stopTimer()


    if self._timer then
        self._timer:destroy()
        self._timer = nil
    end

    return self
end






function VisibilityController:destroy()


    self._vehicleDataSubscriber:destroy()
    self:_stopTimer()
end

return APL.LuaUtils.readOnly(VisibilityController)
