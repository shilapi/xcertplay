-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"
local Constants = require "Constants"
local VehicleDataUpdater = require "VehicleDataUpdater"
local VehicleDataSubscriber = require "VehicleDataSubscriber"

local InputStream = APL.LuaUtils.makeObject({ _type = "InputStream" })

InputStream.KIND = APL.LuaUtils.readOnly({
    CAMERA = 0,
    SETTINGS = 1,
    WIDGET = 2,
    IPHONEVIDEO = 3,
    ROADSIGN = 4,
})

local KIND_TYPES = APL.LuaUtils.getValues(InputStream.KIND)











function InputStream.new(streamIdentifier, dataIdentifier, frameDuration, kind, streamBounds)







    local self = APL.LuaUtils.newObject(InputStream, {
        _streamIdentifier = streamIdentifier,
        _dataIdentifier = dataIdentifier or APL.LuaUtils.NIL,
        _videoLayer = APL.LuaUtils.NIL,
        _kind = kind,
        _frameDuration = frameDuration,
        _isVisible = false,
        _tweens = {},
        _transform = APL.LuaUtils.NIL,
        _vehicleDataSubscriber = VehicleDataSubscriber.new(),
        _streamBounds = streamBounds
    })





    self._videoLayer = APL.VideoLayer.new(streamIdentifier)
        :setName(streamIdentifier)
        :setFrame(streamBounds)
        :setVisible(false)


    if self._frameDuration == 0 then
        APL.Log.warn(InputStream, function() return "Invalid frame duration for stream: `%s`", tostring(streamIdentifier) end)
        self._frameDuration  = math.floor(1 / 60)
    end

    return self
end






function InputStream:destroy()


    APL.flux.clear(self._tweens)
    self._vehicleDataSubscriber:destroy()
    self._videoLayer:destroy()
end






function InputStream:getRootLayer()


    return self._videoLayer
end








function InputStream:setTransform(transform)



    self._transform = transform
    self._videoLayer:setTransform(transform)

    return self
end






function InputStream:getStreamIdentifier()


    return self._streamIdentifier
end






function InputStream:getKind()


    return self._kind
end






function InputStream:isOEMControlled()


    return self._kind == InputStream.KIND.CAMERA or self._kind == InputStream.KIND.SETTINGS
end






function InputStream:getStreamState()


    return self._videoLayer:getStreamState()
end






function InputStream:getCurrentPTS()


    return self._videoLayer:getCurrentPTS()
end










function InputStream:getNextPTS()


    return self._videoLayer:getNextPTS()
end








function InputStream:deferNextPTS()


    self._videoLayer:deferNextPTS()
    return self
end






function InputStream:getFrameDuration()


    return self._frameDuration
end






function InputStream:getStreamBounds()


    return self._streamBounds
end






function InputStream:flush()


    self._videoLayer:flush()
    return self
end






function InputStream:subscribe()


    self._videoLayer:subscribe()
    return self
end






function InputStream:unsubscribe()


    self._videoLayer:unsubscribe()
    return self
end







function InputStream:setVehicleDataUpdater(vehicleDataUpdater)



    if vehicleDataUpdater == nil then
        self._vehicleDataSubscriber:removeSubscription()
        return true
    end

    if self._dataIdentifier then
        local identifiers = { self._dataIdentifier }
        local validIdentifiers, subscriber = vehicleDataUpdater:subscribe(identifiers, function(update)
            local keyPath = tostring(self._dataIdentifier) .. "." .. tostring(self._streamIdentifier)
            local value = APL.LuaUtils.query(update, keyPath)
            if value ~= nil then
                self:setVisible(value)
            end
        end)

        self._vehicleDataSubscriber:updateSubscription(vehicleDataUpdater, subscriber)

        return #validIdentifiers == #identifiers
    end

    APL.Log.error(InputStream, function() return "setVehicleDataUpdater: stream is not oem controlled (`" .. self._streamIdentifier .. "`)" end)
    return true
end







function InputStream:setVisible(isVisible)



    if self._isVisible == isVisible then
        APL.Log.info(InputStream, function() return "Not updating primary value because it's the same as the previous value " .. tostring(isVisible) .. " for `" .. self._streamIdentifier .. "`" end)
        return self
    end

    APL.Log.info(InputStream, function() return "Changing isVisible from " ..  tostring(self._isVisible) .. " to " .. tostring(isVisible) .. " for `" .. self._streamIdentifier .. "`" end)
    self._isVisible = isVisible

    if isVisible then
        if self:_shouldAnimate() then
            self:_presentAnimation()
        else
            APL.Log.info(InputStream, function() return "Presenting input stream `" .. self._streamIdentifier .. "` without animation." end)
            APL.Signpost.emitEvent("Presenting input stream " .. self._streamIdentifier .. " without animation.")
            self._videoLayer:setVisible(true)
        end
    else
        if self:_shouldAnimate() then
            self:_dismissAnimation()
        else
            APL.Log.info(InputStream, function() return "Dismissing input stream `" .. self._streamIdentifier .. "` without animation" end)
            APL.Signpost.emitEvent("Dismissing input stream " .. self._streamIdentifier .. " without animation")
            self._videoLayer:setVisible(false)
        end
    end

    return self
end






function InputStream:_presentAnimation()


    APL.Log.info(InputStream, function() return "Start presenting input stream `" .. self._streamIdentifier .. "` with animation" end)
    APL.Signpost.emitEvent("Start presenting input stream " .. self._streamIdentifier .. " with animation")

    self._videoLayer
        :setOpacity(0)
        :setVisible(true)

    self._tweens.opacity = 0
    self._tweens.scaleX = 0.95
    self._tweens.scaleY = 0.95

    APL.flux.to(self._tweens, Constants.INPUTSTREAM_ANIMATION_DURATION, { opacity = 1, scaleX = 1, scaleY = 1 })
        :ease("bezier", table.unpack(Constants.POPOVER_CURVE))
        :onupdate(function(t)
            self._videoLayer
                :setOpacity(t.opacity)
                :setTransform(self:_getTransform(t.scaleX, t.scaleY))
        end)
        :oncomplete(function()
            APL.Log.info(InputStream, function() return "Completed presentation animation for input stream `" ..  APL.LuaUtils.prettyPrint(self._streamIdentifier) .. "`" end)
            APL.Signpost.emitEvent("Completed presentation animation for input stream " ..  APL.LuaUtils.prettyPrint(self._streamIdentifier))
        end)

    return self
end






function InputStream:_dismissAnimation()



    APL.Log.info(InputStream, function() return "Start dismissing input stream `" .. self._streamIdentifier .. "` with animation" end)
    APL.Signpost.emitEvent("Start dismissing input stream " ..  self._streamIdentifier .. " with animation")

    APL.flux.to(self._tweens, Constants.INPUTSTREAM_ANIMATION_DURATION, { opacity = 0.0, scaleX = 1.05, scaleY = 1.05 })
        :ease("bezier", table.unpack(Constants.POPOVER_CURVE))
        :onupdate(function(t)
            self._videoLayer
                :setOpacity(t.opacity)
                :setTransform(self:_getTransform(t.scaleX, t.scaleY))
        end)
        :oncomplete(function()
            APL.Log.info(InputStream, function() return "Completed dismissal animation for input stream `" ..  self._streamIdentifier .. "`" end)
            APL.Signpost.emitEvent("Completed dismissal animation for input stream" ..  self._streamIdentifier)

            self._videoLayer:setVisible(false)
        end)

    return self
end






function InputStream:description()


    return "InputStream (`" .. self._streamIdentifier .. "`, " .. tostring(self._dataIdentifier) .. ")"
end








function InputStream:_shouldAnimate()


    return self._kind == InputStream.KIND.CAMERA or self._kind == InputStream.KIND.SETTINGS
end









function InputStream:_getTransform(scaleX, scaleY)




    local scale = APL.Transform.newWithScale(scaleX, scaleY)



    return self._transform and scale:concatenate(self._transform) or scale
end

return APL.LuaUtils.readOnly(InputStream)
