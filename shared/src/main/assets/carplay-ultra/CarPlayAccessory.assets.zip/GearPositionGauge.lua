-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local AttributedString = require "APL.AttributedString"
local Constants = require "Constants"
local Enums = require "Enums"
local GaugeColor = require "GaugeColor"
local ImageGroupGauge = require "ImageGroupGauge"
local TransmissionState = require "TransmissionState"
local VehicleDataSubscriber = require "VehicleDataSubscriber"
local VehicleDataUpdater = require "VehicleDataUpdater"
local VerifiedUIController = require "VerifiedUIController"

local GearPositionGauge = APL.LuaUtils.makeObject({ _type = "GearPositionGauge" })

GearPositionGauge.VERSION = APL.LuaUtils.readOnly({
    PRIMARY = "primary",
    SECONDARY = "secondary",
    NUMERICAL_ONLY = "numericalOnly"
})












function GearPositionGauge.new(config, colors, controller, appearanceController, gearShiftImageGroupGaugeConfiguration, gearShiftImageGroupGauge)









    local self = APL.LuaUtils.newObject(GearPositionGauge, {
        _controller = controller,
        _appearanceController = appearanceController,
        _gears = {
            [Enums.TransmissionMode.NONE] = "-",
            [Enums.TransmissionMode.D] = "D",
            [Enums.TransmissionMode.L] = "L",
            [Enums.TransmissionMode.M] = "M",
            [Enums.TransmissionMode.N] = "N",
            [Enums.TransmissionMode.P] = "P",
            [Enums.TransmissionMode.R] = "R",
            [Enums.TransmissionMode.S] = "S"
        },

        _fullPRNDLGears = {
            [1] = Enums.TransmissionMode.P,
            [2] = Enums.TransmissionMode.R,
            [3] = Enums.TransmissionMode.N,
            [4] = Enums.TransmissionMode.D,
            [5] = Enums.TransmissionMode.M
        },
        _currentTransmissionMode = 0, -- undetermined state initially
        _currentGearPosition = 0,
        _colors = colors,
        _isSinglePRNDL = config.gaugeVersion == GearPositionGauge.VERSION.PRIMARY or
                         config.gaugeVersion == GearPositionGauge.VERSION.NUMERICAL_ONLY,

        _rootLayer = APL.LuaUtils.NIL,


        _circle = APL.LuaUtils.NIL,
        _label = APL.LuaUtils.NIL,

        _fontConfig = config.font,
        _font = APL.RasterFont.new(config.font.name),

        _configuration = config,


        _selectedCircle = APL.LuaUtils.NIL,
        _circles = {},
        _textImages = {},
        _greenTextImages = {},
        _circleStartOffset = APL.LuaUtils.NIL,
        _circleOffset = APL.LuaUtils.NIL,

        _vehicleDataSubscriber = VehicleDataSubscriber.new(),

        _gearShiftImageGroupConfig = config.gearShiftImageGroupConfig or APL.LuaUtils.NIL,
        _gearShiftImageGroupGauge = gearShiftImageGroupGauge or APL.LuaUtils.NIL,
        _gearShiftWidth = APL.LuaUtils.NIL
    })

    local imageStates = gearShiftImageGroupGaugeConfiguration and gearShiftImageGroupGaugeConfiguration.states or {}
    local maxWidth = APL.LuaUtils.reduce(APL.LuaUtils.getKeys(imageStates), 0, function(partial, state)
        local imageConfig = imageStates[state]

        local w = imageConfig and APL.Asset.loadNamedTexture(imageConfig.image):getSize() or 0
        return math.max(partial, w)
    end)
    self._gearShiftWidth = maxWidth or 0



    self._rootLayer = APL.Layer.new()
        :setName("GearPosition")

    local lastState
    local lastAppearanceState = appearanceController:getState()
    local setState = function()
        local state = lastState
        if state then
            local transmissionMode = state.mode
            local gearPosition = state.position

            if transmissionMode ~= self._currentTransmissionMode or
                gearPosition ~= self._currentGearPosition then
                self:_setState(state, lastAppearanceState)

                self._currentTransmissionMode = transmissionMode
                self._currentGearPosition = gearPosition
            end
        end
    end

    self._controller:setUpdateHandler(function(state)
        lastState = state
        setState()
    end)

    appearanceController:setUpdateHandler(function(appearanceState)
        lastAppearanceState = appearanceState

        local textColor = lastState and lastState:canShowRedactedState()
            and APL.LuaUtils.setAlpha(appearanceState:getSolidColor(self._configuration.textColorID), Constants.REDACTED_ALPHA)
            or appearanceState:getSolidColor(self._configuration.textColorID)
        if self._label then
            self._label:setForegroundColor(textColor)
        end
    end)

    VerifiedUIController.current():addVerifiedElement(self)

    return self
end






function GearPositionGauge:destroy()


    self._vehicleDataSubscriber:destroy()
    self._rootLayer:destroy()

    VerifiedUIController.current():removeVerifiedElement(self)
end







function GearPositionGauge:setFrame(frame)



    self._rootLayer
        :removeSublayers()
        :setFrame(frame)

    if self._isSinglePRNDL then
        self:_createSinglePRNDL(frame)
    else
        self:_createFullPRNDL(frame)
    end

    return self
end








function GearPositionGauge:sizeThatFits(width, height)


    local desiredWidth
    local desiredHeight

    if self._isSinglePRNDL then
        desiredWidth = self:_getCircleDiameter(APL.Rect.new(0,0, width, height))
        desiredHeight = desiredWidth
    else
        desiredWidth = width
        desiredHeight = height
    end

    return desiredWidth, desiredHeight
end






function GearPositionGauge:getRootLayer()


    return self._rootLayer
end






function GearPositionGauge:getVerifiedLayer()



    if self._configuration.gaugeVersion == GearPositionGauge.VERSION.NUMERICAL_ONLY then
        return nil
    end

    if self._isSinglePRNDL then
        return self._label
    else
        return self._rootLayer
    end
end







function GearPositionGauge:getVerifierIdentifier()



    return "prndl"
end






function GearPositionGauge:description()

    return APL.LuaUtils.prettyPrint(self)
end











function GearPositionGauge:_createFullPRNDL(frame)



    local width = frame._width
    local height = frame._height

    local heightDiameter = height - 4
    local numGears = #(self._fullPRNDLGears)

    local widthDiameter = (width - (numGears * 4))  / numGears
    local circleDiameter = math.min(widthDiameter, heightDiameter)

    local heightOffset = (height - circleDiameter) / 2.0
    local spacing = (width - (numGears * circleDiameter)) / numGears

    self._circleStartOffset = circleDiameter / 2.0
    self._circleOffset = (circleDiameter + spacing)


    for gearIndex = 1, numGears do


        local circleFrame = APL.Rect.new(
            (gearIndex - 1) * (circleDiameter + spacing),
            heightOffset,
            circleDiameter,
            circleDiameter
        )
        local circle, textImage, greenTextImage = self:_createGear(circleFrame, self._fullPRNDLGears[gearIndex], circleDiameter)

        self._circles[gearIndex] = circle
            :addToSuperLayer(self._rootLayer)
        self._textImages[gearIndex] = textImage
            :addToSuperLayer(self._rootLayer)
        self._greenTextImages[gearIndex] = greenTextImage
            :setOpacity(0)
            :setVisible(false)
            :addToSuperLayer(self._rootLayer)
    end


    local selectedCircleFrame = APL.Rect.new(
        0,
        heightOffset,
        circleDiameter,
        circleDiameter
    )


    local selectedCirclePath = APL.Path.new()
        :ellipseIn(APL.Rect.new(2, 2, circleDiameter - 4, circleDiameter - 4))

    self._selectedCircle = APL.ShapeLayer.new()
        :setFrame(selectedCircleFrame)
        :setPath(selectedCirclePath)
        :setStrokeColor(self._colors.green)
        :setLineWidth(4)
        :setVisible(false)
        :addToSuperLayer(self._rootLayer)

    return self
end







function GearPositionGauge:_createSinglePRNDL(frame, appearanceController)



    local circleDiameter = self:_getCircleDiameter(frame)

    local circleFrame = APL.Rect.new(
        frame._width / 2 - circleDiameter / 2,
        frame._height / 2 - circleDiameter / 2,
        circleDiameter,
        circleDiameter
    )

    self._circle, self._label = self:_createGear(circleFrame, Enums.TransmissionMode.P, circleDiameter, appearanceController)

    self._rootLayer
        :addSublayer(self._circle)
        :addSublayer(self._label:setVisible(false))


    if self._gearShiftImageGroupGauge then
        self._rootLayer:addSublayer(self._gearShiftImageGroupGauge:getRootLayer())
    end

    return self
end







function GearPositionGauge:_getCircleDiameter(frame)




    return math.min(frame._height, frame._width)
end














function GearPositionGauge:_createGear(circleFrame, gearIndex, circleDiameter)





    local setBackgroundAppearanceState



    local circlePath = APL.Path.new()
        :ellipseIn(APL.Rect.new(1, 1, circleDiameter - 2, circleDiameter - 2))


    local baseCircle = APL.ShapeLayer.new()
    if self._configuration.blurredPlatter then
        local circleBounds = APL.Rect.new(0, 0, circleFrame:getSize())


        APL.BackdropLayer.new()
            :addFilter(
                APL.BlurFilter.new()
                    :setRadius(20)
                    :setNormalizedEdges(true)
            )
            :setFrame(circleBounds)
            :addToSuperLayer(baseCircle)


        APL.Layer.new()
            :setBackgroundColor(APL.LuaUtils.setAlpha(GaugeColor.black, 0.4))
            :addToSuperLayer(baseCircle)


        local backgroundCircleLayer = APL.Layer.new()
            :setFrame(circleBounds)

            :addToSuperLayer(baseCircle)

        setBackgroundAppearanceState = function(state)
            backgroundCircleLayer:setBackgroundColor(state:getSolidColor(self._configuration.backgroundColorID))
        end


        baseCircle
            :setFrame(circleFrame)
            :setMask(
                APL.ShapeLayer.new()
                    :setFrame(circleBounds)
                    :setPath(circlePath)
                    :setLineWidth(2.0)
                    :setFillColor(GaugeColor.white)
            )
    else
        baseCircle
            :setFrame(circleFrame)
            :setLineWidth(2.0)
            :setPath(circlePath)
        setBackgroundAppearanceState = function(state)
            baseCircle:setFillColor(state:getSolidColor(self._configuration.backgroundColorID))
        end
    end

    if self._isSinglePRNDL then

        local label = APL.TextLayer.new(self._font, "PRNDL")
            :setAlignment(self._configuration.alignment)

        self._appearanceController:setUpdateHandler(function(state)
            setBackgroundAppearanceState(state)
            local textColor = state:getSolidColor(self._configuration.textColorID)
            label:setForegroundColor(textColor)
        end)

        return baseCircle, label, nil -- single PRNDL doesn't have green text, so returning nil for 3rd element.
    else

        local texture = self._font:textureForCharacter(self._gears[gearIndex])
        local textFrame = APL.Rect.new(0, 0, texture:getSize())
            :centeredInRect(circleFrame)


        local textImage = APL.ImageLayer.new()
            :setTexture(texture)
            :setFrame(textFrame)


        local greenTextImage = APL.ImageLayer.new(self._font)
            :setTexture(texture)
            :setFrame(textFrame)
            :setTint(self._colors.green)

        self._appearanceController:setUpdateHandler(function(state)
            setBackgroundAppearanceState(state)
            local textColor = state:getSolidColor(self._configuration.textColorID)
            textImage:setTint(textColor)
        end)

        return baseCircle, textImage, greenTextImage
    end
end








function GearPositionGauge:_setState(transmissionState, appearanceState)




    if self._isSinglePRNDL then
        self:_setSinglePRNDLState(transmissionState, appearanceState)
    else
        self:_setGearFullPRNDLState(transmissionState)
    end

    VerifiedUIController.current():setNeedsUpdate()

    return self
end








function GearPositionGauge:_setSinglePRNDLState(transmissionState, appearanceState)




    local text = ''
    local redacted = false
    local textColor = appearanceState:getSolidColor(self._configuration.textColorID)

    if transmissionState:canShowRedactedState() then
        text = '---'
        redacted = true
        textColor = APL.LuaUtils.setAlpha(textColor, Constants.REDACTED_ALPHA)
    else
        if transmissionState:canShowNumericalGearPosition() then

            text = tostring(transmissionState.position or '-')
        end

        if self._configuration.gaugeVersion ~= GearPositionGauge.VERSION.NUMERICAL_ONLY then

            text = self._gears[transmissionState.mode or Enums.TransmissionMode.N] .. text
        end
    end

    local visible = text ~= ''

    self._circle:setVisible(visible)

    local circleFrame = APL.Rect.new(self._circle:getFrame())


    local newLabel = APL.TextLayer.new(self._font, "PRNDL")
        :setVisible(visible)
        :setForegroundColor(textColor)
        :setAlignment(self._configuration.alignment)
        :setText(text)
        :setRedacted(redacted)

    local textSize = newLabel:getBoundingRect()
    local rootLayerFrame = APL.Rect.new(self._rootLayer:getFrame())
    local textWidth = self._configuration.alignment == AttributedString.ALIGNMENT.CENTER and textSize._width or rootLayerFrame._width
    local textRect = APL.Rect.new(0, 0, textWidth, newLabel:getFont():getHeight())

    textRect = textRect:centeredInRect(circleFrame)
    if text == "1" and self._configuration.shiftFirstGearLabel then


        local shift = textSize._width * 0.18
        textRect._x = textRect._x - shift
    end

    if self._configuration.baselineSpacing then
        local baselineSpacingDiff = rootLayerFrame._height - textSize._height
        textRect._y = baselineSpacingDiff - self._configuration.baselineSpacing
        textRect._height = textSize._height
    end

    self._rootLayer:addSublayer(newLabel)
    newLabel:setFrame(textRect)

    if self._label then
        self._rootLayer:removeSublayer(self._label)
    end
    self._label = newLabel

    if self._gearShiftImageGroupGauge then
        local labelX, labelY, labelWidth, labelHeight = self._label:getFrame()
        local gearShiftX = labelX + labelWidth



        if self._configuration.alignment == AttributedString.ALIGNMENT.RIGHT then
            gearShiftX = labelWidth - textSize._width - self._gearShiftWidth - self._configuration.recommendationSpacing -- Put the recommendation image on the left side of the gear.
        elseif self._configuration.alignment == AttributedString.ALIGNMENT.LEFT then
            gearShiftX = textSize._width + self._configuration.recommendationSpacing -- Put the recommendation image on the right side of the gear.
        end






        local numberHeight = self._font:getCharacterBoundingBox("0")._height
        local gearShiftY = labelY + (labelHeight / 2.0) - (numberHeight / 2.0)
        local gearShiftHeight = labelY + self._font:getBaselineOffset() - gearShiftY

        if self._configuration.baselineSpacing then
            gearShiftHeight = textRect._height
        end

        local gearShiftFrame = APL.Rect.new(gearShiftX, gearShiftY, self._gearShiftWidth, gearShiftHeight)
        self._gearShiftImageGroupGauge:setFrame(gearShiftFrame)
    end

    return self
end








function GearPositionGauge:_setGearFullPRNDLState(transmissionState)




    local redacted = transmissionState:canShowRedactedState()
    local textColor = self._palette:getSolidColor(self._configuration.textColorID)

    if redacted then
        self._selectedCircle:setVisible(false)
    end


    for gearIndex = 1, #(self._fullPRNDLGears) do
        self._greenTextImages[gearIndex]
            :setVisible(not redacted)
    end

    if redacted then
        return self
    end

    local success, previousIndex = APL.LuaUtils.find(self._fullPRNDLGears, self._currentTransmissionMode)
    if not success then
        previousIndex = 0
    end

    local success, gearIndex = APL.LuaUtils.find(self._fullPRNDLGears, transmissionState.mode)
    if not success then
        APL.Log.error("GearPositionGauge", function() return "Unsupported gear: " .. transmissionState.mode end)
        return self
    end

    local _, selectedCircleY = self._selectedCircle:getPosition()
    local selectedCircleNewX = self._circleStartOffset + (gearIndex - 1) * self._circleOffset

    if previousIndex == 0 then -- Don't animate if previous selected gear was unknown
        self._greenTextImages[gearIndex]
            :setOpacity(1)
            :setVisible(true)

        self._selectedCircle
            :setVisible(true)
            :setPosition(selectedCircleNewX, selectedCircleY)
    else

        for gear = 1, #(self._fullPRNDLGears) do
            if gear == gearIndex then
                self._greenTextImages[gearIndex]
                    :setVisible(true)
                    :animOpacity(1, 3)

            end

            if gear == previousIndex then
                self._greenTextImages[gear]
                    :animOpacity(0, 3, function()
                        self._greenTextImages[gear]:setVisible(false)
                    end)

            end
        end


        self._selectedCircle
            :setVisible(true)
            :animPosition(selectedCircleNewX, selectedCircleY, 3)

            :ease("cubicinout")
    end

    return self
end

return APL.LuaUtils.readOnly(GearPositionGauge)
