-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Constants = require "Constants"
local DigiBarCommonLayoutUtils = require "DigiBarCommonLayoutUtils"
local DigiBarCruiseControlConfiguration = require "DigiBarCruiseControlConfiguration"

local DigiBarCruiseControl = { _type = "DigiBarCruiseControl" }

DigiBarCruiseControl.Value = APL.LuaUtils.namedObject(
    "DigiBarCruiseControl.Value",
    { "vehicleSpeed", "number" },
    { "targetSpeed", "number" }
)

DigiBarCruiseControl.EPSILON = 0.0001







function DigiBarCruiseControl.createDigiBarCruiseControl(parameters)










    if parameters.configuration.type == DigiBarCruiseControlConfiguration.BAR_TYPE.FOREGROUND then
        local barLayer, setFrame, setValue, setState = DigiBarCruiseControl._createDigiBarCruiseControl(
            parameters,
            DigiBarCruiseControl._cruiseControlStrokeStart(),
            DigiBarCruiseControl._cruiseControlStrokeEndForeground()
        )
        return barLayer, setFrame, setValue, setState
    elseif parameters.configuration.type == DigiBarCruiseControlConfiguration.BAR_TYPE.BACKGROUND then
        local barLayer, setFrame, setValue, setState = DigiBarCruiseControl._createDigiBarCruiseControl(
            parameters,
            DigiBarCruiseControl._cruiseControlStrokeStartBackground(),
            DigiBarCruiseControl._cruiseControlStrokeEnd()
        )

        return  barLayer, setFrame, setValue, setState
    elseif parameters.configuration.type == DigiBarCruiseControlConfiguration.BAR_TYPE.DETACHED then
        local barLayer, setFrame, setValue, setState = DigiBarCruiseControl._createDigiBarCruiseControl(
            parameters,
            DigiBarCruiseControl._cruiseControlStrokeStart(),
            DigiBarCruiseControl._cruiseControlStrokeEnd()
        )
        return barLayer, setFrame, setValue, setState
    else

    end
end









function DigiBarCruiseControl._createDigiBarCruiseControl(parameters, getStrokeStart, getStrokeEnd)





    local cruiseControlBarConfiguration = parameters.configuration.cruiseControlBarConfiguration
    local cruiseControlBarStyle = cruiseControlBarConfiguration.style
    local cruiseControlLayout = DigiBarCommonLayoutUtils.getDigiBarLayout(cruiseControlBarStyle)
    local colorsConfiguration = cruiseControlBarConfiguration.colorsConfiguration
    local activeColors = colorsConfiguration.activeColorIDs

    local progressLayer = APL.ShapeLayer.new()
        :setName("CruiseControl:BarProgress")

    local setValue = function(value)

        local start = getStrokeStart(value)

        progressLayer:setStrokeStart(start)
        progressLayer:setStrokeEnd(getStrokeEnd(value))
    end
    local setFrame = function(frame)
        local digiBarFrame, path, lineWidth, lineCap = cruiseControlLayout.getBarLayout(cruiseControlBarStyle, frame, 0, 0)
        progressLayer
            :setFrame(digiBarFrame)
            :setPath(path)
            :setLineWidth(lineWidth)
            :setLineCap(lineCap)
    end

    local setState = function(state, appearanceState)
        local getColor = DigiBarCommonLayoutUtils.getSolidColor(activeColors, appearanceState)
        local color = getColor(state)

        if progressLayer:getVisible() and progressLayer:getOpacity() > 0.1 and Constants.STATEFUL_COLOR_CHANGE_DURATION > 0 then
            progressLayer:animStrokeColor(color, Constants.STATEFUL_COLOR_CHANGE_DURATION)
        else
            progressLayer:setStrokeColor(color)
        end
    end

    return progressLayer, setFrame, setValue, setState
end






function DigiBarCruiseControl._cruiseControlStrokeStartBackground()
    return function()
        return 0
    end
end






function DigiBarCruiseControl._cruiseControlStrokeEndForeground()

    return function(value)


        return value.vehicleSpeed
    end
end






function DigiBarCruiseControl._cruiseControlStrokeStart()

    return function(value)


        return math.min(value.vehicleSpeed, value.targetSpeed) - DigiBarCruiseControl.EPSILON
    end
end






function DigiBarCruiseControl._cruiseControlStrokeEnd()

    return function(value)


        local progress = math.max(value.vehicleSpeed, value.targetSpeed)
        progress = math.min(1, progress + DigiBarCruiseControl.EPSILON)
        progress = math.max(DigiBarCruiseControl.EPSILON, progress)
        return progress
    end
end

return APL.LuaUtils.readOnly(DigiBarCruiseControl)