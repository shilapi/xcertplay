-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local VehicleDataUpdater = require "VehicleDataUpdater"

local ImageGroupGauge = APL.LuaUtils.makeObject({ _type = "ImageGroupGauge" })

ImageGroupGauge.DEFAULT_STATE = 0

ImageGroupGauge.DATA_TRANSFORMATION_TYPE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "gearShiftRecommendation"
}))










function ImageGroupGauge.new(configuration, appearanceController, stateController, criticalStateController)




    local self = APL.LuaUtils.newObject(ImageGroupGauge, {
        _imageLayer = APL.ImageLayer.new(),
        _rootLayer = APL.LuaUtils.NIL,
        _appearanceController = appearanceController,
        _lastState = APL.LuaUtils.NIL,
        _lastCriticalState = APL.LuaUtils.NIL,
        _lastAppearanceState = APL.LuaUtils.NIL,
        _setStateAndTint = APL.LuaUtils.NIL
    })
    local imagesByState = configuration.states or {}


    self._rootLayer = APL.Layer.new()
        :setName("ImageGroup")
        :addSublayer(self._imageLayer)

    self._lastState = ImageGroupGauge._imageKeyForStateValue(configuration)
    self._lastAppearanceState = appearanceController:getState()

    local function setTint(state, criticalState, appearanceState)

        local imageConfiguration = imagesByState[state]
        criticalState = criticalState or ImageGroupGauge.DEFAULT_STATE



        if not imageConfiguration then
            APL.Log.error(ImageGroupGauge, function() return "No image configuration for state: " .. APL.LuaUtils.prettyPrint(state) end)
            return
        end

        local tintColors = APL.LuaUtils.numberedKeys(imageConfiguration.tintColorIDs)
        local colorID = tintColors[criticalState]
        if colorID then
            local color = appearanceState:getSolidColor(colorID)
            self._imageLayer:setTint(color)
        else
            APL.Log.error(ImageGroupGauge, function() return "No color for state: " .. APL.LuaUtils.prettyPrint(criticalState) end)
        end
    end

    local function setState(state)


        local imageConfiguration = imagesByState[state]
        if not imageConfiguration then
            APL.Log.info(ImageGroupGauge, function() return "No image configuration for state: " .. APL.LuaUtils.prettyPrint(state) .. ", " .. APL.LuaUtils.prettyPrint(imagesByState) end)


            self._imageLayer:setTexture(nil)
            return
        end



        local _, _, width, height = self._rootLayer:getFrame()
        local bounds = APL.Rect.new(0, 0, width, height)

        local imageTexture = APL.Asset.loadNamedTexture(imageConfiguration.image)
        local textureBounds = APL.Rect.new(0, 0, imageTexture:getSize())
            :rectWithAlignment(bounds, imageConfiguration.alignment)

        self._imageLayer
            :setFrame(textureBounds)
            :setTexture(imageTexture)
    end

    local function setStateAndTint(state, criticalState, appearanceState)




        setState(state)
        setTint(state, criticalState, appearanceState)
    end

    self._setStateAndTint = setStateAndTint

    if stateController then
        stateController:setUpdateHandler(function(state)
            self._lastState = ImageGroupGauge._imageKeyForStateValue(configuration, state)
            setStateAndTint(self._lastState, self._lastCriticalState, self._lastAppearanceState)
        end)
    end

    if criticalStateController then
        criticalStateController:setUpdateHandler(function(criticalState)
            self._lastCriticalState = criticalState
            setTint(self._lastState, self._lastCriticalState, self._lastAppearanceState)
        end)
    end

    appearanceController:setUpdateHandler(function(appearanceState)
        self._lastAppearanceState = appearanceState
        setTint(self._lastState, self._lastCriticalState, self._lastAppearanceState)
    end)

    return self
end








function ImageGroupGauge._imageKeyForStateValue(config, value)



    if value == nil then
        return config.defaultState or tostring(ImageGroupGauge.DEFAULT_STATE)
    elseif value == VehicleDataUpdater.INVALID then
        return config.redactedState
    elseif config.dataTransformationType == ImageGroupGauge.DATA_TRANSFORMATION_TYPE.gearShiftRecommendation then
        if value == 0 then return "none"
        elseif value > 0 then return "up"
        else return "down" end
    else
        return tostring(value)
    end
end






function ImageGroupGauge:destroy()


    self._rootLayer:destroy()
end







function ImageGroupGauge:setFrame(frame)



    self._rootLayer:setFrame(frame)
    self._setStateAndTint(self._lastState, self._lastCriticalState, self._lastAppearanceState)

    return self
end






function ImageGroupGauge:getRootLayer()


    return self._rootLayer
end






function ImageGroupGauge:description()


    return "ImageGroupGauge " .. APL.LuaUtils.prettyPrint(self._lastState, false, 3)
end

return APL.LuaUtils.readOnly(ImageGroupGauge)
