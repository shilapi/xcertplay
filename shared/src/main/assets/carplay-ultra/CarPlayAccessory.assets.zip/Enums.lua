-- Copyright © 2021-2026 Apple, Inc. All rights reserved.


local LuaUtils = require "APL.LuaUtils"

local Enums = { _type = "Enums" }

Enums.AppearanceMode = LuaUtils.readOnly({
    LIGHT = 0,
    DARK = 1,
})

Enums.BatteryLevelState = LuaUtils.readOnly({
    NORMAL = 0,
    LOW = 1,
    CRITICAL_LOW = 2,
})

Enums.ContentURL = LuaUtils.readOnly({
    WIDGET = "widget://",
    WIDGET_WITH_IDENTIFIER = "widget://?identifier=",
    WIDGET_WITH_IDENTIFIER_CHARGING = "widget://?identifier=com.apple.charging",
    WIDGET_WITH_IDENTIFIER_TIRES = "widget://?identifier=com.apple.tires",
    WIDGET_WITH_IDENTIFIER_CAR_BODY_STATUS = "widget://?identifier=com.apple.carBodyStatus",
    REMOTE_NOTIFICATION = "remoteNotification://",
    LOCAL_NOTIFICATION = "localNotification://",
    PICKER = "picker://",
    DRIVER_ASSISTANCE_INPUT_STREAM = "inputStream://?identifier=adasView",
})

Enums.DisplayPanelIdentifier = LuaUtils.readOnly({
    CENTER_DISPLAY = "Center_Display",
    CLUSTER_DISPLAY = "Cluster_Display",
})

Enums.DisplayZoneIdentifier = LuaUtils.readOnly({
    ZONE_1 = "zone1",
    ZONE_2 = "zone2",
})

Enums.DynamicContentURL = LuaUtils.readOnly({
    WIDGET = "widget://",
    WIDGET_WITH_IDENTIFIER = "widget://?identifier=",
    WIDGET_WITH_IDENTIFIER_CHARGING = "widget://?identifier=com.apple.charging",
    WIDGET_WITH_IDENTIFIER_TIRES = "widget://?identifier=com.apple.tires",
    WIDGET_WITH_IDENTIFIER_CAR_BODY_STATUS = "widget://?identifier=com.apple.carBodyStatus",
    DRIVER_ASSISTANCE_INPUT_STREAM = "inputStream://?identifier=adasView",
})

Enums.FillLevelLabel = LuaUtils.readOnly({
    EMPTY_TO_FULL = 0,
    ZERO_TO_ONE = 1,
})

Enums.FuelLevelState = LuaUtils.readOnly({
    NORMAL = 0,
    LOW = 1,
    CRITICAL_LOW = 2,
})

Enums.ImageColor = LuaUtils.readOnly({
    DEFAULT = 0,
    WHITE = 1,
    BLACK = 2,
    GRAY = 3,
    RED = 4,
    YELLOW = 5,
    BLUE = 6,
    GREEN = 7,
    MINT = 8,
    ORANGE = 9,
    TEAL = 10,
    CYAN = 11,
    INDIGO = 12,
    PURPLE = 13,
    PINK = 14,
    BROWN = 15,
})

Enums.LanguageIdentifier = LuaUtils.readOnly({
    ARABIC = "ar",
    BULGARIAN = "bg",
    CHINESE_SIMPLIFIED = "zh-Hans",
    CHINESE_TRADITIONAL = "zh-Hant",
    CHINESE_TRADITIONALHK = "zh-HK",
    CROATIAN = "hr",
    CZECH = "cs",
    DANISH = "da",
    DUTCH = "nl",
    ENGLISH = "en",
    FINNISH = "fi",
    FRENCH = "fr",
    GERMAN = "de",
    HEBREW = "he",
    HINDI = "hi",
    INDONESIAN = "id",
    ITALIAN = "it",
    JAPANESE = "ja",
    KOREAN = "ko",
    MALAY = "ms",
    NORWEGIAN = "no",
    POLISH = "pl",
    PORTUGUESE = "pt",
    ROMANIAN = "ro",
    RUSSIAN = "ru",
    SERBIAN = "sr",
    SLOVAK = "sk",
    SPANISH = "es",
    SWEDISH = "sv",
    THAI = "th",
    TURKISH = "tr",
    VIETNAMESE = "vi",
})

Enums.PortSideIndicator = LuaUtils.readOnly({
    NONE = 0,
    RIGHT = 2,
    LEFT = 4,
})

Enums.PowerState = LuaUtils.readOnly({
    NORMAL = 0,
    INACTIVE = 1,
    ECO = 2,
    BOOST_ACTIVATED_AND_UNAVAILABLE = 3,
    BOOST_ACTIVATED_AND_AVAILABLE = 4,
    BOOST = 5,
})

Enums.ProximityAlert = LuaUtils.readOnly({
    OFF = 0,
    WARNING = 1,
    CRITICAL_WARNING = 2,
})

Enums.RotationalSpeedState = LuaUtils.readOnly({
    NORMAL = 0,
    REDLINE = 1,
    INACTIVE = 2,
})

Enums.TargetSpeedState = LuaUtils.readOnly({
    UNAVAILABLE = 0,
    DEACTIVATED = 1,
    ACTIVATED_PASSIVE = 2,
    ACTIVATED_OPERATING = 3,
    ACTIVATED_UNCONFIGURED = 4,
})

Enums.TemperatureState = LuaUtils.readOnly({
    NORMAL = 0,
    COLD = 1,
    HOT = 2,
})

Enums.TemporaryContentURL = LuaUtils.readOnly({
    DYNAMIC_CONTENT_ELEMENT = "dynamicContentElement://",
    LOCAL_NOTIFICATION = "localNotification://",
    DYNAMIC_LOCAL_NOTIFICATION = "dynamicLocalNotification://",
    PICKER = "picker://",
    MINIMAL_REMOTE_NOTIFICATION = "minimalRemoteNotification://",
    ALERT_REMOTE_NOTIFICATION = "alertRemoteNotification://",
    ACTION_REMOTE_NOTIFICATION = "actionRemoteNotification://",
    SINGLE_SELECT_REMOTE_NOTIFICATION = "singleSelectRemoteNotification://",
    MULTI_SELECT_REMOTE_NOTIFICATION = "multiSelectRemoteNotification://",
    AUTOMAKER_SETTINGS_REMOTE_NOTIFICATION = "settingsRemoteNotification://",
})

Enums.TransmissionMode = LuaUtils.readOnly({
    NONE = 0,
    D = 68,
    L = 76,
    M = 77,
    N = 78,
    P = 80,
    R = 82,
    S = 83,
})

Enums.TurnSignal = LuaUtils.readOnly({
    OFF = 0,
    ON = 1,
})

Enums.UIEmphasizedEngineGauge = LuaUtils.readOnly({
    COMBUSTION_ENGINERPM = 0,
    ELECTRIC_ENGINE_POWER = 1,
})

Enums.UIInputDeviceButtonEvent = LuaUtils.readOnly({
    BUTTON_UP = 0,
    BUTTON_DOWN = 1,
})

Enums.UIInputDevicePurpose = LuaUtils.readOnly({
    SELECT = 0,
    BACK = 1,
})

Enums.UISceneOption = LuaUtils.readOnly({
    ALLOW_PAIRING_ANIMATION = "AllowPairingAnimation",
    SKIP_STARTUP_FADE_IN = "SkipStartupFadeIn",
})

Enums.UISceneState = LuaUtils.readOnly({
    NONE = 0,
    STARTUP = 1,
    DRIVE = 2,
    EXIT = 3,
    ACCESSORY_MODE = 4,
})

return LuaUtils.readOnly(Enums)