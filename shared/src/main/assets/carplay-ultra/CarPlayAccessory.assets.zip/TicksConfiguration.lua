






local APL = require "APL.APL"
local AngleConfiguration = require "AngleConfiguration"
local TickLabelsConfiguration = require "TickLabelsConfiguration"
local TicksTypeConfiguration = require "TicksTypeConfiguration"

local TicksConfiguration = APL.LuaUtils.namedObject(
    "TicksConfiguration",
    { "tickTypeConfigurations", "table" },
    { "tickLabelsConfiguration", "TickLabelsConfiguration" },
    { "style", "TicksConfiguration.Style" }
)
TicksConfiguration.TYPE = APL.LuaUtils.readOnly({
    PRIMARY = "primary",
    SECONDARY = "secondary",
    TERTIARY = "tertiary"
 })

TicksConfiguration.Style = APL.LuaUtils.namedObject(
    "TicksConfiguration.Style",
    { "angleConfiguration", "AngleConfiguration?" },
    { "linearConfiguration", "TicksConfiguration.LinearConfiguration?" }
 )

 TicksConfiguration.LinearConfiguration = APL.LuaUtils.namedObject(
    "TicksConfiguration.LinearConfiguration",
    { "isRTL", "boolean" }
)

function TicksConfiguration.Style.fromJson(json)




    return TicksConfiguration.Style.new(
        json.circular and AngleConfiguration.fromJson(json.circular.configuration),
        json.linear and TicksConfiguration.LinearConfiguration.fromJson(json.linear.configuration)
    )
end

function TicksConfiguration.LinearConfiguration.fromJson(json)

    return TicksConfiguration.LinearConfiguration.new(json.isRTL)
end

function TicksConfiguration.fromJson(json)


    return TicksConfiguration.new(
        APL.LuaUtils.map(json.tickTypeConfigurations, TicksTypeConfiguration.fromJson),
        TickLabelsConfiguration.fromJson(json.tickLabelsConfiguration),
        TicksConfiguration.Style.fromJson(json.style)
    )
end

return APL.LuaUtils.readOnly(TicksConfiguration)