-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local CP = CP or require "CPMock" -- Mock CP bridge for exporting ASCPaths using Luau since Globals are locked per scripts
local DynamicContentState = require "DynamicContentState"
local Enums = require "Enums"
local LuaUtils = require "APL.LuaUtils"
local Log = require "APL.Log"
local LocalNotificationState = require "LocalNotificationState"
local RequestContentState = require "RequestContentState"
local Thread = require "APL.Thread"
local TransmissionState = require "TransmissionState"
local UISceneState = require "UISceneState"
local Units = require "Units"





local BaseConfig = LuaUtils.namedObject(
    "BaseConfig",
    { "iid", "number" },
    { "format", "number?" },
    { "initialValue", "*?" },
    { "minimumValue", "*?" },
    { "maximumValue", "*?" },
    { "stepValue", "*?" },
    { "units", "*?" },
    { "validValues", "table?" },
    { "supportsInvalid", "boolean" },
    { "supportsError", "boolean" }
)
BaseConfig.from = function(config)
    return BaseConfig.new(
        config.iid,
        config.format,
        config.initialValue,
        config.minimumValue,
        config.maximumValue,
        config.stepValue,
        config.units,
        config.validValues,
        config.supportsInvalid or false,
        config.supportsError or false
    )
end
BaseConfig = LuaUtils.readOnly(BaseConfig)





local DataUpdater = LuaUtils.namedObject(
    "DataUpdater",
    { "iids", "table" },             -- A list of iids this dataIdentifier requires to subscribe to.
    { "handleUpdate", "function" },  -- A function called with a table of values by iids to optionally transform if necessary.
    { "processWrite", "function?" }  -- An optional function to handle converting data into a table of iid (number) to value (any).
)
DataUpdater = LuaUtils.readOnly(DataUpdater)





local VehicleDataUpdater = LuaUtils.makeObject({ _type = "VehicleDataUpdater" })


VehicleDataUpdater.INVALID = CP.INVALIDVALUE


local dataIdentifiers = {}


local optionalASCPaths = {
    ["uiControl.uiState.uiSceneOptions"] = true
}


VehicleDataUpdater.TRIP_TYPE = LuaUtils.readOnly({
    FROM_RESET = "__TRIP_FROM_RESET__",
    FROM_START = "__TRIP_FROM_START__",
    FROM_REFUEL = "__TRIP_FROM_REFUEL__",
})







function VehicleDataUpdater.new(vehicleConfig)


    local self = LuaUtils.newObject(VehicleDataUpdater, {

        _paths = {},


        _pathsByDataIdentifier = {},


        _updaters = {},


        _subscribersByDataIdentifier = {}, -- table of subscribers list { f=function, args=... } by dataIdentifier
        _dataIdentifiersBySubscriber = {}, -- table of dataIdentifier strings list by subscriber { f=function, args=... }


        _updateHandlersByIid = {}, -- table of update handlers list { f=function, args=... } by iid
        _iidsByUpdateHandler = {}, -- table of iids list by update handler { f=function, args=... }

        _updateThread = LuaUtils.NIL,
        _onUpdateCompleteSubscribers = {}, -- table of { f=function, args=... }

        _cache = {},   -- last known changes by dataIdentifier
        _updates = {}, -- incremental changes by dataIdentifier since previous update

        _configCache = {} -- vehicle config parsing cache
    })


    local mergePaths = function(paths)
        LuaUtils.forEach(paths or {}, function(path)
            self._paths[path] = true
        end)
    end


    local builder = function(dataIdentifier, f, ...)
        Log.info(VehicleDataUpdater, function() return "Making updater for " .. dataIdentifier end)


        local updater, paths, initialValue = f(self, vehicleConfig, ...)



        self._pathsByDataIdentifier[dataIdentifier] = paths
        mergePaths(paths)


        if initialValue ~= nil then
            Log.info(VehicleDataUpdater, function() return "Storing initial value for " .. dataIdentifier .. ": " .. LuaUtils.prettyPrint(initialValue) end)

            self._updates[dataIdentifier] = initialValue
            self._cache[dataIdentifier] = initialValue
        end


        if not updater then
            Log.debug(VehicleDataUpdater, function() return "Builder returned no updater function" end)
            return
        end


        local handleUpdate = function(update)
            local result = updater.handleUpdate(update)
            if result ~= nil then
                Log.debug(VehicleDataUpdater, function() return "Received update for " .. dataIdentifier .. ": " .. LuaUtils.prettyPrint(result) end)
            else
                Log.error(VehicleDataUpdater, function() return "Invalid update for " .. dataIdentifier .. ": " .. LuaUtils.prettyPrint(update) end)
            end

            self._updates[dataIdentifier] = result
            self._cache[dataIdentifier] = result
        end


        self._updaters[dataIdentifier] = updater


        if #updater.iids > 0 then
            self:_registerUpdateHandler(updater.iids, dataIdentifier, handleUpdate)
        end
    end


    LuaUtils.forEach(VehicleDataUpdater.DATAIDENTIFIERS, function(dataIdentifier)
        builder(
            dataIdentifier,
            dataIdentifiers[dataIdentifier].f,
            table.unpack(dataIdentifiers[dataIdentifier].args or {})
        )
    end)


    self._configCache = nil


    self:_fetch(true)

    return self
end






function VehicleDataUpdater:destroy()


    if self._updateThread then
        self._updateThread:destroy()
        self._updateThread = nil
    end

    self._updateHandlersByIid = nil
    self._iidsByUpdateHandler = nil
    self._subscribersByDataIdentifier = nil
    self._dataIdentifiersBySubscriber = nil

    self._updaters = nil
end







function VehicleDataUpdater:isSubscribable(...)


    local invalidDataIdentifiers = {}
    for _, dataIdentifier in {...} do


        if not self._updaters[dataIdentifier] then
            table.insert(invalidDataIdentifiers, dataIdentifier)
        end
    end

    return #invalidDataIdentifiers == 0, #invalidDataIdentifiers > 0 and invalidDataIdentifiers or nil
end





















function VehicleDataUpdater:subscribe(dataIdentifiers, f, ...)





    Log.debug(VehicleDataUpdater, function() return "Subscription request for: " .. LuaUtils.prettyPrint(dataIdentifiers) end)

    local subscriber = {
        f = f
    }
    self._dataIdentifiersBySubscriber[subscriber] = dataIdentifiers

    local validDataIdentifiers = {}
    for _, dataIdentifier in ipairs(dataIdentifiers) do
        if not VehicleDataUpdater.DATAIDENTIFIERS[dataIdentifier] then
            Log.error(VehicleDataUpdater, function() return "Unknown dataIdentifier: '" .. dataIdentifier .. "'" end)
        elseif not self._updaters[dataIdentifier] then
            Log.warn(VehicleDataUpdater, function() return "No updater found for dataIdentifier: '" .. dataIdentifier .. "'" end)
        else
            local subscribers = self._subscribersByDataIdentifier[dataIdentifier] or {}
            subscribers[#subscribers+1] = subscriber
            self._subscribersByDataIdentifier[dataIdentifier] = subscribers

            validDataIdentifiers[#validDataIdentifiers+1] = dataIdentifier
        end
    end


    if self._updateThread then

        local data = {}
        for _, dataIdentifier in ipairs(validDataIdentifiers) do
            data[dataIdentifier] = self._cache[dataIdentifier]
        end


        if not LuaUtils.isEmpty(data) then
            self:_notifySubscriber(subscriber, data, {})
        end
    end

    return validDataIdentifiers, subscriber
end










function VehicleDataUpdater:unsubscribe(subscriber)



    local dataIdentifiers = self._dataIdentifiersBySubscriber[subscriber]
    self._dataIdentifiersBySubscriber[subscriber] = nil


    LuaUtils.forEach(dataIdentifiers, function(dataIdentifier)
        if self._subscribersByDataIdentifier[dataIdentifier] then
            self._subscribersByDataIdentifier[dataIdentifier] = LuaUtils.removeByValue(self._subscribersByDataIdentifier[dataIdentifier], subscriber)
            if #self._subscribersByDataIdentifier[dataIdentifier] == 0 then
                self._subscribersByDataIdentifier[dataIdentifier] = nil
            end
        end
    end)

    return self
end






function VehicleDataUpdater:unsubscribeAll()


    self._subscribersByDataIdentifier = {}
    self._dataIdentifiersBySubscriber = {}

    return self
end






function VehicleDataUpdater:start()


    Log.info(VehicleDataUpdater, function() return "Starting (started = %s)", tostring(self._updateThread ~= nil) end)

    if self._updateThread then
        return self
    end


    local iids = LuaUtils.getKeys(self._updateHandlersByIid)
    Log.info(VehicleDataUpdater, function() return "Subscribing to IIDs: " .. LuaUtils.prettyPrint(iids) end)
    if #iids > 0 then
        CP.registerVehicleDataTypes(iids)
    end



    self:_fetch(false, true)


    self._updateThread = Thread.new(function()
        Log.info(VehicleDataUpdater, function() return "Starting update thread" end)

        while true do

            self:_fetch(false, false)

            Thread.yield()
        end
    end)
    :setTag("vehicle_data")
    :start()

    return self
end







function VehicleDataUpdater:stop(unsubscribeAll)



    local unsubscribeAll = unsubscribeAll == nil or unsubscribeAll

    Log.info(VehicleDataUpdater, function() return "Stopping (unsubscribeAll = " .. tostring(unsubscribeAll).. ")" end)

    if self._updateThread then
        self._updateThread:stop()
        self._updateThread:destroy()
        self._updateThread = nil
    end

    if unsubscribeAll then
        self:unsubscribeAll()
    end

    self._updates = {}

    return self
end








function VehicleDataUpdater:_fetch(fetchAll, notifyAll)




    local iids = fetchAll == true and LuaUtils.getKeys(self._updateHandlersByIid) or nil


    local data = iids and CP.getVehicleData(iids) or CP.getVehicleDataUpdates()


    if not LuaUtils.isEmpty(data) or notifyAll then
        self:_processData(data)

        if notifyAll ~= nil then
            self:_notifySubscribers(notifyAll)
        end


        LuaUtils.forEach(self._onUpdateCompleteSubscribers, function(handler)
            handler.f(table.unpack(handler.args))
        end)
    end

    return self
end








function VehicleDataUpdater:registerOnUpdateComplete(f, ...)



    self._onUpdateCompleteSubscribers[#self._onUpdateCompleteSubscribers+1] = {
        f = f,
        args = {...}
    }

    return self
end







function VehicleDataUpdater:getData(dataIdentifiers)



    local result = {}
    LuaUtils.forEach(dataIdentifiers, function(dataIdentifier)

        result[dataIdentifier] = self._cache[dataIdentifier]
    end)

    return result
end







function VehicleDataUpdater:setData(dataIdentifierToValue)



    local iidToValue = {}

    for dataIdentifier, value in pairs(dataIdentifierToValue) do
        local updater = self._updaters[dataIdentifier]
        if updater then


            for iid, value in pairs(updater.processWrite(value)) do
                iidToValue[iid] = value
            end
        else
            Log.warn(VehicleDataUpdater, function() return "No updater found for dataIdentifier: '" .. dataIdentifier .. "'" end)
        end
    end

    local writtenData = CP.setVehicleData(iidToValue)
    local ret = #iidToValue == #writtenData

    if not ret then
        Log.error(VehicleDataUpdater, function() return "VehicleDataUpdater.setData: expected to write " .. LuaUtils.prettyPrint(iidToValue) .. " but only successfully wrote " .. LuaUtils.prettyPrint(writtenData) end)
    end

    return ret
end






function VehicleDataUpdater:getPaths()


    local paths = LuaUtils.getKeys(self._paths)
    table.sort(paths)

    return paths, LuaUtils.map(self._pathsByDataIdentifier, function(paths)
    table.sort(paths)
        return paths
    end)
end







function VehicleDataUpdater:_processData(data)



    Log.debug(VehicleDataUpdater, function() return "Handling update: " .. LuaUtils.prettyPrint(data) end)


    local updatesByUpdateHandler = {}
    for iid, value in pairs(data) do
        local updateHandlers = self._updateHandlersByIid[iid] or {}
        for _, updateHandler in ipairs(updateHandlers) do
            local update = updatesByUpdateHandler[updateHandler] or {}
            update[iid] = value
            updatesByUpdateHandler[updateHandler] = update
        end
    end


    for updateHandler, updates in pairs(updatesByUpdateHandler) do
        updateHandler.f(updates, table.unpack(updateHandler.args))
    end

    return self
end







function VehicleDataUpdater:_notifySubscribers(notifyAll)



    local data = notifyAll and self._cache or self._updates


    local updatesBySubscriber = {}
    for dataIdentifier, data in pairs(data) do
        local subscribers = self._subscribersByDataIdentifier[dataIdentifier] or {}
        for _, subscriber in ipairs(subscribers) do
            local update = updatesBySubscriber[subscriber] or {}
            update[dataIdentifier] = data
            updatesBySubscriber[subscriber] = update
        end
    end


    for subscriber, updates in pairs(updatesBySubscriber) do

        if self._dataIdentifiersBySubscriber[subscriber] then


            local cache = {}
            for _, dataIdentifier in ipairs(self._dataIdentifiersBySubscriber[subscriber]) do
                if updates[dataIdentifier] == nil then
                    cache[dataIdentifier] = self._cache[dataIdentifier]
                end
            end

            self:_notifySubscriber(subscriber, updates, cache)
        end
    end


    self._updates = {}

    return self
end









function VehicleDataUpdater:_notifySubscriber(subscriber, update, previous)





    Log.debug(VehicleDataUpdater, function() return "Notifying subscriber: " .. LuaUtils.prettyPrint(update) end)

    subscriber.f(update, previous)

    return self
end














function VehicleDataUpdater._queryPath(vehicleConfig, path, cache)




    local config = cache and cache[path] or LuaUtils.query(vehicleConfig, path)
    if not config then
        Log.error(VehicleDataUpdater, function() return "Unknown path: " .. path end)
        return nil
    end

    if cache then
        cache[path] = config
    end

    local parts = LuaUtils.splitString(path, ".")


    local result = {}


    if #parts == 1 then
        for service, characteristics in pairs(config) do
            if cache then
                cache[path .. "." .. service] = characteristics
            end

            for characteric, baseConfig in pairs(characteristics) do
                local ascPath = path .. "." .. service .. "." .. characteric
                result[ascPath] = BaseConfig.from(baseConfig)

                if cache then
                    cache[ascPath] = result[ascPath]
                end
            end
        end

    elseif #parts == 2 then
        for characteric, baseConfig in pairs(config) do
            local ascPath = path .. "." .. characteric
            result[ascPath] = BaseConfig.from(baseConfig)

            if cache then
                cache[ascPath] = result[ascPath]
            end
        end

    else
        result[path] = BaseConfig.from(config)

        if cache then
            cache[path] = result[path]
        end
    end

    return result
end









function VehicleDataUpdater._queryPaths(vehicleConfig, paths, cache)




    local configs = {}
    local cache = cache or {}
    local missingPaths = nil
    for name, path in pairs(paths) do
        local result = VehicleDataUpdater._queryPath(vehicleConfig, path, cache)
        if not result and not optionalASCPaths[path] then
            missingPaths = missingPaths or {}
            missingPaths[#missingPaths+1] = path
        end

        configs[name] = result ~= nil and result[path] or nil
    end

    if missingPaths then
        Log.error(VehicleDataUpdater, function() return "Missing required ASC paths: " .. LuaUtils.joinStrings(missingPaths, ", ") end)
        return nil
    end

    return configs
end







function VehicleDataUpdater:_makeDisplayedSpeedUpdater(vehicleConfig)


    local paths = {
        displayedSpeed         = "vehicleMotion.displayedSpeed.speed",
        displayedSpeedMPH      = "vehicleMotion.displayedSpeed.speedMPH",
        displayedSpeedKMH      = "vehicleMotion.displayedSpeed.speedKMH",
    }

    local configs = VehicleDataUpdater._queryPaths(vehicleConfig, paths, self._configCache)
    if not configs then
        return nil, LuaUtils.getUniqueValues(paths)
    end


    local iids = LuaUtils.getUniqueValues(
        LuaUtils.map(configs, function(config)

            return config.iid
        end)
    )

    return
        DataUpdater.new(
            iids,
            function(update)
                local values = {}
                for k, config in pairs(configs) do
                    values[config.units] = update[config.iid]

                    if values[config.units] == VehicleDataUpdater.INVALID then
                        Log.warn(VehicleDataUpdater, function() return "VehicleDataUpdater._makeDisplayedSpeedUpdater: " .. tostring(paths[k]) .. " is invalid" end)
                        return VehicleDataUpdater.INVALID
                    end
                end


                return values
            end
        ),
        LuaUtils.getUniqueValues(paths)
end








function VehicleDataUpdater:_makeTargetSpeedUpdater(vehicleConfig, path)



    local paths = {
        speedMPH = path .. ".speedMPH",
        speedKMH = path .. ".speedKMH",
    }

    local configs = VehicleDataUpdater._queryPaths(vehicleConfig, paths, self._configCache)
    if not configs then
        return nil, LuaUtils.getUniqueValues(paths)
    end


    local iids = LuaUtils.getUniqueValues(
        LuaUtils.map(configs, function(config)

            return config.iid
        end)
    )

    return
        DataUpdater.new(
            iids,
            function(update)
                local values = {}
                for k, config in pairs(configs) do
                    values[config.units] = update[config.iid]

                    if values[config.units] == VehicleDataUpdater.INVALID then
                        Log.warn(VehicleDataUpdater, function() return "VehicleDataUpdater._makeTargetSpeedUpdater: " .. tostring(paths[k]) .. " is invalid" end)
                        return VehicleDataUpdater.INVALID
                    end
                end


                return values
            end
        ),
        LuaUtils.getUniqueValues(paths)
end







function VehicleDataUpdater:_makeVehicleSpeedMaxUpdater(vehicleConfig)


    local paths = {
        displayedSpeedMaxKMH   = "vehicleMotion.displayedSpeed.speedMaxKMH",
        displayedSpeedMaxMPH   = "vehicleMotion.displayedSpeed.speedMaxMPH",
    }

    local configs = VehicleDataUpdater._queryPaths(vehicleConfig, paths, self._configCache)
    if not configs then
        return nil, LuaUtils.getUniqueValues(paths)
    end

    local iids = LuaUtils.getUniqueValues(
        LuaUtils.map(configs, function(config)

            return config.iid
        end)
    )

    local initialValues = {}
    for _, config in pairs(configs) do
        initialValues[config.iid] = config.initialValue
    end


    return
        DataUpdater.new(
            iids,
            function(update)
                local values = {}
                for k, config in pairs(configs) do
                    values[config.units] = update[config.iid]

                    if values[config.units] == VehicleDataUpdater.INVALID then
                        Log.warn(VehicleDataUpdater, function() return "VehicleDataUpdater._makeVehicleSpeedMaxUpdater: " .. tostring(paths[k]) .. " is invalid" end)
                        return VehicleDataUpdater.INVALID
                    end
                end


                return values
            end
        ),
        LuaUtils.getUniqueValues(paths),
        initialValues
end







function VehicleDataUpdater:_makeTransmissionUpdater(vehicleConfig)


    local paths = {
        transmissionMode = "driveState.transmissionStatus.transmissionMode",
        gearPosition     = "driveState.transmissionStatus.gearPosition"
    }

    local configs = VehicleDataUpdater._queryPaths(vehicleConfig, paths, self._configCache)
    if not configs then
        return nil, LuaUtils.getUniqueValues(paths)
    end

    local iids = LuaUtils.getUniqueValues(
        LuaUtils.map(configs, function(config)
            return config.iid
        end)
    )

    return
        DataUpdater.new(
            iids,
            function(update)
                local transmissionMode = update[configs.transmissionMode.iid]
                local gearPosition = update[configs.gearPosition.iid]





                if transmissionMode == VehicleDataUpdater.INVALID then
                    transmissionMode = nil
                end

                if gearPosition == VehicleDataUpdater.INVALID then
                    gearPosition = nil
                end

                return TransmissionState.new(transmissionMode, gearPosition)
            end
        ),
        LuaUtils.getUniqueValues(paths)
end







function VehicleDataUpdater:_makeUISceneStateUpdater(vehicleConfig)


    local paths = {
        uiSceneState    = "uiControl.uiState.uiSceneState",
        uiSceneOptions  = "uiControl.uiState.uiSceneOptions"
    }

    local configs = VehicleDataUpdater._queryPaths(vehicleConfig, paths, self._configCache)
    if not configs then
        return nil, LuaUtils.getUniqueValues(paths)
    end

    local iids = LuaUtils.getUniqueValues(
        LuaUtils.map(configs, function(config)
            return config.iid
        end)
    )

    return
        DataUpdater.new(
            iids,
            function(update)
                local uiSceneState = update[configs.uiSceneState.iid]
                local uiSceneOptions = configs.uiSceneOptions and update[configs.uiSceneOptions.iid]

                if uiSceneState == VehicleDataUpdater.INVALID then
                    uiSceneState = Enums.UISceneState.NONE
                end

                if uiSceneOptions == VehicleDataUpdater.INVALID then
                    uiSceneOptions = nil
                end

                return UISceneState.new(uiSceneState, uiSceneOptions)
            end
        ),
        LuaUtils.getUniqueValues(paths)
end







function VehicleDataUpdater:_makeDriveModeUpdater(vehicleConfig)


    local paths = {
        currentIndex = "driveState.driveMode.currentIndex",
        identifiers  = "driveState.driveMode.identifiers"   -- immutable
    }


    local configs = VehicleDataUpdater._queryPaths(vehicleConfig, paths, self._configCache)
    if not configs then
        return nil, LuaUtils.getUniqueValues(paths)
    end

    local iids = LuaUtils.getUniqueValues(
        LuaUtils.map(configs, function(config)
            return config.iid
        end)
    )


    local identifiers = configs.identifiers.initialValue or {}
    local initialIndex = configs.currentIndex.initialValue

    local initialValue = type(initialIndex) == "number" and identifiers[initialIndex+1] or initialIndex

    return
        DataUpdater.new(
            iids,
            function(update)
                local index = update[configs.currentIndex.iid]
                if index == VehicleDataUpdater.INVALID then
                    return index
                end

                local identifier = index and identifiers[index+1]
                if identifier ~= nil then
                    return identifier
                end

                Log.error(VehicleDataUpdater, function() return "VehicleDataUpdater._makeDrivingModeUpdater: bad index" end)

            end
        ),
        LuaUtils.getUniqueValues(paths),
        initialValue
end







function VehicleDataUpdater:_makeFuelEfficiencyUpdater(vehicleConfig)


    local paths = {
        fuelEfficiency    = "tripComputer.trip.fuelEfficiency",
        userVisibleLabel  = "tripComputer.trip.userVisibleLabel"
    }

    local path = "tripComputer.trip.*/userVisibleLabel.fuelEfficiency"
    local trips = VehicleDataUpdater._extract(vehicleConfig, path) -- userVisibleLabel: fuelEfficiency
    if not trips then
        Log.error(VehicleDataUpdater, function() return "Unknown ASC path: " .. path end)
        return nil, LuaUtils.getUniqueValues(paths)
    end

    Log.debug(VehicleDataUpdater, function() return "Found config for trips: " .. LuaUtils.prettyPrint(trips, true, 3) end)


    local iidsToSubscribe = {}
    local lastValues = {} -- userVisibleLabel (string): fuelEfficiency(number)
    local fuelEfficiencyIIDbyUserVisibleIID = {} -- userVisibleLabel.iid: fuelEfficiency.iid
    local userVisibleLabelByIID = {} -- userVisibleLabel.iid: String?
    for userVisibleLabelInfo, fuelEfficiencyInfo in pairs(trips) do
        iidsToSubscribe[#iidsToSubscribe+1] = userVisibleLabelInfo.iid
        iidsToSubscribe[#iidsToSubscribe+1] = fuelEfficiencyInfo.iid
        fuelEfficiencyIIDbyUserVisibleIID[userVisibleLabelInfo.iid] = fuelEfficiencyInfo.iid
    end




    local fuelEfficiencyByIID = {}

    return
        DataUpdater.new(
            iidsToSubscribe,
            function(update)

                for userVisibleLabelIID, fuelEfficiencyIID in pairs(fuelEfficiencyIIDbyUserVisibleIID) do
                    local previousUserVisibleLabel = userVisibleLabelByIID[userVisibleLabelIID]
                    userVisibleLabelByIID[userVisibleLabelIID] = userVisibleLabelByIID[userVisibleLabelIID] or update[userVisibleLabelIID]
                    local userVisibleLabel = userVisibleLabelByIID[userVisibleLabelIID]
                    local fuelEfficiency = update[fuelEfficiencyIID]
                    if userVisibleLabel and (previousUserVisibleLabel ~= userVisibleLabel or fuelEfficiency) then
                        lastValues[userVisibleLabel] = fuelEfficiency or fuelEfficiencyByIID[fuelEfficiencyIID]
                    end

                    fuelEfficiencyByIID[fuelEfficiencyIID] = update[fuelEfficiencyIID] or fuelEfficiencyByIID[fuelEfficiencyByIID]
                end

                return LuaUtils.duplicate(lastValues)
            end
        ),
        LuaUtils.getUniqueValues(paths),
        lastValues
end








function VehicleDataUpdater:_makeDistanceUpdater(vehicleConfig, servicePath)



    local paths = {
        distanceKM    = servicePath .. ".distanceKM",
        distanceMiles = servicePath .. ".distanceMiles"
    }

    local configs = VehicleDataUpdater._queryPaths(vehicleConfig, paths, self._configCache)
    if not configs then
        return nil, LuaUtils.getUniqueValues(paths)
    end

    local iids = LuaUtils.getUniqueValues(
        LuaUtils.map(configs, function(config)

            return config.iid
        end)
    )

    local initialValues = {}
    for _, config in pairs(configs) do
        initialValues[config.units] = config.initialValue
    end

    return
        DataUpdater.new(
            iids,
            function(update)
                local values = {}
                for k, config in pairs(configs) do
                    values[config.units] = update[config.iid]

                    if values[config.units] == VehicleDataUpdater.INVALID then
                        Log.warn(VehicleDataUpdater, function() return "VehicleDataUpdater._makeDistanceUpdater: " .. tostring(paths[k]) .. " is invalid" end)
                        return VehicleDataUpdater.INVALID
                    end
                end


                return values
            end
        ),
        LuaUtils.getUniqueValues(paths),
        initialValues
end







function VehicleDataUpdater:_makeCriticalStreamUpdater(vehicleConfig)


    local paths = {
        "automakerInputStreams.criticalInputStream.inputStreamUID",
        "automakerInputStreams.criticalInputStream.on"
    }


    local path = "automakerInputStreams.criticalInputStream.*/inputStreamUID.on"
    local streams = VehicleDataUpdater._extract(vehicleConfig, path)
    if not streams then
        Log.error(VehicleDataUpdater, function() return "Unknown ASC path: " .. path end)
        return nil, LuaUtils.getUniqueValues(paths)
    end

    Log.debug(VehicleDataUpdater, function() return "Found config for streams: " .. LuaUtils.prettyPrint(streams) end)

    local lastValues = {} -- table of last state (boolean) by stream identifier
    local streamIdentifierByIID = {}
    for k, v in pairs(streams) do
        streamIdentifierByIID[v.iid] = k.initialValue
        lastValues[k.initialValue] = v.initialValue
    end

    return
        DataUpdater.new(
            LuaUtils.getKeys(streamIdentifierByIID),
            function(update)

                for iid, streamIdentifier in pairs(streamIdentifierByIID) do
                    if update[iid] ~= nil then
                        lastValues[streamIdentifier] = update[iid]
                    end
                end


                return LuaUtils.duplicate(lastValues)
            end
        ),
        LuaUtils.getUniqueValues(paths),
        lastValues
end









function VehicleDataUpdater:_makeSingleValueUpdater(vehicleConfig, path, default)



    local config = LuaUtils.query(vehicleConfig, path)
    if not config then
        Log.error(VehicleDataUpdater, function() return "Unknown ASC path: " .. path end)
        return nil, { path }, default
    end

    config = BaseConfig.from(config)
    local initialValue = config.initialValue
    if initialValue == nil then
        initialValue = default
    end

    return
        DataUpdater.new(
            { config.iid },
            function(update)
                return update[config.iid]
            end
        ),
        { path },
        initialValue
end








function VehicleDataUpdater:_makeSingleValueWriteOnlyUpdater(vehicleConfig, path)



    local config = LuaUtils.query(vehicleConfig, path)
    if not config then
        Log.error(VehicleDataUpdater, function() return "Unknown ASC path: " .. path end)
        return nil, { path }
    end

    config = BaseConfig.from(config)

    return
        DataUpdater.new(
            { config.iid },
            function() end, -- noop
            function(dataToWrite)
                return { [config.iid] = dataToWrite }
            end
        ),
        { path }
end








function VehicleDataUpdater:_makeNormalizedSingleValueUpdater(vehicleConfig, path)



    local config = LuaUtils.query(vehicleConfig, path)
    if not config then
        Log.error(VehicleDataUpdater, function() return "Unknown ASC path: " .. path end)
        return nil, { path }
    end

    config = BaseConfig.from(config)

    local initialValue = config.initialValue
    local minValue = config.minimumValue
    local maxValue = config.maximumValue

    local clamped = function(value)
        value = math.min(maxValue, math.max(value, minValue))
        return math.abs((value - minValue) / (maxValue - minValue))
    end





    return
        DataUpdater.new(
            { config.iid },
            function(update)
                local value = update[config.iid]

                if value == VehicleDataUpdater.INVALID then
                    return value
                elseif value then
                    return clamped(value)
                end

                return
            end
        ),
        { path },
        initialValue and clamped(initialValue)
end







function VehicleDataUpdater:_makeLocalNotificationUpdater(vehicleConfig)


    local paths = {
        identifier              = "automakerNotifications.localNotification.identifier",
        displayPanelIdentifier  = "automakerNotifications.localNotification.displayPanelIdentifier", -- immutable
        displayZoneIdentifier   = "automakerNotifications.localNotification.displayZoneIdentifier"   -- immutable
    }

    local path = "automakerNotifications.localNotification.*"
    local localNotification = VehicleDataUpdater._extract(vehicleConfig, path)
    if not localNotification then
        Log.error(VehicleDataUpdater, function() return "Unknown ASC path: " .. path end)
        return nil, LuaUtils.getUniqueValues(paths)
    end

    local lastValues = {}

    local updateLastValues = function(identifier, displayZoneIdentifier, displayPanelIdentifier)




        local notifications = lastValues[displayPanelIdentifier] or {}

        notifications[displayZoneIdentifier] = LocalNotificationState.new(identifier, false, false, displayZoneIdentifier)
        lastValues[displayPanelIdentifier] = notifications
    end

    local updatersByIids = {}
    local iids = {}
    for _, v in pairs(localNotification) do
        updatersByIids[v.identifier.iid] = function(identifier)
            updateLastValues(
                identifier,
                v.displayZoneIdentifier.initialValue,
                v.displayPanelIdentifier.initialValue
            )
        end

        iids[#iids+1] = v.identifier.iid
        local initialValue = v.identifier.initialValue
        if initialValue then
            updatersByIids[v.identifier.iid](initialValue)
        end
    end

    return
        DataUpdater.new(
            iids,
            function(update)
                for iid, updater in pairs(updatersByIids) do
                    local identifier = update[iid]
                    if identifier then
                        updater(identifier)
                    end
                end

                return LuaUtils.duplicate(lastValues)
            end
        ),
        LuaUtils.getUniqueValues(paths),
        lastValues
end







function VehicleDataUpdater:_makeDynamicLocalNotificationUpdater(vehicleConfig)


    local paths = {
        identifier              = "automakerNotifications.dynamicLocalNotification.identifier",
        userVisibleLabel        = "automakerNotifications.dynamicLocalNotification.userVisibleLabel",
        userVisibleDescription  = "automakerNotifications.dynamicLocalNotification.userVisibleDescription",
        userDismissible         = "automakerNotifications.dynamicLocalNotification.userDismissible",
        symbolNameAndColor      = "automakerNotifications.dynamicLocalNotification.symbolNameAndColor",
        displayPanelIdentifier  = "automakerNotifications.dynamicLocalNotification.displayPanelIdentifier", -- immutable
        displayZoneIdentifier   = "automakerNotifications.dynamicLocalNotification.displayZoneIdentifier"   -- immutable
    }

    local path = "automakerNotifications.dynamicLocalNotification.*"
    local localNotification = VehicleDataUpdater._extract(vehicleConfig, path)
    if not localNotification then
        Log.error(VehicleDataUpdater, function() return "Unknown ASC path: " .. path end)
        return nil, LuaUtils.getUniqueValues(paths)
    end

    local lastValues = {}

    local updateLastValues = function(identifier, displayZoneIdentifier, displayPanelIdentifier, userDismissible, textContent)






        local notifications = lastValues[displayPanelIdentifier] or {}

        notifications[displayZoneIdentifier] = LocalNotificationState.new(identifier, userDismissible, false, displayZoneIdentifier, textContent)
        lastValues[displayPanelIdentifier] = notifications
    end

    local updatersByService = {}
    local iids = {}
    for _, v in pairs(localNotification) do
        updatersByService[v] = function(identifier, userDismissible, label, description, symbolNameAndColor)
            updateLastValues(
                identifier,
                v.displayZoneIdentifier.initialValue,
                v.displayPanelIdentifier.initialValue,
                userDismissible,
                LocalNotificationState.TextContent.new(
                    label,
                    description,
                    LocalNotificationState.SymbolNameAndColor.new(
                        symbolNameAndColor["name"],
                        symbolNameAndColor["color"]
                    )
                )
            )
        end

        iids[#iids+1] = v.identifier.iid
        iids[#iids+1] = v.userVisibleLabel.iid
        iids[#iids+1] = v.userVisibleDescription.iid
        iids[#iids+1] = v.userDismissible.iid
        iids[#iids+1] = v.symbolNameAndColor.iid

        local identifier = v.identifier.initialValue
        local userVisibleLabel = v.userVisibleLabel.initialValue
        local userVisibleDescription = v.userVisibleDescription.initialValue
        local userDismissible = v.userDismissible.initialValue
        local symbolNameAndColor = v.symbolNameAndColor.initialValue
        if identifier and userVisibleLabel and userVisibleDescription and userDismissible ~= nil then
            updatersByService[v](identifier, userDismissible, userVisibleLabel, userVisibleDescription, symbolNameAndColor)
        end
    end

    return
        DataUpdater.new(
            iids,
            function(update)
                for v, updater in pairs(updatersByService) do
                    local identifier = update[v.identifier.iid]
                    local userVisibleLabel = update[v.userVisibleLabel.iid]
                    local userVisibleDescription = update[v.userVisibleDescription.iid]
                    local userDismissible = update[v.userDismissible.iid]
                    local symbolNameAndColor = update[v.symbolNameAndColor.iid]
                    if identifier and userVisibleLabel and userVisibleDescription and userDismissible ~= nil and symbolNameAndColor and symbolNameAndColor["name"] and symbolNameAndColor["color"] then
                        updater(identifier, userDismissible, userVisibleLabel, userVisibleDescription, symbolNameAndColor)
                    else

                    end
                end

                return LuaUtils.duplicate(lastValues)
            end
        ),
        LuaUtils.getUniqueValues(paths),
        lastValues
end







function VehicleDataUpdater:_makeRequestContentUpdater(vehicleConfig, dataIdentifier)


    local paths = {
        contentURL                  = "automakerRequestContent.requestContent.contentURL",
        on                          = "automakerRequestContent.requestContent.on",
        userDismissible             = "automakerRequestContent.requestContent.userDismissible",
        displayPanelIdentifier      = "automakerRequestContent.requestContent.displayPanelIdentifier",  -- immutable
        displayZoneIdentifier       = "automakerRequestContent.requestContent.displayZoneIdentifier"    -- immutable
    }

    local path = "automakerRequestContent.requestContent.*"
    local requestContent = VehicleDataUpdater._extract(vehicleConfig, path)
    if not requestContent then
        Log.error(VehicleDataUpdater, function() return "Unknown ASC path: " .. path end)
        return nil, LuaUtils.getUniqueValues(paths)
    end

    local lastValues = {}

    local updateLastValues = function(contentURL, on, userDismissible, displayZoneIdentifier, displayPanelIdentifier)
        local requestContentStates = lastValues[displayPanelIdentifier] or {}

        requestContentStates[displayZoneIdentifier] = RequestContentState.new(contentURL, on, userDismissible, displayZoneIdentifier)
        lastValues[displayPanelIdentifier] = requestContentStates
    end

    local updaterByRequestContent = {}
    local requestContentByZoneID = {}
    local iids = {}
    for _, v in pairs(requestContent) do



        requestContentByZoneID[v.displayZoneIdentifier.initialValue] = v
        updaterByRequestContent[v] = function(contentURL, on, userDismissible)
            updateLastValues(
                contentURL, on, userDismissible,
                v.displayZoneIdentifier.initialValue,
                v.displayPanelIdentifier.initialValue
            )
        end

        iids[#iids+1] = v.contentURL.iid
        iids[#iids+1] = v.on.iid
        iids[#iids+1] = v.userDismissible.iid

        if v.contentURL.initialValue and v.on.initialValue and v.userDismissible.initialValue then
            updaterByRequestContent[v](
                v.contentURL.initialValue,
                v.on.initialValue,
                v.userDismissible.initialValue
            )
        end
    end

    return
        DataUpdater.new(
            iids,
            function(update)
                for requestContent, updater in pairs(updaterByRequestContent) do
                    local contentURL = update[requestContent.contentURL.iid]
                    local userDismissible = update[requestContent.userDismissible.iid]
                    local on = update[requestContent.on.iid]

                    if contentURL ~= nil and userDismissible ~= nil and on ~= nil then
                        updater(contentURL, on, userDismissible)
                    else

                    end
                end

                return LuaUtils.duplicate(lastValues)
            end,
            function(dataToWrite)


                local requestContent = requestContentByZoneID[dataToWrite.zoneRegion]
                return { [requestContent.on.iid] = dataToWrite.on }
            end
        ),
        LuaUtils.getUniqueValues(paths),
        lastValues
end







function VehicleDataUpdater:_makeRequestTemporaryContentUpdater(vehicleConfig, dataIdentifier)


    local paths = {
        contentURL                  = "automakerRequestContent.requestTemporaryContent.temporaryContentURL",
        on                          = "automakerRequestContent.requestTemporaryContent.on",
        displayPanelIdentifier      = "automakerRequestContent.requestTemporaryContent.displayPanelIdentifier",  -- immutable
        displayZoneIdentifier       = "automakerRequestContent.requestTemporaryContent.displayZoneIdentifier"    -- immutable
    }

    local path = "automakerRequestContent.requestTemporaryContent.*"
    local requestContent = VehicleDataUpdater._extract(vehicleConfig, path)
    if not requestContent then
        Log.error(VehicleDataUpdater, function() return "Unknown ASC path: " .. path end)
        return nil, LuaUtils.getUniqueValues(paths)
    end

    local lastValues = {}

    local updateLastValues = function(contentURL, on, displayZoneIdentifier, displayPanelIdentifier)
        local requestContentStates = lastValues[displayPanelIdentifier] or {}

        requestContentStates[displayZoneIdentifier] = RequestContentState.new(contentURL, on, false, displayZoneIdentifier)
        lastValues[displayPanelIdentifier] = requestContentStates
    end

    local updaterByRequestContent = {}
    local requestContentByZoneID = {}
    local iids = {}
    for _, v in pairs(requestContent) do



        requestContentByZoneID[v.displayZoneIdentifier.initialValue] = v
        updaterByRequestContent[v] = function(contentURL, on)
            updateLastValues(
                contentURL, on,
                v.displayZoneIdentifier.initialValue,
                v.displayPanelIdentifier.initialValue
            )
        end

        iids[#iids+1] = v.temporaryContentURL.iid
        iids[#iids+1] = v.on.iid

        if v.temporaryContentURL.initialValue and v.on.initialValue then
            updaterByRequestContent[v](
                v.temporaryContentURL.initialValue,
                v.on.initialValue
            )
        end
    end

    return
        DataUpdater.new(
            iids,
            function(update)
                for requestContent, updater in pairs(updaterByRequestContent) do
                    local contentURL = update[requestContent.temporaryContentURL.iid]
                    local on = update[requestContent.on.iid]

                    if contentURL ~= nil and on ~= nil then
                        updater(contentURL, on)
                    else

                    end
                end

                return LuaUtils.duplicate(lastValues)
            end,
            function(dataToWrite)


                local requestContent = requestContentByZoneID[dataToWrite.zoneRegion]
                return { [requestContent.on.iid] = dataToWrite.on }
            end
        ),
        LuaUtils.getUniqueValues(paths),
        lastValues
end







function VehicleDataUpdater:_makeDynamicContentElementUpdater(vehicleConfig, dataIdentifier)


    local paths = {
        contentURL                  = "automakerNotifications.dynamicContentElement.dynamicContentURL",
        userDismissible             = "automakerNotifications.dynamicContentElement.userDismissible",
        displayPanelIdentifier      = "automakerNotifications.dynamicContentElement.displayPanelIdentifier",  -- immutable
        displayZoneIdentifier       = "automakerNotifications.dynamicContentElement.displayZoneIdentifier"    -- immutable
    }

    local path = "automakerNotifications.dynamicContentElement.*"
    local dynamicContentElement = VehicleDataUpdater._extract(vehicleConfig, path)
    if not dynamicContentElement then
        Log.error(VehicleDataUpdater, function() return "Unknown ASC path: " .. path end)
        return nil, LuaUtils.getUniqueValues(paths)
    end

    local lastValues = {}

    local updateLastValues = function(contentURL, userDismissible, displayZoneIdentifier, displayPanelIdentifier)
        local dynamicContentStates = lastValues[displayPanelIdentifier] or {}
        dynamicContentStates[displayZoneIdentifier] = DynamicContentState.new(contentURL, userDismissible, displayZoneIdentifier, displayPanelIdentifier)
        lastValues[displayPanelIdentifier] = dynamicContentStates
    end

    local updaterByDynamicContentElement = {}
    local dynamicContentElementByZoneID = {}
    local iids = {}
    for _, v in pairs(dynamicContentElement) do



        dynamicContentElementByZoneID[v.displayZoneIdentifier.initialValue] = v
        updaterByDynamicContentElement[v] = function(contentURL, userDismissible)
            updateLastValues(
                contentURL, userDismissible,
                v.displayZoneIdentifier.initialValue,
                v.displayPanelIdentifier.initialValue
            )
        end

        iids[#iids+1] = v.dynamicContentURL.iid
        iids[#iids+1] = v.userDismissible.iid

        if v.dynamicContentURL.initialValue and v.userDismissible.initialValue then
            updaterByDynamicContentElement[v](
                v.dynamicContentURL.initialValue,
                v.userDismissible.initialValue
            )
        end
    end

    return
        DataUpdater.new(
            iids,
            function(update)
                for dynamicContentElement, updater in pairs(updaterByDynamicContentElement) do
                    local contentURL = update[dynamicContentElement.dynamicContentURL.iid]
                    local userDismissible = update[dynamicContentElement.userDismissible.iid]

                    if contentURL ~= nil and userDismissible ~= nil then
                        updater(contentURL, userDismissible)
                    else

                    end
                end

                return LuaUtils.duplicate(lastValues)
            end
        ),
        LuaUtils.getUniqueValues(paths),
        lastValues
end







function VehicleDataUpdater:_makeButtonInputUpdater(vehicleConfig)


    local paths = {
        event   = "uiControl.uiInputDeviceButton.uiInputDeviceButtonEvent",
        purpose = "uiControl.uiInputDeviceButton.uiInputDevicePurpose"
    }

    local path = "uiControl.uiInputDeviceButton.*"
    local buttons = VehicleDataUpdater._extract(vehicleConfig, path)
    if not buttons then
        Log.error(VehicleDataUpdater, function() return "Unknown ASC path: " .. path end)
        return nil, LuaUtils.getUniqueValues(paths)
    end

    local buttonStates = {}
    local buttonPurposesByIID = {}
    for _, button in pairs(buttons) do
        local purpose = button.uiInputDevicePurpose.initialValue
        local event = button.uiInputDeviceButtonEvent.initialValue

        buttonStates[purpose] = (event == Enums.UIInputDeviceButtonEvent.BUTTON_DOWN)
        buttonPurposesByIID[button.uiInputDeviceButtonEvent.iid] = purpose
    end

    return
        DataUpdater.new(
            LuaUtils.getKeys(buttonPurposesByIID),
            function(update)
                for iid, event in pairs(update) do
                    local purpose = buttonPurposesByIID[iid]


                    buttonStates[purpose] = (event == Enums.UIInputDeviceButtonEvent.BUTTON_DOWN)
                end

                return LuaUtils.duplicate(buttonStates)
            end
        ),
        LuaUtils.getUniqueValues(paths),
        buttonStates
end










function VehicleDataUpdater:_registerUpdateHandler(iids, dataIdentifier, f, ...)





    local updateHandler = {
        f = f,
        dataIdentifier = dataIdentifier,
        args = {...}
    }

    Log.info(VehicleDataUpdater, function() return "Registering Update Handler iids for " .. dataIdentifier .. ": ".. LuaUtils.prettyPrint(iids) end)


    self._iidsByUpdateHandler[updateHandler] = iids


    LuaUtils.forEach(iids, function(iid)
        local updateHandlers = self._updateHandlersByIid[iid] or {}
        updateHandlers[#updateHandlers+1] = updateHandler
        self._updateHandlersByIid[iid] = updateHandlers
    end)

    return self
end























function VehicleDataUpdater._extract(config, path, instance)




    local parts = LuaUtils.splitString(path, ".")




    local node = config
    local partialPath = ""
    while #parts > 0 and not LuaUtils.hasPrefix(parts[1], "*") do
        node = node[parts[1]]
        if not node then
            Log.error(VehicleDataUpdater, function() return "Unknown ASC path " ..  path end)
            return nil
        end
        partialPath = partialPath .. "." .. parts[1]
        table.remove(parts, 1)
    end

    if path == "automakerNotifications.dynamicContentElement.*" then










        Log.debug(VehicleDataUpdater, function() return "Debugging - Path: " .. path end)
        Log.debug(VehicleDataUpdater, function() return "Debugging - Config: " .. LuaUtils.prettyPrint(config) end)
        Log.debug(VehicleDataUpdater, function() return "Debugging - Node: " .. LuaUtils.prettyPrint(node) end)

        node = { node }
    end


    if #parts == 0 then
        return node and BaseConfig.from(node) or nil
    end


    local listPath = table.remove(parts, 1)
    partialPath = partialPath .. "." .. listPath


    local orderBy
    if LuaUtils.hasPrefix(listPath, "*/") then
        orderBy = string.sub(listPath, 3)

    end


    local entries = {}
    if orderBy then
        for _, entry in ipairs(node) do
            local orderByValue = entry[orderBy]


            entries[orderByValue] = entry
        end
    else
        entries = node
    end



    local keyPath = #parts > 0 and table.remove(parts) or nil



    entries = LuaUtils.map(entries, function(entry)
        local result = {}

        if keyPath then
            if not entry[keyPath] then
                Log.info("VehicleDataUpdater", function() return "Unable to extract path: " .. path .. " from config: " .. LuaUtils.prettyPrint(config, true, 10) end)
                return nil
            end
            result = BaseConfig.from(entry[keyPath])
        else
            result = LuaUtils.map(entry, function(property)
                return BaseConfig.from(property)
            end)
        end

        return result
    end)


    return instance and entries[instance] or entries
end

dataIdentifiers = LuaUtils.readOnly({
    batteryTemperature = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "highVoltageBattery.batteryTemperature.temperature" }
    },
    batteryTemperatureMin = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "highVoltageBattery.batteryTemperature.temperatureMin" }
    },
    batteryTemperatureMax = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "highVoltageBattery.batteryTemperature.temperatureMax" }
    },
    batteryTemperatureState = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "highVoltageBattery.batteryTemperature.temperatureState" }
    },
    batteryTemperatureMarkerCold = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "highVoltageBattery.batteryTemperature.temperatureMarkerCold" }
    },
    batteryTemperatureMarkerHot = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "highVoltageBattery.batteryTemperature.temperatureMarkerHot" }
    },
    remainingBatteryDistance = {
        f = VehicleDataUpdater._makeDistanceUpdater,
        args = { "highVoltageBattery.batteryRemainingRange"}
    },
    remainingBatteryRangeHidden = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "highVoltageBattery.batteryRemainingRange.hidden", false}
    },
    buttonInput = {
        f = VehicleDataUpdater._makeButtonInputUpdater
    },
    chargeLevel = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "highVoltageBattery.batteryLevel.batteryLevel" }
    },
    chargeLevelState = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "highVoltageBattery.batteryLevel.batteryLevelState" }
    },
    chargeLevelMarkerLow = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "highVoltageBattery.batteryLevel.batteryLevelMarkerLow" }
    },
    chargePortSideIndicator = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "charging.chargingStatus.portSideIndicator" }
    },
    dynamicContentElement = {
        f = VehicleDataUpdater._makeDynamicContentElementUpdater
    },
    speedLimited = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "driverAssistance.targetSpeed.speedLimited" }
    },
    cruiseControlSpeed = {
        f = VehicleDataUpdater._makeTargetSpeedUpdater,
        args = { "driverAssistance.targetSpeed" }
    },
    cruiseControlState = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "driverAssistance.targetSpeed.targetSpeedState" }
    },
    driveMode = {
        f = VehicleDataUpdater._makeDriveModeUpdater
    },
    driveModeHidden = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "driveState.driveMode.hidden", false }
    },
    emphasizedEngineGauge = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "uiControl.engineGaugeUI.uiEmphasizedEngineGauge" }
    },
    engineMarkerRedlineRPM = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "internalCombustionEngine.engineRPM.rotationalSpeedMarkerRedline" }
    },
    enginePower = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "electricEngine.enginePower.power"}
    },
    engineRPM = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "internalCombustionEngine.engineRPM.rotationalSpeed" }
    },
    engineRPMMax = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "internalCombustionEngine.engineRPM.rotationalSpeedMax" }
    },
    engineRPMState = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "internalCombustionEngine.engineRPM.rotationalSpeedState"
    } },
    engineTemperature = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "internalCombustionEngine.engineTemperature.temperature" }
     },
    engineTemperatureMin = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "internalCombustionEngine.engineTemperature.temperatureMin" }
    },
    engineTemperatureMarkerCold = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "internalCombustionEngine.engineTemperature.temperatureMarkerCold" }
    },
    engineTemperatureMarkerHot = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "internalCombustionEngine.engineTemperature.temperatureMarkerHot" }
    },
    engineTemperatureMax = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "internalCombustionEngine.engineTemperature.temperatureMax" }
    },
    engineTemperatureState = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "internalCombustionEngine.engineTemperature.temperatureState" }
    },
    outsideTemperature = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "environmentalConditions.exteriorConditions.temperature" }
    },
    fillLevelLabel = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "fuel.fuelLevel.fillLevelLabel" } },
    fuelLevel = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "fuel.fuelLevel.fuelLevel" }
    },
    fuelLevelState = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "fuel.fuelLevel.fuelLevelState" }
    },
    fuelLevelMarkerLow = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "fuel.fuelLevel.fuelLevelMarkerLow" }
    },
    fuelPortSideIndicator = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "fuel.fuelLevel.portSideIndicator" }
    },
    fuelEfficiency = {
        f = VehicleDataUpdater._makeFuelEfficiencyUpdater
    },
    fuelEfficiencyUnit = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "vehicleUnits.displayUnits.fuelEfficiencyUnit", Units.FuelEfficiency.MILES_PER_GALLON }
    },
    remainingFuelDistance = {
        f = VehicleDataUpdater._makeDistanceUpdater,
        args = { "fuel.fuelRemainingRange"}
    },
    remainingFuelRangeHidden = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "fuel.fuelRemainingRange.hidden", false}
    },
    gearShiftRecommendation = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "driveState.gearRecommendation.gearShiftRecommendation" }
    },
    lengthUnit = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "vehicleUnits.displayUnits.distanceUnit", Units.Length.MILES }
    },
    languageIdentifier = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "vehicleUnits.locale.languageIdentifier", Enums.LanguageIdentifier.ENGLISH }
    },
    localNotification = {
        f = VehicleDataUpdater._makeLocalNotificationUpdater
    },
    odometer    = {
        f = VehicleDataUpdater._makeDistanceUpdater,
        args = { "tripComputer.odometer" }
    },
    powerMarkerAvailableMax = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "electricEngine.enginePower.powerMarkerAvailableMax" }
    },
    powerMarkerAvailableMin = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "electricEngine.enginePower.powerMarkerAvailableMin" }
    },
    powerMax = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "electricEngine.enginePower.powerMax" }
    },
    powerMin = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "electricEngine.enginePower.powerMin" }
    },
    powerState = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "electricEngine.enginePower.powerState" }
    },
    punchThrough = {
        f = VehicleDataUpdater._makeCriticalStreamUpdater
    },
    secondaryEngineGaugeHidden = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "uiControl.engineGaugeUI.uiSecondaryEngineGaugeHidden", false }
    },
    remainingDistance = {
        f = VehicleDataUpdater._makeDistanceUpdater,
        args = { "tripComputer.remainingRange" }
    },
    remainingRangeHidden = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "tripComputer.remainingRange.hidden", false }
    },
    requestContent = {
        f = VehicleDataUpdater._makeRequestContentUpdater
    },
    requestTemporaryContent = {
        f = VehicleDataUpdater._makeRequestTemporaryContentUpdater
    },
    showSecondarySpeed = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "vehicleMotion.displayedSpeed.showSecondarySpeed", false }
    },
    temperatureUnit = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "vehicleUnits.displayUnits.temperatureUnit", Units.Temperature.FAHRENHEIT }
    },
    dynamicLocalNotification = {
        f = VehicleDataUpdater._makeDynamicLocalNotificationUpdater
    },
    transmission = {
        f = VehicleDataUpdater._makeTransmissionUpdater
    },
    uiSceneState = {
        f = VehicleDataUpdater._makeUISceneStateUpdater
    },
    vehicleLogo = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "vehicleResources.vehicleVariant.vehicleLogo" }
    },
    vehicleSpeed = {
        f = VehicleDataUpdater._makeDisplayedSpeedUpdater
    },
    vehicleSpeedMax = {
        f = VehicleDataUpdater._makeVehicleSpeedMaxUpdater
    },
    vehicleSpeedUnit = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "vehicleUnits.displayUnits.speedUnit", Units.Speed.MILES_PER_HOUR }
    },
    nightMode = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "uiControl.uiAppearance.nightMode" }
    },
    appearanceMode = {
        f = VehicleDataUpdater._makeSingleValueWriteOnlyUpdater,
        args = { "uiControl.uiAppearance.appearanceMode" }
    },
    turnSignalLeft = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "indicators.turnSignals.turnSignalLeft" }
    },
    turnSignalRight = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "indicators.turnSignals.turnSignalRight" }
    },
    proximityAlertRearLeft = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "indicators.proximityAlerts.proximityAlertRearLeft" }
    },
    proximityAlertRearRight = {
        f = VehicleDataUpdater._makeSingleValueUpdater,
        args = { "indicators.proximityAlerts.proximityAlertRearRight" }
    }
})


VehicleDataUpdater.DATAIDENTIFIERS = (function()
    local result = {}
    for dataIdentifier, _ in dataIdentifiers do
        result[dataIdentifier] = dataIdentifier
    end
    return result
end)()

return LuaUtils.readOnly(VehicleDataUpdater)
