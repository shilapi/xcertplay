-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local AngleConfiguration = require "AngleConfiguration"
local APL = require "APL.APL"
local DigiBarRadialLayout = require "DigiBarRadialLayout"

local ConcentricRingsUtils = APL.LuaUtils.makeObject({ _type = "ConcentricRingsUtils" })









function ConcentricRingsUtils.layoutParameters(frame, configuration, value)





    local inset = configuration.inset
    local ringLineWidth = configuration.ringWidth


    local ringsFrame = APL.Rect.new(0, 0, frame:getSize())
        :centeredMinSquare()
        :insetBy(inset, inset, inset, inset)

    local ringsMaskFrame = APL.Rect.new(0, 0, ringsFrame:getSize())
    local ringsCenterX, ringsCenterY = ringsMaskFrame:getCenter()
    local ringsRadius = ringsMaskFrame:getMinSideSize() / 2


    local primaryAngleConfig = configuration.primaryAngleConfiguration
    local secondaryAngleConfig = configuration.secondaryAngleConfiguration
    local gapLength = configuration.ringsGap
    gapLength = gapLength > 0 and gapLength or 0.0001 -- start/end angles should be >0, or the ring will not be drawn
    local ringsNumber = configuration.ringsNumber
    local spacing = configuration.spacing
    local path = APL.Path.new()

    for i = 0, ringsNumber - 1 do
        local radius = ringsRadius - spacing * i - ringLineWidth

        local angle = math.atan(gapLength / radius)
        path
            :moveTo(ringsCenterX + radius, ringsCenterY + gapLength)
            :arcTo(ringsCenterX, ringsCenterY, radius, -angle, angle, true)
    end

    local trackingDigiRingRadius = DigiBarRadialLayout.getTrackRadius(
        frame._width,
        configuration.targetDigiBarWidth,
        configuration.targetDigiBarInset
    )

    local initialTransform = ConcentricRingsUtils._getRotationTransform(
        value,
        trackingDigiRingRadius,
        configuration.targetDigiBarWidth,
        primaryAngleConfig,
        secondaryAngleConfig
    )

    return ringsFrame, ringsMaskFrame, path, initialTransform
end











function ConcentricRingsUtils._getRotationTransform(progressValue, radius, trackWidth, primaryAngleConfiguration, secondaryAngleConfiguration)






    local normalizedValue
    local primaryProgress = progressValue > 0 and progressValue or 0
    local secondaryProgress = progressValue < 0 and -progressValue or 0

    local angleConfiguration

    local bandThicknessShift = math.atan(trackWidth / (2 * radius))
    if primaryProgress > 0 then
        angleConfiguration = AngleConfiguration.new(
            primaryAngleConfiguration.minimumAngle + bandThicknessShift,
            primaryAngleConfiguration.maximumAngle - bandThicknessShift,
            true
        )
        normalizedValue = primaryProgress
    elseif secondaryProgress > 0 then
        angleConfiguration = AngleConfiguration.new(
            secondaryAngleConfiguration.minimumAngle - bandThicknessShift,
            secondaryAngleConfiguration.maximumAngle + bandThicknessShift,
            false
        )
        normalizedValue = secondaryProgress
    else

        local center = (APL.MathUtils.normalizeAngle(primaryAngleConfiguration.minimumAngle) + APL.MathUtils.normalizeAngle(secondaryAngleConfiguration.minimumAngle)) / 2
        angleConfiguration = AngleConfiguration.new(
            center,
            center,
            true
        )
        normalizedValue = 0
    end

    local maxAngleDelta = AngleConfiguration.getNormalizedMinMaxAngleDelta(angleConfiguration)
    local angleProgress = maxAngleDelta * normalizedValue
    local clockwiseSign = angleConfiguration.clockwise and 1 or -1
    local startAngle = APL.MathUtils.normalizeAngle(angleConfiguration.minimumAngle)
    local needleAngle = startAngle + angleProgress * clockwiseSign

    return APL.Transform.newWithRotation(needleAngle)
end

return APL.LuaUtils.readOnly(ConcentricRingsUtils)
