-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"


local Catalog = {
    _type = "Catalog",

    ImageGroupGauge = require "ImageGroupGauge",
    GearPositionGauge = require "GearPositionGauge",
    Indicator = require "Indicator"
}






function Catalog.getVersion()
    return "1"
end

return APL.LuaUtils.readOnly(Catalog)
