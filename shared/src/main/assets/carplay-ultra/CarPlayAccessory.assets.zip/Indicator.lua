-- Copyright © 2021-2026 Apple, Inc. All rights reserved.



























local APL = require "APL.APL"
local Button = require "Button"
local Constants = require "Constants"
local DynamicAppearanceImage = require "DynamicAppearanceImage"
local EdgeInsets = require "EdgeInsets"
local Enums = require "Enums"
local FontUtils = require "FontUtils"
local ImageLocalNotification = require "ImageLocalNotification"
local LocalNotificationState = require "LocalNotificationState"
local Signpost = require "APL.Signpost"
local Shadow = require "Shadow"
local DynamicLocalNotification = require "DynamicLocalNotification"
local DynamicLocalNotificationConfiguration = require "DynamicLocalNotificationConfiguration"
local VehicleDataUpdater = require "VehicleDataUpdater"
local VehicleDataSubscriber = require "VehicleDataSubscriber"
local VerifiedUIController = require "VerifiedUIController"
local VerticalEdge = require "VerticalEdge"

local Indicator = APL.LuaUtils.makeObject({ _type = "Indicator" })

local function validateConfiguration(config)





end












function Indicator.new(frame, instrument, focusSystem, contentController, appearanceController, notifications, shadowConfig)

    validateConfiguration(instrument.configuration)





    local containerInsets = EdgeInsets.fromJson(instrument.configuration.containerInsets)

    APL.Log.debug(Indicator, function() return "Creating Indicator: " .. APL.LuaUtils.prettyPrint(instrument.configuration) end)

    local self = APL.LuaUtils.newObject(Indicator, {
        _pendingAnimations = 0,
        _zoneRegion = contentController:getZoneRegion(), -- The zoneRegion this Indicator is a part of, Enums.DisplayZoneIdentifier.ZONE_1 or Enums.DisplayZoneIdentifier.ZONE_2
        _imageLayer = APL.LuaUtils.NIL,
        _activeNotification = APL.LuaUtils.NIL,     -- The active notification.

        _notificationState = APL.LuaUtils.NIL,      -- The most recently updated local notification on the LocalNotification ASC
        _requestContentState = APL.LuaUtils.NIL,    -- The most recently updated requestContentState on the Request Content ASC
        _dataIdentifier = instrument.configuration.dataIdentifier,
        _notifications = notifications,
        _closeButtonImage = APL.LuaUtils.NIL,
        _focusedCloseButtonImage = APL.LuaUtils.NIL,
        _presentationEdge = instrument.configuration.presentationEdge,
        _containerInsets = containerInsets,
        _rootLayer = APL.LuaUtils.NIL,
        _tweensByNotification = {}, -- Table for layer to animation values (opacity, x scale, y scale)



        _vehicleDataSubscriber = VehicleDataSubscriber.new(),
        _vehicleDataUpdater = APL.LuaUtils.NIL,
        _contentController = contentController,
        _appearanceController = appearanceController,
        _focusSystem = focusSystem,
        _subscription = APL.LuaUtils.NIL,
        _shadowConfig = shadowConfig or APL.LuaUtils.NIL,
        _lastValue = APL.LuaUtils.NIL,
        _textConfig = APL.LuaUtils.NIL
    })

    local criticalConfig = instrument.configuration.style.critical.configuration

    self._closeButtonImage = DynamicAppearanceImage.fromJson(criticalConfig.closeButton)
    self._focusedCloseButtonImage = DynamicAppearanceImage.fromJson(criticalConfig.focusedCloseButton)

    if criticalConfig.textConfiguration then
        if not APL.VectorFont.isFeatureSupported() then
            APL.Log.error(Indicator, function() return "Unable to create Indicator: vector fonts not supported" end)
            return nil
        end

        self._textConfig = DynamicLocalNotificationConfiguration.fromJson(criticalConfig.textConfiguration)
    end



    setmetatable(self._tweensByNotification, { __mode = "k" })

    local width = frame._width
    local height = frame._height
    local bounds = APL.Rect.new(0, 0, width, height)


    self._rootLayer = APL.Layer.new()
        :setFrame(frame)

    VerifiedUIController.current():addVerifiedElement(self)

    self._subscription = self._contentController:subscribe(function(update)
        APL.Log.info(Indicator, function() return "Indicator received requestContent update: " .. APL.LuaUtils.prettyPrint(update, false, 3) end)
        self._requestContentState = update
        self:_updateNotification()
    end)



    self._appearanceController:setUpdateHandler(function(state)
        self:setAppearanceState(state)
    end)

    return self
end






function Indicator:destroy()


    APL.LuaUtils.forEach(self._tweensByNotification, function(tween)
        APL.flux.clear(tween)
    end)
    if self._subscription then
        self._contentController:unsubscribe(self._subscription)
    end
    self._contentController = nil
    self._vehicleDataSubscriber:destroy()
    self._vehicleDataUpdater = nil
    self._rootLayer:destroy()
    VerifiedUIController.current():removeVerifiedElement(self)
end







function Indicator:setVehicleDataUpdater(vehicleDataUpdater)



    if vehicleDataUpdater == nil then
        self._vehicleDataSubscriber:removeSubscription()
        return true
    end

    local identifiers = { self._dataIdentifier }
    local validIdentifiers, subscriber = vehicleDataUpdater:subscribe(identifiers, function(update)
        local data = update[self._dataIdentifier]
        local displayPanelIdentifier = self._contentController:getDisplayPanelIdentifier()
        local zoneRegion = self._contentController:getZoneRegion()


        local valuesForDisplayPanel = data and data[displayPanelIdentifier] or nil
        local value = valuesForDisplayPanel and valuesForDisplayPanel[zoneRegion] or nil
        if value ~= nil and value ~= self._lastValue then
            self._lastValue = value
            self:_setPrimaryValue(value)
        end
    end)

    self._vehicleDataSubscriber:updateSubscription(vehicleDataUpdater, subscriber)
    self._vehicleDataUpdater = vehicleDataUpdater

    return #validIdentifiers == #identifiers
end







function Indicator:setAppearanceState(state)



    if self._activeNotification then
        self._activeNotification:setAppearanceState(state)
    end

    for notification, _ in pairs(self._tweensByNotification) do
        if notification ~= self._activeNotification then
            notification:setAppearanceState(state)
        end
    end

    return self
end






function Indicator:getRootLayer()


    return self._rootLayer
end






function Indicator:getVerifiedLayer()


    if self._activeNotification ~= nil then
        return self._activeNotification._imageLayer -- TODO fix bug
    else
        return self._imageLayer
    end
end






function Indicator:getVerifierIdentifier()


    return "notification"
end






function Indicator:description()


    return "Indicator (" .. self._dataIdentifier .. ") [" .. self._zoneRegion .. "]"
end







function Indicator:_createNotification(notificationDataSource)



    if notificationDataSource.textContent then
        return self:_createTextNotification(notificationDataSource)
    end

    return self:_createImageNotification(notificationDataSource)
end






function Indicator:_createImageNotification(state)



    local identifier = state.identifier
    local notification = self._notifications[identifier]

    if notification == nil then
        APL.Log.error(Indicator, function() return "Unknown indicator identifier " .. identifier end)
        return nil
    end

    local imageTexture = APL.Asset.loadNamedTexture(notification.image)
    if imageTexture == nil then
        APL.Log.error(Indicator, function() return "Failed to load image for indicator identifier " .. identifier end)
        return nil
    end

    return ImageLocalNotification.new(
        state:copy(),
        APL.ImageLayer.new():setTexture(imageTexture),
        self._appearanceController:getState(),
        notification.userDismissible and self:_createCloseButton() or nil,
        self._shadowConfig and Shadow.new(self._shadowConfig) or nil
    )
end







function Indicator:_createTextNotification(state)




    return DynamicLocalNotification.new(
        state:copy(),
        self._textConfig,
        self._appearanceController:getState(),
        state.userDismissible and self:_createCloseButton() or nil,
        self._shadowConfig and Shadow.new(self._shadowConfig) or nil
    )
end






function Indicator:_createCloseButton()
    return Button.new(self._closeButtonImage, self._focusedCloseButtonImage, self._appearanceController:getState(), self._focusSystem, function()
        if self._contentController then
            self._contentController:dismissContent()
        end
    end)
end












function Indicator:_updateNotification()


    if not self._requestContentState or not self._notificationState then
        return
    end

    local textBasedNotifications = self._dataIdentifier == VehicleDataUpdater.DATAIDENTIFIERS.dynamicLocalNotification

    if self._activeNotification and self._activeNotification:getState():equals(self._notificationState) then
        APL.Log.info(Indicator, function() return "Not updating local notification as it hasn't changed" .. APL.LuaUtils.prettyPrint(self._notificationState) end)
        return self
    end

    local urlScheme = textBasedNotifications and Enums.TemporaryContentURL.DYNAMIC_LOCAL_NOTIFICATION or Enums.TemporaryContentURL.LOCAL_NOTIFICATION
    local shouldShowNotification = self._requestContentState.on and APL.LuaUtils.hasPrefix(self._requestContentState.contentURL, urlScheme)


    local userDismissible
    if textBasedNotifications then
        userDismissible = self._notificationState.userDismissible
    else
        userDismissible = self._requestContentState.userDismissible
    end

    local localNotificationState = LocalNotificationState.new(
        self._notificationState.identifier,
        userDismissible,
        shouldShowNotification,
        self._requestContentState.zoneRegion,
        self._notificationState.textContent
    )

    APL.Log.info(Indicator, function() return "Updating notification with requestContentState: " .. APL.LuaUtils.prettyPrint(self._requestContentState) .. ", local Notification: " .. APL.LuaUtils.prettyPrint(self._notificationState) end)



    if self._activeNotification ~= nil then
        APL.Log.info(Indicator, function() return "Dismissing active notification" end)
        self:_dismiss(self._activeNotification)
        self._activeNotification = nil
    end

    if localNotificationState.on then
        local notification = self:_createNotification(localNotificationState)
        if notification then
            APL.Log.info(Indicator, function() return "Created notification for state: " .. APL.LuaUtils.prettyPrint(localNotificationState) end)

            self._activeNotification = notification
            self:_present(notification)
        else
            APL.Log.warn(Indicator, function() return "Unable to create notification for state: " .. APL.LuaUtils.prettyPrint(localNotificationState) end)
        end
    end

    if self._pendingAnimations == 0 then
        APL.Log.info(Indicator, function() return "No animations pending." end)
        VerifiedUIController.current():setNeedsUpdate()
    end

    return self
end









function Indicator:_setPrimaryValue(notification)



    APL.Log.info(Indicator, function() return "Indicator on zone: " .. self._zoneRegion .. " updating identifier from: " ..  (self._notificationState and self._notificationState.identifier or "<none>") .. " to identifier: " .. notification.identifier end)
    self._notificationState = notification

    self:_updateNotification()
    return self
end








function Indicator:_present(notification)



    local identifier = notification:getState().identifier
    APL.Log.info(Indicator, function() return "Indicator starting present animation for state " .. identifier end)
    local signpostId = Signpost.beginInterval("Indicator present animation started for state " .. identifier .. " zone:" .. self._zoneRegion)
    notification:setEnabled(true)



    local layer = notification:getRootLayer()
        :setOpacity(0) -- hide layer before adding to root to avoid flickering effect
        :addToSuperLayer(self._rootLayer)

    local insets = self._containerInsets
    local _, _, width, height = self._rootLayer:getFrame()
    local bounds = APL.Rect.new(0, 0, width, height)
        :insetBy(insets.leading, insets.top, insets.trailing, insets.bottom)


    local frame = APL.Rect.new(0, 0, notification:preferredContentSize(bounds:getSize())):centeredXInRect(bounds)
    if self._presentationEdge == VerticalEdge.TOP then
        frame._y = bounds._y
    else
        frame._y = bounds._y + bounds._height - frame._height
    end

    notification:setFrame(frame)

    self._tweensByNotification[notification] = { opacity = 0, x = 0.90, y = 0.90 } -- starting values.

    self._pendingAnimations = self._pendingAnimations + 1
    APL.flux.to(self._tweensByNotification[notification], Constants.POPOVER_ANIMATION_DURATION, { opacity = 1, x = 1, y = 1 })
        :ease("bezier", table.unpack(Constants.POPOVER_CURVE))
        :onupdate(function(t)
            layer:setOpacity(t.opacity)
                 :setTransform(APL.Transform.newWithScale(t.x, t.y))
        end)
        :oncomplete(function()
            APL.Log.info(Indicator, function() return "Completed presentation animation. state = " .. identifier end)
            Signpost.endInterval(signpostId, "Indicator present animation completed for state " .. identifier .. " zone:" .. self._zoneRegion)

            self._pendingAnimations = self._pendingAnimations - 1
            if self._pendingAnimations == 0 then
                APL.Log.info(Indicator, function() return "Last animation finished." end)
                Signpost.emitEvent("Last animation finished for indicator.")
                VerifiedUIController.current():setNeedsUpdate()
            end
        end)

    return self
end









function Indicator:_dismiss(notification)





    local identifier = notification:getState().identifier

    APL.Log.info(Indicator, function() return "Indicator starting dismissal animation for state " .. identifier .. " zone: " .. self._zoneRegion end)
    local signpostId = Signpost.beginInterval("Indicator dismiss animation started for state " .. identifier .. " zone: " .. self._zoneRegion)

    notification:setEnabled(false)
    local layer = notification:getRootLayer()

    self._pendingAnimations = self._pendingAnimations + 1
    APL.flux.to(self._tweensByNotification[notification], Constants.POPOVER_ANIMATION_DURATION, { opacity = 0.0, x = 1.00, y = 1.00 })
        :ease("bezier", table.unpack(Constants.POPOVER_CURVE))
        :onupdate(function(t)
            layer:setOpacity(t.opacity)
                 :setTransform(APL.Transform.newWithScale(t.x, t.y))
        end)
        :oncomplete(function()
            APL.Log.info(Indicator, function() return "Completed dismissal animation. state = " .. identifier .. " zone: " .. self._zoneRegion end)
            Signpost.endInterval(signpostId, "Indicator dismiss animation completed for state " .. identifier .. " zone: " .. self._zoneRegion)
            self._rootLayer:removeSublayer(layer)

            self._pendingAnimations = self._pendingAnimations - 1
            if self._pendingAnimations == 0 then
                APL.Log.info(Indicator, function() return "Last animation finished." end)
                Signpost.emitEvent("Finished last animation for indicator.")

                VerifiedUIController.current():setNeedsUpdate()
            end

            self._tweensByNotification[notification] = nil
            notification:destroy()
        end)

    return self
end

return APL.LuaUtils.readOnly(Indicator)