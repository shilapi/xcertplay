-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"

local VerifiedUIController = APL.LuaUtils.makeObject({ _type = "VerifiedUIController" })

APL.LuaUtils.runWithUnlockedGlobals(function()
    __global__activeVerifiedUIController = nil
end)






function VerifiedUIController.current()
    return APL.LuaUtils.runWithUnlockedGlobals(function()
        return __global__activeVerifiedUIController or VerifiedUIController.new()
    end)
end






function VerifiedUIController.new()

    APL.LuaUtils.runWithUnlockedGlobals(function()
        if __global__activeVerifiedUIController then
            __global__activeVerifiedUIController:destroy()
            __global__activeVerifiedUIController = nil
        end
    end)

    local self = APL.LuaUtils.newObject(VerifiedUIController, {
        _updateRequested = false,
        _verifiedElements = {}, -- Set of active verified objects
        _updateHandler = APL.LuaUtils.NIL,
        _updateThread = APL.LuaUtils.NIL,
    })



    setmetatable(self._verifiedElements, { __mode = "k" })



    APL.LuaUtils.runWithUnlockedGlobals(function()
        __global__activeVerifiedUIController = self
    end)

    return self
end






function VerifiedUIController:destroy()


    if self._updateThread then
        self._updateThread:destroy()
        self._updateThread = nil
    end

    self._verifiedElements = {}
    self._updateHandler = nil

    APL.LuaUtils.runWithUnlockedGlobals(function()
        __global__activeVerifiedUIController = nil
    end)
end







function VerifiedUIController:addVerifiedElement(obj)



    self._verifiedElements[obj] = true
    return self
end







function VerifiedUIController:removeVerifiedElement(obj)



    self._verifiedElements[obj] = nil
    return self
end







function VerifiedUIController:setNeedsUpdate()


    self._updateRequested = true
    return self
end






function VerifiedUIController:getVerifiedElements()


    return APL.LuaUtils.getKeys(self._verifiedElements)
end








function VerifiedUIController:start(f)




    APL.Log.info(VerifiedUIController, function() return "Starting" end)

    self._updateHandler = f
    self._updateThread =  APL.Thread.new(function()
        while true do
            self:updateIfNecessary()
             APL.Thread.yield()
        end
    end)
    :setTag("VerifiedUIController")
    :start()

    return self
end






function VerifiedUIController:stop()


    APL.Log.info(VerifiedUIController, function() return "Stopping" end)

    self._updateHandler = nil

    if self._updateThread then
        self._updateThread:stop()
        self._updateThread = nil
    end

    return self
end






function VerifiedUIController:updateIfNecessary()


    if self._updateRequested then
        if self._updateHandler then
            self._updateHandler()
            self._updateRequested = false
        end
    end

    return self
end

return APL.LuaUtils.readOnly(VerifiedUIController)
