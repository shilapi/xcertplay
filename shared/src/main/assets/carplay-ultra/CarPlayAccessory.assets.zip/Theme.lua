-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local ColorType = require "ColorType"
local GradientColor = require "GradientColor"
local PaletteInfo = require "PaletteInfo"




local LayoutStyle = APL.LuaUtils.namedObject(
    "LayoutStyle",
    { "overridesByPaletteID", "table?" } -- (paletteID) -> (colorID: ColorType)
)







function LayoutStyle.fromJson(json)


    local overridesByPaletteID = {}
    for paletteID, colors in pairs(json) do
        overridesByPaletteID[paletteID] = APL.LuaUtils.map(colors, ColorType.fromJson)
    end

    return LayoutStyle.new(overridesByPaletteID)
end




local Theme = APL.LuaUtils.namedObject(
    "Theme",
    { "palettes", "table" },
    { "layoutStyles", "table" },
    { "defaultPaletteIDs", "table" }
)


Theme.Appearance = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "LIGHT",
    "DARK"
}))







function Theme.fromJson(json)




    local palettes = {}
    for id, palette in pairs(json.palettes) do


        palettes[id] = PaletteInfo.fromJson(palette)
    end

    local layoutStyles = {}
    for id, paletteOverrides in pairs(json.layoutStyles) do


        layoutStyles[id] = LayoutStyle.fromJson(paletteOverrides)
    end

    for id, paletteID in pairs(json.defaultPaletteIDs) do


    end

    return Theme.new(palettes, layoutStyles, json.defaultPaletteIDs)
end

return APL.LuaUtils.readOnly(Theme)