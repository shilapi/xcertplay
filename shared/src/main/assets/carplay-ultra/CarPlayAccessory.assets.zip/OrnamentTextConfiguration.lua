






local APL = require "APL.APL"

local OrnamentTextConfiguration = APL.LuaUtils.namedObject(
    "OrnamentTextConfiguration",
    { "ornamentLabels", "table" },
    { "ornamentFontName", "string" }
)

function OrnamentTextConfiguration.fromJson(json)

    return OrnamentTextConfiguration.new(
        json.ornamentLabels,
        json.ornamentFont.name
    )
end

return APL.LuaUtils.readOnly(OrnamentTextConfiguration)