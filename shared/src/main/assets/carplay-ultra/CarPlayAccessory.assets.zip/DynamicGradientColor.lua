-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local GradientColor = require "GradientColor"


local DynamicGradientColor = APL.LuaUtils.namedObject(
    "DynamicGradientColor",
    { "lightMode", "GradientColor?" },
    { "darkMode", "GradientColor?" }
)







function DynamicGradientColor.fromJson(json)


    return DynamicGradientColor.new(
        json.lightMode and GradientColor.fromJson(json.lightMode),
        json.darkMode and GradientColor.fromJson(json.darkMode)
    )
end

return APL.LuaUtils.readOnly(DynamicGradientColor)