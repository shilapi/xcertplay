-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local EdgeInsets = require "EdgeInsets"
local NinePartImageConfiguration = require "NinePartImageConfiguration"

local ShadowConfiguration = APL.LuaUtils.namedObject(
    "ShadowConfiguration",
    { "image", "NinePartImageConfiguration" },
    { "shadowSize", "EdgeInsets" }
)







function ShadowConfiguration.fromJson(jsonRepresentation)


    return ShadowConfiguration.new(
        NinePartImageConfiguration.fromJson(jsonRepresentation.image),
        EdgeInsets.fromJson(jsonRepresentation.shadowSize)
    )
end

return APL.LuaUtils.readOnly(ShadowConfiguration)
