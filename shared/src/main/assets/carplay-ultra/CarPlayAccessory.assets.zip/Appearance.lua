-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Enums = require "Enums"

local Appearance = APL.LuaUtils.namedObject(
    "Appearance",
    { "targetAppearanceMode", "number" },
    { "preference", "number" }
)



Appearance.MODE = APL.LuaUtils.readOnly({
    UNDEFINED = -1,
    LIGHT = Enums.AppearanceMode.LIGHT,
    DARK = Enums.AppearanceMode.DARK
})
Appearance.MODES = APL.LuaUtils.makeSet(APL.LuaUtils.getValues(Appearance.MODE))







function Appearance.toUIAppearanceMode(appearance)



    if appearance == Appearance.MODE.DARK then
        return Enums.AppearanceMode.DARK
    elseif appearance == Appearance.MODE.LIGHT then
        return Enums.AppearanceMode.LIGHT
    else

        return Enums.AppearanceMode.DARK
    end
end


Appearance.PREFERENCE = APL.LuaUtils.readOnly({
    AUTOMATIC = 0,
    ALWAYS_LIGHT = 1,
    ALWAYS_DARK = 2
})
local PREFERENCE_TYPES = APL.LuaUtils.makeSet(APL.LuaUtils.getValues(Appearance.PREFERENCE))







function Appearance:applyingPreference(preference)




    return Appearance.new(self.targetAppearanceMode, preference)
end







function Appearance:applyingTargetAppearanceMode(appearanceMode)




    return Appearance.new(appearanceMode, self.preference)
end






function Appearance:getResolvedAppearanceMode()


    if self.targetAppearanceMode == Appearance.MODE.UNDEFINED then
        return Appearance.MODE.UNDEFINED
    elseif self.preference == Appearance.PREFERENCE.ALWAYS_DARK then
        return Appearance.MODE.DARK
    elseif self.preference == Appearance.PREFERENCE.ALWAYS_LIGHT then
        return Appearance.MODE.LIGHT
    end

    return self.targetAppearanceMode
end







function Appearance.targetAppearanceFromNightMode(nightMode)


    if nightMode == nil then
        return Appearance.MODE.UNDEFINED
    elseif nightMode then
        return Appearance.MODE.DARK
    else
        return Appearance.MODE.LIGHT
    end
end

return APL.LuaUtils.readOnly(Appearance)
