-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local TemperatureDataIdentifiers = APL.LuaUtils.namedObject(
    "TemperatureDataIdentifiers",
    { "temperatureDataIdentifier", "string" },
    { "temperatureMinDataIdentifier", "string" },
    { "temperatureMaxDataIdentifier", "string" },
    { "temperatureStateDataIdentifier", "string" },
    { "coldTemperatureMarkerDataIdentifier", "string" },
    { "hotTemperatureMarkerDataIdentifier", "string" },
    { "temperatureUnitDataIdentifier", "string" }
)
TemperatureDataIdentifiers.fromJson = function(json)
    return TemperatureDataIdentifiers.new(
        json.dataIdentifier,
        json.temperatureMinDataIdentifier,
        json.temperatureMaxDataIdentifier,
        json.temperatureStateDataIdentifier,
        json.coldTemperatureMarkerDataIdentifier,
        json.hotTemperatureMarkerDataIdentifier,
        json.temperatureUnitDataIdentifier
    )
end

return APL.LuaUtils.readOnly(TemperatureDataIdentifiers)
