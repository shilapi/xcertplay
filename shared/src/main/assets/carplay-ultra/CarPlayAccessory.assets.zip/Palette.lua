-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Appearance = require "Appearance"
local Enums = require "Enums"
local ColorType = require "ColorType"

local Palette = APL.LuaUtils.makeObject({ _type = "Palette" })










function Palette.new(id, displayName, colors, overrides)





    return APL.LuaUtils.newObject(Palette, {
        _id = id,
        _displayName = displayName,
        _colors = colors,
        _overrides = overrides or APL.LuaUtils.NIL
    })
end






function Palette:getID()


    return self._id
end








function Palette:getGradientColor(colorID, appearanceMode)




    local colorType = self._colors[colorID]


    local override
    local baseColor
    if colorType.single then
        local singleOverride = self._overrides[colorID]

        local singleGradient = singleOverride and singleOverride.single

        override = singleGradient
        baseColor = colorType.single
    elseif colorType.dynamic then
        local dynamicOverride = self._overrides[colorID]

        local dynamicGradient = dynamicOverride and dynamicOverride.dynamic


        if appearanceMode == Enums.AppearanceMode.DARK then
            override = dynamicGradient and dynamicGradient.darkMode
            baseColor = colorType.dynamic.darkMode
        elseif appearanceMode == Enums.AppearanceMode.LIGHT then
            override = dynamicGradient and dynamicGradient.lightMode
            baseColor = colorType.dynamic.lightMode
        else

        end
    else

    end

    return override or baseColor
end








function Palette:getSolidColor(colorID, appearanceMode)





    local colorType = self._colors[colorID]


    local override
    local baseColor
    if colorType.single then
        local singleOverride = self._overrides and self._overrides[colorID]

        local singleGradient = singleOverride and singleOverride.single

        override = singleGradient
        baseColor = colorType.single
    elseif colorType.dynamic then
        local dynamicOverride = self._overrides and self._overrides[colorID]

        local dynamicGradient = dynamicOverride and dynamicOverride.dynamic


        if appearanceMode == Enums.AppearanceMode.DARK then
            override = dynamicGradient and dynamicGradient.darkMode
            baseColor = colorType.dynamic.darkMode
        elseif appearanceMode == Enums.AppearanceMode.LIGHT then
            override = dynamicGradient and dynamicGradient.lightMode
            baseColor = colorType.dynamic.lightMode
        else

        end
    else

    end

    local gradient = override or baseColor



    local _, color = next(gradient.stops)


    return color
end






function Palette:destroy()

end

return APL.LuaUtils.readOnly(Palette)
