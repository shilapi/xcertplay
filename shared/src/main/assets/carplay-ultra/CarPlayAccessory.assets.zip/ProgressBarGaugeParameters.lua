-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local ProgressBarGaugeParameters = APL.LuaUtils.namedObject(
    "ProgressBarGaugeParameters",



    { "configuration", "*?" },



    { "ticksLayoutConfiguration", "TicksLayoutConfiguration?" },


    { "labelValues", "table?" }
)

return APL.LuaUtils.readOnly(ProgressBarGaugeParameters)
