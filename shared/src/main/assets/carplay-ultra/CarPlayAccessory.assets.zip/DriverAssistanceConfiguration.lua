-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local DriverAssistanceConfiguration = APL.LuaUtils.namedObject(
    "DriverAssistanceConfiguration",
    { "dataIdentifiers", "DriverAssistanceConfiguration.DataIdentifiers" }
)

DriverAssistanceConfiguration.DataIdentifiers = APL.LuaUtils.namedObject(
    "DriverAssistanceConfiguration.DataIdentifiers",
    { "speedDataIdentifier", "string" },
    { "speedUnitDataIdentifier", "string" },
    { "speedMaxDataIdentifier", "string" },
    { "speedLimitedDataIdentifier", "string"},
    { "cruiseControlSpeedDataIdentifier", "string" },
    { "cruiseControlStateDataIdentifier", "string" },
    { "uiSceneStateDataIdentifier", "string" }
)







function DriverAssistanceConfiguration.fromJson(json)


    return DriverAssistanceConfiguration.new(
        DriverAssistanceConfiguration.DataIdentifiers.fromJson(json.dataIdentifiers)
    )
end







function DriverAssistanceConfiguration.DataIdentifiers.fromJson(json)


    return DriverAssistanceConfiguration.DataIdentifiers.new(
        json.speedDataIdentifier,
        json.speedUnitDataIdentifier,
        json.speedMaxDataIdentifier,
        json.speedLimitedDataIdentifier,
        json.cruiseControlSpeedDataIdentifier,
        json.cruiseControlStateDataIdentifier,
        json.uiSceneStateDataIdentifier
    )
end




function DriverAssistanceConfiguration.DataIdentifiers:getIdentifiers()
    return {
        self.speedDataIdentifier,
        self.speedUnitDataIdentifier,
        self.speedMaxDataIdentifier,
        self.speedLimitedDataIdentifier,
        self.cruiseControlSpeedDataIdentifier,
        self.cruiseControlStateDataIdentifier
    }
end

return APL.LuaUtils.readOnly(DriverAssistanceConfiguration)
