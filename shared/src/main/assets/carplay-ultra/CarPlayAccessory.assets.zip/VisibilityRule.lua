-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local VisibilityConfiguration = require "VisibilityConfiguration"


local VisibilityRule = APL.LuaUtils.namedObject(
    "VisibilityRule",
    function(
        lastResult: VisibilityRule.Result?, -- Last visibility result from the rule
        handler: (...any) -> ...any         -- rule handler function. Return VisibilityRule.Result
    )
        return {
            lastResult = lastResult,
            handler = handler
        }
    end
)


VisibilityRule.Parameters = APL.LuaUtils.namedObject(
    "VisibilityRule.Parameters",
    function(
        update: table,      -- Vehicle data update, if any
        previous: table,    -- Vehicle data last known values, if any
        layoutMode: number  -- layout mode, if known
    )
        return {
            update = update,
            previous = previous,
            layoutMode = layoutMode
        }
    end
)


VisibilityRule.Result = APL.LuaUtils.namedObject(
    "VisibilityRule.Result",
    function(
        opacity: number,  -- Gauge opacity. If opacity is 0, the gauge will be hidden (visible=false), if >0 it will be visible (visible=true).
        animation: VisibilityConfiguration.Animation,  -- Animation
        autoHideAnimation: VisibilityConfiguration.Animation? -- Optional auto-hide animation. If set, the timer will fire in `autoHideAnimation.delay` seconds to hide the gauge
    )
        return {
            opacity = opacity,
            animation = animation,
            autoHideAnimation = autoHideAnimation
        }
    end
)

function VisibilityRule.Result.newWithVisibility(visible, animation)



    return VisibilityRule.Result.new(visible and 1 or 0, animation)
end

function VisibilityRule.Result.equals(lhs, rhs)



    return lhs ~= nil and rhs ~= nil
        and lhs.opacity == rhs.opacity
        and VisibilityConfiguration.Animation.equals(lhs.animation, rhs.animation)
        and ((lhs.autoHideAnimation == nil and rhs.autoHideAnimation == nil) or lhs.autoHideAnimation == rhs.autoHideAnimation)
end

return APL.LuaUtils.readOnly(VisibilityRule)