-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"

local DynamicContentState = LuaUtils.makeObject({ _type = "DynamicContentState" })










function DynamicContentState.new(contentURL, userDismissible, zoneRegion, displayPanelIdentifier)





    local self = LuaUtils.newObject(DynamicContentState, {
        contentURL = contentURL,
        userDismissible = userDismissible,
        zoneRegion = zoneRegion, -- Enums.DisplayZoneIdentifier.ZONE_1 or Enums.DisplayZoneIdentifier.ZONE_2
        displayPanelIdentifier = displayPanelIdentifier
    })

    return self
end






function DynamicContentState:destroy()

end







function DynamicContentState:equals(dynamicContentState)



    return self.contentURL == dynamicContentState.contentURL and
        self.userDismissible == dynamicContentState.userDismissible and
        self.zoneRegion == dynamicContentState.zoneRegion and
        self.displayPanelIdentifier == dynamicContentState.displayPanelIdentifier
end






function DynamicContentState:copy()


    return DynamicContentState.new(self.contentURL, self.userDismissible, self.zoneRegion, self.displayPanelIdentifier)
end

return LuaUtils.readOnly(DynamicContentState)
