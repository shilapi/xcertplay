-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"

local VerticalEdge = { _type = "VerticalEdge" }

VerticalEdge.TOP = 0
VerticalEdge.BOTTOM = 1

VerticalEdge.EDGES = APL.LuaUtils.readOnly({
    [VerticalEdge.TOP] = true,
    [VerticalEdge.BOTTOM] = true
})

return APL.LuaUtils.readOnly(VerticalEdge)