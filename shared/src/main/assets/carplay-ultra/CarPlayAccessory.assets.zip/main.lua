

-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local APL = require "APL.APL"
local LayoutController = require "LayoutController"
local PackageParser = require "PackageParser"
local Theme = require "Theme"

local args = {...}
APL.Log.info("main", function() return "Args: " .. APL.LuaUtils.prettyPrint(args) end)

APL.Log.log("main", "Optimization: " .. (APL.LuaUtils.isOptimized() and "Enabled" or "Disabled"))

APL.Log.setLevel(APL.Config.readParam("LOG.LEVEL") or APL.Log.LEVEL.INFO)
APL.Log.info("main", function() return "Setting global Log level: " .. tostring(APL.Log.getLevel()) end)
for tag, level in pairs(APL.Config.readParam("LOG.LEVELS") or {}) do
    APL.Log.setLevel(level, tag)
    APL.Log.info("main", function() return "Setting Log level for '%s': %s", tag, level end)
end


pcall(function()
    local infoPlist = CP.createAssetRAW("Info.plist")
    if infoPlist then
        local info = CP.parsePlist(infoPlist)
        if info then
            APL.Log.log("main", "Loading asset %s (%d) - Build %s", info.CFBundleIdentifier or "unknown", info.CFBundleVersion or -1, info.CFBundleShortVersionString or "unknown")
        end
    end
end)


local outStreams = CP.enumerateOutputStreams()

local outputStream = outStreams[1]

APL.Log.info("main", function() return "OutputStream " end)
APL.Log.info("main", function() return "\t identifier: %s", outputStream.identifier end)
APL.Log.info("main", function() return "\t frameDuration: %.6f", outputStream.frameDuration end)
APL.Log.info("main", function() return "\t width: %d", outputStream.width end)
APL.Log.info("main", function() return "\t height: %d", outputStream.height end)

local displayID = outputStream.identifier


APL.Log.setPrefix(displayID)
APL.Signpost.setPrefix(displayID)


local packageData = APL.Signpost.measure("Loading package data", function()
    return APL.Asset.loadLua("r/PackageData")
end)
local packageParser = APL.Signpost.measure("Parsing package data", function()
    return PackageParser.new(packageData)
end)


APL.Asset.setManifest("AssetManifestData", "r/" .. displayID)


local display = packageParser:getDisplay(displayID)



local themeData = APL.Signpost.measure("Loading theme data", function()
    return APL.Asset.loadLua("r/ThemeData")
end)
local theme = APL.Signpost.measure("Parsing theme data", function()
    return Theme.fromJson(themeData)
end)


if display:getFontManager() then
    APL.VectorFontManager.setDefaultManager(display:getFontManager())
end


local args = #args > 0 and args[1] or {}
local fastStart = args.fastStart or false
APL.Log.info("main", function() return "Ready to load display \"" .. displayID .. "\" (package version: " .. packageParser:getVersion() .. ", fastStart: " .. tostring(fastStart) .. ")" end)

local layoutController, failure = APL.LuaUtils.safeCall(false, function()
    return APL.Signpost.measure("Loading Display", function()
        return LayoutController.new(theme, fastStart, display)
    end)
end)

if layoutController == false then
    APL.ErrorHandler.forwardError(failure)
end

APL.Log.info("main", function() return "Script loaded" end)
