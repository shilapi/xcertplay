-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local ShapeLayer = require "APL.ShapeLayer"

local DigiBarLinearLayout = APL.LuaUtils.makeObject({ _type = "DigiBarLinearLayout" })

DigiBarLinearLayout.gradientLayout = {
    startPoint = { 0, 0.5 },
    endPoint = { 1, 0.5 },
    kind = APL.GradientLayer.KIND.LINEAR
}








function DigiBarLinearLayout.new(configuration)


    return APL.LuaUtils.newObject(DigiBarLinearLayout, {
        _configuration = configuration
    })
end






function DigiBarLinearLayout:destroy()

end










function DigiBarLinearLayout.getBarLayout(barStyle, frame, offset, widthExtension)





    local digiBarFrame, xFrom, xTo, y = DigiBarLinearLayout._getModularTrackLayout(frame, barStyle)

    y = y + offset
    local path = APL.Path.new()
        :moveTo(xFrom, y)
        :lineTo(xTo, y)

    return digiBarFrame, path, barStyle.trackWidth + widthExtension, ShapeLayer.LINECAP.ROUND, barStyle.centerOffset
end









function DigiBarLinearLayout.getProgressCoordinates(barStyle, frame, value)




    local _, xFromTrack, xToTrack, y = DigiBarLinearLayout._getModularTrackLayout(frame, barStyle)
    local _, xFromExtended, xToExtended = DigiBarLinearLayout._getModularTrackLayout(frame, barStyle)

    local progressX = xFromExtended + (xToExtended - xFromExtended) * value
    progressX = math.min(xToTrack, math.max(xFromTrack, progressX))

    return frame._x + progressX, frame._y + y
end






function DigiBarLinearLayout.getRotationAngle()
    return math.pi / 2
end







function DigiBarLinearLayout.getLineCapLength(barStyle)


    return barStyle.trackWidth / 2
end











function DigiBarLinearLayout._getModularTrackLayout(frame, configuration)



    local barFrame = frame:insetBy(configuration.leftInset, 0, configuration.rightInset, 0)
    local trackYOffset = barFrame._height / 2 + configuration.centerOffset

    local xFrom = (configuration.isRTL and barFrame._width or 0)
    local xTo = (configuration.isRTL and 0 or barFrame._width)

    return barFrame, xFrom, xTo, trackYOffset
end

return APL.LuaUtils.readOnly(DigiBarLinearLayout)