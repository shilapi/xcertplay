

-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local APL = require "APL.APL"
local Constants = require "Constants"
local GaugeColor = require "GaugeColor"

local LogoAnim = {}

local makeDividerLayer = function(width, startLength, endlength)
    return APL.ShapeLayer.new()
        :setPath(APL.Path.new()
            :moveTo(0, endlength)
            :lineTo(0, 0)
        )
        :setLineCap(APL.ShapeLayer.LINECAP.ROUND)
        :setLineJoin(APL.ShapeLayer.LINEJOIN.ROUND)
        :setStrokeStart((endlength - startLength) / (2 * endlength))
        :setStrokeEnd((endlength + startLength) / (2 * endlength))
        :setLineWidth(width)
        :setStrokeColor(GaugeColor.white)
        :setFillRule(APL.ShapeLayer.FILLRULE.NONZERO)
end












function LogoAnim.anim(displayWidth, displayHeight, animator, skipPartnerLogoFadeIn)





    local skipPartnerLogoFadeIn = skipPartnerLogoFadeIn ~= nil and skipPartnerLogoFadeIn or false

    local partnerLogoTexture = APL.TextureCache.current():getTexture("Images/partner_logo_bootup.png")
    local partnerLogoFrame = APL.Rect.new(0, 0, partnerLogoTexture:getSize())

    local appleCarPlayTexture = APL.TextureCache.current():getTexture("Images/apple_logo_bootup.png")
    local appleCarPlayFrame = APL.Rect.new(0, 0, appleCarPlayTexture:getSize())

    local dividerWidth = 4
    local dividerOffset = partnerLogoTexture:getSize() / 2 + 72 + dividerWidth / 2
    local carPlayOffset = dividerOffset + dividerWidth / 2 - 8

    local animRootLayer = APL.Layer.new()
        :setFrame(APL.Rect.new(0, 0, displayHeight, displayWidth))

    local partnerImage = APL.ImageLayer.new()
        :setTexture(partnerLogoTexture)
        :setFrame(partnerLogoFrame)
        :setPosition(displayWidth / 2, displayHeight / 2)
        :addToSuperLayer(animRootLayer)

    local divider = makeDividerLayer(dividerWidth, 0, 130)
        :setFrame(APL.Rect.new(0, 0, 0, 130))
        :setAnchorPoint(0.5, 0.5)
        :setPosition(displayWidth / 2 + dividerOffset, displayHeight / 2)
        :setOpacity(0)
        :addToSuperLayer(animRootLayer)

    local appleCarPlay = APL.ImageLayer.new()
        :setTexture(appleCarPlayTexture)
        :setFrame(appleCarPlayFrame)
        :setAnchorPoint(0, 0.5)
        :setPosition(displayWidth / 2 + carPlayOffset, displayHeight / 2)
        :setOpacity(0)
        :addToSuperLayer(animRootLayer)

    local moveDelay = 0


    if not skipPartnerLogoFadeIn then
        partnerImage:setOpacity(0)


        animator
            :animOpacity(partnerImage, 1, 0, 1)
            :ease("bezier", table.unpack(Constants.LOGOS_ANIM_CURVE))
        animator
            :animScale(partnerImage, 1, 0.65, 0.65)
            :ease("bezier", table.unpack(Constants.LOGOS_ANIM_CURVE))

        moveDelay = 100/60
    end


    local x, y = animRootLayer:getPosition()
    animator
        :animPosition(animRootLayer, 1.6667, x, y, x - dividerOffset, y)
        :ease("bezier", table.unpack(Constants.LOGOS_ANIM_CURVE))
        :delay(moveDelay)

    animator
        :anim({ strokeStart = divider:getStrokeStart(), strokeEnd = divider:getStrokeEnd() }, 1.0833, { strokeStart = 0, strokeEnd = 1 })
        :onupdate(function(tween)
            divider
                :setStrokeStart(tween.strokeStart)
                :setStrokeEnd(tween.strokeEnd)
        end)
        :ease("bezier", table.unpack(Constants.LOGOS_ANIM_CURVE2))
        :delay(moveDelay)

    animator
        :animOpacity(divider, 1.25, 0, 1)
        :ease("bezier", table.unpack(Constants.LOGOS_ANIM_CURVE2))
        :delay(moveDelay + 0.16667)


    animator
        :animOpacity(appleCarPlay, 1.3333, 0, 1)
        :ease("bezier", table.unpack(Constants.LOGOS_ANIM_CURVE2))
        :delay(moveDelay + 0.5)

    local x, y = appleCarPlay:getPosition()
    animator
        :animPosition(appleCarPlay, 1.6667, x, y, x + 80, y)
        :ease("bezier", table.unpack(Constants.LOGOS_ANIM_CURVE2))
        :delay(moveDelay)


    animator:animOpacity(animRootLayer, 1, 1, 0)
        :ease("bezier", table.unpack(Constants.LOGOS_ANIM_FADEOUT_CURVE))
        :delay(moveDelay + 2.8333)

    return animRootLayer
end

return APL.LuaUtils.readOnly(LogoAnim)
