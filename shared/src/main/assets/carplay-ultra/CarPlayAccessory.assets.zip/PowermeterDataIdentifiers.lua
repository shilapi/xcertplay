-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local PowermeterDataIdentifiers = APL.LuaUtils.namedObject(
    "PowermeterDataIdentifiers",
    { "powerDataIdentifier", "string" },
    { "powerMinDataIdentifier", "string" },
    { "powerMaxDataIdentifier", "string" },
    { "powerMarkerAvailableMinDataIdentifier", "string" },
    { "powerMarkerAvailableMaxDataIdentifier", "string" },
    { "uiSceneStateDataIdentifier", "string" },
	{ "powerStateDataIdentifier", "string" }
)







function PowermeterDataIdentifiers.fromJson(json)


    return PowermeterDataIdentifiers.new(
        json.powerDataIdentifier,
        json.powerMinDataIdentifier,
        json.powerMaxDataIdentifier,
        json.powerMarkerAvailableMinDataIdentifier,
        json.powerMarkerAvailableMaxDataIdentifier,
        json.uiSceneStateDataIdentifier,
		json.powerStateDataIdentifier
    )
end

return APL.LuaUtils.readOnly(PowermeterDataIdentifiers)
