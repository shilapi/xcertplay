-- Copyright © 2021-2026 Apple, Inc. All rights reserved.











local APL = require "APL.APL"
local Constants = require "Constants"
local Signpost = require "APL.Signpost"
local VehicleDataUpdater = require "VehicleDataUpdater"
local VehicleDataSubscriber = require "VehicleDataSubscriber"
local RequestContentState = require "RequestContentState"

local RequestContentController = APL.LuaUtils.makeObject({ _type = "RequestContentController" })








function RequestContentController.new(zoneRegion, displayPanelIdentifier)



    local self = APL.LuaUtils.newObject(RequestContentController, {
        _activeRequestContentState = APL.LuaUtils.NIL,
        _zoneRegion = zoneRegion, -- Enums.DisplayZoneIdentifier.ZONE_1 or Enums.DisplayZoneIdentifier.ZONE_2
        _displayPanelIdentifier = displayPanelIdentifier, -- "Cluster_Display"
        _dataIdentifier = VehicleDataUpdater.DATAIDENTIFIERS.requestContent,
        _vehicleDataSubscriber = VehicleDataSubscriber.new(),
        _vehicleDataUpdater = APL.LuaUtils.NIL,
        _lastValue = APL.LuaUtils.NIL,
        _requestContentSubscribers = {}
    })

    return self
end






function RequestContentController:getZoneRegion()


    return self._zoneRegion
end






function RequestContentController:getDisplayPanelIdentifier()


    return self._displayPanelIdentifier
end






function RequestContentController:destroy()


    self._vehicleDataSubscriber:destroy()
    self._vehicleDataSubscriber = nil
    self._vehicleDataUpdater = nil
    self._requestContentSubscribers = nil
end







function RequestContentController:setVehicleDataUpdater(vehicleDataUpdater)



    if vehicleDataUpdater == nil then
        self._vehicleDataSubscriber:removeSubscription()
        self._activeRequestContentState = nil
        return true
    end

    local identifiers = { self._dataIdentifier }
    local validIdentifiers, subscriber = vehicleDataUpdater:subscribe(identifiers, function(update)
        local data = update[self._dataIdentifier]

        local valuesForDisplayPanel = data and data[self._displayPanelIdentifier] or nil
        local value = valuesForDisplayPanel and valuesForDisplayPanel[self._zoneRegion] or nil
        if value and (not self._lastValue or not self._lastValue:equals(value)) then
            self._lastValue = value
            self:_setPrimaryValue(value)
        end
    end)

    self._vehicleDataSubscriber:updateSubscription(vehicleDataUpdater, subscriber)
    self._vehicleDataUpdater = vehicleDataUpdater

    return #validIdentifiers == #identifiers
end






function RequestContentController:publishLatestValues()


    if self._lastValue then
        self:_setPrimaryValue(self._lastValue )
    end

    return self
end






function RequestContentController:isZoneSupported()



    local _, data = next(self._vehicleDataUpdater:getData({ self._dataIdentifier }))
    local valuesForDisplayPanel = data and data[self._displayPanelIdentifier] or nil
    return valuesForDisplayPanel and valuesForDisplayPanel[self._zoneRegion] ~= nil or false
end






function RequestContentController:description()


    return "RequestContentController: " .. APL.LuaUtils.prettyPrint(self._activeRequestContentState)
end









function RequestContentController:_setPrimaryValue(state)



    APL.Log.info(RequestContentController, function() return "Changing active state from " ..  APL.LuaUtils.prettyPrint(self._activeRequestContentState) .. " to state " .. APL.LuaUtils.prettyPrint(state) end)

    self._activeRequestContentState = state

    for subscriber, _ in pairs(self._requestContentSubscribers) do
        subscriber.f(self._activeRequestContentState, table.unpack(subscriber.args))
    end

    return self
end








function RequestContentController:subscribe(f, ...)



    local subscriber = APL.LuaUtils.readOnly({
        f = f,
        args = {...}
    })

    self._requestContentSubscribers[subscriber] = true

    return subscriber
end








function RequestContentController:unsubscribe(subscriber)



    self._requestContentSubscribers[subscriber] = nil

    return self
end









function RequestContentController:dismissContent()


    if self._vehicleDataUpdater then
        local _, requestContentStates = next(self._vehicleDataUpdater:getData({ self._dataIdentifier }))
        requestContentStates = requestContentStates[self._displayPanelIdentifier]
        APL.Log.info(RequestContentController, function() return "User dismissed requestContent. Current requestContent states: " .. APL.LuaUtils.prettyPrint(requestContentStates) end)

        for _, requestContent in pairs(requestContentStates) do
            if self._activeRequestContentState:equals(requestContent) and requestContent.on then
                APL.Log.info(RequestContentController, function() return "User dismissed requestContent. Current requestContent: " .. APL.LuaUtils.prettyPrint(requestContent) end)

                local newState = requestContent:copy()
                newState.on = false
                self._vehicleDataUpdater:setData({ [self._dataIdentifier] = newState })
            end
        end
    end

    return self
end

return APL.LuaUtils.readOnly(RequestContentController)