-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Button = require "Button"
local Colors = require "GaugeColor"
local Popover = APL.LuaUtils.makeObject({ _type = "Popover" })








function Popover.new(inputStream, cornerRadius)



    local self = APL.LuaUtils.newObject(Popover, {
        _rootLayer = APL.LuaUtils.NIL,
        _popoverLayer = APL.LuaUtils.NIL,
        _inputStream = inputStream,
        _closeButton = APL.LuaUtils.NIL,
        _transform = APL.LuaUtils.NIL
    })

    self._rootLayer = APL.Layer.new()
        :setBackgroundColor(Colors.black)
        :setCornerRadius(cornerRadius)
        :setCornerCurve(APL.Layer.CORNER_CURVE.CONTINUOUS)
        :setMaskToBounds(true)

    self._popoverLayer = APL.Layer.new()
        :addToSuperLayer(self._rootLayer)

    self._inputStream
        :getRootLayer()
        :setOpacity(1)
        :setVisible(false)
        :addToSuperLayer(self._popoverLayer)

    return self
end







function Popover:setCloseButton(button)



    if self._closeButton and self._closeButton == button then
        return self
    end

    if self._closeButton then
        self._closeButton
            :setEnabled(false)
            :getRootLayer()
            :removeFromSuperlayer()
        self._closeButton = nil
    end

    self._closeButton = button

    if button then
        button:getRootLayer()
            :addToSuperLayer(self._rootLayer)


        self:setFrame(APL.Rect.new(self._rootLayer:getFrame()))
    end


    return self
end







function Popover:setEnabled(enabled)



    if self._closeButton then
        self._closeButton:setEnabled(enabled)
    end

    return self
end







function Popover:setFrame(frame)



    self._rootLayer:setFrame(frame)

    local transform = (function()

        local translateX, translateY = self._inputStream:getStreamBounds()
            :centeredAtBottomOfRect(frame)
            :getBounds()

        APL.Log.info(Popover, function() return "translating ADAS Popover: %f, %f", translateX, translateY end)
        return APL.Transform.newWithIdentity():translate(translateX, translateY)
    end)()
    self._inputStream:setTransform(transform)

    if self._closeButton then
        local buttonInset = 20.0
        local buttonWidth, buttonHeight = self._closeButton:preferredContentSize()
        self._closeButton:setFrame(APL.Rect.new(
            frame._width - buttonInset - buttonWidth,
            buttonInset,
            self._closeButton:preferredContentSize()
        ))
    end

    return self
end






function Popover:preferredContentSize()


    local width, height = APL.Rect.new(self._rootLayer:getFrame()):getSize()

    return width, height
end






function Popover:getRootLayer()


    return self._rootLayer
end






function Popover:destroy()


    self._rootLayer:destroy()

    if self._closeButton then
        self._closeButton:destroy()
    end
end

return APL.LuaUtils.readOnly(Popover)
