-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local DigiBarLinearStyle = APL.LuaUtils.namedObject(
    "DigiBarLinearStyle",
    { "trackWidth", "number" },
    { "leftInset", "number" },
    { "rightInset", "number" },
    { "centerOffset", "number" },
    { "isRTL", "boolean" }
)







function DigiBarLinearStyle.fromJson(jsonRepresentation)


    return DigiBarLinearStyle.new(
        jsonRepresentation.trackWidth,
        jsonRepresentation.leftInset,
        jsonRepresentation.rightInset,
        jsonRepresentation.centerOffset,
        jsonRepresentation.isRTL
    )
end

return APL.LuaUtils.readOnly(DigiBarLinearStyle)