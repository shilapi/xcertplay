-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local DigiBarLinearStyle = require "DigiBarLinearStyle"
local DigiBarRadialStyle = require "DigiBarRadialStyle"
local DigiBarRectangularStyle = require "DigiBarRectangularStyle"


local DigiBarRedlineConfiguration = APL.LuaUtils.namedObject(
    "DigiBarRedlineConfiguration",
    { "colorIDs", "table" },
    { "crossedColorIDs", "table?" },
    { "style", "*" } -- Either DigiBarRadialStyle or DigiBarLinearStyle
)

DigiBarRedlineConfiguration.fromJson = function(json)


    local colorIDs = APL.LuaUtils.numberedKeys(json.colorIDs)

    local crossedColorIDs = APL.LuaUtils.numberedKeys(json.crossedColorIDs)


    local trackConfiguration
    if json.style.radial then
        trackConfiguration = DigiBarRadialStyle.fromJson(json.style.radial.configuration)
    elseif json.style.linear then
        trackConfiguration = DigiBarLinearStyle.fromJson(json.style.linear.configuration)
    elseif json.style.rectangular then
        trackConfiguration = DigiBarRectangularStyle.fromJson(json.style.rectangular.configuration)
    else

    end

    return DigiBarRedlineConfiguration.new(colorIDs, crossedColorIDs, trackConfiguration)
end

return APL.LuaUtils.readOnly(DigiBarRedlineConfiguration)