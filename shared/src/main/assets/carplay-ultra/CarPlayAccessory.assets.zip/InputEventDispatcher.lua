-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local PressEvent = require "PressEvent"
local VehicleDataUpdater = require "VehicleDataUpdater"
local VehicleDataSubscriber = require "VehicleDataSubscriber"

local InputEventDispatcher = APL.LuaUtils.makeObject({ _type = "InputEventDispatcher" })










function InputEventDispatcher.new(vehicleDataUpdater, eventHandler)



    local self = APL.LuaUtils.newObject(InputEventDispatcher, {
        _lastButtonStates = {},
        _vehicleDataSubscriber = VehicleDataSubscriber.new(),
        _eventHandler = eventHandler
    })


    local dataIdentifiers = { VehicleDataUpdater.DATAIDENTIFIERS.buttonInput }
    local _, buttonStates = next(vehicleDataUpdater:getData(dataIdentifiers))
    self._lastButtonStates = buttonStates

    local _, subscriber = vehicleDataUpdater:subscribe(dataIdentifiers, function(update)
        local buttonStates = update[VehicleDataUpdater.DATAIDENTIFIERS.buttonInput]
        if buttonStates then
            self:handleButtonUpdate(buttonStates)
        end
    end)

    self._vehicleDataSubscriber:updateSubscription(vehicleDataUpdater, subscriber)

    return self
end







function InputEventDispatcher:handleButtonUpdate(buttonStates)



    local pressEvents = {}

    for buttonType, isPressed in pairs(buttonStates) do
        if isPressed ~= self._lastButtonStates[buttonType] then
            local phase = isPressed and PressEvent.PHASE.BEGIN or PressEvent.PHASE.END
            pressEvents[#pressEvents + 1] = PressEvent.new(buttonType, phase)
        end
    end

    self._lastButtonStates = buttonStates

    self._eventHandler(pressEvents)

    return self
end






function InputEventDispatcher:destroy()


    self._lastButtonStates = nil
    self._vehicleDataSubscriber:destroy()
    self._eventHandler = nil
end

return APL.LuaUtils.readOnly(InputEventDispatcher)