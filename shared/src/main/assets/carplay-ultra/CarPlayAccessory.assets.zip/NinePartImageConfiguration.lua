-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local NinePartImageConfiguration = APL.LuaUtils.namedObject(
    "NinePartImageConfiguration",

    { "topLeftCorner", "table" },
    { "topEdge", "table" },
    { "topRightCorner", "table" },
    { "leftEdge", "table" },
    { "middle", "table?" },
    { "rightEdge", "table" },
    { "bottomLeftCorner", "table" },
    { "bottomEdge", "table" },
    { "bottomRightCorner", "table" }
)







function NinePartImageConfiguration.fromJson(jsonRepresentation)


    return NinePartImageConfiguration.new(
        jsonRepresentation.topLeftCorner,
        jsonRepresentation.topEdge,
        jsonRepresentation.topRightCorner,
        jsonRepresentation.leftEdge,
        jsonRepresentation.middle,
        jsonRepresentation.rightEdge,
        jsonRepresentation.bottomLeftCorner,
        jsonRepresentation.bottomEdge,
        jsonRepresentation.bottomRightCorner
    )
end

return APL.LuaUtils.readOnly(NinePartImageConfiguration)
