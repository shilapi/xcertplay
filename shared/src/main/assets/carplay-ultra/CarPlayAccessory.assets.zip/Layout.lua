-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local APL = require "APL.APL"
local AppearanceController = require "AppearanceController"
local Catalog = require "Catalog"
local ChargeFuelDataIdentifiers = require "ChargeFuelDataIdentifiers"
local ChargeFuelUtils = require "ChargeFuelUtils"
local ChargeFuelLevelGaugeConfiguration = require "ChargeFuelLevelGaugeConfiguration"
local Component = require "Component"
local ConcentricRingsConfiguration = require "ConcentricRingsConfiguration"
local Constants = require "Constants"
local DigiBandGradientProgressConfiguration = require "DigiBandGradientProgressConfiguration"
local DigiBarBackground = require "DigiBarBackground"
local DigiBarMarkerGauge = require "DigiBarMarkerGauge"
local DigiBarMarkerConfiguration = require "DigiBarMarkerConfiguration"
local DigiBarProgressGauge = require "DigiBarProgressGauge"
local DigiBarBackgroundConfiguration = require "DigiBarBackgroundConfiguration"
local DigiBarConfiguration = require "DigiBarConfiguration"
local DigiBarCruiseControlConfiguration = require "DigiBarCruiseControlConfiguration"
local DigiBarMaskConfiguration = require "DigiBarMaskConfiguration"
local DriverAssistanceUtils = require "DriverAssistanceUtils"
local Enums = require "Enums"
local FocusSystem = require "FocusSystem"
local GaugeColor = require "GaugeColor"
local ImageGroupGauge = require "ImageGroupGauge"
local InputStream = require "InputStream"
local Layer = require "APL.Layer"
local MeasurementLabelConfiguration = require "MeasurementLabelConfiguration"
local LabelController = require "LabelController"
local MeasurementLabelGauge = require "MeasurementLabelGauge"
local PowermeterDataIdentifiers = require "PowermeterDataIdentifiers"
local PowermeterUtils = require "PowermeterUtils"
local ProgressBarGaugeParameters = require("ProgressBarGaugeParameters")
local ProgressController = require "ProgressController"
local RequestContentController = require "RequestContentController"
local RequestTemporaryContentController = require "RequestTemporaryContentController"
local RequestContentPopover = require "RequestContentPopover"
local DriverAssistanceConfiguration = require "DriverAssistanceConfiguration"
local Shadow = require "Shadow"
local ShapeLayerGauge = require "ShapeLayerGauge"
local SpeedometerDataIdentifiers = require "SpeedometerDataIdentifiers"
local SpeedometerTextGaugeConfiguration = require "SpeedometerTextGaugeConfiguration"
local State = require "State"
local TachometerDataIdentifiers = require "TachometerDataIdentifiers"
local TemperatureDataIdentifiers = require "TemperatureDataIdentifiers"
local TextConfiguration = require "TextConfiguration"
local TextGauge = require "TextGauge"
local TicksConfiguration = require "TicksConfiguration"
local TicksLayoutConfiguration = require "TicksLayoutConfiguration"
local Ticks = require "Ticks"
local StateController = require "StateController"
local SpeedometerUtils = require "SpeedometerUtils"
local TachometerUtils = require "TachometerUtils"
local TemperatureUtils = require "TemperatureUtils"
local VehicleDataUpdater = require "VehicleDataUpdater"
local VisibilityConfiguration = require 'VisibilityConfiguration'
local VisibilityController = require "VisibilityController"
local Zone = require "Zone"
local LayoutInfo = require "LayoutInfo"

local Layout = APL.LuaUtils.makeObject({ _type = "Layout" })


Layout.MODE = APL.LuaUtils.readOnly({
    OFF = 0,                -- Blank screen
    EXIT = 100,             -- Show odometer if not drawn natively.
    OUTLINE = 200,          -- Show outline of gauges without any values.
    ACCESSORY = 300,        -- Show most elements except for a few.
    DRIVE = 400,            -- Show all elements are visible.
})
local MODE_TYPES = APL.LuaUtils.getValues(Layout.MODE)


Layout.PROGRESS_CONTROLLER_TYPE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "CHARGE_FUEL",
    "CHARGE_FUEL_LOW_LEVEL",
    "CHARGE",
    "CHARGE_LOW_LEVEL",
    "FUEL",
    "FUEL_LOW_LEVEL",
    "SPEED",
    "POWER",
    "POWER_CONSUMED_LIMIT",
    "POWER_REGENERATED_LIMIT",
    "TACHOMETER",
    "TACHOMETER_REDLINE",
    "TACHOMETER_DETACHED_NOMINAL",
    "TACHOMETER_DETACHED_REDLINE",
    "TARGET_SPEED",
    "TEMPERATURE",
    "TEMPERATURE_COLD_MARKER",
    "TEMPERATURE_HOT_MARKER",
}, false))
local PROGRESS_CONTROLLER_TYPES = APL.LuaUtils.getValues(Layout.PROGRESS_CONTROLLER_TYPE)


Layout.LABEL_CONTROLLER_TYPE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "PRIMARY_SPEED",
    "SECONDARY_SPEED_WITH_UNIT",
    "ENGINE_BATTERY_TEMPERATURE",
    "OUTSIDE_TEMPERATURE",
    "SPEED_LIMITER_LABEL",
    "CHARGE_FUEL_RANGE",
    "FUEL_RANGE",
    "CHARGE_RANGE",
    "ROTATIONAL_SPEED",
    "FUEL_EFFICIENCY",
    "CHARGE_LEVEL"
}, false))
local LABEL_CONTROLLER_TYPES = APL.LuaUtils.getValues(Layout.LABEL_CONTROLLER_TYPE)
















function Layout.new(layoutInfo, appearanceState, frame, vehicleDataUpdater, inputStreamInfoByType, inputStreamInfoById, notifications, shadows, displayPanelIdentifier, initialPopoverUpdates)











    local self = APL.LuaUtils.newObject(Layout, {
        _displayPanelIdentifier = displayPanelIdentifier,
        _layoutInfo = layoutInfo,
        _appearanceController = AppearanceController.new(appearanceState),
        _frame = frame,

        _inputStreams = {},
        _inputStreamInfoByType = inputStreamInfoByType,
        _inputStreamInfoById = inputStreamInfoById,

        _vehicleDataUpdater = vehicleDataUpdater,
        _vehicleDataConnected = false,
        _vehicleDataSubscribers = {},

        _zones = {},
        _components = {},
        _componentByGauge = {},
        _persistentGauges = {},
        _gaugesBySlotPositionID = {},
        _zoneByComponentIDs = {},

        _requestContentControllers = {}, -- Contents will either be of type RequestContentController or RequestTemporaryContentController

        _attached = false,
        _rootLayer = APL.LuaUtils.NIL,
        _layoutRootLayer = APL.LuaUtils.NIL,
        _persistentGaugesLayer = APL.LuaUtils.NIL,
        _popoverLayers = {},
        _popoverShadowLayersContainer = APL.LuaUtils.NIL,
        _popoverShadowLayers = {},
        _fader = APL.LuaUtils.NIL,

        _controllers = {},
        _progressControllers = {},
        _stateControllers = {},
        _labelControllers = {},
        _visibilityControllersByGauge = {},

        _focusSystem = APL.LuaUtils.NIL,
        _notifications = notifications,
        _shadows = shadows,

        _layoutMode = Layout.MODE.OFF, -- Default to all off

        _transitionTargetComponentIDs = APL.LuaUtils.NIL,
        _punchoutLayer = APL.LuaUtils.NIL,

        _allowFadeToBlack = true, -- if false, the fader will never be applied on a layout transition

        _lastPopoverUpdates = initialPopoverUpdates or APL.LuaUtils.NIL -- tracks the most recent popover transition data applied. nil if no popover visible.
    })

    self._rootLayer = APL.Layer.new()
        :setVisible(false)
        :setFrame(self._frame)

    self._focusSystem = FocusSystem.new()

    self:_build()


    local lastActiveDCAComponents = State.getActiveDCAComponentIDs() or {}
    APL.LuaUtils.forEach(self._zones, function(zone)
        if zone:isDCA() then

            local activeComponent = lastActiveDCAComponents[zone:getID()] or zone:getPrimaryComponentIDs()[1]
            zone:setActiveComponent(activeComponent)
        end
    end)

    if self._lastPopoverUpdates then
        APL.Log.info(Layout, function() return "Applying popover transition data to new layout" .. APL.LuaUtils.prettyPrint(self._lastPopoverUpdates) end)
        for popoverID, transitionData in pairs(self._lastPopoverUpdates) do
            self:_applyPopoverTransitionData(popoverID, transitionData)
        end
    end

    return self
end






function Layout:destroy()




    for gauge in pairs(self._componentByGauge) do
        self._controllers[gauge] = nil
    end

    APL.LuaUtils.forEach(self._zones, function(zone)
        zone:destroy()
    end)
    self._componentByGauge = nil

    for controller, _ in pairs(self._controllers) do
        controller:destroy()
    end
    self._controllers = nil

    APL.LuaUtils.forEach(self._visibilityControllersByGauge, function(visibilityController)
        visibilityController:destroy()
    end)
    self._visibilityControllersByGauge = nil

    APL.LuaUtils.forEach(self._vehicleDataSubscribers, function(subscriber)
        subscriber:destroy()
    end)
    self._vehicleDataSubscribers = nil

    APL.LuaUtils.forEach(self._requestContentControllers, function(controller)
        controller:destroy()
    end)
    self._requestContentControllers = nil

    self._focusSystem:destroy()

    APL.LuaUtils.forEach(self._popoverLayers, function(layer)
        layer:destroy()
    end)
    self._popoverLayers = nil

    APL.LuaUtils.forEach(self._popoverShadowLayers, function(layer)
        layer:destroy()
    end)
    self._popoverShadowLayers = nil

    self._popoverShadowLayersContainer:destroy()
    self._popoverShadowLayersContainer = nil

    self._layoutRootLayer:destroy()
    self._layoutRootLayer = nil

    self._fader:destroy()
    self._fader = nil

    self._rootLayer:destroy()
    self._rootLayer = nil
end






function Layout:getID()


    return self._layoutInfo:getID()
end






function Layout:getZones()


    return self._zones
end






function Layout:getDisplayName()


    return self._layoutInfo:getDisplayName()
end






function Layout:getKind()


    return self._layoutInfo:getKind()
end






function Layout:getVisible()


    return self._rootLayer:getVisible()
end






function Layout:getPaletteID()


    return self._appearanceController:getState().palette:getID()
end








function Layout:attach(parentLayer, isFullyVisible)




    APL.Log.info(Layout, function() return "Attaching layout=\"%s\" (%s), isFullyVisible=%s", self:getDisplayName(), self:getID(), tostring(isFullyVisible) end)

    self._rootLayer:setVisible(true)





    if isFullyVisible then
        self._persistentGaugesLayer:setVisible(true)

        self._fader
            :setOpacity(0)
            :setVisible(false)
    end


    for _, inputStream in pairs(self._inputStreams) do
        if inputStream:getRootLayer():getVisible() then
            inputStream:subscribe()
        end
    end

    parentLayer:addSublayer(self._rootLayer)

    self._attached = true

    return self:_connectVehicleData()
end






function Layout:detach()



    if not self._attached then
        return self
    end

    APL.Log.info(Layout, function() return "Detaching layout \"%s\" (%s)", self:getDisplayName(), self:getID() end)

    self._rootLayer:removeFromSuperlayer()


    self._persistentGaugesLayer:setVisible(true)
    self._fader:setVisible(false)


    for _, inputStream in pairs(self._inputStreams) do
        if inputStream:getRootLayer():getVisible() then
            inputStream:unsubscribe()
        end
    end

    self:hideRemoteUI(false, false)

    self._attached = false

    return self:_disconnectVehicleData()
end






function Layout:isAttached()


    return self._attached
end








function Layout:showRemoteUI(animated, delay)




    APL.Log.info(Layout, function() return "Showing remote UI on layout .. " .. self:getDisplayName() end)

    APL.LuaUtils.forEach(self._popoverLayers, function(layer)
        layer
            :animOpacity(1, animated and Constants.REMOTEUI_FADEIN_DURATION or 0)
            :ease("bezier", table.unpack(Constants.REMOTEUI_CURVE))
            :delay(delay or 0)
            :onstart(function()
                layer:setVisible(true)
            end)
    end)

    self._popoverShadowLayersContainer
        :animOpacity(1, animated and Constants.REMOTEUI_FADEIN_DURATION or 0)
        :ease("bezier", table.unpack(Constants.REMOTEUI_CURVE))
        :delay(delay or 0)
        :onstart(function()
            self._popoverShadowLayersContainer:setVisible(true)
        end)

    return self
end








function Layout:hideRemoteUI(disconnected, animated)




    APL.Log.info(Layout, function() return "Hiding remote UI on layout .. " .. self:getDisplayName() .. " Disconnected: " .. tostring(disconnected) end)

    for popoverID, layer in pairs(self._popoverLayers) do
        layer
            :animOpacity(0, animated and Constants.REMOTEUI_FADEOUT_DURATION or 0)
            :ease("bezier", table.unpack(Constants.REMOTEUI_CURVE))
            :oncomplete(function()
                layer:setVisible(false)
            end)
    end

    self._popoverShadowLayersContainer
        :animOpacity(0, animated and Constants.REMOTEUI_FADEOUT_DURATION or 0)
        :ease("bezier", table.unpack(Constants.REMOTEUI_CURVE))
        :oncomplete(function()
            self._popoverShadowLayersContainer:setVisible(false)
        end)

    APL.LuaUtils.forEach(self._zones, function(zone)


        if disconnected then
            self:endZoneTransition()
        end
    end)

    return self
end






function Layout:getZones()


    return self._zones
end







function Layout:getInputStreamsByKind(kind)



    local result = {}

    for identifier, inputStream in pairs(self._inputStreams) do
        if inputStream:getKind() == kind then

            result[identifier] = inputStream
        end
    end

    return result
end






function Layout:getFocusSystem()


    return self._focusSystem
end






function Layout:setFocusEnabled(enabled)



    APL.Log.info(Layout, function() return "Setting focus to %s for layout \"%s\" (%s)", (enabled and "enabled" or "disabled"), self:getDisplayName(), self:getID() end)

    self._focusSystem:setEnabled(enabled)

    return self
end









function Layout:setLayoutMode(mode, animated, animationInitialDelay)






    if mode == self._layoutMode then
        return self
    end

    APL.Log.info(Layout, function() return "Setting layout mode: %s For layout: \"%s\" (%s): ", mode, self:getDisplayName(), self:getID() end)

    self._layoutMode = mode
    if self._vehicleDataConnected then
        self:_setGaugesVisibilityHandler(mode, animated, animationInitialDelay)
    end

    local resetRequestContentController = function(zoneRegionIdentifier)



            if self._vehicleDataConnected then
                local controller = zoneRegionIdentifier and self._requestContentControllers[zoneRegionIdentifier]
                if controller then
                    APL.Log.info(
                        Layout,
                        "Resetting data source for requestContentController - layout mode changed. Layout: %s, ZoneRegion: %s",
                        self:getDisplayName(),
                        tostring(zoneRegionIdentifier)
                    )
                    controller:publishLatestValues()
                end
            end
        end


    APL.LuaUtils.forEach(self._zones, function(zone)
        if mode == Layout.MODE.ACCESSORY or mode == Layout.MODE.DRIVE then


            zone:showDCA(
                animated and Constants.REMOTEUI_FADEIN_DURATION or 0,
                animationInitialDelay,
                function()
                    resetRequestContentController(zone:getZoneRegion())
                end
            )
        else
            zone:hideDCA(animated and Constants.REMOTEUI_FADEOUT_DURATION or 0)
            resetRequestContentController(zone:getZoneRegion())
        end
    end)

    return self
end






function Layout:getLayoutMode()


    return self._layoutMode
end







function Layout:startZoneTransition(targetComponentIDs)



    self._transitionTargetComponentIDs = targetComponentIDs

    APL.Log.info(Layout,
        "Starting zone transition with target components: %s on layout \"%s\" (%s): ",
        APL.LuaUtils.prettyPrint(targetComponentIDs),
        self:getDisplayName(),
        self:getID()
    )

    return self
end






function Layout:endZoneTransition()


    if self._transitionTargetComponentIDs then
        APL.Log.info(Layout, function() return "Ending zone transition with target components: %s on layout \"%s\" (%s): ", APL.LuaUtils.prettyPrint(self._transitionTargetComponentIDs), self:getDisplayName(), self:getID() end)

        APL.LuaUtils.forEach(self._zones, function(zone)
            if zone:isDCA() then
                zone:setActiveComponent(self._transitionTargetComponentIDs[zone:getID()])
            end
        end)


        State.setActiveDCAComponentIDs(APL.LuaUtils.merge(State.getActiveDCAComponentIDs() or {}, self._transitionTargetComponentIDs))

        self._transitionTargetComponentIDs = nil
    end

    return self
end







function Layout:setActiveDCAComponentIDs(componentIDs)



    APL.Log.info(Layout, function() return "Setting active DCA component IDs: %s on layout \"%s\" (%s): ", APL.LuaUtils.prettyPrint(componentIDs), self:getDisplayName(), self:getID() end)


    State.setActiveDCAComponentIDs(APL.LuaUtils.merge(State.getActiveDCAComponentIDs() or {}, componentIDs))

    APL.LuaUtils.forEach(self._zones, function(zone)
        local componentID = componentIDs[zone:getID()]
        if zone:isDCA() and componentID then
            zone:setActiveComponent(componentID)
        end
    end)




    if self._vehicleDataConnected then
        APL.LuaUtils.forEach(self._requestContentControllers, function(requestContentController)
            APL.Log.info(Layout, function() return "Resetting data source for requestContentController - Active DCA component set. Layout: " .. self:getDisplayName() .. ". ZoneRegion: " .. requestContentController:getZoneRegion() end)
            requestContentController:publishLatestValues()
        end)
    end

    return self
end






function Layout:getActiveDCAComponentIDs()


    local componentIDs = {}

    APL.LuaUtils.forEach(self._zones, function(zone)
        if zone:isDCA() then
            local activeComponent = zone:getActiveComponent()
            componentIDs[zone:getID()] = activeComponent and activeComponent:getID() or nil
        end
    end)

    APL.Log.info(Layout, function() return "Getting active DCA component IDs: %s for layout \"%s\" (%s): ", APL.LuaUtils.prettyPrint(componentIDs), self:getDisplayName(), self:getID() end)

    return componentIDs
end












function Layout:_setGaugesVisibilityHandler(mode, firstUpdateAnimated, animationInitialDelay)





    local animated = firstUpdateAnimated

    if APL.Config.readParam("TESTING.ANIMATIONS.QUICK") then
        APL.Log.log(Layout, "Testing: using quick animations .. forcing animated to false")
        animated = false
    end

    APL.Log.info(Layout, function() return "_setGaugesVisibilityHandler mode=%s, firstUpdateAnimated=%s, animationInitialDelay=%s", tostring(mode), tostring(firstUpdateAnimated), tostring(animationInitialDelay) end)

    for gauge, controller in pairs(self._visibilityControllersByGauge) do
        controller:setVisibilityUpdateHandler(self._vehicleDataUpdater, mode, animationInitialDelay or 0, function(visibility, animationDelay)



            local delay = visibility.animation.delay + animationDelay
            local duration = visibility.animation.duration


            if not animated or (delay == 0 and duration == 0) then
                APL.Log.debug(Layout, function() return "Setting opacity: %s, animated: %s, duration: %s, delay: %s for gauge: \"%s\"", tostring(visibility.opacity), tostring(animated), tostring(visibility.animation.duration), tostring(delay), gauge:description() end)

                gauge:getRootLayer()
                    :setOpacity(visibility.opacity)
                    :setVisible(visibility.opacity > 0)
            else
                APL.Log.debug(Layout, function() return "Animating opacity: %s, animated: %s, duration: %s, delay: %s for gauge: \"%s\"", tostring(visibility.opacity), tostring(animated), tostring(visibility.animation.duration), tostring(delay), gauge:description() end)

                gauge:getRootLayer()
                    :animOpacity(visibility.opacity, duration)
                    :ease("bezier", table.unpack(visibility.animation.bezierCurve))
                    :delay(delay)
                    :onstart(function()
                        if visibility.opacity > 0 then



                            gauge:getRootLayer()
                                :setVisible(true)
                        end
                    end)
                    :oncomplete(function()

                        if visibility.opacity == 0 then
                            gauge:getRootLayer()
                                :setVisible(false)
                        end

                        APL.Log.debug(Layout, function() return "Animated opacity: %s for gauge: \"%s\"", tostring(gauge:getRootLayer():getOpacity()),  gauge:description() end)
                    end)
            end
        end)
    end

    APL.Log.debug(Layout, function() return "_setGaugesVisibilityHandler: setting animated to true" end)


    animated = true


    if APL.Config.readParam("TESTING.ANIMATIONS.QUICK") then
        APL.Log.log(Layout, "Testing: using quick animations .. forcing animated to false")
        animated = false
    end

    return self
end







function Layout:setAppearance(appearanceState)




    if self._appearanceController:setState(appearanceState) then
        APL.Log.log(Layout, "Layout " .. self:getDisplayName() .. " - Appearance appearance changed to " .. APL.LuaUtils.prettyPrint(appearanceState))
    else
        APL.Log.log(Layout, "Layout " .. self:getDisplayName() .. " - Appearance did not change, ignoring...")
    end

    return self
end






function Layout:_connectVehicleData()


    if self._vehicleDataConnected then
        return self
    end

    self._vehicleDataConnected = true
    APL.Log.info(Layout, function() return "Connecting vehicle data to layout \"%s\" (%s)", self:getDisplayName(), self:getID() end)

    for controller, info in pairs(self._controllers) do
        APL.Log.info(Layout, function() return "Connecting vehicle data to controller: " .. tostring(info) end)
        local success = controller:setVehicleDataUpdater(self._vehicleDataUpdater)
        if not success then
            APL.Log.error(Layout, function() return "Unable to set data source for controller: " .. tostring(info) end)
        end
    end


    self:_setGaugesVisibilityHandler(self._layoutMode, false)

    APL.LuaUtils.forEach(self._requestContentControllers, function(requestContentController)
        local zoneIdentifier = requestContentController:getZoneRegion()
        APL.Log.debug(Layout, function() return "Setting data source for requestContentController on zone: " .. zoneIdentifier .. " - vehicle data connected on layout." end)
        local success = requestContentController:setVehicleDataUpdater(self._vehicleDataUpdater)
        if not success then
            APL.Log.error(Layout, function() return "Unable to set data source for requestContentController on zone: " .. zoneIdentifier end)
        end
    end)


    local supportedZones = 0
    for _, controller in pairs(self._requestContentControllers) do
        supportedZones = supportedZones + (controller:isZoneSupported() and 1 or 0)
    end

    self._focusSystem:setAlwaysShowFocusEffects(supportedZones > 1)

    return self
end






function Layout:_disconnectVehicleData()


    if not self._vehicleDataConnected then
        return self
    end

    self._vehicleDataConnected = false
    APL.Log.info(Layout, function() return "Disconnecting vehicle data from layout: \"%s\" (%s)", self:getDisplayName(), self:getID() end)

    for controller, _ in pairs(self._controllers) do
        controller:setVehicleDataUpdater(nil)
    end

    APL.LuaUtils.forEach(self._requestContentControllers, function(requestContentController)
        requestContentController:setVehicleDataUpdater(nil)
    end)

    APL.LuaUtils.forEach(self._visibilityControllersByGauge, function(controller)
        controller:unsubscribe()
    end)

    return self
end







function Layout:_updatesFromTransitionData(transitionData)



    local updates = APL.LuaUtils.reduce(transitionData.regions, { components = {}, layouts = {}, popovers = {} }, function(result, region)
        if not region.identifier then
            return result
        end
        APL.Log.debug(Layout, function() return "Region found in transition metadata: " .. APL.LuaUtils.prettyPrint(region) end)
        region.cumulative_opacity = region.cumulative_opacity or region.opacity


        local component = (function(id)
            if #id > 5 and APL.LuaUtils.hasPrefix(id, "comp:") then
                local componentIdentifier = string.sub(id, 6)
                return self._components[componentIdentifier]
            elseif #id > 7 and APL.LuaUtils.hasPrefix(id, "stream:") then
                local streamIdentifier = string.sub(id, 8)
                local gauge = self._inputStreams[streamIdentifier]
                return gauge and self._componentByGauge[gauge] or nil
            end

            return nil
        end)(region.identifier)
        if component then
            result.components[component] = region
            return result
        end


        local layoutID = (function(id)
            if #id > 7 and APL.LuaUtils.hasPrefix(id, "layout:") then
                return string.sub(id, 8)
            end
            return nil
        end)(region.identifier)
        if layoutID and (layoutID == self:getID()) then
            result.layouts[layoutID] = region
            return result
        end


        local popoverID = (function(id)
            if #id > 8 and APL.LuaUtils.hasPrefix(id, "popover:") then
                return string.sub(id, 9)
            end
            return nil
        end)(region.identifier)
        if popoverID then
            result.popovers[popoverID] = region
            return result
        end

        return result
    end)

    return updates
end










function Layout:applyTransitionData(transitionData, layoutTransitionDirection, persistentGaugesVisibilityOverride, ignoreUpdates)






    if transitionData.regions == nil then
        APL.Log.warn(Layout, function() return "No regions found in transition metadata: " .. APL.LuaUtils.prettyPrint(transitionData) end)
        return
    end

    local updates = self:_updatesFromTransitionData(transitionData)
    local ignoreUpdates = ignoreUpdates or {}



    if self._transitionTargetComponentIDs == nil then
        ignoreUpdates.components = true
    end

    if next(ignoreUpdates) then
        APL.Log.info(Layout, function() return "Ignoring transition metadata: %s", APL.LuaUtils.prettyPrint(APL.LuaUtils.getKeys(ignoreUpdates)) end)
        for key, _ in pairs(ignoreUpdates) do
            updates[key] = {}
        end
    end

    for component, transitionData in pairs(updates.components) do
        self:_applyComponentTransitionData(component, transitionData)
    end

    for _, transitionData in pairs(updates.layouts) do
        self:_applyLayoutTransitionData(transitionData, layoutTransitionDirection, persistentGaugesVisibilityOverride)
    end

    for popoverID, transitionData in pairs(updates.popovers) do
        self:_applyPopoverTransitionData(popoverID, transitionData)
    end

    self._lastPopoverUpdates = updates.popovers


    for popoverID, _ in pairs(self._popoverLayers) do
        if updates.popovers[popoverID] == nil then
            APL.Log.info(Layout, function() return "Removing stale popover " .. popoverID end)
            local layer = self._popoverLayers[popoverID]
            self._popoverLayers[popoverID] = nil
            layer:destroy()
        end
    end


    for popoverID, _ in pairs(self._popoverShadowLayers) do
        if updates.popovers[popoverID] == nil then
            APL.Log.info(Layout, function() return "Removing stale popover shadow" .. popoverID end)
            local shadow = self._popoverShadowLayers[popoverID]
            self._popoverShadowLayers[popoverID] = nil
            shadow:destroy()
        end
    end

    return self
end






function Layout:getLastPopoverUpdates()
    return self._lastPopoverUpdates
end






function Layout:getPersistentGaugesVisible()


    return self._rootLayer:getVisible() and self._persistentGaugesLayer:getVisible()
end






function Layout:hasPersistentGauges()


    return APL.LuaUtils.effectiveSize(self._persistentGauges) > 0
end








function Layout:_applyPopoverTransitionData(popoverID, transitionData)




    local opacity = transitionData.cumulative_opacity
    local parameters = APL.LuaUtils.urlQueryParameters(transitionData.identifier)

    APL.Log.debug(Layout, function() return "Applying popover transition metadata: %s", APL.LuaUtils.prettyPrint(transitionData, false, 4) end)
    if self._layoutInfo:getKind() ~= LayoutInfo.KIND.UNDERLAY then
        local zone = parameters["zone"] and self._zones[parameters["zone"]]

        if not zone or not (zone:getZoneRegion() == Enums.DisplayZoneIdentifier.ZONE_1 or zone:getZoneRegion() == Enums.DisplayZoneIdentifier.ZONE_2) then
            return
        end

        local popoverLayerFrame = APL.Rect.new(table.unpack(transitionData.bounds))
        local zoneFrame = APL.Rect.new(zone:getRootLayer():getFrame())

        if (zoneFrame._width + zoneFrame._x < popoverLayerFrame._width + popoverLayerFrame._x) then
            APL.Log.error(Layout, function() return "Malformed data. Popover exceeds zone horizontally. Popover frame: %s Zone frame: %s", APL.LuaUtils.prettyPrint(popoverLayerFrame), APL.LuaUtils.prettyPrint(zoneFrame) end)
            return
        end
        if (zoneFrame._height + zoneFrame._y < popoverLayerFrame._height + popoverLayerFrame._y) then
            APL.Log.error(Layout, function() return "Malformed data. Popover exceeds zone vertically. Popover frame: %s Zone frame: %s", APL.LuaUtils.prettyPrint(popoverLayerFrame), APL.LuaUtils.prettyPrint(zoneFrame) end)
            return
        end
    else



        if not parameters["zone"] then
            return
        end
    end


    if opacity <= 0 then
        local layer = self._popoverLayers[popoverID]
        self._popoverLayers[popoverID] = nil
        if layer then
            APL.Log.info(Layout, function() return "Removing zero opacity popover " .. popoverID end)
            layer:destroy()
        end

        local shadow = self._popoverShadowLayers[popoverID]
        self._popoverShadowLayers[popoverID] = nil
        if shadow then
            APL.Log.info(Layout, function() return "Removing zero opacity shadow " .. popoverID end)
            shadow:destroy()
        end

        self._lastPopoverUpdates = nil

        return
    end

    local bounds = APL.Rect.new(table.unpack(transitionData.bounds))
    local transform = APL.Transform.new(table.unpack(transitionData.transform2D))
    local layer = self._popoverLayers[popoverID] or APL.Layer.new()
    layer
        :setAnchorPoint(0, 0) -- Anchor point must be 0,0 as the transform is in world coordinate
        :setBounds(bounds)
        :setTransform(transform)
        :setBackgroundColor("#FFFFFFFF")
        :setBlendMode(APL.Layer.BLEND_MODE.DESTOUT)
        :setOpacity(opacity)
        :setVisible(true)

    if self._punchoutLayer then


        layer:addToSuperLayer(self._punchoutLayer)
    else
        layer:addToSuperLayer(self._layoutRootLayer)
    end

    local shadowID = parameters["shadowID"]
    if shadowID then
        local shadowConfig = self._shadows[shadowID]
        if shadowConfig then
            local shadow = self._popoverShadowLayers[popoverID] or Shadow.new(shadowConfig)

            shadow
                :setContentFrame(APL.Rect.new(layer:getFrame()))

            shadow
                :getRootLayer()
                :setOpacity(opacity)
                :setVisible(true)
                :addToSuperLayer(self._popoverShadowLayersContainer)

            self._popoverShadowLayers[popoverID] = shadow
        else
            APL.Log.error(Layout, function() return "Ignoring unknown shadow: " .. shadowID end)
        end
    end

    if transitionData.corner_radius then
        layer
            :setCornerRadius(transitionData.corner_radius or 0)
            :setCornerCurve(transitionData.continuous_corners and Layer.CORNER_CURVE.CONTINUOUS or Layer.CORNER_CURVE.CIRCULAR)
    end

    self._popoverLayers[popoverID] = layer

    return self
end









function Layout:_applyLayoutTransitionData(transitionData, layoutTransitionDirection, persistentGaugesVisibilityOverride)





    APL.Log.debug(Layout, function() return "Applying layout transition metadata: %s", APL.LuaUtils.prettyPrint(transitionData, false, 4) end)

    local opacity = math.max(0, math.min(transitionData.cumulative_opacity, 1))
    local bounds = APL.Rect.new(table.unpack(transitionData.bounds))
    local transform = APL.Transform.new(table.unpack(transitionData.transform2D))
    local visible = opacity > 0 and true or false
    local persistentGaugesVisible = visible

    APL.Log.debug(Layout, "Transition data for layout \"%s\" (%s): opacity = %s, layoutTransitionDirection = %s, override = %s",
        self:getDisplayName(), self:getID(), tostring(opacity), tostring(layoutTransitionDirection), tostring(persistentGaugesVisibilityOverride or "nil"))


    if self:hasPersistentGauges() then
        if persistentGaugesVisibilityOverride ~= nil then
            persistentGaugesVisible = persistentGaugesVisibilityOverride
            APL.Log.debug(Layout, function() return "Forcing visibility of persistent gauges for layout \"%s\" (%s): %s", self:getDisplayName(), self:getID(), persistentGaugesVisibilityOverride and "visible" or "hidden" end)
        end

        if persistentGaugesVisible ~= self._persistentGaugesLayer:getVisible() then
            APL.Log.info(Layout, function() return "Setting visibility of persistent gauges for layout \"%s\" (%s): %s", self:getDisplayName(), self:getID(), persistentGaugesVisible and "visible" or "hidden" end)
            APL.Signpost.emitEvent("Setting visibility of persistent gauges for layout %s to %s", self:getID(), persistentGaugesVisible and "visible" or "hidden")

            self._persistentGaugesLayer:setVisible(persistentGaugesVisible)
        end
    end

    self._layoutRootLayer
        :setAnchorPoint(0, 0) -- Anchor point must be 0,0 as the transform is in world coordinate
        :setFrame(self._frame) -- Frame must be re-applied when anchor point changes
        :setBounds(bounds)
        :setTransform(transform)


    self._rootLayer:setVisible(visible or persistentGaugesVisible)


    self._fader
        :setOpacity(1 - opacity)
        :setVisible(self._allowFadeToBlack and visible)

    return self
end








function Layout:_applyComponentTransitionData(component, transitionData)




    APL.Log.debug(Layout, function() return "Applying component transition metadata: %s", APL.LuaUtils.prettyPrint(transitionData, false, 4) end)

    local opacity = transitionData.cumulative_opacity
    local transformData = transitionData.transform2D
    if opacity ~= nil and transformData then
        local transform = APL.Transform.new(table.unpack(transformData))
        component
            :setVisible(opacity > 0)
            :applyTransitionData(transform, opacity)
    end

    return self
end






function Layout:_build()


    APL.Log.info(Layout, function() return "Loading layout \"%s\" (%s)", self:getDisplayName(), self:getID() end)

    local frame = APL.Rect.new(self._rootLayer:getFrame())
    local rootLayerZones = self._layoutInfo:getZones()


    self._layoutRootLayer = self:_buildLayoutLayer(frame, rootLayerZones)
        :addToSuperLayer(self._rootLayer)

    self._popoverShadowLayersContainer = APL.Layer.new()
        :setName("PopoverShadowsLayersContainer " .. self:getDisplayName())
        :setFrame(self._frame)
        :addToSuperLayer(self._layoutRootLayer)


    self._fader = APL.Layer.new()
        :setFrame(self._frame)
        :setBackgroundColor(GaugeColor.black)
        :setVisible(false)
        :addToSuperLayer(self._rootLayer)


    self._persistentGaugesLayer = APL.Layer.new()
        :setFrame(self._frame)
        :addToSuperLayer(self._rootLayer)



    for gauge, _ in pairs(self._persistentGauges) do
        local layer = gauge:getRootLayer()
        layer:setFrame(layer:convertFrameToSuperLayer(self._layoutRootLayer))
            :removeFromSuperlayer()
            :addToSuperLayer(self._persistentGaugesLayer)
    end

    APL.Log.debug(Layout, function() return "Layout Zones: " .. APL.LuaUtils.prettyPrint(self._zones, true) end)

    return self
end








function Layout:getPunchoutLayer()
    return self._punchoutLayer
end








function Layout:setAllowFadeToBlack(allowFadeToBlack)



    self._allowFadeToBlack = allowFadeToBlack

    return self
end








function Layout:_buildLayoutLayer(frame, layoutZones)





    local layer = APL.Layer.new()
        :setFrame(frame)


    APL.LuaUtils.forEach(layoutZones, function(layoutZone)
        APL.Signpost.measure("Loading zone \"" .. layoutZone.displayName .. "\"", function()
            local zoneRegionIdentifier = layoutZone.zoneRegion
            if zoneRegionIdentifier and not self._requestContentControllers[zoneRegionIdentifier] then



                local requestContentSubscribable = self._vehicleDataUpdater:isSubscribable(VehicleDataUpdater.DATAIDENTIFIERS.requestContent)
                local requestTemporaryContentSubscribable = self._vehicleDataUpdater:isSubscribable(VehicleDataUpdater.DATAIDENTIFIERS.requestTemporaryContent)
                local dynamicContentElementSubscribable = self._vehicleDataUpdater:isSubscribable(VehicleDataUpdater.DATAIDENTIFIERS.dynamicContentElement)

                if requestTemporaryContentSubscribable and dynamicContentElementSubscribable then
                    APL.Log.debug(Layout, function() return "Creating RequestTemporaryContentController for zone id: " .. layoutZone.id .. " with zone region identifier: " .. zoneRegionIdentifier end)

                    self._requestContentControllers[zoneRegionIdentifier] = RequestTemporaryContentController.new(
                        zoneRegionIdentifier,
                        self._displayPanelIdentifier
                    )
                elseif requestContentSubscribable then
                APL.Log.debug(Layout, function() return "Creating RequestContentController for zone id: " .. layoutZone.id .. " with zone region identifier: " .. zoneRegionIdentifier end)

                self._requestContentControllers[zoneRegionIdentifier] = RequestContentController.new(
                    zoneRegionIdentifier,
                    self._displayPanelIdentifier
                )
                end
            end

            local zoneRect = APL.Rect.new(table.unpack(layoutZone.frame))

            local components = self:_buildComponents(layoutZone)
            local zone = Zone.new(
                layoutZone.id,
                components,
                zoneRect,
                layoutZone.type,
                layoutZone.shape,
                zoneRegionIdentifier
            )
            self._zones[layoutZone.id] = zone

            APL.LuaUtils.forEach(components, function(component)
                self._zoneByComponentIDs[component:getID()] = zone
            end)


            zone:getRootLayer()
                :addToSuperLayer(layer)

            if self._layoutInfo:getKind() == LayoutInfo.KIND.UNDERLAY then



                self._punchoutLayer = self._punchoutLayer or APL.Layer.new():setBlendMode(APL.Layer.BLEND_MODE.DESTOUT):setBackgroundColor(GaugeColor.clear)
                local newPunchoutZoneRect = APL.Rect.new(self._punchoutLayer:getFrame()):union(zoneRect)
                self._punchoutLayer:setFrame(newPunchoutZoneRect)

                local cornerRadius = (layoutZone.shape and layoutZone.shape.rectangular and layoutZone.shape.rectangular.cornerRadius) or 0



                local externalContent = APL.Layer.new()

                externalContent
                    :setFrame(zoneRect)
                    :setBackgroundColor(GaugeColor.black)
                    :setCornerRadius(cornerRadius)
                    :addToSuperLayer(self._punchoutLayer)
            end
        end)
    end)


    return layer
end







function Layout:_buildComponents(zone)



    local COMPONENT_TYPES = APL.LuaUtils.readOnly({
        primary = Component.TYPE.PRIMARY,
        overlay = Component.TYPE.OVERLAY
    })

    local buildComponent = function(component)

        local slots = APL.LuaUtils.duplicate(component.slots)
        table.sort(slots, function(lhs, rhs)
            return lhs.zIndex < rhs.zIndex
        end)

        local gauges = APL.LuaUtils.flatMap(slots, function(slot)
                local gauges = slot.instrument
                    and self:_buildGauges(
                        slot,
                        self._requestContentControllers[zone.zoneRegion]
                    )
                    or {}

                if slot.positionId then
                    self._gaugesBySlotPositionID[slot.positionId] = { slot, gauges }
                end

                APL.LuaUtils.forEach(gauges, function(gauge)
                    APL.Log.debug(Layout, function() return string.format("Created instrument: %s", gauge:description()) end)


                    if slot.instrument.globalConfiguration.persistent then
                        self._persistentGauges[gauge] = true
                    end


                    if APL.LuaUtils.getClassName(gauge) == "InputStream" then
                        local streamIdentifier = gauge:getStreamIdentifier()

                        self._inputStreams[streamIdentifier] = gauge
                    end
                end)

                return gauges
        end)


        if #gauges == 0 then
            return nil
        end


        local result = Component.new(
            COMPONENT_TYPES[component.type],
            component.id,
            component.displayName,
            APL.Rect.new(table.unpack(zone.frame)),
            gauges
        )


        APL.LuaUtils.forEach(gauges, function(gauge)
            self._componentByGauge[gauge] = result
        end)
        self._components[component.id] = result

        APL.Log.debug(Layout, function() return "Created component ".. result:description() end)

        return result
    end

    return APL.LuaUtils.compactMap(zone.components, function(component)
        return APL.Signpost.measure("Loading component \"" .. component.displayName .. "\" (" .. component.id .. ")", function()
            return buildComponent(component)
        end)
    end)
end








function Layout:_buildGauges(slot, requestContentController)






    local gauges = {}
    local instrument = slot.instrument
    local style = slot.style
    local slotFrame = APL.Rect.new(table.unpack(slot.frame))


    if instrument.kind == "gauge" then
        local gauge = self:_buildGauge(instrument.style, style)
        if gauge then
            if instrument.visibilityConfiguration then
                local visibilityConfiguration = VisibilityConfiguration.fromJson(instrument.visibilityConfiguration)
                local visibilityController = VisibilityController.newWithConfiguration(visibilityConfiguration)
                self._visibilityControllersByGauge[gauge] = visibilityController

                APL.Log.debug(Layout, function() return 'Created VisibilityController with config %s for gauge %s', tostring(visibilityConfiguration), gauge:description() end)


                gauge:getRootLayer()
                    :setVisible(false)
            end

            gauges[#gauges+1] = gauge:setFrame(slotFrame)
        end

    elseif instrument.kind == "indicator" then
        if not requestContentController then
            APL.Log.error(Layout, function() return "Indicator cannot be created without a requestContentController" end)
        else
            local gauge = Catalog.Indicator.new(
                slotFrame,
                instrument,
                self._focusSystem,
                requestContentController,
                self._appearanceController,
                self._notifications,
                self._shadows[instrument.globalConfiguration.shadowID]
            )
            gauges[#gauges+1] = gauge

            self._controllers[gauge] = gauge:description()
        end

    elseif instrument.kind == "widgetPopover" then
        local streamName = instrument.configuration.location.localRenderer and instrument.configuration.location.localRenderer.configuration.streamName
        local adasStreamInfo = streamName and self._inputStreamInfoById[streamName]

        if not adasStreamInfo then
            APL.Log.error(Layout, function() return "No adasView input stream found" end)
        elseif not requestContentController then
            APL.Log.error(Layout, function() return "Popover for adasView cannot be created without a requestContentController" end)
        else
            local requestContentPopover = RequestContentPopover.new(
                    self:_createInputStream(adasStreamInfo, slotFrame),
                    requestContentController,
                    self._focusSystem,
                    self._appearanceController,
                    instrument,
                    40.0,
                    self._shadows[instrument.globalConfiguration.shadowID],
                    function()


                        local inputStream = self._inputStreams[streamName]
                        local prevent = inputStream and inputStream:getRootLayer():getVisible() or false
                        APL.Log.info(Layout, function() return "Evaluating presentation conditions for RequestContentPopover. Layout Mode: " .. tostring(self._layoutMode) .. ". Input stream already visible: " .. tostring(prevent) .. ". Layout: " .. self:getDisplayName() end)

                        if self._layoutMode == Layout.MODE.ACCESSORY or self._layoutMode == Layout.MODE.DRIVE then
                            return prevent
                        end
                        return true
                    end
                )
                :setFrame(slotFrame)

            gauges[#gauges+1] = requestContentPopover
        end
    elseif instrument.kind == "punchThroughType" then
        local newGauges = (function()

            local kinds = APL.LuaUtils.readOnly({
                camera = InputStream.KIND.CAMERA,
                setting = InputStream.KIND.SETTINGS
            })

            if not instrument.type or not kinds[instrument.type] then
                APL.Log.error(Layout, function() return "Invalid punchThroughType: " .. APL.LuaUtils.prettyPrint(instrument) end)
                return {}
            end

            local kind = kinds[instrument.type]
            APL.Log.info(Layout, function() return "Looking for input streams matching type: %d (%s)", kind, instrument.type end)

            return APL.LuaUtils.compactMap(self._inputStreamInfoByType[kind] or {}, function(streamInfo)
                return self:_createInputStream(streamInfo, slotFrame, instrument.dataIdentifier)
            end)
        end)()

        gauges = APL.LuaUtils.merge(gauges, newGauges)
    elseif instrument.kind == "inputStream" or instrument.kind == "punchThrough" then
        local streamInfo = self._inputStreamInfoById[instrument.streamIdentifier]
        if not streamInfo then
            APL.Log.error(Layout, function() return "No input stream found with identifier: " .. instrument.streamIdentifier end)
        else
            local gauge = streamInfo and self:_createInputStream(
                streamInfo,
                slotFrame,
                instrument.dataIdentifier
            )

            if instrument.visibilityConfiguration then
                local visibilityConfiguration = VisibilityConfiguration.fromJson(instrument.visibilityConfiguration)
                local visibilityController = VisibilityController.newWithConfiguration(visibilityConfiguration)
                self._visibilityControllersByGauge[gauge] = visibilityController
            end

            gauges[#gauges+1] = gauge
        end
    end

    if #gauges == 0 then
        APL.Log.error(Layout, function() return "Unable to load instrument: " .. APL.LuaUtils.prettyPrint(instrument, false, 6) end)
    end

    return gauges
end









function Layout:_createInputStream(streamInfo, slotFrame, dataIdentifier)




    local transform = (function()
        local streamBounds = APL.Rect.new(0, 0, streamInfo.width, streamInfo.height)


        local translateX, translateY = (function()
            if streamInfo.kind == InputStream.KIND.WIDGET then

                return streamBounds
                    :centeredAtBottomOfRect(slotFrame)
                    :getBounds()
            else
                return streamBounds
                    :centeredInRect(slotFrame)
                    :getBounds()
            end
        end)()

        APL.Log.info(Layout, function() return "translating %s: %f, %f", streamInfo.identifier, translateX, translateY end)
        return APL.Transform.newWithIdentity():translate(translateX, translateY)
    end)()

    local inputStream = InputStream.new(
        streamInfo.identifier,
        dataIdentifier,
        streamInfo.frameDuration,
        streamInfo.type,
        APL.Rect.new(0, 0, streamInfo.width, streamInfo.height)
    ):setTransform(transform)



    if streamInfo.kind == InputStream.KIND.ROADSIGN then
        local path = APL.Path.new()
            :rectangleIn(APL.Rect.new(0, 0, slotFrame._width, slotFrame._height))


        local mask = APL.ShapeLayer.new()
            :setFrame(slotFrame)
            :setPath(path)
            :setFillColor(GaugeColor.white)
            :setFillRule(APL.ShapeLayer.FILLRULE.NONZERO)

        inputStream:setMask(mask)
    end


    if dataIdentifier then
        self._controllers[inputStream] = inputStream:description()
    end

    return inputStream
end








function Layout:_buildGauge(gaugeStyle, slotStyle)




    local gauge
    local appearanceController = self._appearanceController

    if gaugeStyle.progressBar then
        gauge = self:_createRadialProgressGauge(gaugeStyle.progressBar.type, appearanceController)

    elseif gaugeStyle.textElement then
        local config = gaugeStyle.textElement.configuration

        if config.dataType.gearPosition then
            local stateController = self:_getStateController(config.dataType.gearPosition.configuration.dataIdentifier)
            local gearShiftImageGroupConfig = config.dataType.gearPosition.configuration.gearShiftImageGroupConfig
            local gearShiftImageGroupGauge
            if gearShiftImageGroupConfig then
                local gearShiftStateController = gearShiftImageGroupConfig.dataIdentifier and self:_getStateController(gearShiftImageGroupConfig.dataIdentifier)
                local criticalStateController = gearShiftImageGroupConfig.criticalStateDataIdentifier and self:_getStateController(gearShiftImageGroupConfig.criticalStateDataIdentifier)
                gearShiftImageGroupGauge = ImageGroupGauge.new(
                    gearShiftImageGroupConfig,
                    appearanceController,
                    gearShiftStateController,
                    criticalStateController
                )
            end

            gauge = Catalog.GearPositionGauge.new(
                config.dataType.gearPosition.configuration,
                GaugeColor,
                stateController,
                appearanceController,
                gearShiftImageGroupConfig,
                gearShiftImageGroupGauge
            )

        elseif config.dataType.dynamic then
            local configuration = TextConfiguration.fromJson(config.dataType.dynamic.configuration)
            local textController
            local tintController
            if configuration.dataIdentifier then
                textController = self:_getStateController(config.dataType.dynamic.configuration.dataIdentifier)

            end

            if configuration.colorDataIdentifier then
                tintController = self:_getStateController(config.dataType.dynamic.configuration.colorDataIdentifier)

            end

            gauge = TextGauge.new(configuration, appearanceController, textController, tintController)
        elseif config.dataType.speedLimiter then
            local dataIdentifiers = DriverAssistanceConfiguration.DataIdentifiers.fromJson(config.dataType.speedLimiter.dataIdentifiers)
            local labelController = self:_getLabelController(
                Layout.LABEL_CONTROLLER_TYPE.SPEED_LIMITER_LABEL,
                dataIdentifiers.cruiseControlSpeedDataIdentifier,
                dataIdentifiers.speedUnitDataIdentifier,
                dataIdentifiers.cruiseControlStateDataIdentifier
            )
            local stateController = self:_getStateController(dataIdentifiers.cruiseControlStateDataIdentifier)
            local speedLimitedStateController = self:_getStateController(dataIdentifiers.speedLimitedDataIdentifier)
            local configuration = MeasurementLabelConfiguration.fromJson(config.dataType.speedLimiter.labelConfiguration)



            if stateController and speedLimitedStateController then
                gauge = MeasurementLabelGauge.newSpeedLimiter(
                    configuration,
                    labelController,
                    stateController,
                    speedLimitedStateController,
                    appearanceController
                )
            end
        elseif config.dataType.speed then
            local configuration = SpeedometerTextGaugeConfiguration.fromJson(config.dataType.speed.configuration)
            local controller = self:_getLabelController(Layout.LABEL_CONTROLLER_TYPE.PRIMARY_SPEED, configuration.dataIdentifier, configuration.unitDataIdentifier)


            if controller then
                gauge = MeasurementLabelGauge.newPrimarySpeed(
                    configuration.labelConfiguration,
                    controller,
                    appearanceController
                )
            end
        elseif config.dataType.speedUnit then
            local configuration = SpeedometerTextGaugeConfiguration.fromJson(config.dataType.speedUnit.configuration)
            local controller = self:_getLabelController(Layout.LABEL_CONTROLLER_TYPE.PRIMARY_SPEED, configuration.dataIdentifier, configuration.unitDataIdentifier)


            if controller then
                gauge = MeasurementLabelGauge.newSpeedUnit(
                    configuration.labelConfiguration,
                    controller,
                    appearanceController
                )
            end
        elseif config.dataType.secondarySpeedWithUnit then
            local configuration = SpeedometerTextGaugeConfiguration.fromJson(config.dataType.secondarySpeedWithUnit.configuration)
            local controller = self:_getLabelController(Layout.LABEL_CONTROLLER_TYPE.SECONDARY_SPEED_WITH_UNIT, configuration.dataIdentifier, configuration.unitDataIdentifier)


            if controller then
                gauge = MeasurementLabelGauge.newPrimarySpeed(
                    configuration.labelConfiguration,
                    controller,
                    appearanceController
                )
            end
        elseif config.dataType.remainingChargeFuelRange then
            local chargeConfig = ChargeFuelLevelGaugeConfiguration.fromJson(config.dataType.remainingChargeFuelRange.configuration)
            local rangeTextConfig = chargeConfig.remainingRangeTextConfiguration
            local measurementLabelConfiguration = rangeTextConfig.labelConfiguration



            local controllerType = Layout.LABEL_CONTROLLER_TYPE.CHARGE_FUEL_RANGE
            if rangeTextConfig.remainingRangeDataIdentifier == VehicleDataUpdater.DATAIDENTIFIERS.remainingBatteryDistance then
                controllerType = Layout.LABEL_CONTROLLER_TYPE.CHARGE_RANGE
            elseif rangeTextConfig.remainingRangeDataIdentifier == VehicleDataUpdater.DATAIDENTIFIERS.remainingFuelDistance then
                controllerType = Layout.LABEL_CONTROLLER_TYPE.FUEL_RANGE
            end
            local controller = self:_getLabelController(
                controllerType,
                chargeConfig.remainingRangeTextConfiguration.remainingRangeDataIdentifier,
                chargeConfig.remainingRangeTextConfiguration.unitDataIdentifier
            )
            local stateController = self:_getStateController(chargeConfig.levelStateDataIdentifier)
            local portSideController = self:_getStateController(chargeConfig.portSideIndicatorDataIdentifier)




            if controller and stateController and portSideController then
                gauge = MeasurementLabelGauge.newRemainingChargeRange(
                    measurementLabelConfiguration,
                    controller,
                    stateController,
                    portSideController,
                    appearanceController
                )
            end
        elseif config.dataType.temperature then
            local dataIdentifiers = TemperatureDataIdentifiers.fromJson(config.dataType.temperature.dataIdentifiers)
            local temperatureDataIdentifier = dataIdentifiers.temperatureDataIdentifier
            local unitDataIdentifier = dataIdentifiers.temperatureUnitDataIdentifier
            local labelController = self:_getLabelController(
                Layout.LABEL_CONTROLLER_TYPE.ENGINE_BATTERY_TEMPERATURE,
                temperatureDataIdentifier,
                unitDataIdentifier
            )
            local stateController = self:_getStateController(dataIdentifiers.temperatureStateDataIdentifier)



            if labelController and stateController then
                local labelConfiguration = MeasurementLabelConfiguration.fromJson(config.dataType.temperature.labelConfiguration)
                gauge = MeasurementLabelGauge.newTemperature(
                    labelConfiguration,
                    labelController,
                    stateController,
                    appearanceController
                )
            end
        elseif config.dataType.outsideTemperature then
            local temperatureDataIdentifier = config.dataType.outsideTemperature.dataIdentifiers.temperatureDataIdentifier
            local unitDataIdentifier = config.dataType.outsideTemperature.dataIdentifiers.unitDataIdentifier
            local controller = self:_getLabelController(Layout.LABEL_CONTROLLER_TYPE.OUTSIDE_TEMPERATURE, temperatureDataIdentifier, unitDataIdentifier)


            if controller then
                local labelConfiguration = MeasurementLabelConfiguration.fromJson(config.dataType.outsideTemperature.labelConfiguration)
                gauge = MeasurementLabelGauge.newOutsideTemperature(
                    labelConfiguration,
                    controller,
                    appearanceController
                )
            end
        elseif config.dataType.rotationalSpeed then
            local rpmDataIdentifier = config.dataType.rotationalSpeed.dataIdentifier
            local controller = self:_getLabelController(Layout.LABEL_CONTROLLER_TYPE.ROTATIONAL_SPEED, rpmDataIdentifier, nil)


            local labelConfiguration = MeasurementLabelConfiguration.fromJson(config.dataType.rotationalSpeed.labelConfiguration)
            gauge = MeasurementLabelGauge.newGenericLabel(
                labelConfiguration,
                controller,
                appearanceController,
                "RotationalSpeed"
            )
        elseif config.dataType.fuelEfficiency then
            local fuelEfficiencyDataIdentifier = config.dataType.fuelEfficiency.dataIdentifiers.dataIdentifier
            local unitDataIdentifier = config.dataType.fuelEfficiency.dataIdentifiers.unitDataIdentifier
            local controller = self:_getLabelController(Layout.LABEL_CONTROLLER_TYPE.FUEL_EFFICIENCY, fuelEfficiencyDataIdentifier, unitDataIdentifier)


            local labelConfiguration = MeasurementLabelConfiguration.fromJson(config.dataType.fuelEfficiency.labelConfiguration)
            gauge = MeasurementLabelGauge.newFuelEfficiency(
                labelConfiguration,
                controller,
                appearanceController,
                "FuelEfficiency",
                config.dataType.fuelEfficiency.identifier
            )
        elseif config.dataType.chargeLevel then
            local chargeLevelDataIdentifier = config.dataType.chargeLevel.dataIdentifier
            local controller = self:_getLabelController(Layout.LABEL_CONTROLLER_TYPE.CHARGE_LEVEL, chargeLevelDataIdentifier, nil)


            local labelConfiguration = MeasurementLabelConfiguration.fromJson(config.dataType.chargeLevel.labelConfiguration)
            gauge = MeasurementLabelGauge.newGenericLabel(
                labelConfiguration,
                controller,
                appearanceController,
                "ChargeLevel"
            )
        else

        end

    elseif gaugeStyle.imageGroup then
        local configuration = gaugeStyle.imageGroup.configuration
        local stateController = configuration.dataIdentifier and self:_getStateController(configuration.dataIdentifier)
        local criticalStateController = configuration.criticalStateDataIdentifier and self:_getStateController(configuration.criticalStateDataIdentifier)
        gauge = Catalog.ImageGroupGauge.new(
            configuration,
            appearanceController,
            stateController,
            criticalStateController
        )
    elseif gaugeStyle.shapeLayer then
        APL.Log.debug(Layout, function() return "Creating ShapeLayerGauge with configuration: " .. APL.LuaUtils.prettyPrint(gaugeStyle.shapeLayer.configuration, false, 3) end)
        gauge = ShapeLayerGauge.new(gaugeStyle.shapeLayer.configuration, appearanceController)
    end

    if not gauge then
        APL.Log.error(Layout, function() return "Invalid Gauge Style: " .. APL.LuaUtils.prettyPrint(gaugeStyle, false, 10) end)
    end

    return gauge
end








function Layout:_getProgressController(controllerType, dataIdentifiers)




    if not self._progressControllers[controllerType] then
        local progressDataIdentifiers
        local progressForUpdate
        local animationDuration
        local animationDamping
        if controllerType == Layout.PROGRESS_CONTROLLER_TYPE.SPEED then


            local _, maxSpeeds = next(self._vehicleDataUpdater:getData({ dataIdentifiers.vehicleSpeedMaxDataIdentifier }))
            if not maxSpeeds then

                return nil
            end
            progressForUpdate = SpeedometerUtils.progressForUpdate(
                maxSpeeds,
                dataIdentifiers.vehicleSpeedDataIdentifier,
                dataIdentifiers.vehicleSpeedUnitDataIdentifier,
                dataIdentifiers.uiSceneStateDataIdentifier,
                true
            )
            progressDataIdentifiers = {
                dataIdentifiers.vehicleSpeedDataIdentifier,
                dataIdentifiers.vehicleSpeedUnitDataIdentifier,
                dataIdentifiers.uiSceneStateDataIdentifier
            }
        elseif controllerType == Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER then

            local _, engineRPMMax = next(self._vehicleDataUpdater:getData({ dataIdentifiers.engineRPMMaxDataIdentifier }))
            if not engineRPMMax then

                return nil
            end
            progressForUpdate = TachometerUtils.progressForUpdate(engineRPMMax, dataIdentifiers.dataIdentifier, dataIdentifiers.uiSceneStateDataIdentifier)
            progressDataIdentifiers = { dataIdentifiers.dataIdentifier, dataIdentifiers.uiSceneStateDataIdentifier }
        elseif controllerType == Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_DETACHED_NOMINAL or controllerType == Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_DETACHED_REDLINE then

            local engineMaxValues = self._vehicleDataUpdater:getData({ dataIdentifiers.markerRedlineDataIdentifier, dataIdentifiers.engineRPMMaxDataIdentifier })
            if not engineMaxValues then

                return nil
            end
            local detachedType = controllerType == Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_DETACHED_NOMINAL
                and TachometerUtils.DETACHED_REGION.NOMINAL
                or TachometerUtils.DETACHED_REGION.REDLINE
            progressForUpdate = TachometerUtils.progressForDetachedUpdate(
                engineMaxValues,
                dataIdentifiers.dataIdentifier,
                dataIdentifiers.markerRedlineDataIdentifier,
                dataIdentifiers.engineRPMMaxDataIdentifier,
                dataIdentifiers.uiSceneStateDataIdentifier,
                detachedType
            )
            progressDataIdentifiers = { dataIdentifiers.dataIdentifier, dataIdentifiers.markerRedlineDataIdentifier, dataIdentifiers.uiSceneStateDataIdentifier }
        elseif controllerType == Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_REDLINE then

            local _, engineRPMMax = next(self._vehicleDataUpdater:getData({ dataIdentifiers.engineRPMMaxDataIdentifier }))
            if not engineRPMMax then

                return nil
            end
            progressForUpdate = TachometerUtils.progressForRedlineUpdate(engineRPMMax, dataIdentifiers.markerRedlineDataIdentifier)
            progressDataIdentifiers = { dataIdentifiers.markerRedlineDataIdentifier }
        elseif controllerType == Layout.PROGRESS_CONTROLLER_TYPE.POWER then

            local initial = PowermeterUtils.getInitialVehicleDataValues(self._vehicleDataUpdater, dataIdentifiers)
            if not initial then

                return nil
            end
            progressForUpdate = PowermeterUtils.getNormalizedPower(dataIdentifiers.powerDataIdentifier, dataIdentifiers.uiSceneStateDataIdentifier, initial)
            progressDataIdentifiers = { dataIdentifiers.powerDataIdentifier, dataIdentifiers.uiSceneStateDataIdentifier }
        elseif controllerType == Layout.PROGRESS_CONTROLLER_TYPE.POWER_CONSUMED_LIMIT then

            local initial = PowermeterUtils.getInitialVehicleDataValues(self._vehicleDataUpdater, dataIdentifiers)
            if not initial then

                return nil
            end
            progressForUpdate = PowermeterUtils.getNormalizedConsumedPower(dataIdentifiers.powerMarkerAvailableMaxDataIdentifier, initial)
            progressDataIdentifiers = { dataIdentifiers.powerMarkerAvailableMaxDataIdentifier }
        elseif controllerType == Layout.PROGRESS_CONTROLLER_TYPE.POWER_REGENERATED_LIMIT then

            local initial = PowermeterUtils.getInitialVehicleDataValues(self._vehicleDataUpdater, dataIdentifiers)
            if not initial then

                return nil
            end
            progressForUpdate = PowermeterUtils.getNormalizedRegeneratedPower(dataIdentifiers.powerMarkerAvailableMinDataIdentifier, initial)
            progressDataIdentifiers = { dataIdentifiers.powerMarkerAvailableMinDataIdentifier }
        elseif controllerType == Layout.PROGRESS_CONTROLLER_TYPE.CHARGE_FUEL or controllerType == Layout.PROGRESS_CONTROLLER_TYPE.FUEL or controllerType == Layout.PROGRESS_CONTROLLER_TYPE.CHARGE then

            progressForUpdate = ChargeFuelUtils.progressNormalizer(dataIdentifiers.levelDataIdentifier)
            progressDataIdentifiers = { dataIdentifiers.levelDataIdentifier }
        elseif controllerType == Layout.PROGRESS_CONTROLLER_TYPE.CHARGE_FUEL_LOW_LEVEL or controllerType == Layout.PROGRESS_CONTROLLER_TYPE.CHARGE_LOW_LEVEL or controllerType == Layout.PROGRESS_CONTROLLER_TYPE.FUEL_LOW_LEVEL then

            progressForUpdate = ChargeFuelUtils.progressNormalizer(dataIdentifiers.levelMarkerLowDataIdentifier)
            progressDataIdentifiers = { dataIdentifiers.levelMarkerLowDataIdentifier }
        elseif controllerType == Layout.PROGRESS_CONTROLLER_TYPE.TEMPERATURE then

            local initialValues = TemperatureUtils.getInitialVehicleDataValues(self._vehicleDataUpdater, dataIdentifiers)
            if not initialValues then

                return nil
            end
            progressForUpdate = TemperatureUtils.progressNormalizer(initialValues, dataIdentifiers.temperatureDataIdentifier)
            progressDataIdentifiers = { dataIdentifiers.temperatureDataIdentifier }
        elseif controllerType == Layout.PROGRESS_CONTROLLER_TYPE.TEMPERATURE_COLD_MARKER then

            local initialValues = TemperatureUtils.getInitialVehicleDataValues(self._vehicleDataUpdater, dataIdentifiers)
            if not initialValues then

                return nil
            end
            progressForUpdate = TemperatureUtils.progressNormalizer(initialValues, dataIdentifiers.coldTemperatureMarkerDataIdentifier)
            progressDataIdentifiers = { dataIdentifiers.coldTemperatureMarkerDataIdentifier }
        elseif controllerType == Layout.PROGRESS_CONTROLLER_TYPE.TEMPERATURE_HOT_MARKER then

            local initialValues = TemperatureUtils.getInitialVehicleDataValues(self._vehicleDataUpdater, dataIdentifiers)
            if not initialValues then

                return nil
            end
            progressForUpdate = TemperatureUtils.progressNormalizer(initialValues, dataIdentifiers.hotTemperatureMarkerDataIdentifier)
            progressDataIdentifiers = { dataIdentifiers.hotTemperatureMarkerDataIdentifier }
        elseif controllerType == Layout.PROGRESS_CONTROLLER_TYPE.TARGET_SPEED then




            local _, maxSpeeds = next(self._vehicleDataUpdater:getData({dataIdentifiers.speedMaxDataIdentifier}))
            if not maxSpeeds then

                return nil
            end
            progressForUpdate = DriverAssistanceUtils.progressForTargetSpeedUpdate(
                maxSpeeds,
                dataIdentifiers.cruiseControlSpeedDataIdentifier,
                dataIdentifiers.speedUnitDataIdentifier,
                dataIdentifiers.cruiseControlStateDataIdentifier
            )
            progressDataIdentifiers = { dataIdentifiers.cruiseControlSpeedDataIdentifier, dataIdentifiers.speedUnitDataIdentifier, dataIdentifiers.cruiseControlStateDataIdentifier }
            animationDuration = Constants.PROGRESS_ANIMATION_DURATION
        end

        if not progressForUpdate or not progressDataIdentifiers then

            return nil
        end

        local subscribable, invalidDataIdentifiers = self._vehicleDataUpdater:isSubscribable(table.unpack(progressDataIdentifiers))
        if not subscribable then
            APL.Log.error(LabelController, function() return "Unable to create ProgressController for " .. controllerType .. ". Vehicle doesn't support " .. APL.LuaUtils.joinStrings(invalidDataIdentifiers, ", ") end)

            return nil
        end

        local progressController = ProgressController.new(
            progressDataIdentifiers,
            progressForUpdate,
            animationDuration,
            animationDamping
        )

        self._progressControllers[controllerType] = progressController
        self._controllers[progressController] = progressController:description()
    end

    return self._progressControllers[controllerType]
end







function Layout:_getStateController(dataIdentifier)



    if not self._stateControllers[dataIdentifier] then
        if not self._vehicleDataUpdater:isSubscribable(dataIdentifier) then
            APL.Log.error(LabelController, function() return "Unable to create StateController: vehicle doesn't support " .. dataIdentifier end)

            return nil
        end

        local stateController = StateController.new(
            dataIdentifier,
            self._vehicleDataUpdater:getData({dataIdentifier})[dataIdentifier]
        )

        self._stateControllers[dataIdentifier] = stateController
        self._controllers[stateController] = stateController:description()
    end

    return self._stateControllers[dataIdentifier]
end

local LABEL_VALUE_UPDATER_BY_CONTROLLER_TYPE










function Layout:_getLabelController(controllerType, valueDataIdentifier, unitDataIdentifier, stateDataIdentifier)






    if not LABEL_VALUE_UPDATER_BY_CONTROLLER_TYPE then
        LABEL_VALUE_UPDATER_BY_CONTROLLER_TYPE = APL.LuaUtils.readOnly({
            [Layout.LABEL_CONTROLLER_TYPE.PRIMARY_SPEED] = SpeedometerUtils.displaySpeedForUpdate,
            [Layout.LABEL_CONTROLLER_TYPE.SECONDARY_SPEED_WITH_UNIT] = SpeedometerUtils.alternativeSpeedForUpdate,
            [Layout.LABEL_CONTROLLER_TYPE.ENGINE_BATTERY_TEMPERATURE] = TemperatureUtils.temperatureDisplayTextForUpdate,
            [Layout.LABEL_CONTROLLER_TYPE.OUTSIDE_TEMPERATURE] = TemperatureUtils.temperatureDisplayTextForUpdate,
            [Layout.LABEL_CONTROLLER_TYPE.SPEED_LIMITER_LABEL] = DriverAssistanceUtils.displaySpeedForUpdate(),
            [Layout.LABEL_CONTROLLER_TYPE.CHARGE_FUEL_RANGE] = ChargeFuelUtils.remainingRangeForUpdate,
            [Layout.LABEL_CONTROLLER_TYPE.CHARGE_RANGE] = ChargeFuelUtils.remainingRangeForUpdate,
            [Layout.LABEL_CONTROLLER_TYPE.FUEL_RANGE] = ChargeFuelUtils.remainingRangeForUpdate,
            [Layout.LABEL_CONTROLLER_TYPE.ROTATIONAL_SPEED] = TachometerUtils.rpmTextForUpdate,
            [Layout.LABEL_CONTROLLER_TYPE.FUEL_EFFICIENCY] = ChargeFuelUtils.fuelEfficiencyForUpdate,
            [Layout.LABEL_CONTROLLER_TYPE.CHARGE_LEVEL] = ChargeFuelUtils.chargeLevelForUpdate
        })
    end

    if not self._labelControllers[controllerType] then
        local valueForUpdate = LABEL_VALUE_UPDATER_BY_CONTROLLER_TYPE[controllerType]
        if not valueForUpdate then

            APL.Log.error(Layout, function() return "No valueForUpdate found for controller type: " .. tostring(controllerType) end)
            return nil
        end

        local subscribable, invalidDataIdentifiers = self._vehicleDataUpdater:isSubscribable(valueDataIdentifier, unitDataIdentifier, stateDataIdentifier)
        if not subscribable then
            APL.Log.error(LabelController, function() return "Unable to create LabelController for " .. controllerType .. ". Vehicle doesn't support " .. APL.LuaUtils.joinStrings(invalidDataIdentifiers, ", ") end)

            return nil
        end

        local labelController = LabelController.new(
            valueForUpdate,
            valueDataIdentifier,
            unitDataIdentifier,
            stateDataIdentifier
        )

        self._labelControllers[controllerType] = labelController
        self._controllers[labelController] = labelController:description()
    end

    return self._labelControllers[controllerType]
end








function Layout:_createRadialProgressGauge(radialProgressType, appearanceController)




    local gauge

    local ticksConfig, ticksMode = (function()
        if radialProgressType.tickmarks then
            return radialProgressType.tickmarks, Ticks.MODE.TICKMARKS
        elseif radialProgressType.tickLabels then
            return radialProgressType.tickLabels, Ticks.MODE.LABELS
        elseif radialProgressType.tickOrnamentLabels then
            return radialProgressType.tickOrnamentLabels, Ticks.MODE.ORNAMENTS
        else
            return nil
        end
    end)()

    if ticksMode and ticksConfig then
        local ticksConfiguration = TicksConfiguration.fromJson(ticksConfig.configuration)

        if ticksConfig.dataSource.speedometer then
            local dataSource = ticksConfig.dataSource.speedometer
            local dataIdentifiers = SpeedometerDataIdentifiers.fromJson(dataSource.dataIdentifiers)
            local speedProgressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.SPEED, dataIdentifiers)
            local speedUnitController = self:_getStateController(dataIdentifiers.vehicleSpeedUnitDataIdentifier)



            if speedProgressController and speedUnitController then
                local _, maxSpeeds = next(self._vehicleDataUpdater:getData({dataIdentifiers.vehicleSpeedMaxDataIdentifier}))
                local parameters = {}
                for unit, maxSpeed in pairs(maxSpeeds) do
                    parameters[unit] = Ticks.progressBarParameters(
                        ticksConfiguration,
                        maxSpeed,
                        SpeedometerUtils.MIN_LABELS_COUNT,
                        SpeedometerUtils.MAX_LABELS_COUNT,
                        SpeedometerUtils.LABEL_INTERVALS
                    )
                end
                gauge = DigiBarProgressGauge.newTicks(
                    speedProgressController,
                    appearanceController,
                    nil,
                    speedUnitController,
                    nil,
                    parameters,
                    ticksMode,
                    "SpeedometerTickmarks"
                )
            else

            end
        elseif ticksConfig.dataSource.tachometer then
            local dataSource = ticksConfig.dataSource.tachometer
            local dataIdentifiers = TachometerDataIdentifiers.fromJson(dataSource.dataIdentifiers)
            local _, engineRPMMax = next(self._vehicleDataUpdater:getData({dataIdentifiers.engineRPMMaxDataIdentifier}))
            local parameters = {
                Ticks.progressBarParameters(
                    ticksConfiguration,
                    engineRPMMax,
                    TachometerUtils.MIN_LABELS_COUNT,
                    TachometerUtils.MAX_LABELS_COUNT,
                    TachometerUtils.LABEL_INTERVALS
                )
            }

            local stateController = self:_getStateController(dataIdentifiers.engineRPMStateDataIdentifier)
            local tachometerProgressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER, dataIdentifiers)
            local redlineController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_REDLINE, dataIdentifiers)




            if tachometerProgressController and redlineController then
                gauge = DigiBarProgressGauge.newTicks(
                    tachometerProgressController,
                    appearanceController,
                    redlineController,
                    nil,
                    stateController,
                    parameters,
                    ticksMode,
                    "TachometerTickmarks"
                )
            else

            end
        elseif ticksConfig.dataSource.powermeterConsumed then
            local dataSource = ticksConfig.dataSource.powermeterConsumed
            local dataIdentifiers = PowermeterDataIdentifiers.fromJson(dataSource.dataIdentifiers)
            local initial = PowermeterUtils.getInitialVehicleDataValues(self._vehicleDataUpdater, dataIdentifiers)
            local parameters = {
                Ticks.progressBarParameters(
                    ticksConfiguration,
                    initial.consumedPowerMax,
                    PowermeterUtils.CONSUMED_MIN_LABELS_COUNT,
                    PowermeterUtils.CONSUMED_MAX_LABELS_COUNT,
                    PowermeterUtils.CONSUMED_LABEL_INTERVALS
                )
            }

            local stateController = self:_getStateController(dataIdentifiers.powerStateDataIdentifier)
            local progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER, dataIdentifiers)
            local redlineController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER_CONSUMED_LIMIT, dataIdentifiers)




            if progressController and redlineController and stateController then
                local modifier = function(value) return { 0, math.max(0, value) } end
                gauge = DigiBarProgressGauge.newTicks(
                    progressController,
                    appearanceController,
                    redlineController,
                    nil,
                    stateController,
                    parameters,
                    ticksMode,
                    "PowermeterConsumedTickmarks",
                    modifier
                )
            else

            end
        elseif ticksConfig.dataSource.powermeterRegenerated then
            local dataSource = ticksConfig.dataSource.powermeterRegenerated
            local dataIdentifiers = PowermeterDataIdentifiers.fromJson(dataSource.dataIdentifiers)
            local initial = PowermeterUtils.getInitialVehicleDataValues(self._vehicleDataUpdater, dataIdentifiers)
            local parameters = {
                Ticks.progressBarParameters(
                    ticksConfiguration,
                    initial.consumedPowerMax,
                    PowermeterUtils.CONSUMED_MIN_LABELS_COUNT,
                    PowermeterUtils.CONSUMED_MAX_LABELS_COUNT,
                    PowermeterUtils.CONSUMED_LABEL_INTERVALS
                )
            }

            local progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER, dataIdentifiers)
            local redlineController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER_REGENERATED_LIMIT, dataIdentifiers)



            if progressController and redlineController then
                local modifier = function(value) return { 0, math.max(0, -value) } end
                gauge = DigiBarProgressGauge.newTicks(
                    progressController,
                    appearanceController,
                    redlineController,
                    nil,
                    nil,
                    parameters,
                    ticksMode,
                    "PowermeterRegenTickmarks",
                    modifier
                )
            else

            end
        elseif ticksConfig.dataSource.powermeter then -- like powermeter consumed but also displays the regenerated progress, used for layouts such as hybrid.
            local dataSource = ticksConfig.dataSource.powermeter
            local dataIdentifiers = PowermeterDataIdentifiers.fromJson(dataSource.dataIdentifiers)
            local initial = PowermeterUtils.getInitialVehicleDataValues(self._vehicleDataUpdater, dataIdentifiers)
            local parameters = {
                ProgressBarGaugeParameters.new(
                    ticksConfiguration,
                    TicksLayoutConfiguration.newWithLabelsCountAndConfig(ticksConfiguration.tickLabelsConfiguration.maxLabelsCount, ticksConfiguration),
                    ticksConfiguration.tickLabelsConfiguration.labelOverrides
                )
            }
            local stateController = self:_getStateController(dataIdentifiers.powerStateDataIdentifier)
            local progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER, dataIdentifiers)
            local redlineController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER_CONSUMED_LIMIT, dataIdentifiers)




            if progressController and redlineController and stateController then
                local progressValueModifier = function(value) return Ticks.powermeterProgressModifier(value, parameters[1].configuration.tickLabelsConfiguration.labelOverrides, initial) end
                gauge = DigiBarProgressGauge.newTicks(
                    progressController,
                    appearanceController,
                    redlineController,
                    nil,
                    stateController,
                    parameters,
                    ticksMode,
                    "PowermeterTickmarks",
                    progressValueModifier
                )
            else

            end
        elseif ticksConfig.dataSource.chargeFuel then
            local dataSource = ticksConfig.dataSource.chargeFuel
            local dataIdentifiers = ChargeFuelDataIdentifiers.fromJson(dataSource.dataIdentifiers)
            local stateController = self:_getStateController(dataIdentifiers.levelStateDataIdentifier)
            local controllerType = Layout.PROGRESS_CONTROLLER_TYPE.CHARGE_FUEL
            if dataIdentifiers.levelDataIdentifier == VehicleDataUpdater.DATAIDENTIFIERS.fuelLevel then
                controllerType = Layout.PROGRESS_CONTROLLER_TYPE.FUEL
            elseif dataIdentifiers.levelDataIdentifier == VehicleDataUpdater.DATAIDENTIFIERS.chargeLevel then
                controllerType = Layout.PROGRESS_CONTROLLER_TYPE.CHARGE
            end
            local progressController = self:_getProgressController(controllerType, dataIdentifiers)



            local parameters = {
                ProgressBarGaugeParameters.new(
                    ticksConfiguration,
                    TicksLayoutConfiguration.newWithLabelsCountAndConfig(ticksConfiguration.tickLabelsConfiguration.maxLabelsCount, ticksConfiguration),
                    Ticks.labelValues(ticksConfiguration.tickLabelsConfiguration.maxLabelsCount, 100, ticksConfiguration.tickLabelsConfiguration.labelDivider or 1)
                )
            }
            if progressController and stateController then
                gauge = DigiBarProgressGauge.newTicks(
                    progressController,
                    appearanceController,
                    nil,
                    nil,
                    stateController,
                    parameters,
                    ticksMode,
                    "TachometerTickmarks"
                )
            else

            end
        else

        end
    elseif radialProgressType.digiBandGradientProgress then
        local progressBar = radialProgressType.digiBandGradientProgress
        local configuration = DigiBandGradientProgressConfiguration.fromJson(progressBar.configuration)
        if progressBar.dataSource.speedometer then
            local dataSource = progressBar.dataSource.speedometer
            local dataIdentifiers = SpeedometerDataIdentifiers.fromJson(dataSource.dataIdentifiers)
            local controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.SPEED, dataIdentifiers)


            if controller then
                gauge = DigiBarProgressGauge.newDigiBandGradientProgressBar(
                    configuration,
                    controller,
                    appearanceController,
                    nil,
                    "SpeedometerGradientProgressBar"
                )
            end
        elseif progressBar.dataSource.tachometer then
            local dataSource = progressBar.dataSource.tachometer
            local dataIdentifiers = TachometerDataIdentifiers.fromJson(dataSource.dataIdentifiers)
            local stateController = self:_getStateController(dataIdentifiers.engineRPMStateDataIdentifier)
            local controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER, dataIdentifiers)



            if controller and stateController then
                gauge = DigiBarProgressGauge.newDigiBandGradientProgressBar(
                    configuration,
                    controller,
                    appearanceController,
                    stateController,
                    "TachometerGradientProgressBar"
                )
            end
        end
    elseif radialProgressType.digiBar then

    elseif radialProgressType.digiBarCruiseControl then
        local configuration = DigiBarCruiseControlConfiguration.fromJson(radialProgressType.digiBarCruiseControl.configuration)
        local dataSource = radialProgressType.digiBarCruiseControl.dataSource.cruiseControl
        local driverAssistanceConfiguration = DriverAssistanceConfiguration.fromJson(dataSource)
        local dataIdentifiers = driverAssistanceConfiguration.dataIdentifiers
        local speedDataIdentifiers = SpeedometerDataIdentifiers.new(
            dataIdentifiers.speedDataIdentifier,
            dataIdentifiers.speedUnitDataIdentifier,
            dataIdentifiers.speedMaxDataIdentifier,
            "",
            dataIdentifiers.uiSceneStateDataIdentifier
        )
        local vehicleSpeedController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.SPEED, speedDataIdentifiers)
        local targetSpeedController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TARGET_SPEED, dataIdentifiers)
        local stateController = self:_getStateController(dataIdentifiers.cruiseControlStateDataIdentifier)




        gauge = DigiBarProgressGauge.newCruiseControl(
            configuration,
            vehicleSpeedController,
            targetSpeedController,
            appearanceController,
            stateController
        )
    elseif radialProgressType.digiBarBackground then
        local dataSource = radialProgressType.digiBarBackground.dataSource
        local name = "DigiBarBackground"
        local stateController
        local startController
        local endController
        if dataSource then
            if dataSource.tachometer then
                name = "DigiBarTachometerBackground"
                local dataIdentifiers = TachometerDataIdentifiers.fromJson(dataSource.tachometer.dataIdentifiers)
                stateController = self:_getStateController(dataIdentifiers.engineRPMStateDataIdentifier)

            elseif dataSource.chargeFuel then
                name = "DigiBarChargeFuelBackground"
                local dataIdentifiers = ChargeFuelDataIdentifiers.fromJson(dataSource.chargeFuel.dataIdentifiers)
                stateController = self:_getStateController(dataIdentifiers.levelStateDataIdentifier)

            elseif dataSource.temperature then
                name = "DigiBarTemperatureBackground"
                local dataIdentifiers = TemperatureDataIdentifiers.fromJson(dataSource.temperature.dataIdentifiers)
                stateController = self:_getStateController(dataIdentifiers.temperatureStateDataIdentifier)

            elseif dataSource.tachometerNominalMax then
                name = "DigiBarSecondaryTachometerBackground"
                local dataIdentifiers = TachometerDataIdentifiers.fromJson(dataSource.tachometerNominalMax.dataIdentifiers)
                endController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_REDLINE, dataIdentifiers)
                stateController = self:_getStateController(dataIdentifiers.engineRPMStateDataIdentifier)


            elseif dataSource.tachometerRedlineMax then
                name = "DigiBarSecondaryTachometerRedlineBackground"
                local dataIdentifiers = TachometerDataIdentifiers.fromJson(dataSource.tachometerRedlineMax.dataIdentifiers)
                startController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_REDLINE, dataIdentifiers)
                stateController = self:_getStateController(dataIdentifiers.engineRPMStateDataIdentifier)


            elseif dataSource.powermeterConsumed then
                name = "DigiBarPowermeterConsumedBackground"
                local dataIdentifiers = PowermeterDataIdentifiers.fromJson(dataSource.powermeterConsumed.dataIdentifiers)
                stateController = self:_getStateController(dataIdentifiers.powerStateDataIdentifier)

            elseif dataSource.powermeterRegenerated then
                name = "DigiBarPowermeterRegeneratedBackground"
                local dataIdentifiers = PowermeterDataIdentifiers.fromJson(dataSource.powermeterRegenerated.dataIdentifiers)
                stateController = self:_getStateController(dataIdentifiers.powerStateDataIdentifier)

            elseif dataSource.consumedPowerLimit then
                name = "DigiBarConsumedPowerLimitBackground"
                local dataIdentifiers = PowermeterDataIdentifiers.fromJson(dataSource.consumedPowerLimit.dataIdentifiers)
                endController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER_CONSUMED_LIMIT, dataIdentifiers)
                stateController = self:_getStateController(dataIdentifiers.powerStateDataIdentifier)


            else

            end
        end
        local configuration = DigiBarBackgroundConfiguration.fromJson(radialProgressType.digiBarBackground.configuration)
        gauge = DigiBarBackground.newDigiBarBackground(
            appearanceController,
            stateController,
            startController,
            endController,
            configuration,
            name
        )
    elseif radialProgressType.digiBarProgress then
        local configuration = DigiBarConfiguration.fromJson(radialProgressType.digiBarProgress.configuration)
        local name
        local controller
        local strokeStartController
        local stateController
        local progressValueModifier
        if radialProgressType.digiBarProgress.dataSource.speedometer then
            name = "SpeedometerProgressBar"
            local dataIdentifiers = SpeedometerDataIdentifiers.fromJson(radialProgressType.digiBarProgress.dataSource.speedometer.dataIdentifiers)
            controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.SPEED, dataIdentifiers)

        elseif radialProgressType.digiBarProgress.dataSource.tachometer then
            name = "TachometerProgressBar"
            local dataIdentifiers = TachometerDataIdentifiers.fromJson(radialProgressType.digiBarProgress.dataSource.tachometer.dataIdentifiers)
            controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER, dataIdentifiers)
            stateController = self:_getStateController(dataIdentifiers.engineRPMStateDataIdentifier)


        elseif radialProgressType.digiBarProgress.dataSource.tachometerNominalProgress then
            name = "TachometerNominalProgressBar"
            local dataIdentifiers = TachometerDataIdentifiers.fromJson(radialProgressType.digiBarProgress.dataSource.tachometerNominalProgress.dataIdentifiers)
            controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_DETACHED_NOMINAL, dataIdentifiers)
            stateController = self:_getStateController(dataIdentifiers.engineRPMStateDataIdentifier)


        elseif radialProgressType.digiBarProgress.dataSource.tachometerRedlineProgress then
            name = "TachometerRedlineProgressBar"
            local dataIdentifiers = TachometerDataIdentifiers.fromJson(radialProgressType.digiBarProgress.dataSource.tachometerRedlineProgress.dataIdentifiers)
            strokeStartController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_REDLINE, dataIdentifiers)
            controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_DETACHED_REDLINE, dataIdentifiers)
            stateController = self:_getStateController(dataIdentifiers.engineRPMStateDataIdentifier)


        elseif radialProgressType.digiBarProgress.dataSource.tachometerNominalMax then
            name = "TachometerNominalBackgroundBar"
            local dataIdentifiers = TachometerDataIdentifiers.fromJson(radialProgressType.digiBarProgress.dataSource.tachometerNominalMax.dataIdentifiers)
            controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_REDLINE, dataIdentifiers)
            stateController = self:_getStateController(dataIdentifiers.engineRPMStateDataIdentifier)


        elseif radialProgressType.digiBarProgress.dataSource.tachometerRedlineMax then
            name = "TachometerRedlineBackgroundBar"
            local dataIdentifiers = TachometerDataIdentifiers.fromJson(radialProgressType.digiBarProgress.dataSource.tachometerRedlineMax.dataIdentifiers)
            strokeStartController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_REDLINE, dataIdentifiers)
            stateController = self:_getStateController(dataIdentifiers.engineRPMStateDataIdentifier)


        elseif radialProgressType.digiBarProgress.dataSource.chargeFuel then
            name = "ChargeFuelProgressBar"
            local dataIdentifiers = ChargeFuelDataIdentifiers.fromJson(radialProgressType.digiBarProgress.dataSource.chargeFuel.dataIdentifiers)
            local controllerType = Layout.PROGRESS_CONTROLLER_TYPE.CHARGE_FUEL
            if dataIdentifiers.levelDataIdentifier == VehicleDataUpdater.DATAIDENTIFIERS.fuelLevel then
                controllerType = Layout.PROGRESS_CONTROLLER_TYPE.FUEL
            elseif dataIdentifiers.levelDataIdentifier == VehicleDataUpdater.DATAIDENTIFIERS.chargeLevel then
                controllerType = Layout.PROGRESS_CONTROLLER_TYPE.CHARGE
            end
            controller = self:_getProgressController(controllerType, dataIdentifiers)
            stateController = self:_getStateController(dataIdentifiers.levelStateDataIdentifier)


        elseif radialProgressType.digiBarProgress.dataSource.powermeterRegenerated then
            name = "ConsumedPowerBar"
            local dataIdentifiers = PowermeterDataIdentifiers.fromJson(radialProgressType.digiBarProgress.dataSource.powermeterRegenerated.dataIdentifiers)
            controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER, dataIdentifiers)
            progressValueModifier = function(value) return -math.min(0, value) end

        elseif radialProgressType.digiBarProgress.dataSource.powermeterConsumed then
            name = "ConsumedPowerBar"
            local dataIdentifiers = PowermeterDataIdentifiers.fromJson(radialProgressType.digiBarProgress.dataSource.powermeterConsumed.dataIdentifiers)
            controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER, dataIdentifiers)
            stateController = self:_getStateController(dataIdentifiers.powerStateDataIdentifier)
            progressValueModifier = function(value) return math.max(0, value) end


        elseif radialProgressType.digiBarProgress.dataSource.consumedPowerLimit then
            name = "ConsumedPowerLimitBar"
            local dataIdentifiers = PowermeterDataIdentifiers.fromJson(radialProgressType.digiBarProgress.dataSource.consumedPowerLimit.dataIdentifiers)
            controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER_CONSUMED_LIMIT, dataIdentifiers)
            stateController = self:_getStateController(dataIdentifiers.powerStateDataIdentifier)


        elseif radialProgressType.digiBarProgress.dataSource.regeneratedPowerLimit then
            name = "RegeneratedPowerLimitBar"
            local dataIdentifiers = PowermeterDataIdentifiers.fromJson(radialProgressType.digiBarProgress.dataSource.regeneratedPowerLimit.dataIdentifiers)
            controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER_REGENERATED_LIMIT, dataIdentifiers)

        else

        end

        gauge = DigiBarProgressGauge.newDigiBarProgressBar(
            configuration,
            appearanceController,
            strokeStartController,
            controller,
            stateController,
            name,
            progressValueModifier
        )
    elseif radialProgressType.digiBarProgressMask then
        local configuration = DigiBarMaskConfiguration.fromJson(radialProgressType.digiBarProgressMask.configuration)
        local name = "DigiBarMask"
        local progressController
        local progressValueModifier
        if radialProgressType.digiBarProgressMask.dataSource then
            if radialProgressType.digiBarProgressMask.dataSource.consumedPowerLimit then
                name = "ConsumedPowerLimitMask"
                local dataIdentifiers = PowermeterDataIdentifiers.fromJson(radialProgressType.digiBarProgressMask.dataSource.consumedPowerLimit.dataIdentifiers)
                progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER_CONSUMED_LIMIT, dataIdentifiers)
            elseif radialProgressType.digiBarProgressMask.dataSource.regeneratedPowerLimit then
                name = "RegeneratedPowerLimitMask"
                local dataIdentifiers = PowermeterDataIdentifiers.fromJson(radialProgressType.digiBarProgressMask.dataSource.regeneratedPowerLimit.dataIdentifiers)
                progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER_REGENERATED_LIMIT, dataIdentifiers)
            elseif radialProgressType.digiBarProgressMask.dataSource.inverseRegeneratedPowerLimit then
                name = "RegeneratedPowerLimitMask"
                local dataIdentifiers = PowermeterDataIdentifiers.fromJson(radialProgressType.digiBarProgressMask.dataSource.inverseRegeneratedPowerLimit.dataIdentifiers)
                progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER_REGENERATED_LIMIT, dataIdentifiers)
                progressValueModifier = function(value) return 1 - value end
            elseif radialProgressType.digiBarProgressMask.dataSource.inverseConsumedPowerLimit then
                name = "ConsumerPowerLimitMask"
                local dataIdentifiers = PowermeterDataIdentifiers.fromJson(radialProgressType.digiBarProgressMask.dataSource.inverseConsumedPowerLimit.dataIdentifiers)
                progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER_CONSUMED_LIMIT, dataIdentifiers)
                progressValueModifier = function(value) return 1 - value end
            else

            end


        end

        gauge = DigiBarProgressGauge.newDigiBarProgressMask(
            configuration,
            progressController,
            name,
            progressValueModifier
        )
    elseif radialProgressType.digiBarRedline then
        local configuration = DigiBarConfiguration.fromJson(radialProgressType.digiBarRedline.configuration)
        if radialProgressType.digiBarRedline.dataSource.tachometer then
            local dataIdentifiers = TachometerDataIdentifiers.fromJson(radialProgressType.digiBarRedline.dataSource.tachometer.dataIdentifiers)
            local controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER, dataIdentifiers)
            local redlineController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_REDLINE, dataIdentifiers)
			local stateController = self:_getStateController(dataIdentifiers.engineRPMStateDataIdentifier)




            if controller and redlineController and stateController then
                gauge = DigiBarProgressGauge.newDigiBarRedlineProgress(
                    configuration,
                    controller,
                    redlineController,
                    appearanceController,
					stateController,
                    "TachometerRedline"
                )
            end
        elseif radialProgressType.digiBarRedline.dataSource.tachometerNominalProgress then
            local dataIdentifiers = TachometerDataIdentifiers.fromJson(radialProgressType.digiBarRedline.dataSource.tachometerNominalProgress.dataIdentifiers)
            local controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_DETACHED_NOMINAL, dataIdentifiers)
            local redlineController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_REDLINE, dataIdentifiers)



            if controller and redlineController then
                gauge = DigiBarProgressGauge.newDigiBarRedlineProgress(
                    configuration,
                    controller,
                    redlineController,
                    appearanceController,
                    nil,
                    "TachometerRedline"
                )
            end
        elseif radialProgressType.digiBarRedline.dataSource.consumedPowerLimit then
            local dataIdentifiers = PowermeterDataIdentifiers.fromJson(radialProgressType.digiBarRedline.dataSource.consumedPowerLimit.dataIdentifiers)
            local controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER, dataIdentifiers)
            local redlineController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER_CONSUMED_LIMIT, dataIdentifiers)



            if controller and redlineController then
                gauge = DigiBarProgressGauge.newDigiBarRedlineProgress(
                    configuration,
                    controller,
                    redlineController,
                    appearanceController,
                    nil,
                    "ConsumedPowerDigiBandLimit",
                    function(v) return math.max(0, v) end
                )
            end
        elseif radialProgressType.digiBarRedline.dataSource.regeneratedPowerLimit then
            local dataIdentifiers = PowermeterDataIdentifiers.fromJson(radialProgressType.digiBarRedline.dataSource.regeneratedPowerLimit.dataIdentifiers)
            local controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER, dataIdentifiers)
            local redlineController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER_REGENERATED_LIMIT, dataIdentifiers)



            if controller and redlineController then
                gauge = DigiBarProgressGauge.newDigiBarRedlineProgress(
                    configuration,
                    controller,
                    redlineController,
                    appearanceController,
                    nil,
                    "RegeneratedPowerDigiBandLimit",
                    function(v) return math.max(0, v) end
                )
            end
        else

        end
    elseif radialProgressType.digiBarRectangleRedline then
        local configuration = DigiBarConfiguration.fromJson(radialProgressType.digiBarRectangleRedline.configuration)
        local dataSource = radialProgressType.digiBarRectangleRedline.dataSource
        if dataSource.tachometer then
            local dataIdentifiers = TachometerDataIdentifiers.fromJson(dataSource.tachometer.dataIdentifiers)
            local controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER, dataIdentifiers)
            local redlineController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER_REDLINE, dataIdentifiers)
			local stateController = self:_getStateController(dataIdentifiers.engineRPMStateDataIdentifier)




            if controller and redlineController and stateController then
                gauge = DigiBarProgressGauge.newDigiBarRedlineProgress(
                    configuration,
                    controller,
                    redlineController,
                    appearanceController,
					stateController,
                    "TachometerRedline"
                )
            end
        else

        end
    elseif radialProgressType.digiBarMarker then
        local configuration = DigiBarMarkerConfiguration.fromJson(radialProgressType.digiBarMarker.configuration)
        if radialProgressType.digiBarMarker.dataSource.chargeFuelLowLevel then
            local dataIdentifiers = radialProgressType.digiBarMarker.dataSource.chargeFuelLowLevel.dataIdentifiers
            local controllerType = Layout.PROGRESS_CONTROLLER_TYPE.CHARGE_FUEL_LOW_LEVEL
            if dataIdentifiers.levelMarkerLowDataIdentifier == VehicleDataUpdater.DATAIDENTIFIERS.fuelLevelMarkerLow then
                controllerType = Layout.PROGRESS_CONTROLLER_TYPE.FUEL_LOW_LEVEL
            elseif dataIdentifiers.levelMarkerLowDataIdentifier == VehicleDataUpdater.DATAIDENTIFIERS.chargeLevelMarkerLow then
                controllerType = Layout.PROGRESS_CONTROLLER_TYPE.CHARGE_LOW_LEVEL
            end
            local progressController = self:_getProgressController(controllerType, dataIdentifiers)
            local stateController = self:_getStateController(dataIdentifiers.levelStateDataIdentifier)



            if progressController and stateController then
                gauge = DigiBarMarkerGauge.newDigiBarDotMarker(
                    configuration,
                    progressController,
                    stateController,
                    appearanceController,
                    "ChargeFuelLowLevelMarker"
                )
            end
        elseif radialProgressType.digiBarMarker.dataSource.temperature then
            local dataIdentifiers = TemperatureDataIdentifiers.fromJson(radialProgressType.digiBarMarker.dataSource.temperature.dataIdentifiers)
            local progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TEMPERATURE, dataIdentifiers)
            local stateController = self:_getStateController(dataIdentifiers.temperatureStateDataIdentifier)



            if progressController and stateController then
                gauge = DigiBarMarkerGauge.newDigiBarDotMarker(
                    configuration,
                    progressController,
                    stateController,
                    appearanceController,
                    "TemperatureMarker"
                )
            end
        elseif radialProgressType.digiBarMarker.dataSource.temperatureColdMarker then
            local dataIdentifiers = TemperatureDataIdentifiers.fromJson(radialProgressType.digiBarMarker.dataSource.temperatureColdMarker.dataIdentifiers)
            local progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TEMPERATURE_COLD_MARKER, dataIdentifiers)
            local stateController = self:_getStateController(dataIdentifiers.temperatureStateDataIdentifier)



            if progressController and stateController then
                gauge = DigiBarMarkerGauge.newDigiBarDotMarker(
                    configuration,
                    progressController,
                    stateController,
                    appearanceController,
                    "TemperatureColdLevelMarker"
                )
            end
        elseif radialProgressType.digiBarMarker.dataSource.temperatureHotMarker then
            local dataIdentifiers = TemperatureDataIdentifiers.fromJson(radialProgressType.digiBarMarker.dataSource.temperatureHotMarker.dataIdentifiers)
            local progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TEMPERATURE_HOT_MARKER, dataIdentifiers)
            local stateController = self:_getStateController(dataIdentifiers.temperatureStateDataIdentifier)



            if progressController and stateController then
                gauge = DigiBarMarkerGauge.newDigiBarDotMarker(
                    configuration,
                    progressController,
                    stateController,
                    appearanceController,
                    "TemperatureHotLevelMarker"
                )
            end
        elseif radialProgressType.digiBarMarker.dataSource.speedLimiter then
            local dataIdentifiers = DriverAssistanceConfiguration.DataIdentifiers.fromJson(radialProgressType.digiBarMarker.dataSource.speedLimiter.dataIdentifiers)
            local progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TARGET_SPEED, dataIdentifiers)


            if progressController then
                gauge = DigiBarMarkerGauge.newDigiBarTickMarker(
                    configuration,
                    progressController,
                    appearanceController,
                    "SpeedLimiterTick"
                )
            end
        elseif radialProgressType.digiBarMarker.dataSource.speedLimiterLabel then
            local dataIdentifiers = DriverAssistanceConfiguration.DataIdentifiers.fromJson(radialProgressType.digiBarMarker.dataSource.speedLimiterLabel.dataIdentifiers)
            local valueDataIdentifier = dataIdentifiers.cruiseControlSpeedDataIdentifier
            local unitDataIdentifier = dataIdentifiers.speedUnitDataIdentifier
            local cruiseControlStateDataIdentifier = dataIdentifiers.cruiseControlStateDataIdentifier
            local labelController = self:_getLabelController(Layout.LABEL_CONTROLLER_TYPE.SPEED_LIMITER_LABEL, valueDataIdentifier, unitDataIdentifier, cruiseControlStateDataIdentifier)
            local progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TARGET_SPEED, dataIdentifiers)
            local stateController = self:_getStateController(cruiseControlStateDataIdentifier)
            local speedLimitedStateController = self:_getStateController(dataIdentifiers.speedLimitedDataIdentifier)




            if progressController and stateController and labelController and speedLimitedStateController then
                gauge = DigiBarMarkerGauge.newLabelMarker(
                    configuration,
                    progressController,
                    stateController,
                    labelController,
                    speedLimitedStateController,
                    appearanceController,
                    "SpeedLimiterLabel"
                )
            end
        else

        end
    elseif radialProgressType.powermeterConcentricRings then
        local config = ConcentricRingsConfiguration.fromJsonPowermeter(radialProgressType.powermeterConcentricRings.configuration)
        local controller = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER, config.dataIdentifiers)


        if controller then
            gauge = DigiBarProgressGauge.newConcentricRings(
                config,
                controller,
                appearanceController,
                "ConcentricRings"
            )
        end
    elseif radialProgressType.digiBarRectangleProgress then
        local configuration = DigiBarConfiguration.fromJson(radialProgressType.digiBarRectangleProgress.configuration)
        local dataSource = radialProgressType.digiBarRectangleProgress.dataSource

        if dataSource then
            if dataSource.chargeFuel then
                local dataIdentifiers = ChargeFuelDataIdentifiers.fromJson(dataSource.chargeFuel.dataIdentifiers)
                local controllerType = Layout.PROGRESS_CONTROLLER_TYPE.CHARGE_FUEL
                if dataIdentifiers.levelDataIdentifier == VehicleDataUpdater.DATAIDENTIFIERS.fuelLevel then
                    controllerType = Layout.PROGRESS_CONTROLLER_TYPE.FUEL
                elseif dataIdentifiers.levelDataIdentifier == VehicleDataUpdater.DATAIDENTIFIERS.chargeLevel then
                    controllerType = Layout.PROGRESS_CONTROLLER_TYPE.CHARGE
                end
                local progressController = self:_getProgressController(controllerType, dataIdentifiers)
                local stateController = self:_getStateController(dataIdentifiers.levelStateDataIdentifier)


                gauge = DigiBarProgressGauge.newRectangularGauge(configuration, appearanceController, nil, progressController, stateController, "ChargeFuel", nil)
            elseif dataSource.tachometer then
                local dataIdentifiers = TachometerDataIdentifiers.fromJson(dataSource.tachometer.dataIdentifiers)
                local progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.TACHOMETER, dataIdentifiers)
                local stateController = self:_getStateController(dataIdentifiers.engineRPMStateDataIdentifier)


                gauge = DigiBarProgressGauge.newRectangularGauge(configuration, appearanceController, nil, progressController, stateController, "Tachometer", nil)
            elseif dataSource.powermeterConsumed then
                local dataIdentifiers = PowermeterDataIdentifiers.fromJson(dataSource.powermeterConsumed.dataIdentifiers)
                local progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER, dataIdentifiers)
                local stateController = self:_getStateController(dataIdentifiers.powerStateDataIdentifier)
                local progressValueModifier = function(value) return math.max(0, value) end


                gauge = DigiBarProgressGauge.newRectangularGauge(configuration, appearanceController, nil, progressController, stateController, "PowermeterConsumed", progressValueModifier)
            elseif dataSource.powermeterRegenerated then
                local dataIdentifiers = PowermeterDataIdentifiers.fromJson(dataSource.powermeterRegenerated.dataIdentifiers)
                local progressController = self:_getProgressController(Layout.PROGRESS_CONTROLLER_TYPE.POWER, dataIdentifiers)
                local progressValueModifier = function(value) return -math.min(0, value) end

                gauge = DigiBarProgressGauge.newRectangularGauge(configuration, appearanceController, nil, progressController, nil, "PowermeterRegenerated", progressValueModifier)
            else

            end
        else
            gauge = DigiBarProgressGauge.newRectangularGauge(configuration, appearanceController, nil, nil, nil, "Background", nil)
        end
    else

    end

    return gauge
end

return APL.LuaUtils.readOnly(Layout)
