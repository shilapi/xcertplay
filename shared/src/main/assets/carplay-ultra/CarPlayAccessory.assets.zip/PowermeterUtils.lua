-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Enums = require "Enums"
local VehicleDataUpdater = require "VehicleDataUpdater"
local Ticks = require "Ticks"

local PowermeterUtils = APL.LuaUtils.makeObject({ _type = "PowermeterUtils" })

PowermeterUtils.PowermeterInitialValues = APL.LuaUtils.namedObject(
    "PowermeterUtils.PowermeterInitialValues",
    { "powerMarkerAvailableConsumed", "number?" }, -- Raw value (0 to +max)
    { "powerMarkerAvailableRegenerated", "number?" },  -- Raw value (-min to 0)
    { "consumedPowerMax", "number" },
    { "consumedLabelsCount", "number" },
    { "regeneratedPowerMax", "number" },
    { "regeneratedLabelsCount", "number" }
)


PowermeterUtils.CONSUMED_MIN_LABELS_COUNT = 5
PowermeterUtils.CONSUMED_MAX_LABELS_COUNT = 12
PowermeterUtils.CONSUMED_LABEL_INTERVALS = { 5000, 10000, 20000, 40000, 50000, 100000, 500000 }

PowermeterUtils.REGENERATED_LABELS_COUNT = 2
PowermeterUtils.REGENERATED_LABEL_INTERVALS = { 100000, 200000, 250000, 300000, 350000, 500000 }









function PowermeterUtils.getInitialVehicleDataValues(vehicleDataUpdater, dataIdentifiersConfiguration)



    local requiredDataIdentifiers = {
        dataIdentifiersConfiguration.powerMaxDataIdentifier,
        dataIdentifiersConfiguration.powerMinDataIdentifier
    }
    local optionalDataIdentifiers = {
        dataIdentifiersConfiguration.powerDataIdentifier,
        dataIdentifiersConfiguration.powerMarkerAvailableMaxDataIdentifier,
        dataIdentifiersConfiguration.powerMarkerAvailableMinDataIdentifier
    }
    local dataIdentifiers = APL.LuaUtils.merge(requiredDataIdentifiers, optionalDataIdentifiers)
    local data = vehicleDataUpdater:getData(dataIdentifiers)
    for _, identifier in ipairs(requiredDataIdentifiers) do
        if data[identifier] == nil then
            APL.Log.error(PowermeterUtils, function() return "Missing initial value for data: " .. identifier end)
            return nil
        end
    end

    local power = data[dataIdentifiersConfiguration.powerDataIdentifier]
    local powerMarkerAvailableMax = data[dataIdentifiersConfiguration.powerMarkerAvailableMaxDataIdentifier]
    local powerMarkerAvailableMin = data[dataIdentifiersConfiguration.powerMarkerAvailableMinDataIdentifier]
    local consumedPowerMax = data[dataIdentifiersConfiguration.powerMaxDataIdentifier]
    local regeneratedPowerMax = data[dataIdentifiersConfiguration.powerMinDataIdentifier]

    local consumedPowerMaxAdjusted, consumedLabelsCount = Ticks.getMaxValueWithLabelsCount(
        consumedPowerMax,
        PowermeterUtils.CONSUMED_MIN_LABELS_COUNT,
        PowermeterUtils.CONSUMED_MAX_LABELS_COUNT,
        PowermeterUtils.CONSUMED_LABEL_INTERVALS
    )
    local regeneratedPowerMaxAdjusted, regeneratedLabelsCount = Ticks.getMaxValueWithLabelsCount(
        math.abs(regeneratedPowerMax),
        PowermeterUtils.REGENERATED_LABELS_COUNT,
        PowermeterUtils.REGENERATED_LABELS_COUNT,
        PowermeterUtils.REGENERATED_LABEL_INTERVALS
    )

    return PowermeterUtils.PowermeterInitialValues.new(powerMarkerAvailableMax, powerMarkerAvailableMin, consumedPowerMaxAdjusted, consumedLabelsCount, -regeneratedPowerMaxAdjusted, regeneratedLabelsCount)
end









function PowermeterUtils.getNormalizedPower(powerDataIdentifier, uiSceneStateDataIdentifier, initial)




    return function(update, cached)

        local uiSceneState = update[uiSceneStateDataIdentifier] or cached[uiSceneStateDataIdentifier]

        if uiSceneState.state ~= Enums.UISceneState.DRIVE then
            return 0
        end

        local power = update[powerDataIdentifier]
        if power == VehicleDataUpdater.INVALID then
            return nil
        end

        return power >= 0
            and math.max(0, math.min(1, power / initial.consumedPowerMax))
            or -math.max(0, math.min(1, power / initial.regeneratedPowerMax))
    end
end








function PowermeterUtils.getNormalizedConsumedPower(powerDataIdentifier, initial)



    return function(update)
        local power = update[powerDataIdentifier]
        if power == VehicleDataUpdater.INVALID then
            return nil
        end

        return math.max(0, math.min(1, power / initial.consumedPowerMax))
    end
end








function PowermeterUtils.getNormalizedRegeneratedPower(powerDataIdentifier, initial)



    return function(update)
        local power = update[powerDataIdentifier]
        if power == VehicleDataUpdater.INVALID then
            return nil
        end

        return math.max(0, math.min(1, power / initial.regeneratedPowerMax))
    end
end

return APL.LuaUtils.readOnly(PowermeterUtils)