-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local APL = require "APL.APL"
local Component = APL.LuaUtils.makeObject({ _type = "Component" })

Component.TYPE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "PRIMARY",
    "OVERLAY"
}))

local TYPES = APL.LuaUtils.getValues(Component.TYPE)











function Component.new(componentType, id, name, frame, gauges)






    local self = APL.LuaUtils.newObject(Component, {
        _componentType = componentType,
        _id = id,
        _name = name,
        _zoneFrame = frame,
        _gauges = gauges,
        _rootLayer = APL.LuaUtils.NIL,
        _inputStreams = {}
    })


    local frame = APL.Rect.new(0, 0, frame._width, frame._height)



    self._rootLayer = APL.Layer.new()
        :setFrame(frame)
        :setVisible(false)

    for _, gauge in ipairs(self._gauges) do
        if APL.LuaUtils.getClassName(gauge) == "InputStream" then
            self._inputStreams[#self._inputStreams+1] = gauge
        end

        gauge
            :getRootLayer()
            :addToSuperLayer(self._rootLayer)
    end

    return self
end






function Component:destroy()


    for _, gauge in ipairs(self._gauges) do
        gauge:destroy()
    end
    self._rootLayer:destroy()
end






function Component:getID()


    return self._id
end






function Component:getType()


    return self._componentType
end








function Component:getZOrderPriority()


    local priorityByType = {
        [Component.TYPE.PRIMARY] = 0,
        [Component.TYPE.OVERLAY] = 1
    }
    local priority = priorityByType[self._componentType]


    return priority
end






function Component:getRootLayer()


    return self._rootLayer
end












function Component:setVisible(isVisible, opacity)




    APL.Log.info(Component, function() return (isVisible and "Showing" or "Hiding") .. " component " .. self._id end)

    self._rootLayer:setVisible(isVisible)

    if opacity ~= nil then
        self._rootLayer:setOpacity(opacity)
    end



    for _, inputStream in ipairs(self._inputStreams) do
        if not inputStream:isOEMControlled() then
            inputStream:setVisible(isVisible)
        end
    end

    return self
end












function Component:applyTransitionData(transform, opacity)




    APL.Log.debug(Component, function() return "Applying transform to component " .. self._id .. ": transform = " .. tostring(transform) ..", opacity = " .. tostring(opacity) .. ", parent position: " .. self._zoneFrame._x .. ", " .. self._zoneFrame._y end)



    local frame = APL.Rect.new(self._rootLayer:getFrame())
    local transform = transform:translate(-self._zoneFrame._x, -self._zoneFrame._y)

    self._rootLayer
        :setAnchorPoint(0, 0) -- Anchor point must be 0,0 as the transform is in world coordinate and
        :setFrame(frame) -- Frame must be re-applied when anchor point changes
        :setOpacity(opacity)
        :setTransform(transform)

    return self
end






function Component:description()


    return self._name .. " (" .. self._id .. ")"
end

return APL.LuaUtils.readOnly(Component)
