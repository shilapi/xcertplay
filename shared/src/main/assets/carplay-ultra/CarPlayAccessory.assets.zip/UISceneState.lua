-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local LuaUtils = require "APL.LuaUtils"

local UISceneState = LuaUtils.namedObject(
    "UISceneState",
    {"state", "number"},
    {"options", "table?"}
)

return LuaUtils.readOnly(UISceneState)
