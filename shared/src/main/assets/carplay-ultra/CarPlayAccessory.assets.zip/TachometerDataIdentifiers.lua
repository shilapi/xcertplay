-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local TachometerDataIdentifiers = APL.LuaUtils.namedObject(
    "TachometerDataIdentifiers",
    { "dataIdentifier", "string" },
    { "engineRPMMaxDataIdentifier", "string" },
    { "markerRedlineDataIdentifier", "string"},
    { "engineRPMStateDataIdentifier", "string" },
    { "uiSceneStateDataIdentifier", "string" }
)







function TachometerDataIdentifiers.fromJson(json)


    return TachometerDataIdentifiers.new(
        json.dataIdentifier,
        json.engineRPMMaxDataIdentifier,
        json.markerRedlineDataIdentifier,
        json.engineRPMStateDataIdentifier,
        json.uiSceneStateDataIdentifier
    )
end

return APL.LuaUtils.readOnly(TachometerDataIdentifiers)
