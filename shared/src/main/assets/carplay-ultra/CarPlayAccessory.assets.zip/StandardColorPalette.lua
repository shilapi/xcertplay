-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Enums = require "Enums"

local DynamicColor = APL.LuaUtils.readOnly(APL.LuaUtils.namedObject(
    "DynamicColor",
    { "light", "string" },
    { "dark", "string" }
))




local StandardColorPalette = {
    _type = "StandardColorPalette",

    DynamicColor = DynamicColor,

    primary = DynamicColor.new("#000000FF", "#FFFFFFFF"),
    black = DynamicColor.new("#000000FF", "#000000FF"),
    blue = DynamicColor.new("#007AFFFF", "#0A83FFFF"),
    brown = DynamicColor.new("#A2835EFF", "#AC8E67FF"),
    cyan = DynamicColor.new("#31ADE6FF", "#63D2FFFF"),
    gray = DynamicColor.new("#8E8E93FF", "#8E8E93FF"),
    green = DynamicColor.new("#33C758FF", "#2FD157FF"),
    indigo = DynamicColor.new("#5755D6FF", "#5E5BE6FF"),
    mint = DynamicColor.new("#00C7BEFF", "#62E6E2FF"),
    orange = DynamicColor.new("#FF9500FF", "#FF9F0AFF"),
    pink = DynamicColor.new("#FF2C54FF", "#FF375FFF"),
    purple = DynamicColor.new("#AF52DEFF", "#BF59F2FF"),
    red = DynamicColor.new("#FF3A2FFF", "#FF4539FF"),
    teal = DynamicColor.new("#2FB0C7FF", "#40C8E0FF"),
    white = DynamicColor.new("#FFFFFFFF", "#FFFFFFFF"),
    yellow = DynamicColor.new("#FFCC00FF", "#FFD60AFF")
}


local colorIdentifierToColor = APL.LuaUtils.readOnly({
    [Enums.ImageColor.DEFAULT] = StandardColorPalette.primary,
    [Enums.ImageColor.WHITE] = StandardColorPalette.white,
    [Enums.ImageColor.BLACK] = StandardColorPalette.black,
    [Enums.ImageColor.GRAY] = StandardColorPalette.gray,
    [Enums.ImageColor.RED] = StandardColorPalette.red,
    [Enums.ImageColor.YELLOW] = StandardColorPalette.yellow,
    [Enums.ImageColor.BLUE] = StandardColorPalette.blue,
    [Enums.ImageColor.GREEN] = StandardColorPalette.green,
    [Enums.ImageColor.MINT] = StandardColorPalette.mint,
    [Enums.ImageColor.ORANGE] = StandardColorPalette.orange,
    [Enums.ImageColor.TEAL] = StandardColorPalette.teal,
    [Enums.ImageColor.CYAN] = StandardColorPalette.cyan,
    [Enums.ImageColor.INDIGO] = StandardColorPalette.indigo,
    [Enums.ImageColor.PURPLE] = StandardColorPalette.purple,
    [Enums.ImageColor.PINK] = StandardColorPalette.pink,
    [Enums.ImageColor.BROWN] = StandardColorPalette.brown
})








function StandardColorPalette:getColor(colorIdentifier, appearanceMode)



    local color = colorIdentifierToColor[colorIdentifier] or StandardColorPalette.primary
    return appearanceMode == Enums.AppearanceMode.LIGHT and color.light or color.dark
end

return APL.LuaUtils.readOnly(StandardColorPalette)
