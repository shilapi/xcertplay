-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local MeasurementLabelConfiguration = require "MeasurementLabelConfiguration"

local SpeedometerTextGaugeConfiguration = APL.LuaUtils.namedObject(
    "SpeedometerTextGaugeConfiguration",

    { "dataIdentifier", "string" },
    { "unitDataIdentifier", "string" },
    { "vehicleSpeedMaxDataIdentifier", "string"},
    { "showSecondarySpeedDataIdentifier", "string" },
    { "labelConfiguration", "MeasurementLabelConfiguration" }
)

function SpeedometerTextGaugeConfiguration.fromJson(jsonRepresentation)






    local self = SpeedometerTextGaugeConfiguration.new(
        jsonRepresentation.dataIdentifier,
        jsonRepresentation.unitDataIdentifier,
        jsonRepresentation.vehicleSpeedMaxDataIdentifier,
        jsonRepresentation.showSecondarySpeedDataIdentifier,
        MeasurementLabelConfiguration.fromJson(jsonRepresentation.labelConfiguration)
    )

    return self
end

return APL.LuaUtils.readOnly(SpeedometerTextGaugeConfiguration)