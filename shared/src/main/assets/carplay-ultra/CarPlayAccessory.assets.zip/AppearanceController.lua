-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"

local AppearanceController = APL.LuaUtils.makeObject({ _type = "AppearanceController" })

AppearanceController.State = APL.LuaUtils.namedObject(
    "AppearanceController.State",
    { "palette", "Palette" },
    { "appearance", "number" } -- Enums.AppearanceMode
)







function AppearanceController.State:getSolidColor(colorID)



    return self.palette:getSolidColor(colorID, self.appearance)
end







function AppearanceController.State:getGradientColor(colorID)



    return self.palette:getGradientColor(colorID, self.appearance)
end







function AppearanceController.State:equals(otherState)



    return otherState and self.appearance == otherState.appearance and self.palette:getID() == otherState.palette:getID()
end







function AppearanceController.new(state)


    local self = APL.LuaUtils.newObject(AppearanceController, {
        _updateHandlers = {},
        _state = state
    })

    return self
end






function AppearanceController:destroy()


    self._vehicleDataSubscriber:destroy()
end







function AppearanceController:setUpdateHandler(f)



    self._updateHandlers[f] = true

    self:_notifyHandlers({ [f] = true })

    return self
end






function AppearanceController:getState()


    return self._state
end







function AppearanceController:setState(state)



    if state:equals(self._state) then
        APL.Log.info(AppearanceController, function() return "Appearance did not change. Ignoring update." end)
        return false
    end

    self._state = state
    self:_notifyHandlers()
    return true
end






function AppearanceController:_notifyHandlers(handlers)



    local handlers = handlers or self._updateHandlers

    for handler, _ in pairs(handlers) do
        handler(self._state)
    end

    return self
end

return APL.LuaUtils.readOnly(AppearanceController)
