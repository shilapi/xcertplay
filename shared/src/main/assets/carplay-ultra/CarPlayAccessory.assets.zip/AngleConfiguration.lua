-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local AngleConfiguration = APL.LuaUtils.namedObject(
    "AngleConfiguration",
    { "minimumAngle", "number" },
    { "maximumAngle", "number" },
    { "clockwise", "boolean" }
)











function AngleConfiguration.fromJson(jsonRepresentation)






    local minimumAngle = APL.MathUtils.normalizeRadialGaugeAngle(jsonRepresentation.minimumAngle)
    local maximumAngle = APL.MathUtils.normalizeRadialGaugeAngle(jsonRepresentation.maximumAngle)

    return AngleConfiguration.new(
        minimumAngle,
        maximumAngle,
        jsonRepresentation.clockwise
    )
end






function AngleConfiguration.getNormalizedMinMaxAngleDelta(angleConfiguration)


    if angleConfiguration.clockwise then
        return APL.MathUtils.normalizeAngle(angleConfiguration.maximumAngle - angleConfiguration.minimumAngle)
    else
        return APL.MathUtils.tau - APL.MathUtils.normalizeAngle(angleConfiguration.maximumAngle - angleConfiguration.minimumAngle)
    end
end







function AngleConfiguration:getNormalizedAngleForProgress(progress)



    local maxAngleDelta = AngleConfiguration.getNormalizedMinMaxAngleDelta(self)
    local angleProgress = maxAngleDelta * progress
    local clockwiseSign = self.clockwise and -1 or 1
    local startAngle = 2 * math.pi - APL.MathUtils.normalizeAngle(self.minimumAngle)

    return startAngle + angleProgress * clockwiseSign
end

return APL.LuaUtils.readOnly(AngleConfiguration)