-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"

local EdgeInsets = require "EdgeInsets"
local NinePartImage = require "NinePartImage"

local Shadow = APL.LuaUtils.makeObject({ _type = "Shadow" })







function Shadow.new(config)


    local self = APL.LuaUtils.newObject(Shadow, {
        _image = NinePartImage.new(config.image),
        _insets = EdgeInsets.new(-config.shadowSize.top, -config.shadowSize.leading, -config.shadowSize.trailing, -config.shadowSize.bottom)
    })

    return self
end






function Shadow:destroy()


    self._image:destroy()
    self._image = nil
end







function Shadow:setFrame(frame)



    self._image:setFrame(frame)

    return self
end







function Shadow:setContentFrame(frame)



    return self:setFrame(frame:insetBy(self._insets.leading, self._insets.top, self._insets.trailing, self._insets.bottom))
end






function Shadow:getMinimiumContentSize()


    local minWidth, minHeight = self._image:getMinimiumSize()


    return (minWidth + self._insets.leading + self._insets.trailing), (minHeight + self._insets.top + self._insets.bottom)
end






function Shadow:getRootLayer()


    return self._image:getRootLayer()
end

return APL.LuaUtils.readOnly(Shadow)