-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"

local Constants = { _type = "Constants" }

Constants.INPUTSTREAM_ANIMATION_DURATION = 0.5

Constants.STATEFUL_COLOR_CHANGE_DURATION = 0.25

Constants.INDICATOR_FLASHING_DURATION = 0.5

Constants.PROGRESS_ANIMATION_DURATION = 0.03

Constants.REMOTEUI_FADEIN_DURATION = 0.5
Constants.REMOTEUI_FADEOUT_DURATION = 0.5
Constants.REMOTEUI_CURVE = { 0.2, 0, 0, 1 }
Constants.UI_FADEIN_DELAY = 0.05

Constants.REDACTED_ALPHA = 0.3

Constants.POPOVER_ANIMATION_DURATION = 0.35
Constants.POPOVER_CURVE = { 0.16, 1, 0.3, 1 }

Constants.LOGOS_ANIM_CURVE = { 0.33, 0, 0.2, 1 }
Constants.LOGOS_ANIM_CURVE2 = { 0.33, 0, 0.12, 1 }
Constants.LOGOS_ANIM_FADEOUT_CURVE = { 0.33, 0, 0, 1 }

Constants.LOGOS_ANIM_INTERRUPTION_FADEOUT_DURATION = 0.05

if APL.Config.readParam("TESTING.ANIMATIONS.QUICK") then
    APL.Log.log("Constants", "Testing .. using quick animations")

    Constants.INPUTSTREAM_ANIMATION_DURATION = 0
    Constants.STATEFUL_COLOR_CHANGE_DURATION = 0
    Constants.INDICATOR_FLASHING_DURATION = 0
    Constants.PROGRESS_ANIMATION_DURATION = 0
    Constants.UI_FADEIN_DELAY = 0
    Constants.POPOVER_ANIMATION_DURATION = 0
    Constants.LOGOS_ANIM_INTERRUPTION_FADEOUT_DURATION = 0
end

return APL.LuaUtils.readOnly(Constants)
