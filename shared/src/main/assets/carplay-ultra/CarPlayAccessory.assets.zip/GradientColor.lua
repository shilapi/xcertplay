-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local GaugeColor = require "GaugeColor"

local GradientColor = APL.LuaUtils.namedObject(
    "GradientColor",
    { "stops", "table" }
)







function GradientColor.fromSingleColor(color)


    return GradientColor.new({ [0] = color })
end




GradientColor.clear = GradientColor.fromSingleColor(GaugeColor.clear)
GradientColor.white = GradientColor.fromSingleColor(GaugeColor.white)
GradientColor.secondary = GradientColor.fromSingleColor(GaugeColor.secondary)
GradientColor.green = GradientColor.fromSingleColor(GaugeColor.green)







function GradientColor.fromJson(json)
    local stops = {}
    for k, v in pairs(json.stops) do


        stops[tonumber(k)] = v
    end

    return GradientColor.new(stops)
end

return (GradientColor)