-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"


local ShapeLayerConfiguration = APL.LuaUtils.namedObject(
    "ShapeLayerConfiguration",
    { "path", "Path" },
    { "fillColor", "string" },
    { "strokeColor", "string" },
    { "strokeWidth", "number" },
    { "lineCap", "number" }
)







function ShapeLayerConfiguration.fromJson(jsonRepresentation)
    return ShapeLayerConfiguration.new(
        ShapeLayerConfiguration.pathFromJson(jsonRepresentation.path),
        jsonRepresentation.fillColor,
        jsonRepresentation.strokeColor,
        jsonRepresentation.strokeWidth,
        jsonRepresentation.lineCap
    )
end

return APL.LuaUtils.readOnly(ShapeLayerConfiguration)