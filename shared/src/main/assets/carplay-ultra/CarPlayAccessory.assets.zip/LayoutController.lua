-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local APL = require "APL.APL"
local Appearance = require "Appearance"
local AppearanceController = require "AppearanceController"
local Catalog = require "Catalog"
local Component = require "Component"
local Constants = require "Constants"
local Display = require "Display"
local Enums = require "Enums"
local FocusSystem = require "FocusSystem"
local FocusToken = require "FocusToken"
local GaugeColor = require "GaugeColor"
local InputEventDispatcher = require "InputEventDispatcher"
local InputStream = require "InputStream"
local LayoutInfo = require "LayoutInfo"
local LogoAnim = require "LogoAnim"
local Palette = require "Palette"
local Signpost = require "APL.Signpost"
local State = require "State"
local VehicleDataUpdater = require "VehicleDataUpdater"
local Workspace = require "Workspace"
local Zone = require "Zone"
local Layout = require "Layout"
local UISceneState = require "UISceneState"
local VerifiedUIController = require "VerifiedUIController"

local LayoutController = APL.LuaUtils.makeObject({ _type = "LayoutController" })

local UISYNC_STATE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "IDLE",
    "RESETTING_PHONE",
    "TRANSITIONING"
}))

local UISYNC_COMMAND_TYPE = APL.LuaUtils.readOnly({
    START_ZONE_TRANSITION        = 0x01,
    TRANSITION_DATA              = 0x02,
    START_LAYOUT_TRANSITION      = 0x03,
    END_ZONE_TRANSITION          = 0x04,
    REQUEST_LAYOUT               = 0x05,
    END_LAYOUT_TRANSITION        = 0x06,
    GIVE_FOCUS                   = 0x07,
    REQUEST_FOCUS                = 0x08,
    METATADA_TRANSFER            = 0x09,
    PALETTE_CHANGE               = 0x10,
    ALLOW_LAYOUT_CHANGE          = 0x11,
    REQUEST_APPEARANCE           = 0x12,
    APPEARANCE_PREFERENCE_CHANGE = 0x13,
    REQUEST_DRIVE_MODE           = 0x14
})
local IPHONE_VIDEO_STREAM_NAME = "iPhoneVideo"










function LayoutController.new(theme, fastStart, display, preloadLayouts)





    local self = APL.LuaUtils.newObject(LayoutController, {
        _state = UISYNC_STATE.IDLE,
        _theme = theme,

        _display = APL.LuaUtils.NIL,
        _layoutsById = {}, -- Layout keyed by layout id.
        _layout = APL.LuaUtils.NIL,
        _nextLayout = APL.LuaUtils.NIL, -- when animating between layouts, this property is populated with the new layout.
        _workspace = APL.LuaUtils.NIL,

        _rootLayer = APL.LuaUtils.NIL,
        _contentRoot = APL.LuaUtils.NIL,
        _layoutsRootLayer = APL.LuaUtils.NIL,
        _logoAnimationLayer = APL.LuaUtils.NIL,

        _settingsInputStreams = {},
        _visibleSettingsInputStreams = {},

        _inputStreamInfoByType = {},
        _inputStreamInfoById= {},

        _session = APL.LuaUtils.NIL,
        _sessionFactory = APL.LuaUtils.NIL, -- { f=function, args=... }

        _vehicleDataUpdater = APL.LuaUtils.NIL,

        _transitionDataLastPTS = 0,
        _transitionCommands = {},
        _iPhoneVideoInputStream = APL.LuaUtils.NIL,

        _mainLoop = APL.LuaUtils.NIL,

        _inputEventDispatcher = APL.LuaUtils.NIL,
        _focusToken = APL.LuaUtils.NIL,

        _metadataDebugLayer = APL.LuaUtils.NIL,
        _punchoutLayer = APL.LuaUtils.NIL
    })

    local inputStreams = CP.enumerateInputStreams()
    APL.Log.info(LayoutController, function() return "Found %d input streams", #inputStreams end)
    for k, streamInfo in ipairs(inputStreams) do
        APL.Log.info(LayoutController, function() return "Stream %d", k end)
        APL.Log.info(LayoutController, function() return "\t identifier: %s", streamInfo.identifier end)
        APL.Log.info(LayoutController, function() return "\t frameDuration: %.6f", streamInfo.frameDuration end)
        APL.Log.info(LayoutController, function() return "\t width: %d", streamInfo.width end)
        APL.Log.info(LayoutController, function() return "\t height: %d", streamInfo.height end)
        APL.Log.info(LayoutController, function() return "\t streamMode: %d (0=buffered, 1=detached)", streamInfo.streamMode end)
        APL.Log.info(LayoutController, function() return "\t parameterMode: %d (0=uninitialized, 1=incoming, 2=outgoing)", streamInfo.parameterMode end)
        APL.Log.info(LayoutController, function() return "\t opacityCapability: %d (0=fixed, 1=dynamic)", streamInfo.opacityCapability end)
        APL.Log.info(LayoutController, function() return "\t positionCapability: %d (0=fixed, 1=dynamic)", streamInfo.positionCapability end)
        APL.Log.info(LayoutController, function() return "\t sizeCapability: %d (0=fixed, 1=dynamic)", streamInfo.sizeCapability end)
        APL.Log.info(LayoutController, function() return "\t type: %d (0=camera, 1=settings, 2=widget, 3=iPhoneVideo, 4=roadSign)", streamInfo.type end)

        self._inputStreamInfoById[streamInfo.identifier] = streamInfo
        self._inputStreamInfoByType[streamInfo.type] = self._inputStreamInfoByType[streamInfo.type] or {}
        table.insert(self._inputStreamInfoByType[streamInfo.type], streamInfo)
    end

    self._sessionFactory = {
        f = function() return APL.ClusterControlSession.new(State.getRemoteIdentifier()) end,
        args = {}
    }

    self._vehicleDataUpdater = VehicleDataUpdater.new(CP.getVehicleDataConfig())
    self._vehicleDataUpdater:registerOnUpdateComplete(function()
        VerifiedUIController.current():updateIfNecessary()
    end)

    self._focusToken = FocusToken.new()

    self._inputEventDispatcher = InputEventDispatcher.new(self._vehicleDataUpdater, function(events)
        if self._layout then
            self._layout:getFocusSystem():handleEvents(events)
        end
    end)


    self._mainLoop = APL.Thread.new(function()
        local startTime = CP.PTS
        APL.Log.info(LayoutController, function() return "Starting main loop (time=" .. startTime .. ")" end)

        while true do

            if not self._workspace:getState().isForegrounded and CP.isForegrounded then
                APL.Signpost.emitEvent("Asset will foreground")
                self._workspace:send(Workspace.ACTION.ForegroundStateDidChange.new(true))
            end


            self:_processTransitionCommands()


            local currentTime = CP.PTS
            local diff = (currentTime - startTime)
            APL.flux.update(diff)
            startTime = currentTime

            APL.Thread.yield()
        end
    end)
    :setTag("main_loop")


    local appearancePreference = State.getAppearancePreference() or Appearance.PREFERENCE.AUTOMATIC

    local _, nightModeValue = next(self._vehicleDataUpdater:getData({ VehicleDataUpdater.DATAIDENTIFIERS.nightMode }))
    local appearance = Appearance.new(Appearance.targetAppearanceFromNightMode(nightModeValue), appearancePreference)


    self._workspace = Workspace.new(self, self._vehicleDataUpdater, State, fastStart, display:getID(), appearance)
    local function setLangauge(language)


        local fontManager = APL.VectorFontManager.getDefaultManager()
        if fontManager and fontManager.language ~= language then
            APL.Log.info(LayoutController, function() return "Setting language to: " .. language end)
            fontManager.language = language
        end
    end

    local _, initialLanguage = next(self._vehicleDataUpdater:getData({ VehicleDataUpdater.DATAIDENTIFIERS.languageIdentifier }))
    if initialLanguage then
        setLangauge(initialLanguage)
    end

    local dataIdentifiers = { VehicleDataUpdater.DATAIDENTIFIERS.uiSceneState, VehicleDataUpdater.DATAIDENTIFIERS.languageIdentifier }
    local validDataIdentifiers = self._vehicleDataUpdater:subscribe(dataIdentifiers, function(update)
        local sceneStateUpdate = update[VehicleDataUpdater.DATAIDENTIFIERS.uiSceneState]
        if sceneStateUpdate then


            APL.Log.info(LayoutController, function() return "Received new UISceneState: " .. APL.LuaUtils.prettyPrint(sceneStateUpdate, false, 2) end)
            Signpost.emitEvent("Received new UISceneState: " .. sceneStateUpdate.state)
            self._workspace:send(Workspace.ACTION.UISceneStateDidChange.new(sceneStateUpdate))
        end

        local language = update[VehicleDataUpdater.DATAIDENTIFIERS.languageIdentifier]
        if language then
            setLangauge(language)
        end
    end)

    if APL.LuaUtils.first(validDataIdentifiers, function(id) return id == VehicleDataUpdater.DATAIDENTIFIERS.uiSceneState end) == nil then
        APL.Log.error(LayoutController, function() return "UISceneState not available, this is required!" end)
    end


    local validDataIdentifiers = self._vehicleDataUpdater:subscribe({ VehicleDataUpdater.DATAIDENTIFIERS.nightMode }, function(update)
        local nightMode = update[VehicleDataUpdater.DATAIDENTIFIERS.nightMode]
        APL.Log.info(LayoutController, function() return "Received new NightMode: " .. tostring(nightMode) end)

        self._workspace:send(Workspace.ACTION.TargetAppearanceModeChange.new(Appearance.targetAppearanceFromNightMode(nightMode)))
    end)
    if #validDataIdentifiers == 0 then
        APL.Log.error(LayoutController, function() return "NightMode not available" end)
    end


    APL.Log.info(LayoutController, function() return "Subscribing to driveMode" end)
    local validDataIdentifiers = self._vehicleDataUpdater:subscribe({ VehicleDataUpdater.DATAIDENTIFIERS.driveMode }, function(update)
        APL.Log.info(LayoutController, function() return "Received new driveMode update: " .. APL.LuaUtils.prettyPrint(update, false, 2) end)
        local driveMode = update[VehicleDataUpdater.DATAIDENTIFIERS.driveMode]
        if driveMode ~= VehicleDataUpdater.INVALID then
            self:_sendPayload(LayoutController._driveModeChangePayload(driveMode))
        else
            APL.Log.info(LayoutController, function() return "Received invalid Drive Mode" end)
        end
    end)
    if #validDataIdentifiers == 0 then
        APL.Log.error(LayoutController, function() return "DriveMode not available" end)
    end

    return self:_loadDisplay(display, appearance:getResolvedAppearanceMode())
end






function LayoutController:destroy()


    APL.LuaUtils.forEach(self._layoutsById, function(layout)
        layout:destroy()
    end)

    if self._session then
        self._session:destroy()
    end

    self._inputEventDispatcher:destroy()
    self._vehicleDataUpdater:destroy()
    self._mainLoop:destroy()

    VerifiedUIController.current():stop()
end






function LayoutController:getActiveLayout()


    if not self._layout then
        APL.Log.error(LayoutController, function() return "getActiveLayout No active Layout" end)
        return
    end
    return self._layout
end







function LayoutController:overrideSessionFactory(f, ...)



    self._sessionFactory = {
        f = f,
        args = {...}
    }

    return self
end








function LayoutController:_loadDisplay(display, appearanceMode)





    local uiAppearanceMode = Appearance.toUIAppearanceMode(appearanceMode)

    APL.Log.info(LayoutController, function() return "Loading display %s", display:getID() end)

    self._display = display
    self._focusToken = FocusToken.new()



    local rootLayerColor = uiAppearanceMode == Enums.AppearanceMode.LIGHT and GaugeColor.white or GaugeColor.black






























    self._rootLayer = APL.Layer.new()
        :setFrame(self._display:getBounds())


    self._contentRoot = APL.Layer.new()


    local videoStream = self:_getIPhoneVideoStream()
    if videoStream then
        videoStream
            :setVisible(true)
            :getRootLayer()
            :setOpacity(0)
            :setFrame(self._display:getBounds())
            :addToSuperLayer(self._contentRoot)
    end



    local primaryLayoutFadeToBlack = true
    APL.LuaUtils.forEach(display:getLayouts(LayoutInfo.KIND.UNDERLAY), function(layoutInfo)
        APL.Log.info(LayoutController, function() return "Creating underlay layout" end)
        local underlay = self:_createLayout(layoutInfo:getID(), uiAppearanceMode)
            :attach(self._rootLayer, true)




        if underlay:getPunchoutLayer() then
            underlay:getPunchoutLayer()
               :addToSuperLayer(self._contentRoot)
        end

        self._layoutsById[layoutInfo:getID()] = underlay


        primaryLayoutFadeToBlack = not underlay:hasPersistentGauges()
    end)

    self._contentRoot
        :setFrame(self._display:getBounds())
        :setBackgroundColor(rootLayerColor)
        :addToSuperLayer(self._rootLayer)


    self._layoutsRootLayer = APL.Layer.new()
        :setFrame(self._display:getBounds())
        :addToSuperLayer(self._contentRoot)


    local paletteSelections = State.getPaletteSelections() or {}



    local layoutName = APL.Config.readParam("STARTUP.LAYOUT.NAME")
    local layoutID = APL.Config.readParam("STARTUP.LAYOUT.ID")
    local paletteID = APL.Config.readParam("STARTUP.LAYOUT.PALETTE_ID")
    if (layoutID or layoutName) and paletteID then
        local layout = self._display:getLayout(layoutID or layoutName)
        if layout then
            local paletteSelections = State.getPaletteSelections() or {}
            paletteSelections[layout:getID()] = paletteID
            State.setPaletteSelections(paletteSelections)
        end
    end

    APL.Log.info(LayoutController, function() return "Loaded palette selections from persistent store: " .. APL.LuaUtils.prettyPrint(paletteSelections) end)


    APL.LuaUtils.forEach(display:getLayouts(LayoutInfo.KIND.PRIMARY), function(layout)
        local layoutID = layout:getID()
        local paletteID = paletteSelections[layoutID]
        self._layoutsById[layoutID] = self:_createLayout(layoutID, uiAppearanceMode, paletteID)
            :setAllowFadeToBlack(primaryLayoutFadeToBlack)

        APL.Log.info(LayoutController, function() return "Loaded primary layout: \"%s\" (%s), appearance: (%s)", layout:getDisplayName(), layoutID, APL.LuaUtils.prettyPrint(uiAppearanceMode) end)
    end)



    APL.LuaUtils.forEach(display:getLayouts(LayoutInfo.KIND.OVERLAY), function(layoutInfo)

        local layout = self:_createLayout(layoutInfo:getID(), uiAppearanceMode)
            :attach(self._contentRoot, true)

        self._layoutsById[layoutInfo:getID()] = layout
        APL.Log.info(LayoutController, function() return "Loaded overlay layout: \"%s\" (%s)", layoutInfo:getDisplayName(), layoutInfo:getID() end)

        self._settingsInputStreams = APL.LuaUtils.merge(self._settingsInputStreams, layout:getInputStreamsByKind(InputStream.KIND.SETTINGS))
    end)

    APL.Log.info(LayoutController, function() return "Settings Input Streams: " .. APL.LuaUtils.prettyPrint(self._settingsInputStreams, false, 2) end)


    if APL.Config.readParam("DEBUGGING.TRANSITIONS.VISUAL_FEEDBACK") then
        APL.Log.info(LayoutController, function() return "Setting up metadata debug layer" end)
        local x, y, width, height = self._display:getBounds()
        self._metadataDebugLayer = APL.Layer.new()
            :setFrame(APL.Rect.new(0, math.max(0, height - 200), width, height))
            :addToSuperLayer(self._contentRoot)
    end


    self._mainLoop:start()


    self:_startClusterControlSession()

    VerifiedUIController.current():start(function()
        self:_updateVerifiedUI()
    end)


    self._vehicleDataUpdater:start()


    self:activateLocalDriveUI(Layout.MODE.OFF, false)




    APL.LuaUtils.forEach(display:getLayouts(LayoutInfo.KIND.PRIMARY), function(layoutInfo)
        if layoutInfo:getID() == self._layout:getID() then
            return
        end

        local layout = self._layoutsById[layoutInfo:getID()]
        layout
            :_connectVehicleData()
            :_disconnectVehicleData()
    end)

    Signpost.emitEvent("Ready to render")

    return self
end






function LayoutController:resetClusterControlSession()


    self._session:reset()

    return self
end








function LayoutController:showLogos(animator, skipPartnerLogoFadeIn)





    if self._logoAnimationLayer then
        APL.Log.info(LayoutController, function() return "Destroying logo animation layer" end)
        self._logoAnimationLayer:destroy()
        self._logoAnimationLayer = nil
    end

    local _, _, displayWidth, displayHeight = self._layoutsRootLayer:getFrame()
    self._logoAnimationLayer = LogoAnim.anim(displayWidth, displayHeight, animator, skipPartnerLogoFadeIn)

    animator
        :anim(function()


            self._logoAnimationLayer:addToSuperLayer(self._layoutsRootLayer)
        end)
        :onComplete(function()
            if self._logoAnimationLayer then
                self._logoAnimationLayer:destroy()
                self._logoAnimationLayer = nil
            end
        end)

    return self
end






function LayoutController:isShowingLogo()


    return self._logoAnimationLayer ~= nil
end







function LayoutController:hideLogos(duration)



    if self._logoAnimationLayer then
        APL.Log.info(LayoutController, function() return "Hiding logo animation: duration = %s", tostring(duration) end)

        self._logoAnimationLayer
            :animOpacity(0, duration, function()
                if self._logoAnimationLayer then
                    self._logoAnimationLayer:destroy()
                    self._logoAnimationLayer = nil
                end
            end)
            :ease("bezier", table.unpack(Constants.LOGOS_ANIM_FADEOUT_CURVE))
    end

    return self
end









function LayoutController:activateLocalDriveUI(mode, animated, animationInitialDelay)





    local animated = animated == nil and true or animated

    if self._layout == nil then
        local lastLayoutID = self:_getLastUsedLayoutID()
        if lastLayoutID == nil then

            APL.Log.error(LayoutController, function() return "No primary layout to prepare!" end)
            return self
        end

        self:_stageNextLayout(lastLayoutID)

        self:swapLayout()

    end



    APL.Log.info(LayoutController, function() return "Activating local layout \"%s\" (%s): mode = %s", self._layout:getDisplayName(), self._layout:getID(), tostring(mode) end)



    APL.LuaUtils.forEach(self._display:getLayouts(LayoutInfo.KIND.PRIMARY), function(layout)
        local layout = self._layoutsById[layout:getID()]

        local shouldAnimate = layout:getID() == self._layout:getID() and animated or false
        layout:setLayoutMode(mode, shouldAnimate, animationInitialDelay)
    end)

    return self
end







function LayoutController:activateRemoteUI(appearanceMode)




    APL.Log.info(LayoutController, function() return "Activating remote UI" end)

    local targetLayout = self._nextLayout or self._layout
    if targetLayout == nil then
        APL.Log.warn(LayoutController, "No layout!") -- Center Console assets don't have layouts but need to send request anyway
    end

    self:_sendLayoutRequest(targetLayout, appearanceMode, false, false)

    return self
end







function LayoutController:allowLayoutChange(allow)



    if self._session:getIsReady() then
        local payload = {
            type = UISYNC_COMMAND_TYPE.ALLOW_LAYOUT_CHANGE,
            data = {
                allow = allow
            }
        }
        Signpost.emitEvent("Sending allowLayoutChange command, allow:" .. tostring(allow))

        APL.Log.info(LayoutController, function() return "Queueing allowLayoutChange command, allow: " .. APL.LuaUtils.prettyPrint(payload, false, 3) .. ", session ready: " .. (self._session:getIsReady() and "true" or "false") .. "_state: " .. self._state end)

        self._session:sendCommand(payload)
    else
        APL.Log.info(LayoutController, function() return "Not ready to send allowLayoutChange command, _state: " .. self._state .. ", session ready: " .. (self._session:getIsReady() and "true" or "false") end)
    end

    return self
end








function LayoutController:showRemoteUI(animated, animationDelay)




    local animated = animated == nil and true or animated
    local animationDelay = animationDelay or 0
    APL.Log.info(LayoutController, function() return "Showing remote UI (animated = %s, delay = %s)", tostring(animated), tostring(animationDelay) end)

    local videoStreamLayer = self:_getIPhoneVideoStream():getRootLayer()

    if animated then
        videoStreamLayer
            :animOpacity(1, Constants.REMOTEUI_FADEIN_DURATION)
            :ease("bezier", table.unpack(Constants.REMOTEUI_CURVE))
            :delay(animationDelay or 0)
            :oncomplete(function()
                APL.Log.info(LayoutController, function() return "Remote UI  is fully visible now" end)
            end)
    else
        videoStreamLayer:setOpacity(1) -- cancels on going opacity animation
    end

    for identifier, settingsInputStream in pairs(self._visibleSettingsInputStreams) do
        APL.Log.info(LayoutController, function() return "Re-presenting: " .. identifier end)
        settingsInputStream:setVisible(true)
    end

    if self._layout then
        self._layout:showRemoteUI(animated, animationDelay)
    end

    if self._nextLayout then
        self._nextLayout:showRemoteUI(animated, animationDelay)
    end

    return self
end








function LayoutController:hideRemoteUI(disconnected, animated)




    local disconnected = disconnected ~= nil and disconnected or false
    local animated = animated == nil and true or animated

    APL.Log.info(LayoutController, function() return "Hiding remote UI (animated = %s, disconnected = %s)", tostring(animated), tostring(disconnected) end)

    local videoStreamLayer = self:_getIPhoneVideoStream():getRootLayer()


    if animated then
        videoStreamLayer
            :animOpacity(0, Constants.REMOTEUI_FADEOUT_DURATION)
            :ease("bezier", table.unpack(Constants.REMOTEUI_CURVE))
            :oncomplete(function()
                APL.Log.info(LayoutController, function() return "Remote UI is fully hidden now" end)
            end)
    else
        videoStreamLayer:setOpacity(0)
    end


    for _, gauge in pairs(self._settingsInputStreams) do
        gauge:setVisible(false)
    end

    if disconnected then



        self._visibleSettingsInputStreams = {}
    end

    if self._layout then
        self._layout:hideRemoteUI(disconnected, animated)
    end

    if self._nextLayout then
        self._nextLayout:hideRemoteUI(disconnected, animated)

        if disconnected then
            self:swapLayout()
        end
    end

    APL.LuaUtils.forEach(self._display:getLayouts(LayoutInfo.KIND.UNDERLAY), function(layoutInfo)

        local layout = self._layoutsById[layoutInfo:getID()]
        if layout then
            layout:hideRemoteUI(disconnected, animated)
        end
    end)

    return self
end







function LayoutController:checkRemoteUIFreshness(pts)



    local iPhoneVideoStream = self:_getIPhoneVideoStream()
    if not iPhoneVideoStream then
        return nil
    end


    if not APL.LuaUtils.isOptimized() and APL.Config.readParam("DEBUGGING.TRANSITIONS.FAKE_LATE_VIDEO") then
        local result = math.random(0, 1) == 1 -- randomize between true and false
        APL.Log.warn(LayoutController, function() return "TESTING: faking video staleness: " .. tostring(result) end)
        return result
    end

    local currentPTS = iPhoneVideoStream:getCurrentPTS()
    currentPTS = currentPTS and math.floor(currentPTS * 1e3) -- convert to milliseconds
    if not currentPTS then
        APL.Log.error(LayoutController, function() return "Couldn't get current video stream PTS to check freshness" end)
        return nil
    end

    APL.Log.info(LayoutController, function() return "Checking iPhone video stream freshness: %s >= %s ?", tostring(currentPTS), tostring(pts) end)


    if currentPTS < math.max(0, pts - 10000) then
        APL.Log.warn(LayoutController, function() return "ignoring invalid PTS %s, way over current PTS %s by %s", tostring(pts), tostring(currentPTS), tostring(pts-currentPTS) end)
        return nil
    end

    return currentPTS >= pts
end




function LayoutController:sceneDidForeground()


    APL.Log.info(LayoutController, function() return "Foregrounding scene" end)







    self._session:resetIfWaitingForResetComplete()


    APL.VideoLayer.setSubscribable(true)


    if not APL.ErrorHandler.hasForwardedError() then
        CP.setRootLayer(self._display:getID(), self._rootLayer:getNativeLayer())
    else
        APL.Log.error(LayoutController, function() return "Root layer is showing an error" end)
    end

    APL.Signpost.emitEvent("Asset did foreground")
end






function LayoutController:_getIPhoneVideoStream()


    if not self._iPhoneVideoInputStream then
        local streamInfo = self._inputStreamInfoById[IPHONE_VIDEO_STREAM_NAME]
        if not streamInfo then
            return nil
        end

        APL.Log.info(LayoutController, function() return "Creating iPhone Video inputStream" end)
        local inputStream = InputStream.new(
            IPHONE_VIDEO_STREAM_NAME,
            nil,
            streamInfo.frameDuration,
            streamInfo.type,
            APL.Rect.new(0, 0, streamInfo.width, streamInfo.height)
        )

        self._iPhoneVideoInputStream = inputStream
    end

    return self._iPhoneVideoInputStream
end










function LayoutController:_getLastUsedLayoutID()


    local layout


    local layoutName = APL.Config.readParam("STARTUP.LAYOUT.NAME")
    local layoutID = APL.Config.readParam("STARTUP.LAYOUT.ID")
    if layoutID or layoutName then
        layout = self._display:getLayout(layoutID or layoutName)
    end


    if not layout then
        local lastActiveLayoutID = tostring(State.getActiveLayoutID())
        APL.Log.info(LayoutController, function() return "Last persisted layout ID was: " .. lastActiveLayoutID or "unset" end)



        layout = lastActiveLayoutID
            and self._display:getLayout(lastActiveLayoutID)
            or self._display:getLayouts(LayoutInfo.KIND.PRIMARY)[1]
    end



    return layout:getID()
end









function LayoutController:_createLayout(layoutID, uiAppearanceMode, paletteID)







    local layoutInfo = self._display:getLayout(layoutID)

    APL.Log.info(LayoutController, function() return "Loading layout \"%s\" (%s), appearance: (%s)", layoutInfo:getDisplayName(), layoutInfo:getID(), APL.LuaUtils.prettyPrint(uiAppearanceMode) end)

    local palette = layoutInfo:getPalette(self._theme, paletteID)
    local layout = APL.Signpost.measure("Loading layout \"" .. layoutInfo:getDisplayName() .. "\" (" .. layoutInfo:getID() .. ")", function()
        return Layout.new(
            layoutInfo,
            AppearanceController.State.new(palette, uiAppearanceMode),
            APL.Rect.new(self._contentRoot:getFrame()),
            self._vehicleDataUpdater,
            self._inputStreamInfoByType,
            self._inputStreamInfoById,
            self._display:getNotifications(),
            self._display:getShadows(),
            self._display:getID()
        )
    end)

    layout:getFocusSystem()
        :setHasFocusItemsUpdateHandler(function(hasFocusItems)
            if self._layout == layout then
                self:_evalutateFocusTokenStatus(hasFocusItems, self._workspace:getState():isUISyncConnected())
            end
        end)

    return layout
end







function LayoutController:_stageNextLayout(layoutID)



    if self._nextLayout == nil or self._nextLayout:getID() ~= layoutID then
        local nextLayout = self._layoutsById[layoutID]


        APL.Log.info(LayoutController, function() return "Staging next layout \"%s\" (%s).", nextLayout:getDisplayName(), nextLayout:getID() end)
        APL.Signpost.emitEvent("Staging next layout %s", nextLayout:getID())


        if self._nextLayout then
            self._nextLayout:detach()
            self._nextLayout = nil
        end

        self._nextLayout = nextLayout
    else
        APL.Log.info(LayoutController, function() return "Layout \"%s\" (%s) already staged.",  self._nextLayout:getDisplayName(), self._nextLayout:getID() end)
    end

    return self
end






function LayoutController:swapLayout()


    if not self._nextLayout then
        APL.Log.error(LayoutController, function() return "Asking to swap layout but there's no next layout" end)
        return self
    end

    if self._layout then
        self._layout:detach()
        self._layout = nil
    end

    self._layout = self._nextLayout
        :attach(self._layoutsRootLayer, true)
        :setFocusEnabled(self._focusToken:hasOwnership())

    self._nextLayout = nil

    self:_evalutateFocusTokenStatus(self._layout:getFocusSystem():hasFocusItems(), self._workspace:getState():isUISyncConnected())

    APL.Log.info(LayoutController, function() return "Set current layout: \"%s\" (%s)", self._layout:getDisplayName(), self._layout:getID() end)
    Signpost.emitEvent("Set current layout: " .. self._layout:getID())
    VerifiedUIController.current():setNeedsUpdate()


    State.setActiveLayoutID(self._layout:getID())
    State.setActiveDCAComponentIDs(APL.LuaUtils.merge(State.getActiveDCAComponentIDs() or {}, self._layout:getActiveDCAComponentIDs()))

    return self
end




function LayoutController:_handleGiveFocusCommand(command)



    local tokenID = command.data and command.data.tokenID or nil
    if tokenID then
        APL.Log.info(LayoutController, function() return "Received giveFocus request with token " .. tokenID end)

        self:_takeFocusToken(tokenID)
    else
        APL.Log.error(LayoutController, function() return "Received malformed giveFocus command" end)
    end
end






function LayoutController:_handleRequestFocusCommand(command)



    local tokenID = command.data and command.data.tokenID or nil
    if tokenID then
        APL.Log.info(LayoutController, function() return "Received requestFocus request with token " .. tokenID end)

        if self._focusToken then
            if tokenID ~= self._focusToken:getTokenID() then

                APL.Log.error(LayoutController, function() return "Found focus token " .. tokenID .. " expected " .. self._focusToken:getTokenID() end)
            end

            if self._focusToken:hasOwnership() then
                self._sendGiveFocus()
            else
                APL.Log.error(LayoutController, function() return "Received requestFocus " .. tokenID .. " but remote side already owns focus" end)
            end
        else
            APL.Log.error(LayoutController, function() return "Missing focus token" end)
        end
    else
        APL.Log.error(LayoutController, function() return "Received malformed requestFocus command" end)
    end
end







function LayoutController:_setActiveDCAComponentIDs(componentIDs)



    if not self._layout then
        APL.Log.error(LayoutController, function() return "_setActiveDCAComponentIDs: No active Layout" end)
        return
    end

    self._layout:setActiveDCAComponentIDs(componentIDs)

    return self
end






function LayoutController:_startClusterControlSession()


    if not self._session then
        local wrap = function(self, f)
            return function(...)
                return f(self, table.unpack({...}))
            end
        end

        self._session = self._sessionFactory.f(table.unpack(self._sessionFactory.args))
            :setResetHandler(wrap(self, self._handleSessionReset))
            :setReadyHandler(wrap(self, self._handleSessionReady))
            :setDataHandler(wrap(self, self._handleSessionData))
            :start()
    end

    return self
end






function LayoutController:_updateVerifiedUI()


    if not self._layout then
        APL.Log.error(LayoutController, function() return "_updateVerifiedUI No active Layout" end)
        return
    end

    local verifiedInfo = APL.LuaUtils.reduce(VerifiedUIController.current():getVerifiedElements(), {}, function(result, verifiedElement)
        local layer = verifiedElement:getVerifiedLayer()
        local verifierIdentifier = verifiedElement:getVerifierIdentifier()

        if not verifierIdentifier then
            APL.Log.error(LayoutController, function() return "Unable to retrieve verified element identifier: ".. APL.LuaUtils.prettyPrint(verifiedElement) end)
            return result
        end

        if layer then
            local rect = layer:convertFrameToSuperLayer(self._contentRoot)




            if rect then
                result[#result+1] = {
                    originX = math.floor(rect._x),
                    originY = math.floor(rect._y),
                    width = math.floor(rect._width),
                    height = math.floor(rect._height),
                    presentationStyle = "default-new",
                    identifier = verifierIdentifier
                }
            end
        end

        return result
    end)

    APL.Log.info(LayoutController, function() return "Verified UI State: ".. APL.LuaUtils.prettyPrint(verifiedInfo) end)

    CP.UpdateVerifiedUIElements(verifiedInfo)

    return self
end







function LayoutController:evalutateFocusTokenStatus(connected)



    if not connected then
        self:_resetFocusToken()
    end

    if self._layout then
        self:_evalutateFocusTokenStatus(self._layout:getFocusSystem():hasFocusItems(), connected)
    else
        APL.Log.error(LayoutController, function() return "Unable to evaluate focus token status - no layout" end)
    end
end








function LayoutController:_evalutateFocusTokenStatus(hasFocusItems, connected)




    local tokenID = self._focusToken:getTokenID()
    local hasOwnership = self._focusToken:hasOwnership()

    APL.Log.info(LayoutController, function() return "Evalutating %s focus token %d: hasFocusItems: %s, connected: %s", hasOwnership and "held" or "released", tokenID, tostring(hasFocusItems), tostring(connected) end)

    if self._focusToken then
        if not connected then
            self:_takeFocusIfNeeded()
        elseif hasFocusItems then
            self:_sendRequestFocusIfNeeded()
        else
            self:_sendGiveFocusIfNeeded()
        end
    else
        APL.Log.error(LayoutController, function() return "Unable to evaluate focus token status - no focus token" end)
    end

    return self
end







function LayoutController:_takeFocusToken(tokenID)



    if self._focusToken then
        if tokenID ~= self._focusToken:getTokenID() then

            APL.Log.error(LayoutController, function() return "Found focus token " .. tokenID .. " expected " .. self._focusToken:getTokenID() end)
        end

        if self._focusToken:hasOwnership() then


            APL.Log.error(LayoutController, function() return "Focus token " .. tokenID .. " already acquired" end)
        else
            APL.Log.info(LayoutController, function() return "Acquired focus token " .. tokenID end)

            self._focusToken:acquire()
        end

        if self._layout then
            self._layout:setFocusEnabled(true)
        end
    else
        APL.Log.error(LayoutController, function() return "Unable to take focus token, token is missing" end)
    end
end






function LayoutController:_resetFocusToken()


    self._focusToken:destroy()
    self._focusToken = FocusToken.new()

    if self._layout then
        self._layout:setFocusEnabled(true)
    end

    return self
end




function LayoutController:_handleSessionReset()



    if self._state ~= UISYNC_STATE.IDLE then
        APL.Log.warn(LayoutController, function() return "Received reset during transition..." end)
        self._state = UISYNC_STATE.IDLE
    else
        APL.Log.info(LayoutController, function() return "Received reset, waiting for phone" end)
        self._state = UISYNC_STATE.RESETTING_PHONE
    end


    self._transitionCommands = {}
    self._transitionDataLastPTS = 0

    self._workspace:send(Workspace.ACTION.UISyncConnectionDidChange.new(false))
end






function LayoutController:_handleSessionReady(remoteIdentifier)



    if remoteIdentifier then
        State.setRemoteIdentifier(remoteIdentifier)
    end

    self._workspace:send(Workspace.ACTION.UISyncConnectionDidChange.new(true))
end






function LayoutController:_handleSessionData(data)




    local command = CP.parsePlist(data)
    if not command or not command.type then
        APL.Log.error(LayoutController, function() return "Unable to parse data" end)
        return
    end

    if command.type == UISYNC_COMMAND_TYPE.METATADA_TRANSFER or
       command.type == UISYNC_COMMAND_TYPE.START_ZONE_TRANSITION or
       command.type == UISYNC_COMMAND_TYPE.END_ZONE_TRANSITION or
       command.type == UISYNC_COMMAND_TYPE.START_LAYOUT_TRANSITION or
       command.type == UISYNC_COMMAND_TYPE.END_LAYOUT_TRANSITION or
       command.type == UISYNC_COMMAND_TYPE.TRANSITION_DATA then
        return self:_enqueueTransitionCommand(command)
    elseif command.type == UISYNC_COMMAND_TYPE.GIVE_FOCUS then
        return self:_handleGiveFocusCommand(command)
    elseif command.type == UISYNC_COMMAND_TYPE.REQUEST_FOCUS then
        return self:_handleRequestFocusCommand(command)
    elseif command.type == UISYNC_COMMAND_TYPE.PALETTE_CHANGE then
        return self:_handlePaletteChangeCommand(command)
    elseif command.type == UISYNC_COMMAND_TYPE.APPEARANCE_PREFERENCE_CHANGE then
        return self:_handleAppearancePreferenceChangeCommand(command)
    else
        APL.Log.error(LayoutController, function() return "Unhandled command of type " .. tostring(command.type) end)
        return
    end
end




function LayoutController:_handleMetadataTransfer(command)



    if command.data.isTransitioning then
        APL.Log.info(LayoutController, function() return "Starting Metadata Transition" end)
        self._state = UISYNC_STATE.TRANSITIONING
    else
        APL.Log.info(LayoutController, function() return "Ending Metadata Transition" end)
        self._state = UISYNC_STATE.IDLE

        self._transitionDataLastPTS = 0

        if self._metadataDebugLayer then
            self._metadataDebugLayer:setVisible(false)
        end
    end
end




function LayoutController:_handleSessionStalled(stallTime)




end









function LayoutController:_handleStartZoneTransitionCommand(command)



    APL.Log.info(LayoutController, function() return "Handling zone transition start command: " .. APL.LuaUtils.prettyPrint(command, false, 5) end)
    Signpost.emitEvent("Received START_ZONE_TRANSITION command")

    if not command.data then
        return
    end


    if command.data.presentStream then

        APL.Log.info(LayoutController, function() return "Looking to present: " .. command.data.presentStream end)
        local gauge = self._settingsInputStreams[command.data.presentStream]
        if not gauge then
            APL.Log.error(LayoutController, function() return "unknown input stream " .. command.data.presentStream end)

            return
        end
        gauge:setVisible(true)
        self._visibleSettingsInputStreams[command.data.presentStream] = gauge
    elseif command.data.dismissStream then

        APL.Log.info(LayoutController, function() return "Looking to dismiss: " .. command.data.dismissStream end)
        local gauge = self._settingsInputStreams[command.data.dismissStream]
        if not gauge then
            APL.Log.error(LayoutController, function() return "unknown input stream " .. command.data.dismissStream end)

            return
        end
        gauge:setVisible(false)
        self._visibleSettingsInputStreams[command.data.dismissStream] = nil
    elseif command.data.targetComponents then
        APL.Log.info(LayoutController, function() return "New target components: " .. APL.LuaUtils.prettyPrint(command.data.targetComponents) end)

        if self._layout then
            self._layout:startZoneTransition(command.data.targetComponents)
        end
        if self._nextLayout then
            self._nextLayout:startZoneTransition(command.data.targetComponents)
        end
    end
end






function LayoutController:_handleEndZoneTransitionCommand(command)




    APL.Log.info(LayoutController, function() return "Handling zone transition end command: " .. APL.LuaUtils.prettyPrint(command, false, 5) end)
    Signpost.emitEvent("Received END_ZONE_TRANSITION command")

    if command.data then
        self:_applyTransitionData(command.data)
    end

    if self._layout then
        self._layout:endZoneTransition()
     end
     if self._nextLayout then
         self._nextLayout:endZoneTransition()
     end

     local lastPTS = command.data and command.data.pts
     if lastPTS then

         self._workspace:send(Workspace.ACTION.CheckRemoteUIFreshness.new(lastPTS, 2))
     end
end






function LayoutController:_handleStartLayoutTransitionCommand(command)



    APL.Log.info(LayoutController, function() return "Handling layout transition start command: " .. APL.LuaUtils.prettyPrint(command, false, 4) end)

    if command.data and command.data.layoutID then
        local layoutID = command.data.layoutID
        local activeComponentIDs = command.data.activeComponents
        local layoutInfo = self._display:getLayout(layoutID)

        local kind = layoutInfo:getKind()



        self._workspace:send(Workspace.ACTION.LayoutChangeDidStart.new(layoutID, activeComponentIDs))
    end
end







function LayoutController:prepareNextLayout(layoutID, activeComponentIDs)




    Signpost.emitEvent("Layout transition started. Target layout: " .. layoutID)

    APL.Log.measure(LayoutController, "Measuring prepareNextLayout", true, function()
        local activeLayout = self._layout and self._layout:getID() or "none"
        local layoutInfo = self._display:getLayout(layoutID)

        if activeLayout ~= layoutID then

            if self._nextLayout == nil or self._nextLayout ~= layoutID then
                self:_stageNextLayout(layoutID)




                APL.Log.info(LayoutController, function() return "Layout transition started, showing remote UI for layout " .. layoutID end)
                self._nextLayout:showRemoteUI(false)
            end
        end

        if activeComponentIDs then
            if self._layout then
                self._layout:setActiveDCAComponentIDs(activeComponentIDs)
            end
            if self._nextLayout then
                self._nextLayout:setActiveDCAComponentIDs(activeComponentIDs)
            end
        end
    end)

    Signpost.emitEvent("Phone completed layout loading")
end






function LayoutController:_handleEndLayoutTransitionCommand(command)



    APL.Log.info(LayoutController, function() return "Handling layout transition end command: " .. APL.LuaUtils.prettyPrint(command, false, 4) end)


    if not APL.LuaUtils.isOptimized() and APL.Config.readParam("DEBUGGING.TRANSITIONS.DROP_END_COMMAND") then
        APL.Log.warn(LayoutController, function() return "TESTING: Dropping end command" end)
        return
    end

    if command.data then
        self:_applyTransitionData(command.data)
    end

    local layoutID = command.data.layoutID
    self._workspace:send(Workspace.ACTION.LayoutChangeDidEnd.new(layoutID))

    local lastPTS = command.data and command.data.pts
    if lastPTS then

        self._workspace:send(Workspace.ACTION.CheckRemoteUIFreshness.new(lastPTS, 2))
    end
end






function LayoutController:_enqueueTransitionCommand(command)




    local pts = command.data and command.data.pts and math.floor(command.data.pts * 1e3)
    if pts then
        command.data.pts = pts
    end

    if command.type == UISYNC_COMMAND_TYPE.TRANSITION_DATA then

        if command.data and command.data.regions and pts and pts > 0 then
            APL.Log.debug("Metadata", function() return "Received transition metadata with pts %d (@ %d): %s", pts, CP.getSystemUpTime() * 1000, APL.LuaUtils.prettyPrint(command.data, false, 4) end)

            if pts < self._transitionDataLastPTS then
                APL.Log.error("Metadata", function() return "Skip out of order transition metadata: %d < %d ", pts, self._transitionDataLastPTS end)
                return
            end

            self._transitionDataLastPTS = pts
            self._transitionCommands[#self._transitionCommands+1] = command
        else
            APL.Log.error("Metadata", function() return "Invalid transition metadata: " .. APL.LuaUtils.prettyPrint(command, false, 4) end)
        end
    else
        APL.Log.info("Metadata", function() return "Received transition start/end event (@ %d): %s", CP.getSystemUpTime() * 1000, APL.LuaUtils.prettyPrint(command, false, 4) end)
        self._transitionCommands[#self._transitionCommands+1] = command
    end
end






function LayoutController:_handlePaletteChangeCommand(command)



    APL.Log.info(LayoutController, function() return "Received palette change command: " .. APL.LuaUtils.prettyPrint(command, false, 3) end)


    if command.data and command.data.paletteIdentifier and command.data.layoutIdentifier then
        local paletteIdentifier = command.data.paletteIdentifier
        local layoutIdentifier = command.data.layoutIdentifier

        self._workspace:send(Workspace.ACTION.PaletteChange.new(layoutIdentifier, paletteIdentifier))
    else
        APL.Log.error(LayoutController, function() return "Palette change command is incomplete! Ignoring..." end)
    end
end






function LayoutController:_handleAppearancePreferenceChangeCommand(command)



    APL.Log.info(LayoutController, function() return "Received appearance preference changed command: " .. APL.LuaUtils.prettyPrint(command, false, 3) end)

    local appearancePreference = command.data.preference



    self._workspace:send(Workspace.ACTION.AppearancePreferenceChange.new(appearancePreference))
end








function LayoutController:handlePaletteChange(layoutIdentifier, paletteIdentifier, appearanceMode)




    local uiAppearanceMode = Appearance.toUIAppearanceMode(appearanceMode)

    APL.Log.info(LayoutController, function() return "Handle palette change (" .. layoutIdentifier .. "): " .. paletteIdentifier end)

    APL.Signpost.measure("Changing layouts palette change to " .. APL.LuaUtils.prettyPrint(paletteIdentifier), function()
        local palette = self._display
            :getLayout(self._layout:getID())
            :getPalette(self._theme, paletteIdentifier)
        self._layout:setAppearance(AppearanceController.State.new(palette, uiAppearanceMode))


        local paletteSelections = State.getPaletteSelections() or {}
        paletteSelections[layoutIdentifier] = paletteIdentifier
        APL.Log.info(LayoutController, function() return "Saving palette selections to State: " .. APL.LuaUtils.prettyPrint(paletteSelections) end)
        State.setPaletteSelections(paletteSelections)
    end)
end






function LayoutController:handleAppearanceChange(appearanceMode)



    local uiAppearanceMode = Appearance.toUIAppearanceMode(appearanceMode)

    APL.Signpost.measure("Changing layouts appearance to " .. APL.LuaUtils.prettyPrint(appearanceMode), function()

        local rootLayerColor = uiAppearanceMode == Enums.AppearanceMode.LIGHT and GaugeColor.white or GaugeColor.black
        self._contentRoot:setBackgroundColor(rootLayerColor)

        local paletteSelections = State.getPaletteSelections() or {}

        APL.LuaUtils.forEach(self._layoutsById, function(layout)
            local palette = self._display
                :getLayout(layout:getID())
                :getPalette(self._theme, paletteSelections[layout:getID()])
            layout:setAppearance(AppearanceController.State.new(palette, uiAppearanceMode))
        end)
    end)
end










function LayoutController:_sendLayoutRequest(layout, appearanceMode, fadeInNewLayout, fadeOutOldLayout)







    if self._session:getIsReady() then
        Signpost.emitEvent("Sending layout load request to phone")

        local payload = {
            type = UISYNC_COMMAND_TYPE.REQUEST_LAYOUT,
            data = {
                layoutID = layout and layout:getID() or nil,
                paletteID = layout and layout:getPaletteID() or nil,
                appearanceMode = appearanceMode,
                fadeInNewLayout = fadeInNewLayout == nil and true or fadeInNewLayout,
                fadeOutOldLayout = fadeOutOldLayout == nil and true or fadeOutOldLayout,
                activeComponents = layout and layout:getActiveDCAComponentIDs()
            }
        }

        APL.Log.info(LayoutController, function() return "Queuing requestLayout command: " .. APL.LuaUtils.prettyPrint(payload, false, 3) end)
        self._session:sendCommand(payload)
    else
        APL.Log.info(LayoutController, function() return "Not ready to send requestLayout command, _state: " .. self._state .. ", session ready: " .. (self._session:getIsReady() and "true" or "false") end)
    end

    return self
end








function LayoutController:sendTargetAppearanceChange(appearanceMode)




    if self._session:getIsReady() then
        Signpost.emitEvent("Sending new appearance request to phone")

        local payload = {
            type = UISYNC_COMMAND_TYPE.REQUEST_APPEARANCE,
            data = {
                appearanceMode = appearanceMode
            }
        }

        APL.Log.info(LayoutController, function() return "Queuing appearanceChange command: " .. APL.LuaUtils.prettyPrint(payload, false, 3) end)
        self._session:sendCommand(payload)
    else
        APL.Log.warn(LayoutController, function() return "Not ready to send appearanceChange command, _state: " .. self._state .. ", session ready: " .. (self._session:getIsReady() and "true" or "false") end)
    end

    return self
end







function LayoutController:_sendPayload(payload)




    if self._session:getIsReady() then
        Signpost.emitEvent("Sending new payload to phone")

        APL.Log.info(LayoutController, function() return "Queuing command with payload: " .. APL.LuaUtils.prettyPrint(payload, false, 3) end)
        self._session:sendCommand(payload)
    else
        APL.Log.warn(LayoutController, function() return "Not ready to send command, _state: " .. self._state .. ", session ready: " .. (self._session:getIsReady() and "true" or "false") end)
    end

    return self
end







function LayoutController._driveModeChangePayload(driveMode)


    return {
        type = UISYNC_COMMAND_TYPE.REQUEST_DRIVE_MODE,
        data = {
            driveMode = driveMode
        }
    }
end







function LayoutController:_processTransitionCommands()


    local iPhoneVideoStream = self:_getIPhoneVideoStream()
    if not iPhoneVideoStream then
        return
    end


    if not next(self._transitionCommands) then
        return
    end


    local hasMetadataDebugLayer = self._metadataDebugLayer ~= nil
    if hasMetadataDebugLayer then
        self._metadataDebugLayer:setVisible(false)
    end



    local nextFramePTS, nextFramePTSError = iPhoneVideoStream:getNextPTS()


    local frameDuration = iPhoneVideoStream:getFrameDuration()


    if frameDuration < APL.Throttle.getStep() then
        frameDuration = APL.Throttle.getStep()
    end








    local PTS = nextFramePTS or CP.PTS
    local startFramePTS = PTS and math.floor(PTS * 1e3)
    local endFramePTS = PTS and math.floor((PTS + frameDuration) * 1e3)


    nextFramePTS = nextFramePTS and math.floor(nextFramePTS * 1e3) -- convert to milliseconds after window

    local nextFrameWindow = startFramePTS and endFramePTS and string.format("%d - %d", startFramePTS, endFramePTS) or "-"
    APL.Log.info("Metadata", "Processing transition @ %d with video pts: %s (window: %s)",
        CP.getSystemUpTime() * 1000, tostring(nextFramePTS or nextFramePTSError), nextFrameWindow
    )


    local stopDequeue = false
    while next(self._transitionCommands) and not stopDequeue do
        local command = self._transitionCommands[1]

        if command.type == UISYNC_COMMAND_TYPE.METATADA_TRANSFER then
            table.remove(self._transitionCommands, 1)
            self:_handleMetadataTransfer(command)
            continue
        end


        if self._state ~= UISYNC_STATE.TRANSITIONING and command.type ~= UISYNC_COMMAND_TYPE.END_LAYOUT_TRANSITION then
            APL.Log.warn(LayoutController, function() return "Discarding transition command outside of transition markers: " .. APL.LuaUtils.prettyPrint(command, false, 5) end)
            table.remove(self._transitionCommands, 1)
            continue
        end

        if command.type == UISYNC_COMMAND_TYPE.START_ZONE_TRANSITION then
            table.remove(self._transitionCommands, 1)
            self:_handleStartZoneTransitionCommand(command)
        elseif command.type == UISYNC_COMMAND_TYPE.END_ZONE_TRANSITION then
            table.remove(self._transitionCommands, 1)
            self:_handleEndZoneTransitionCommand(command)
        elseif command.type == UISYNC_COMMAND_TYPE.START_LAYOUT_TRANSITION then
            table.remove(self._transitionCommands, 1)
            self:_handleStartLayoutTransitionCommand(command)
        elseif command.type == UISYNC_COMMAND_TYPE.END_LAYOUT_TRANSITION then
            table.remove(self._transitionCommands, 1)
            self:_handleEndLayoutTransitionCommand(command)
        elseif command.type == UISYNC_COMMAND_TYPE.TRANSITION_DATA then
            local transitionData = command.data
            local pts = transitionData.pts


            if pts < endFramePTS then
                APL.Log.info("Metadata", function() return "Found %s metadata with pts: %s. (window: %s)", pts < startFramePTS and "old" or "matching", tostring(pts), nextFrameWindow end)
                table.remove(self._transitionCommands, 1)
                self:_applyTransitionData(transitionData)
            else
                APL.Log.info("Metadata", function() return "Found future metadata: %s. (window: %s)", tostring(pts), nextFrameWindow end)
                stopDequeue = true
            end
        end
    end
end






function LayoutController:_applyTransitionData(transitionData)



    if transitionData.regions == nil then
        APL.Log.warn("Metadata", function() return "No regions in transition metadata: " .. APL.LuaUtils.prettyPrint(transitionData) end)
        return
    end




    local ignoreUpdates = {}
    if self._workspace:getState():isTransitioning() then
        ignoreUpdates.components = true
    else
        ignoreUpdates.layouts = true
    end


    APL.LuaUtils.forEach(self._display:getLayouts(LayoutInfo.KIND.UNDERLAY), function(layoutInfo)


        local layout = self._layoutsById[layoutInfo:getID()]
        if layout then
            layout:applyTransitionData(transitionData, false, nil, ignoreUpdates)
        end
    end)

    if self._nextLayout then
        self._nextLayout:applyTransitionData(transitionData, true, nil, ignoreUpdates)




        if self._nextLayout:getVisible() and not self._nextLayout:isAttached() then
            self._nextLayout:attach(self._layoutsRootLayer, false)
        end
    end

    if self._layout and self._layout:isAttached() then

        local persistentGaugesVisibilityOverride = nil
        if self._nextLayout then
            persistentGaugesVisibilityOverride = not self._nextLayout:getPersistentGaugesVisible()
        end


        if self._workspace:getState():isTransitioning() and self._nextLayout == nil then
            APL.Log.warn("Metadata", function() return "No next layout, ignoring layout transition metadata" end)
            ignoreUpdates.layouts = true
        end

        self._layout:applyTransitionData(transitionData, false, persistentGaugesVisibilityOverride, ignoreUpdates)


        if not self._layout:getVisible() then
            self._layout:detach()
        end
    end
end




function LayoutController:_sendGiveFocusIfNeeded()


    if self._focusToken:hasOwnership() and self._session:getIsReady() then
        self:_sendGiveFocus()
    end
end




function LayoutController:_sendGiveFocus()




    self._focusToken:release()

    if self._layout then
        self._layout:setFocusEnabled(false)
    end

    local tokenID = self._focusToken:getTokenID()
    APL.Log.info(LayoutController, function() return "Queuing giveFocus with token " .. tokenID end)

    local payload = {
        type = UISYNC_COMMAND_TYPE.GIVE_FOCUS,
        data = {
            tokenID = tokenID
        }
    }

    self._session:sendCommand(payload)
end




function LayoutController:_takeFocusIfNeeded()


    if not self._focusToken:hasOwnership() then
        self:_takeFocusToken(self._focusToken:getTokenID())
    end

    return self
end




function LayoutController:_sendRequestFocusIfNeeded()


    if not self._focusToken:hasOwnership() and self._session:getIsReady() then
        self:_sendRequestFocus()
    end

    return self
end




function LayoutController:_sendRequestFocus()






    local tokenID = self._focusToken:getTokenID()
    APL.Log.info(LayoutController, function() return "Queuing requestFocus for token " .. tokenID end)

    local payload = {
        type = UISYNC_COMMAND_TYPE.REQUEST_FOCUS,
        data = {
            tokenID = tokenID
        }
    }

    self._session:sendCommand(payload)
end

return APL.LuaUtils.readOnly(LayoutController)
