-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local TicksConfiguration = require "TicksConfiguration"

local TicksLayoutConfiguration = APL.LuaUtils.makeObject({ _type = "TicksLayoutConfiguration" })









function TicksLayoutConfiguration.new(primary, secondary, tertiary)




    local self = APL.LuaUtils.newObject(TicksLayoutConfiguration, {
        primary = primary,
        secondary = secondary,
        tertiary = tertiary
    })

    return self
end








function TicksLayoutConfiguration.newWithLabelsCountAndConfig(labelsCount, ticksConfiguration)



    local primaryTicksConfig = ticksConfiguration and ticksConfiguration.tickTypeConfigurations[TicksConfiguration.TYPE.PRIMARY]
    local secondaryTicksConfig = ticksConfiguration and ticksConfiguration.tickTypeConfigurations[TicksConfiguration.TYPE.SECONDARY]
    local tertiaryTicksConfig = ticksConfiguration and ticksConfiguration.tickTypeConfigurations[TicksConfiguration.TYPE.TERTIARY]

    local primaryTicks = primaryTicksConfig and primaryTicksConfig.ticksCount or 0
    local secondaryTicks = secondaryTicksConfig and secondaryTicksConfig.ticksCount or 0
    local tertiaryTicks = tertiaryTicksConfig and tertiaryTicksConfig.ticksCount or 0

    if primaryTicks == 0 then
        return TicksLayoutConfiguration.new(0, 0, 0)
    end

    return TicksLayoutConfiguration.new(

        (math.max(2, labelsCount) - 1) * primaryTicks + 1,
        secondaryTicks,
        tertiaryTicks
    )
end






function TicksLayoutConfiguration:getTotalCount()


    return self.primary == 0 and 0 or (1 + self.tertiary) * (1 + self.secondary) * (self.primary - 1) + 1
end






function TicksLayoutConfiguration:destroy()

end

return APL.LuaUtils.readOnly(TicksLayoutConfiguration)
