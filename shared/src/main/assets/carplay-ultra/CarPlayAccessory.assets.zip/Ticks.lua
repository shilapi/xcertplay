-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local AngleConfiguration = require "AngleConfiguration"
local GaugeColor = require "GaugeColor"
local GradientLayoutUtils = require "GradientLayoutUtils"
local TicksConfiguration = require "TicksConfiguration"
local TicksLayoutConfiguration = require "TicksLayoutConfiguration"
local ProgressBarGaugeParameters = require "ProgressBarGaugeParameters"

local Ticks = APL.LuaUtils.makeObject({ _type = "Ticks" })

Ticks.MODE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "TICKMARKS",
    "LABELS",
    "ORNAMENTS"
}))

Ticks.Parameters = APL.LuaUtils.namedObject(
    "Parameters",
    { "ticksConfiguration", "TicksConfiguration" },
    { "style", "TicksConfiguration.Style" },
    { "ticksLayoutConfiguration", "TicksLayoutConfiguration" },
    { "labelValues", "table" },
    { "inset", "number" }
)

Ticks.TickTypeParameters = APL.LuaUtils.namedObject(
    "TickTypeParameters",
    { "ticksParameters", "Parameters" },
    { "type", "string" },
    { "rootLayer", "Layer" }
)


Ticks.GradientStop = APL.LuaUtils.namedObject(
    "Ticks.GradientStop",

    { "stop", "number" },

    { "colorID", "string" },

    { "behavior", "number" }
)

Ticks.GradientStop.Behavior = APL.LuaUtils.makeEnum({

    "SPLIT",

    "ADVANCE",

    "RECEDE"
 })


Ticks.Value = APL.LuaUtils.namedObject(
    "Ticks.Value",
    { "progress", "number" },
    { "limit", "number?" },
    { "start", "number?" }
)


Ticks.State = APL.LuaUtils.namedObject(
    "Ticks.State",
    { "appearanceState", "AppearanceController.State" },
    { "state", "number?" }
)


Ticks.Colors = APL.LuaUtils.namedObject(
    "Ticks.Colors",
    { "primary", "string" },
    { "secondary", "string" },
    { "tertiary", "string?" },
    { "redlineCrossed", "string?" }
)








function Ticks.Colors.newWithTicksConfiguration(configuration, ticksState)



    return Ticks.Colors.new(
        ticksState.appearanceState:getSolidColor(Ticks._getStatefulColor(configuration.primaryColorID, ticksState.state)),
        ticksState.appearanceState:getSolidColor(Ticks._getStatefulColor(configuration.secondaryColorID, ticksState.state)),
        configuration.tertiaryColorID and ticksState.appearanceState:getSolidColor(Ticks._getStatefulColor(configuration.tertiaryColorID, ticksState.state)),
        configuration.redlineCrossedColorID and ticksState.appearanceState:getSolidColor(Ticks._getStatefulColor(configuration.redlineCrossedColorID, ticksState.state))
    )
end








function Ticks.Colors.newWithLabelsConfiguration(configuration, ticksState)



    return Ticks.Colors.new(
        ticksState.appearanceState:getSolidColor(Ticks._getStatefulColor(configuration.primaryLabelColorID, ticksState.state)),
        ticksState.appearanceState:getSolidColor(Ticks._getStatefulColor(configuration.secondaryLabelColorID, ticksState.state)),
        configuration.tertiaryLabelColorID and ticksState.appearanceState:getSolidColor(Ticks._getStatefulColor(configuration.tertiaryLabelColorID, ticksState.state))
    )
end















function Ticks.create(ticksParametersByUnit, appearanceState, unit, mode)






    local rootLayer = APL.Layer.new()
    local builder
    if mode == Ticks.MODE.TICKMARKS then
        builder = Ticks._createTickMarks
    elseif mode == Ticks.MODE.LABELS then
        builder = Ticks._createLabelLayers
    elseif mode == Ticks.MODE.ORNAMENTS then
        builder = Ticks._createOrnamentLayers
    else

    end

    local ticksParameters = ticksParametersByUnit[unit]
    local layers, setFrames, setValuesStates = builder(ticksParameters, rootLayer)

    local lastFrame
    local lastValue = Ticks.Value.new(0)
    local lastState = Ticks.State.new(appearanceState)
    local lastUnit = unit

    local setValue = function(value)
        lastValue = value
        APL.LuaUtils.forEach(setValuesStates, function(setSublayerValue)
            setSublayerValue(value, lastState)
        end)
    end

    local setState = function(state)
        lastState = state
        APL.LuaUtils.forEach(setValuesStates, function(setSublayerValue)
            setSublayerValue(lastValue, state)
        end)
    end

    local setFrame = function(frame)
        if lastFrame == nil or not frame:equalTo(lastFrame) then
            lastFrame = frame
            rootLayer:setFrame(frame)
            APL.LuaUtils.forEach(setFrames, function(setSublayerFrame)
                setSublayerFrame(frame)
            end)
            if lastValue then
                setValue(lastValue)
            end
        end
    end

    local setUnit = function(unit)
        if unit ~= lastUnit then
            lastUnit = unit
            local frame = lastFrame

            local ticksParameters = ticksParametersByUnit[unit]



            for k in pairs(layers) do
                layers[k]:destroy()
            end

            layers, setFrames, setValuesStates = builder(ticksParameters, rootLayer)
            lastFrame = nil
            if frame and lastValue then
                setFrame(frame)
                setValue(lastValue)
            end
        end
    end

    return rootLayer, setFrame, setValue, setState, setUnit
end











function Ticks.progressBarParameters(ticksConfiguration, maxValue, minLabelsCount, maxLabelsCount, labelIntervals)






    local labelsConfig = ticksConfiguration.tickLabelsConfiguration


    local adjustedMaxValue = 100
    local labelsCount = labelsConfig.maxLabelsCount
    adjustedMaxValue, labelsCount = Ticks.getMaxValueWithLabelsCount(maxValue, minLabelsCount, maxLabelsCount, labelIntervals)

    labelsCount = math.min(labelsConfig.maxLabelsCount, labelsCount)
    local labelDivider = labelsConfig.labelDivider or 1
    local labelValues = Ticks.labelValues(labelsCount, adjustedMaxValue, labelDivider)

    return ProgressBarGaugeParameters.new(
        ticksConfiguration,
        TicksLayoutConfiguration.newWithLabelsCountAndConfig(labelsCount, ticksConfiguration),
        labelValues
    )
end












function Ticks.getMaxValueWithLabelsCount(vehicleMaxValue, minLabelsCount, maxLabelsCount, intervals)









    local minIntervalsCount = minLabelsCount - 1
    local maxIntervalsCount = maxLabelsCount - 1


    if #intervals == 0 then
        APL.Log.error(Ticks, function() return "Intervals must be > 0. Hiding labels" end)
        return vehicleMaxValue, 0
    end
    if minLabelsCount < 2 or maxLabelsCount < 2 then
        APL.Log.error(Ticks, function() return "Min and max number of labels must be >= 1. Hiding labels" end)
        return vehicleMaxValue, 0
    end
    local maxInterval = math.max(table.unpack(intervals))
    if maxInterval * maxIntervalsCount < vehicleMaxValue then
        APL.Log.error(Ticks, function() return string.format("Max number of labels (%d) is too small for the vehicleMaxValue (%d). Hiding labels", maxIntervalsCount + 1, vehicleMaxValue) end)
        return vehicleMaxValue, 0
    end

    local resultIntervalsCount = maxIntervalsCount
    local resultInterval = maxInterval



    for _, value in ipairs(intervals) do
        local intervalsCount = math.ceil(vehicleMaxValue / value)
        intervalsCount = math.max(math.min(intervalsCount, maxIntervalsCount), minIntervalsCount)
        if value * intervalsCount >= vehicleMaxValue then
            local newDiff = intervalsCount * value - vehicleMaxValue
            local oldDiff = resultIntervalsCount * resultInterval - vehicleMaxValue



            if newDiff < oldDiff then
                resultIntervalsCount = intervalsCount
                resultInterval = value
            end
        end
    end

    return resultInterval * resultIntervalsCount, resultIntervalsCount + 1
end










function Ticks.getStrokeValuesForProgress(progress, maxValue, minValue, intervalCount)





    local normalizedZero = (maxValue / intervalCount) / maxValue
    local power = progress * (progress >= 0 and maxValue or math.abs(minValue))

    local startValue = function()
        local adjustedPower = power / intervalCount
        local adjustedMax = minValue / intervalCount

        local adjustedProgress = (1 / intervalCount) - normalizedZero * (adjustedPower / adjustedMax)
        local value = math.max(0, adjustedProgress)

        return power >= 0
            and normalizedZero
            or value
    end

    local endValue = function()
        local adjustedPower = power * (1 - normalizedZero)
        local adjustedProgress = (adjustedPower / maxValue) + normalizedZero

        local value = math.max(0, adjustedProgress)

        return power <= 0
            and normalizedZero
            or value
    end

    return startValue(), endValue()
end








function Ticks.labelValues(count, maxValue, divider)





    if count == 0 then
        return {}
    end

    local result = {0}
    local intervals = count - 1

    for i = 1, intervals do
        local rawValue = maxValue / intervals * i
        result[#result+1] = math.abs(math.floor(rawValue / divider))
    end

    return result
end








function Ticks.powermeterProgressModifier(value, labelOverrides, initial)
    local startValue = 0
    local progressValue = math.max(0, value)

    if labelOverrides then
        local intervalsCount = #labelOverrides - 1

        startValue, progressValue = Ticks.getStrokeValuesForProgress(
            value,
            initial.consumedPowerMax,
            initial.regeneratedPowerMax,
            intervalsCount
        )
    end

    return { startValue, progressValue }
end








function Ticks._createTickMarks(ticksParameters, rootLayer)



    local ticksConfiguration, style = ticksParameters.ticksConfiguration, ticksParameters.style
    local ticksInset = ticksParameters.inset
    local tickLayers = {}
    local setFrames = {}
    local setValues = {}

    for tickType, _ in pairs(ticksConfiguration.tickTypeConfigurations) do
        local ticksMask, ticks = Ticks._createTicksForType(style, ticksConfiguration, tickType)
        local tickTypeConfiguration = ticksConfiguration.tickTypeConfigurations[tickType]
        tickLayers[#tickLayers+1] = ticks
        rootLayer:addSublayer(ticks)

        setFrames[#setFrames+1] = function(frame)
            local ticksFrame, gradientFrame = APL.Rect.new(0, 0, frame:getSize()), APL.Rect.new(0, 0, frame:getSize())

            if style.angleConfiguration then
                ticksFrame = ticksFrame:insetBy(ticksInset, ticksInset, ticksInset, ticksInset)
                gradientFrame = ticksFrame
            else
                ticksFrame = ticksFrame:insetBy(tickTypeConfiguration.tickInset, 0, tickTypeConfiguration.tickInset, 0)
            end
            ticksMask:setPath(Ticks._getTicksPath(ticksFrame, style, ticksConfiguration, tickType, ticksParameters.ticksLayoutConfiguration))
            ticks:setFrame(gradientFrame)
        end

        local tickTypeParams = Ticks.TickTypeParameters.new(ticksParameters, tickType, rootLayer)
        local extensionCache = {}
        setValues[#setValues+1] = function(value, state)
            local _, _, width = rootLayer:getBounds()
            if not extensionCache[width] then
                local tickRadius = width / 2 - tickTypeConfiguration.tickInset - tickTypeConfiguration.tickLength
                extensionCache[width] = style.angleConfiguration
                    and Ticks._getAngleForTangent(tickTypeConfiguration.tickWidth, tickRadius) * 2
                    or tickTypeConfiguration.tickWidth
            end
            local tickTypeConfiguration = tickTypeParams.ticksParameters.ticksConfiguration.tickTypeConfigurations[tickTypeParams.type]
            local colors = Ticks.Colors.newWithTicksConfiguration(tickTypeConfiguration, state)
            local extension = extensionCache[width]
            local tickColors = Ticks._getTicksGradientColors(value, colors, tickTypeParams)
            local layout = GradientLayoutUtils.createLayout(style, tickColors, width, extension)

            APL.Log.debug(Ticks, function() return "Ticks._createTickMarks: layout.stops" .. APL.LuaUtils.prettyPrint(layout.stops) end)

            ticks
                :setStartPoint(table.unpack(layout.startPoint))
                :setEndPoint(table.unpack(layout.endPoint))
                :setStops(layout.stops)
        end
    end

    return tickLayers, setFrames, setValues
end









function Ticks._createLabelLayers(ticksParameters, rootLayer)





    if #ticksParameters.labelValues == 0 then
        return {}, {}, {}
    end
    local ticksConfiguration, style = ticksParameters.ticksConfiguration, ticksParameters.style
    local labelsConfig = ticksConfiguration.tickLabelsConfiguration
    local ticksInset = ticksParameters.inset
    local font = APL.RasterFont.new(labelsConfig.labelsFontName)
    local boundingBox = Ticks.getMaxLabelBoundingBox(font)
    local maxLabelWidth = boundingBox:getSize()
    local labelsCount = #ticksParameters.labelValues
    local labelsMask, labels, labelsLayer = Ticks._createLabelsLayer(style, labelsConfig, ticksParameters.labelValues)
    rootLayer:addSublayer(labelsLayer)

    local setFrames = {}

    setFrames[#setFrames+1] = function(frame)
        local width, height = frame:getSize()
        labelsMask:setFrame(0, 0, width, height)
        labelsLayer:setFrame(0, 0, width, height)
    end

    local extensionAngleCache = {}

    local setValue = function(value, state)
        local _, _, width = rootLayer:getBounds()
        if not extensionAngleCache[width] then
            local tickTypeConfiguration = ticksConfiguration.tickTypeConfigurations[TicksConfiguration.TYPE.PRIMARY]
            local extension
            if style.angleConfiguration then
                extension = ticksConfiguration.tickLabelsConfiguration.continuousFill
                    and 0
                    or Ticks._getAngleForTangent(maxLabelWidth, width / 2 - tickTypeConfiguration.tickInset) * 2
            else
                extension = maxLabelWidth
            end
            extensionAngleCache[width] = extension
        end

        local colors = Ticks.Colors.newWithLabelsConfiguration(labelsConfig, state)
        local labelColors = Ticks._getLabelsGradientColors(value, colors, ticksConfiguration, labelsCount, style, width)
        local layout = GradientLayoutUtils.createLayout(style, labelColors, width, extensionAngleCache[width])

        APL.Log.debug(Ticks, function() return "Ticks._createLabelLayers: layout.stops" .. APL.LuaUtils.prettyPrint(layout.stops) end)

        labelsLayer
            :setStartPoint(table.unpack(layout.startPoint))
            :setEndPoint(table.unpack(layout.endPoint))
            :setStops(layout.stops)
    end

    for index, label in ipairs(labels) do
        setFrames[#setFrames+1] = function(frame)
            local insetFrame = frame
                :minSquare()
                :insetBy(ticksInset, ticksInset, ticksInset, ticksInset)

            local labelValue = ticksParameters.labelValues[index]


            local _, labelHeight = APL.AttributedString.new(tostring(labelValue), font)
                :getBoundingRect()
                :getSize()


            labelHeight = labelHeight + 3

            local labelFrame = style.angleConfiguration
                and Ticks._getLabelFrameRadial(labelsConfig.inset, labelsConfig.zeroLabelInset, #labels, style.angleConfiguration, index, insetFrame, maxLabelWidth, labelHeight, labelsConfig.edgeLabelsShiftCount)
                or Ticks._getLabelFrameLinear(labelsConfig.inset, style.linearConfiguration, #labels, index, frame, maxLabelWidth, labelHeight)
            local visible = not (index == 1 and labelsConfig.hideFirstLabel)
            label
                :setFrame(labelFrame)
                :setAlignment(APL.AttributedString.ALIGNMENT.CENTER)
                :setVisible(visible)
        end
    end

    return { labelsLayer }, setFrames, { setValue }
end








function Ticks._createOrnamentLayers(ticksParameters, rootLayer)



    local ticksConfiguration, style = ticksParameters.ticksConfiguration, ticksParameters.style
    local angleConfiguration
    if style.linearConfiguration then

        return {}, {}, {}
    elseif style.angleConfiguration then
        angleConfiguration = style.angleConfiguration
    else

    end

    local labelsConfig = ticksConfiguration.tickLabelsConfiguration
    local ornamentMask, ornaments, ornamentsLayer = Ticks._createOrnamentsLayer(labelsConfig)
    local setFrames = {}
    rootLayer:addSublayer(ornamentsLayer)





    setFrames[#setFrames+1] = function(frame)
        local width, height = frame:getSize()
        ornamentMask:setFrame(0, 0, width, height)
        ornamentsLayer:setFrame(0, 0, width, height)
    end

    local extensionAngleCache = {}

    local tickTypeConfiguration = ticksConfiguration.tickTypeConfigurations[TicksConfiguration.TYPE.SECONDARY]

    local function setValueState(value, state)
        local colors = Ticks.Colors.newWithTicksConfiguration(tickTypeConfiguration, state)
        local _, _, width = rootLayer:getBounds()
        if not extensionAngleCache[width] then
            extensionAngleCache[width] = 0
        end
        local labelColors = Ticks._getOrnamentsGradientColors(value, colors, ticksConfiguration, #labelsConfig.ornamentTextConfiguration.ornamentLabels, style, width)
        local layout = GradientLayoutUtils.createRadialLayout(angleConfiguration, labelColors, extensionAngleCache[width])
        ornamentsLayer
            :setStartPoint(table.unpack(layout.startPoint))
            :setEndPoint(table.unpack(layout.endPoint))
            :setStops(layout.stops)
    end

    local secondaryTickLineCap = tickTypeConfiguration.tickWidth / 2
    local ornamentInset = tickTypeConfiguration.tickInset - secondaryTickLineCap
    local primaryIntervalsCount = Ticks._tickCountIntervals(TicksConfiguration.TYPE.PRIMARY, ticksParameters.ticksLayoutConfiguration)
    local secondaryIntervalsCount = Ticks._tickCountIntervals(TicksConfiguration.TYPE.SECONDARY, ticksParameters.ticksLayoutConfiguration)

    for index, ornament in ipairs(ornaments) do
        setFrames[#setFrames+1] = function(frame)
            local insetFrame = frame
                :minSquare()
                :insetBy(ornamentInset, ornamentInset, ornamentInset, ornamentInset)

            local startAngle, endAngle = Ticks._getOrnamentAngles(insetFrame, angleConfiguration, ticksConfiguration, primaryIntervalsCount, secondaryIntervalsCount, index)
            ornament
                :setFrame(insetFrame)
                :setRadius(insetFrame._width / 2)
                :setOrigin(insetFrame._width / 2, insetFrame._height / 2)
                :setLayoutAngles(startAngle, endAngle)
        end
    end

    return { ornamentsLayer }, setFrames, { setValueState }
end



























function Ticks._gradientColors(value, getDiscrete, continuousFill, activeColor, trackColor, redlineColor, redlineCrossedColor, redlineBehavior, redlineColorStatic)








    redlineColorStatic = redlineColorStatic or false

    local EPS = 0.00001
    local start = value.start and value.start or 0
    local continuousOrAdvance = continuousFill
        and Ticks.GradientStop.Behavior.SPLIT
        or Ticks.GradientStop.Behavior.ADVANCE


    local startAdvanceBehavior = (value.progress > start) and Ticks.GradientStop.Behavior.RECEDE or Ticks.GradientStop.Behavior.ADVANCE
    local startBehavior = continuousFill
        and Ticks.GradientStop.Behavior.SPLIT
        or startAdvanceBehavior

    start = getDiscrete(start, startBehavior)
    local progress = getDiscrete(value.progress, continuousOrAdvance)
    local redlineValue = (value.limit and value.limit < 1) and getDiscrete(value.limit, redlineBehavior) or nil


    if redlineColorStatic and redlineValue and progress > redlineValue then
        progress = redlineValue - EPS
    end

    if progress == 1 and (not redlineColorStatic) and (not redlineCrossedColor) then
        return {
            { 0, trackColor },

            { start, trackColor },
            { 1, activeColor }
        }

    elseif (redlineValue == nil or redlineColor == nil or redlineValue == 1 or redlineBehavior == nil) then
        return {
            { 0, trackColor },
            { start, trackColor },
            { progress, activeColor },
            { 1, trackColor }
        }

    elseif progress >= redlineValue and redlineCrossedColor then
        return {
            { 0, trackColor },
            { start, trackColor },

            { redlineValue, activeColor },
            { progress, redlineCrossedColor },
            { 1, progress >= 1 and redlineCrossedColor or redlineColor }
        }
    else
        return {
            { 0, trackColor },
            { start, trackColor },
            { progress, activeColor },

            { redlineValue, trackColor },

            { 1, redlineColor }
        }
    end
end









function Ticks._getTicksGradientColors(value, colors, tickTypeParams)




    local tickTypeConfiguration = tickTypeParams.ticksParameters.ticksConfiguration.tickTypeConfigurations[tickTypeParams.type]
    local _, _, width = tickTypeParams.rootLayer:getBounds()
    local style = tickTypeParams.ticksParameters.style

    return Ticks._gradientColors(
        value,
        Ticks._progressValuesDiscrete(width, style, tickTypeConfiguration, tickTypeParams.ticksParameters.ticksLayoutConfiguration:getTotalCount()),
        false,
        colors.primary,
        colors.secondary,
        colors.tertiary,
        colors.redlineCrossed,
        Ticks.GradientStop.Behavior.RECEDE,
        tickTypeConfiguration.redlineColorStatic
    )
end












function Ticks._getLabelsGradientColors(value, colors, ticksConfiguration, labelsCount, style, width)







    local tickTypeConfiguration = ticksConfiguration.tickTypeConfigurations[TicksConfiguration.TYPE.PRIMARY]
    local labelsConfiguration = ticksConfiguration.tickLabelsConfiguration
    return Ticks._gradientColors(
        value,
        Ticks._progressValuesDiscrete(width, style, tickTypeConfiguration, labelsCount),
        labelsConfiguration.continuousFill,
        colors.primary,
        colors.secondary,
        colors.tertiary,
        colors.redlineCrossed,
        Ticks.GradientStop.Behavior.RECEDE,
        tickTypeConfiguration.redlineColorStatic
    )
end









function Ticks._createTicksForType(style, ticksConfiguration, tickConfigurationType)




    local tickTypeConfiguration = ticksConfiguration.tickTypeConfigurations[tickConfigurationType]

    local tickMask = APL.ShapeLayer.new()
        :setLineCap(tickTypeConfiguration.lineCap)
        :setStrokeColor(GaugeColor.white)
        :setLineWidth(tickTypeConfiguration.tickWidth - tickTypeConfiguration.tickWidthInset * 2)
        :setShouldRasterize(true)
    if tickTypeConfiguration.lineCap == APL.ShapeLayer.LINECAP.ROUND then
        tickMask:setLineJoin(APL.ShapeLayer.LINEJOIN.ROUND)-- required for antialiased ticks in single layer
    end

    local gradient = style.angleConfiguration
        and APL.GradientLayer.new(APL.GradientLayer.KIND.CONICAL)
        or APL.GradientLayer.new(APL.GradientLayer.KIND.LINEAR)

    gradient:setMask(tickMask)




    return tickMask, gradient
end












function Ticks._progressValuesDiscrete(
    width,
    style,
    ticksTypeConfiguration,
    elementsCount
)





    local tickNormalizedValue
    if style.angleConfiguration then
        local delta = AngleConfiguration.getNormalizedMinMaxAngleDelta(style.angleConfiguration)
        local outerRadius = width / 2 - ticksTypeConfiguration.tickInset
        tickNormalizedValue = Ticks._getAngleForTangent(ticksTypeConfiguration.tickWidth, outerRadius) / 2 / delta
    elseif style.linearConfiguration then
        tickNormalizedValue = (ticksTypeConfiguration.tickWidth / width)
    else
        APL.Log.error("Ticks._progressValuesDiscrete: bad style" .. tostring(style))
    end

    local insetWidth = style.linearConfiguration and (width - ticksTypeConfiguration.tickInset * 2) or width
    local normalizedWidth = insetWidth / width
    local linearIntervalLength = elementsCount > 1 and insetWidth / (elementsCount - 1) or insetWidth
    local radialIntervalLength = elementsCount > 1 and normalizedWidth / (elementsCount - 1) or 1

    return function(value, behavior)
        if behavior == Ticks.GradientStop.Behavior.SPLIT then
            return value
        end
        local advance = behavior == Ticks.GradientStop.Behavior.ADVANCE
        local normalizedProgress = style.linearConfiguration
            and Ticks._discreteProgressLinear(value, width, ticksTypeConfiguration.tickWidth, linearIntervalLength, ticksTypeConfiguration.tickInset, advance)
            or Ticks._discreteProgressRadial(value, tickNormalizedValue, radialIntervalLength, advance)
        return normalizedProgress
    end
end












function Ticks._discreteProgressLinear(stop, width, tickWidth, interval, inset, advance)








    local value = stop * width


    if advance then
        if value <= math.max(0, inset - tickWidth / 2) then
            return 0
        end

        local step = math.floor((value - inset + tickWidth / 2) / interval)
        local result = inset + step * interval + interval / 2
        return math.min(1, result / width)
    else
        if value <= math.max(0, inset + tickWidth / 2) then
            return 0
        end

        local step = math.ceil((value - inset - tickWidth / 2) / interval)
        local result = inset + step * interval - interval / 2
        return math.min(1, result / width)
    end
end










function Ticks._discreteProgressRadial(stop, tickNormalizedValue, intervalLength, advance)





    if stop == 0 then
        return 0
    end

    return advance
        and math.floor((stop + tickNormalizedValue) / intervalLength) * intervalLength + intervalLength / 2
        or math.floor((stop - tickNormalizedValue) / intervalLength) * intervalLength + intervalLength / 2
end











function Ticks._getTicksPath(frame, style, ticksConfiguration, tickConfigurationType, ticksLayoutConfiguration)






    local width = frame._width
    local height = frame._height
    local tickTypeConfiguration = ticksConfiguration.tickTypeConfigurations[tickConfigurationType]
    local intervalsCount = Ticks._tickCountIntervals(tickConfigurationType, ticksLayoutConfiguration)

    local clockwiseOrLeftToRight
    local delta
    if style.angleConfiguration then
        delta = AngleConfiguration.getNormalizedMinMaxAngleDelta(style.angleConfiguration)
        clockwiseOrLeftToRight = style.angleConfiguration.clockwise
    elseif style.linearConfiguration then
        delta = width
        clockwiseOrLeftToRight = not style.linearConfiguration.isRTL
    else
        APL.Log.error(Ticks, function() return "Ticks._getTicksPath: bad style" .. tostring(style) end)

    end

    local tickRotationProgress = intervalsCount == 0 and 0 or clockwiseOrLeftToRight
        and delta / intervalsCount
        or -delta / intervalsCount



    local intervalsLimit = intervalsCount + 1
    if ticksConfiguration.tickLabelsConfiguration.ornamentTextConfiguration and (tickConfigurationType == TicksConfiguration.TYPE.SECONDARY or tickConfigurationType == TicksConfiguration.TYPE.TERTIARY) then
        local tickMultiplier = (TicksConfiguration.TYPE.SECONDARY and ticksLayoutConfiguration.secondary or ticksLayoutConfiguration.tertiary) + 1
        local ornamentTextIntervalsCount = #ticksConfiguration.tickLabelsConfiguration.ornamentTextConfiguration.ornamentLabels
        intervalsLimit = intervalsCount - (tickMultiplier * ornamentTextIntervalsCount)
    end

    local path = APL.Path.new()
    for tickIndex = 1, (intervalsCount + 1) do
        if Ticks._tickTypeVisible(tickIndex, tickConfigurationType, tickTypeConfiguration) then
            local p0_x
            local p0_y
            local p1_x
            local p1_y
            if style.angleConfiguration then
                local rotation = style.angleConfiguration.minimumAngle + (tickIndex - 1) * (tickRotationProgress)
                local outerRadius = width / 2 - tickTypeConfiguration.tickInset
                local innerRadius = outerRadius - tickTypeConfiguration.tickLength
                p0_x = outerRadius * math.cos(rotation)
                p0_y = outerRadius * math.sin(rotation)
                p1_x = innerRadius * math.cos(rotation)
                p1_y = innerRadius * math.sin(rotation)


                if tickIndex <= intervalsLimit then
                    path
                        :moveTo(p0_x + width / 2, p0_y + height / 2)
                        :lineTo(p1_x + width / 2, p1_y + height / 2)
                end
            else
                local RTLOffset = not clockwiseOrLeftToRight and width + 2 * tickTypeConfiguration.tickInset or 0
                local inset = clockwiseOrLeftToRight and tickTypeConfiguration.tickInset or -tickTypeConfiguration.tickInset
                p0_x = RTLOffset + inset + (tickIndex - 1) * (tickRotationProgress)
                p0_y = height / 2 + tickTypeConfiguration.tickLength / 2
                p1_x = p0_x
                p1_y = height / 2 - tickTypeConfiguration.tickLength / 2
                if tickIndex <= intervalsLimit then
                    path
                        :moveTo(p0_x, p0_y)
                        :lineTo(p1_x, p1_y)
                end
            end
        end
    end

    return path
end








function Ticks._getAngleForTangent(tangentLength, radius)



    return math.atan(tangentLength / 2 / radius) * 2
end








function Ticks._tickCountIntervals(tickConfigurationType, ticksLayoutConfiguration)



    local primary = (ticksLayoutConfiguration.primary - 1)
    local secondary = (ticksLayoutConfiguration.secondary + 1)
    local tertiary = (ticksLayoutConfiguration.tertiary + 1)

    if tickConfigurationType == TicksConfiguration.TYPE.PRIMARY then
        return math.max(0, primary)
    elseif tickConfigurationType == TicksConfiguration.TYPE.SECONDARY then
        return primary * secondary
    else
        return primary * secondary * tertiary
    end
end








function Ticks._tickTypeVisible(index, tickConfigurationType, tickTypeConfiguration)




    local hideFirstTicks = index == 1 and tickTypeConfiguration.hideFirstTick
    if tickConfigurationType == TicksConfiguration.TYPE.PRIMARY then
        return not hideFirstTicks
    else
        local skipInterval = tickTypeConfiguration.ticksCount + 1
        return not hideFirstTicks and (index > 1 and (index - 1) % skipInterval ~= 0)
    end
end











function Ticks._createLabelsLayer(style, tickLabelsConfiguration, labelValues)



    local tickLabels = Ticks._createLabels(tickLabelsConfiguration, labelValues)
    local labelsMaskLayer = APL.Layer.new()

    APL.LuaUtils.forEach(tickLabels, function(label)
        labelsMaskLayer:addSublayer(label)
    end)

    local gradient = style.angleConfiguration
        and APL.GradientLayer.new(APL.GradientLayer.KIND.CONICAL)
        or APL.GradientLayer.new(APL.GradientLayer.KIND.LINEAR)

    gradient:setMask(labelsMaskLayer)

    return labelsMaskLayer, tickLabels, gradient
end








function Ticks._createLabels(labelsConfiguration, labelValues)




    local labels = {}

    for _, value in ipairs(labelValues) do
        local tickMarkLabel = APL.TextLayer.new(APL.RasterFont.new(labelsConfiguration.labelsFontName), "Tick")
            :setForegroundColor(GaugeColor.black)

            :setText(tostring(value))
        labels[#labels + 1] = tickMarkLabel
    end

    return labels
end













function Ticks._getLabelFrameLinear(inset, linearConfiguration, count, index, frame, labelWidth, labelHeight)






    local width, height = frame:getSize()
    width = width - labelWidth
    local labelCenterX = labelWidth / 2 + (index - 1) * width / (count - 1)
    local resultFrame = APL.Rect.new(labelCenterX - labelWidth / 2, height / 2 + labelHeight / 2, labelWidth, labelHeight)

    return resultFrame
end















function Ticks._getLabelFrameRadial(inset, zeroLabelInset, count, angleConfiguration, index, frame, labelWidth, labelHeight, edgeLabelsShiftCount)










    local minWidth = math.abs(frame:getMinSideSize())


    local primaryTickMarkProgress = angleConfiguration.clockwise
        and (index - 1) / (count - 1)
        or -(index - 1) / (count - 1)

    local rotation = angleConfiguration.minimumAngle + primaryTickMarkProgress * AngleConfiguration.getNormalizedMinMaxAngleDelta(angleConfiguration)
    rotation = APL.MathUtils.normalizeAngle(rotation)


    inset = (index == 1 or index == count) and zeroLabelInset or inset
    local labelCenter = minWidth / 2 - inset

    local normalizeToPI_2 = function(angle)
        local alpha = math.max(angle, angle - math.pi)
        return alpha < math.pi / 2 and alpha or math.pi - alpha
    end

    local maxAdjusted = function()

        local zeroLabelWidth = labelWidth / 2.2
        local halfWidth = zeroLabelWidth / 2
        local halfHeight = labelHeight / 2
        local clockwiseDirection = angleConfiguration.clockwise and 1 or -1
        local alpha = normalizeToPI_2(math.atan(halfHeight / halfWidth))
        local r = normalizeToPI_2(angleConfiguration.minimumAngle)
        local ac = math.sqrt(halfWidth * halfWidth + halfHeight * halfHeight)
        local ab = ac * math.sin(alpha + r)
        local offset = math.asin(ab / labelCenter)
        return offset * clockwiseDirection
    end




    local labelsToAdjustCount = math.min(count / 2, edgeLabelsShiftCount)
    local adjustmentMultiplier = function(i)
        return math.max(0, (1 - 1 / labelsToAdjustCount * i * 2))
    end

    local adjustment =
        index <= labelsToAdjustCount and maxAdjusted() * adjustmentMultiplier(index - 1)
        or index >= count - labelsToAdjustCount and -maxAdjusted() * adjustmentMultiplier(count - index)
        or 0

    rotation = rotation + adjustment



    local labelCenterX = frame._x + math.cos(-rotation) * labelCenter + minWidth / 2
    local labelCenterY = frame._y + math.sin(rotation) * labelCenter + minWidth / 2

    local resultFrame = APL.Rect.new(labelCenterX - labelWidth / 2, labelCenterY - labelHeight / 2 - 1, labelWidth, labelHeight)

    return resultFrame
end







function Ticks.getMaxLabelBoundingBox(font)


    local maxWidthString = "444"
    return APL.AttributedString.new(maxWidthString, font):getBoundingRect()
end







function Ticks.getLabelsRadius(width)


    return 0.805 * (width / 2)
end













function Ticks._getOrnamentAngles(frame, angleConfiguration, ticksConfiguration, primaryIntervalsCount, secondaryIntervalsCount, index)







    local angleDelta = AngleConfiguration.getNormalizedMinMaxAngleDelta(angleConfiguration)
    local primaryTickRotationProgress = primaryIntervalsCount == 0 and 0 or angleConfiguration.clockwise
        and angleDelta / primaryIntervalsCount
        or -angleDelta / primaryIntervalsCount

    local angles = {}
    for tickIndex = 1, (primaryIntervalsCount + 1) do
        local rotation = angleConfiguration.minimumAngle + (tickIndex - 1) * (primaryTickRotationProgress)
        angles[#angles+1] = rotation
    end

    local count = #angles
    local secondaryTickIntervalAngle = angleDelta / secondaryIntervalsCount

    local width = ticksConfiguration.tickTypeConfigurations[TicksConfiguration.TYPE.SECONDARY].tickWidth
    local radius = frame._width / 2
    local secondaryTickWidthAngle = math.atan(width / radius) -- Convert width to angle

    local startAngleIndex, endAngleIndex = count+1-index, count-index




    return angles[startAngleIndex] - secondaryTickIntervalAngle + secondaryTickWidthAngle, angles[endAngleIndex] + secondaryTickIntervalAngle - secondaryTickWidthAngle
end







function Ticks._createOrnamentsLayer(tickLabelsConfiguration)


    local createOrnaments = function(labelsConfiguration)


        local labelValues = labelsConfiguration.ornamentTextConfiguration.ornamentLabels



        local labels = {}
        for _, value in ipairs(labelValues) do
            local tickMarkLabel = APL.CurvedTextLayer.new(APL.RasterFont.new(labelsConfiguration.ornamentTextConfiguration.ornamentFontName or labelsConfiguration.labelsFontName), "TickOrnament")
                :setForegroundColor(GaugeColor.white)

                :setText(tostring(value))
                :setClockwiseLayout(true)
                :setAlignment(APL.AttributedString.ALIGNMENT.FLEX)
            labels[#labels + 1] = tickMarkLabel
        end

        return labels
    end

    local tickLabels = createOrnaments(tickLabelsConfiguration)
    local labelsMaskLayer = APL.Layer.new()

    APL.LuaUtils.forEach(tickLabels, function(label)
        labelsMaskLayer:addSublayer(label)
    end)

    local gradient = APL.GradientLayer.new(APL.GradientLayer.KIND.CONICAL)
        :setMask(labelsMaskLayer)

    return labelsMaskLayer, tickLabels, gradient
end












function Ticks._getOrnamentsGradientColors(value, colors, ticksConfiguration, labelsCount, style, width)







    local tickTypeConfiguration = ticksConfiguration.tickTypeConfigurations[TicksConfiguration.TYPE.SECONDARY]
    local labelsConfiguration = ticksConfiguration.tickLabelsConfiguration
    return Ticks._gradientColors(
        value,
        Ticks._progressValuesDiscrete(width, style, tickTypeConfiguration, labelsCount),
        labelsConfiguration.continuousFill,
        colors.primary,
        colors.secondary,
        colors.tertiary,
        colors.redlineCrossed,
        Ticks.GradientStop.Behavior.RECEDE,
        tickTypeConfiguration.redlineColorStatic
    )
end








function Ticks._getStatefulColor(colorIDs, state)
    return state and colorIDs[state] or colorIDs[0]
end

return APL.LuaUtils.readOnly(Ticks)
