-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Button = require "Button"
local Shadow = require "Shadow"

local ImageLocalNotification = APL.LuaUtils.makeObject({ _type = "ImageLocalNotification" })


local BUTTON_INSET = 20











function ImageLocalNotification.new(state, imageLayer, appearanceState, closeButton, shadow)






    local self = APL.LuaUtils.newObject(ImageLocalNotification, {
        _rootLayer = APL.LuaUtils.NIL,
        _state = state,
        _imageLayer = imageLayer,
        _button = closeButton or APL.LuaUtils.NIL,
        _shadow = shadow or APL.LuaUtils.NIL,
    })



    self._rootLayer = APL.Layer.new()

    if shadow then
        shadow:getRootLayer():addToSuperLayer(self._rootLayer)
    end

    imageLayer:addToSuperLayer(self._rootLayer)

    if closeButton then
        closeButton:getRootLayer():addToSuperLayer(self._rootLayer)
        closeButton:setEnabled(true)
    end

    self:setAppearanceState(appearanceState)

    return self
end






function ImageLocalNotification:getState()


    return self._state
end







function ImageLocalNotification:setEnabled(enabled)



    if self._button then
        self._button:setEnabled(enabled)
    end

    return self
end







function ImageLocalNotification:setFrame(frame)



    self._rootLayer:setFrame(frame)

    local textureFrame = APL.Rect.new(0, 0, self._imageLayer:getTexture():getSize())
    self._imageLayer:setFrame(textureFrame)

    if self._shadow then
        self._shadow:setContentFrame(textureFrame)
    end

    if self._button then
        local width, height = self._button:preferredContentSize()
        self._button:setFrame(APL.Rect.new(textureFrame._width - width - BUTTON_INSET, BUTTON_INSET, width, height))
    end

    return self
end







function ImageLocalNotification:setAppearanceState(state)



    if self._button then
        self._button:setAppearanceState(state)
    end



    return self
end








function ImageLocalNotification:preferredContentSize(width, height)




    return self._imageLayer:getTexture():getSize()
end






function ImageLocalNotification:getRootLayer()


    return self._rootLayer
end






function ImageLocalNotification:destroy()


    self._state:destroy()
    self._rootLayer:destroy()
    self._imageLayer:destroy()

    if self._button then
        self._button:destroy()
    end
end

return APL.LuaUtils.readOnly(ImageLocalNotification)
