-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local DigiBarRadialLayout = require "DigiBarRadialLayout"
local DigiBarLinearLayout = require "DigiBarLinearLayout"

local DigiBarCommonLayoutUtils = { _type = "DigiBarCommonLayoutUtils" }







function DigiBarCommonLayoutUtils.getDigiBarLayout(style)


    local trackLayoutName = APL.LuaUtils.getClassName(style)

    if trackLayoutName == "DigiBarRadialStyle" then
        return DigiBarRadialLayout
    elseif trackLayoutName == "DigiBarLinearStyle" then
        return DigiBarLinearLayout
    else

        APL.Log.error(DigiBarCommonLayoutUtils, function() return "Unknown track layout style" end)
        return nil
    end
end








function DigiBarCommonLayoutUtils.getGradientColor(colorIDs, appearanceState)




    return function(state)

        local colorID = state and colorIDs[state] or colorIDs[0]
        return appearanceState:getGradientColor(colorID)
    end
end








function DigiBarCommonLayoutUtils.getSolidColor(colorIDs, appearanceState)



    return function(state)

        local colorID = colorIDs and (state and colorIDs[state] or colorIDs[0])
        return colorID and appearanceState:getSolidColor(colorID)
    end
end







function DigiBarCommonLayoutUtils.getDigiBandBackgroundLayout(barStyle, width)


    return function(frame)


        local trackWidth = width or barStyle.trackWidth
        local trackInset = barStyle.trackInset

        local digiBarFrame = frame
            :insetBy(trackInset, trackInset, trackInset, trackInset)
            :centeredMinSquare()

        local path = APL.Path.new()
            :ellipseIn(
                APL.Rect.new(
                    trackWidth / 2,
                    trackWidth / 2,
                    digiBarFrame._width - trackWidth,
                    digiBarFrame._height - trackWidth
                )
            )

        return digiBarFrame, path, trackWidth, APL.ShapeLayer.LINECAP.SQUARE
    end
end









function DigiBarCommonLayoutUtils.getDigiBarLayoutExtended(barStyle, layout, widthExtension)






    return function(frame)

        return layout.getBarLayout(barStyle, frame, 0, widthExtension)
    end
end

return APL.LuaUtils.readOnly(DigiBarCommonLayoutUtils)
