-- Copyright © 2021-2026 Apple, Inc. All rights reserved.





local APL = require "APL.APL"
local Units = require "Units"

local UnitUtils = {}









function UnitUtils.convertSpeed(speed, fromUnit, toUnit)




    if fromUnit == toUnit then
        return speed
    end
    local metersPerHour
    if fromUnit == Units.Speed.METERS_PER_SECOND then
        metersPerHour = speed * 3600
    elseif fromUnit == Units.Speed.KILOMETERS_PER_HOUR then
        metersPerHour = speed * 1000
    elseif fromUnit == Units.Speed.MILES_PER_HOUR then
        metersPerHour  = speed * 1609.344
    elseif fromUnit == Units.Speed.METERS_PER_HOUR then
        metersPerHour  = speed
    else

    end

    if toUnit == Units.Speed.METERS_PER_SECOND then
        return metersPerHour / 3600
    elseif toUnit == Units.Speed.KILOMETERS_PER_HOUR then
        return metersPerHour / 1000
    elseif toUnit == Units.Speed.MILES_PER_HOUR then
        return metersPerHour * 0.000621371
    elseif toUnit == Units.Speed.METERS_PER_HOUR then
        return metersPerHour
    else

        return 0
    end
end







function UnitUtils.getAlternateSpeedUnit(unit)


    if unit == Units.Speed.MILES_PER_HOUR then
        return Units.Speed.KILOMETERS_PER_HOUR
    elseif unit == Units.Speed.KILOMETERS_PER_HOUR then
        return Units.Speed.MILES_PER_HOUR
    end


end









function UnitUtils.convertTemperature(temperature, fromUnit, toUnit)




    if fromUnit == toUnit then
        return temperature
    end
    local celsius
    if fromUnit == Units.Temperature.CELSIUS then
        celsius = temperature
    elseif fromUnit == Units.Temperature.FAHRENHEIT then
        celsius = (temperature - 32) * 5/9
    elseif fromUnit == Units.Temperature.KELVIN then
        celsius = temperature - 273.15
    else

        return 0
    end

    if toUnit == Units.Temperature.CELSIUS then
        return celsius
    elseif toUnit == Units.Temperature.FAHRENHEIT then
        return celsius * 9/5 + 32
    elseif toUnit == Units.Temperature.KELVIN then
        return celsius + 273.15
    else

        return 0
    end
end

function UnitUtils.convertFuelEfficiency(fuelEfficiency, fromUnit, toUnit)




    if fromUnit == toUnit then
        return fuelEfficiency
    end

    local milliletersPer100Kilometers
    if fromUnit == Units.FuelEfficiency.MILLILITERS_PER_100_KILOMETERS then
        milliletersPer100Kilometers = fuelEfficiency
    elseif fromUnit == Units.FuelEfficiency.LITERS_PER_100_KILOMETERS then
        milliletersPer100Kilometers = fuelEfficiency * 1000
    elseif fromUnit == Units.FuelEfficiency.MILES_PER_GALLON then
        milliletersPer100Kilometers = fuelEfficiency / 3785
    elseif fromUnit == Units.FuelEfficiency.MILES_PER_IMPERIAL_GALLON then
        milliletersPer100Kilometers = fuelEfficiency / 4546
    else

        return 0
    end

    if toUnit == Units.FuelEfficiency.MILLILITERS_PER_100_KILOMETERS then
        return milliletersPer100Kilometers
    elseif toUnit == Units.FuelEfficiency.LITERS_PER_100_KILOMETERS then
        return milliletersPer100Kilometers  / 1000
    elseif toUnit == Units.FuelEfficiency.MILES_PER_GALLON then
        return milliletersPer100Kilometers * 0.000264172
    elseif toUnit == Units.FuelEfficiency.MILES_PER_IMPERIAL_GALLON then
        return milliletersPer100Kilometers * 0.00219969
    else

        return 0
    end
end

return APL.LuaUtils.readOnly(UnitUtils)