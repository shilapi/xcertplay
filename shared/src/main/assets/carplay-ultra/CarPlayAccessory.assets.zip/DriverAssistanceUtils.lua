-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local Enumes = require "Enums"
local SpeedometerUtils = require "SpeedometerUtils"
local VehicleDataUpdater = require "VehicleDataUpdater"

local DriverAssistanceUtils = APL.LuaUtils.makeObject({ _type = "DriverAssistanceUtils" })




DriverAssistanceUtils.CRUISE_CONTROL_STATE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({

    "DISABLED",

    "INACTIVE",

    "ACTIVE",
}))


DriverAssistanceUtils.DRIVER_ASSISTANCE_STATE = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "INACTIVE",
    "CRUISE_CONTROL_ACTIVE",
    "SPEED_LIMITER_ACTIVE"
}))








function DriverAssistanceUtils.getState(cruiseControlState, speedLimited)



    if cruiseControlState == DriverAssistanceUtils.CRUISE_CONTROL_STATE.ACTIVE then
        return speedLimited
            and DriverAssistanceUtils.DRIVER_ASSISTANCE_STATE.SPEED_LIMITER_ACTIVE
            or DriverAssistanceUtils.DRIVER_ASSISTANCE_STATE.CRUISE_CONTROL_ACTIVE
    elseif cruiseControlState == DriverAssistanceUtils.CRUISE_CONTROL_STATE.INACTIVE then

        return speedLimited
            and DriverAssistanceUtils.DRIVER_ASSISTANCE_STATE.SPEED_LIMITER_ACTIVE
            or DriverAssistanceUtils.DRIVER_ASSISTANCE_STATE.INACTIVE
    end


    return 0
end











function DriverAssistanceUtils.progressForTargetSpeedUpdate(maxSpeeds, speedDataIdentifier, unitDataIdentifier, stateDataIdentifier)





    local maxSpeedsWithLabels = SpeedometerUtils.getMaxSpeedWithLabelsCount(maxSpeeds)

    local previousOperationalSpeeds = nil
    return function(update, previous)



        local speeds, unit, state = DriverAssistanceUtils._targetSpeedForUpdate(update, previous, previousOperationalSpeeds, speedDataIdentifier, unitDataIdentifier, stateDataIdentifier)
        previousOperationalSpeeds = speeds

        if speeds == nil or speeds == VehicleDataUpdater.INVALID or unit == nil or state == nil then
            return nil
        end

        return SpeedometerUtils._getNormalizedValue(speeds, maxSpeedsWithLabels.maxSpeeds, unit, false)
    end
end






function DriverAssistanceUtils.displaySpeedForUpdate()
    local previousOperationalSpeeds = nil

    return function(update, cache, speedDataIdentifier, unitDataIdentifier, stateDataIdentifier)






        local speeds, unit = DriverAssistanceUtils._targetSpeedForUpdate(update, cache, previousOperationalSpeeds, speedDataIdentifier, unitDataIdentifier, stateDataIdentifier)
        previousOperationalSpeeds = speeds

        if speeds == nil or speeds == VehicleDataUpdater.INVALID or unit == nil then
            return nil, unit
        end

        return speeds[unit], unit
    end
end











function DriverAssistanceUtils._targetSpeedForUpdate(update, previous, previousOperationalSpeeds, speedDataIdentifier, unitDataIdentifier, stateDataIdentifier)







    local update = APL.LuaUtils.merge(previous, update)
    local state = update[stateDataIdentifier]
    local unit = update[unitDataIdentifier]



    local speeds = previousOperationalSpeeds
    if state == DriverAssistanceUtils.DRIVER_ASSISTANCE_STATE.CRUISE_CONTROL_ACTIVE or
        state == DriverAssistanceUtils.DRIVER_ASSISTANCE_STATE.SPEED_LIMITER_ACTIVE
    then
        speeds = update[speedDataIdentifier]
    end

    return speeds, unit, state
end

return APL.LuaUtils.readOnly(DriverAssistanceUtils)
