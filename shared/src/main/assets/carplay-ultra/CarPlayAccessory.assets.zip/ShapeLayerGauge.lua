-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local APL = require "APL.APL"
local Path = require "APL.Path"

local ShapeLayerGauge = APL.LuaUtils.makeObject({ _type = "ShapeLayerGauge" })









function ShapeLayerGauge.new(configuration, appearanceController, stateController)




    APL.Log.debug(ShapeLayerGauge, function() return "Creating ShapeLayerGauge with configuration: " .. APL.LuaUtils.prettyPrint(configuration, false, 3) end)

    local rootLayer = APL.ShapeLayer.new()
    local path = ShapeLayerGauge.pathFromJson(configuration.pathElements)
    rootLayer:setPath(path)
    if configuration.lineCap then
        rootLayer:setLineCap(configuration.lineCap)
    end
    if configuration.lineWidth then
        rootLayer:setLineWidth(configuration.lineWidth)
    end

    local setFrame = function(frame)
        rootLayer:setFrame(frame)
    end

    local self = APL.LuaUtils.newObject(ShapeLayerGauge, {
        _configuration = configuration,
        _rootLayer = rootLayer,
        _setFrame = setFrame
    })

    local lastAppearance = appearanceController:getState()
    local lastState = stateController and stateController:getState() or "0"
    local setState = function()
        if configuration.fillColorIDs then
            local color = lastState and configuration.fillColorIDs[lastState]
            rootLayer:setFillColor(lastAppearance:getSolidColor(color))
        end
        if configuration.strokeColorIDs then
            local color = lastState and configuration.strokeColorIDs[lastState]
            rootLayer:setStrokeColor(lastAppearance:getSolidColor(color))
        end
    end

    appearanceController:setUpdateHandler(function(state)
        lastAppearance = state
        setState()
    end)

    if stateController then
        stateController:setUpdateHandler(function(state)
            lastState = tostring(state)
            setState()
        end)
    end

    return self
end







function ShapeLayerGauge.pathFromJson(jsonRepresentation)


    local path = Path.new()
    for _, element in ipairs(jsonRepresentation) do
        APL.Log.debug(ShapeLayerGauge, function() return "Path element: " .. APL.LuaUtils.prettyPrint(element, false, 3) end)

        if element.moveTo then
            APL.Log.debug(ShapeLayerGauge, function() return "Move to: " .. APL.LuaUtils.prettyPrint(element.moveTo, false, 3) end)
            path:moveTo(element.moveTo.x, element.moveTo.y)
        elseif element.lineTo then
            APL.Log.debug(ShapeLayerGauge, function() return "Line to: " .. APL.LuaUtils.prettyPrint(element.lineTo, false, 3) end)
            path:lineTo(element.lineTo.x, element.lineTo.y)
        elseif element.arcTo then
            APL.Log.debug(ShapeLayerGauge, function() return "Arc to: " .. APL.LuaUtils.prettyPrint(element.arcTo, false, 3) end)
            path:arcTo(
                element.arcTo.x,
                element.arcTo.y,
                element.arcTo.radius,
                element.arcTo.startAngle,
                element.arcTo.endAngle,
                element.arcTo.clockwise
            )
        elseif element.closeSubpath then
            APL.Log.debug(ShapeLayerGauge, function() return "Close subpath" end)
            path:closeSubpath()
        else
            APL.Log.error(ShapeLayerGauge, function() return "Unknown element: " .. APL.LuaUtils.prettyPrint(element, false, 3) end)

        end
    end

    return path
end






function ShapeLayerGauge:destroy()


    self._rootLayer:destroy()
end







function ShapeLayerGauge:setFrame(frame)



    self._setFrame(frame)

    return self
end






function ShapeLayerGauge:getRootLayer()


    return self._rootLayer
end






function ShapeLayerGauge:description()


    return "ShapeLayerGauge " .. self:getRootLayer()._nativeLayer.name
end

return APL.LuaUtils.readOnly(ShapeLayerGauge)

