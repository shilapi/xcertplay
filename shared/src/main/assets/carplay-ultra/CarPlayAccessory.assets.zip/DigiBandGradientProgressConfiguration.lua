-- Copyright © 2021-2026 Apple, Inc. All rights reserved.






local APL = require "APL.APL"
local DigiBarRadialStyle = require "DigiBarRadialStyle"


local DigiBandGradientProgressConfiguration = APL.LuaUtils.namedObject(
    "DigiBandGradientProgressConfiguration",
    { "colorIDs", "table" },
    { "style", "DigiBarRadialStyle" }
)

DigiBandGradientProgressConfiguration.fromJson = function(json)


    local colorIDs = APL.LuaUtils.numberedKeys(json.colorIDs)


    return DigiBandGradientProgressConfiguration.new(colorIDs, DigiBarRadialStyle.fromJson(json.style))
end

return APL.LuaUtils.readOnly(DigiBandGradientProgressConfiguration)