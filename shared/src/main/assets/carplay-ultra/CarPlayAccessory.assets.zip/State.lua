-- Copyright © 2021-2026 Apple, Inc. All rights reserved.

local APL = require "APL.APL"

local State = APL.LuaUtils.makeObject({ _type = "State" })

local KEYS = APL.LuaUtils.readOnly(APL.LuaUtils.makeEnum({
    "ACTIVE_LAYOUT_ID",
    "PALETTE_SELECTIONS",
    "SKIP_PAIRING_ANIMATION",
    "ACTIVE_DCA_COMPONENTS",
    "REMOTE_IDENTIFIER",
    "APPEARANCE_PREFERENCE"
}, false))

local KEYS_TYPES = APL.LuaUtils.getValues(KEYS)

local _persistence






function State.getActiveLayoutID()
    return State._getValue(KEYS.ACTIVE_LAYOUT_ID)
end






function State.setActiveLayoutID(activeLayoutID)


    State._setValue(KEYS.ACTIVE_LAYOUT_ID, activeLayoutID)
end






function State.getPaletteSelections()
    return State._getValue(KEYS.PALETTE_SELECTIONS)
end






function State.setPaletteSelections(paletteSelections)


    State._setValue(KEYS.PALETTE_SELECTIONS, paletteSelections)
end






function State.canShowPairingAnimation()
    local value = State._getValue(KEYS.SKIP_PAIRING_ANIMATION)
    return value == nil and true or not value
end




function State.skipPairingAnimation()
    State._setValue(KEYS.SKIP_PAIRING_ANIMATION, true)
end






function State.getActiveDCAComponentIDs()
    return State._getValue(KEYS.ACTIVE_DCA_COMPONENTS)
end






function State.setActiveDCAComponentIDs(componentIDs)


    State._setValue(KEYS.ACTIVE_DCA_COMPONENTS, componentIDs)
end






function State.getRemoteIdentifier()
    return State._getValue(KEYS.REMOTE_IDENTIFIER)
end






function State.setRemoteIdentifier(remoteIdentifier)


    State._setValue(KEYS.REMOTE_IDENTIFIER, remoteIdentifier)
end






function State.setAppearancePreference(appearanceModePreference)


    State._setValue(KEYS.APPEARANCE_PREFERENCE, appearanceModePreference)
end






function State.getAppearancePreference()
    return State._getValue(KEYS.APPEARANCE_PREFERENCE)
end












function State._getValue(key)


    if not _persistence then
        _persistence = APL.Persistence.new("state")
    end

    return _persistence.data[key]
end







function State._setValue(key, value)



    if not _persistence then
        _persistence = APL.Persistence.new("state")
    end

    APL.Log.info(State, function() return "Setting value for key: " .. tostring(key) .. " -> " .. APL.LuaUtils.prettyPrint(value) end)
    _persistence.data[key] = value
end

return APL.LuaUtils.readOnly(State)
